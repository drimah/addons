# Ultra Remesh - ponte ctypes para o motor QRemesh (bin/<sistema>/)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Sem bpy aqui: só ctypes e NumPy, para dar para testar fora do Blender.
import ctypes
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_lib = None


class DrqOptions(ctypes.Structure):
    # Igual a DrqOptions em engine/capi.cpp
    _fields_ = [
        ("method", ctypes.c_int32),
        ("targetQuads", ctypes.c_int32),
        ("adaptive", ctypes.c_float),
        ("keepGroups", ctypes.c_int32),
        ("detectEdges", ctypes.c_int32),
        ("useVertexPaint", ctypes.c_int32),
        ("symmetryAxis", ctypes.c_int32),
        ("symmetryAuto", ctypes.c_int32),
        ("symmetryCenter", ctypes.c_float),
        ("smoothIterations", ctypes.c_int32),
        ("seed", ctypes.c_int32),
        ("measureQuality", ctypes.c_int32),
    ]


PROGRESS = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_float, ctypes.c_void_p)


def library_path():
    if sys.platform.startswith("win"):
        return os.path.join(_HERE, "bin", "windows-x64", "ultra_remesh.dll")
    if sys.platform.startswith("linux"):
        return os.path.join(_HERE, "bin", "linux-x64", "libultra_remesh.so")
    return None


def load():
    """Carrega a biblioteca do sistema atual (uma vez). Erro com mensagem clara se não houver."""
    global _lib
    if _lib is not None:
        return _lib
    path = library_path()
    if path is None:
        raise RuntimeError("Sistema não suportado: %s (só Windows e Linux x64)" % sys.platform)
    if not os.path.isfile(path):
        raise RuntimeError("Biblioteca do motor não encontrada: %s" % path)
    lib = ctypes.CDLL(path)
    p, i32, u32p, f32p = ctypes.c_void_p, ctypes.c_int32, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_float)
    lib.drq_version.restype = ctypes.c_int
    lib.drq_remesh.restype = p
    lib.drq_remesh.argtypes = [f32p, i32, u32p, i32, u32p, f32p, ctypes.POINTER(DrqOptions), PROGRESS, p,
                               ctypes.c_char_p, i32]
    lib.drq_result_counts.argtypes = [p] + [ctypes.POINTER(i32)] * 4
    lib.drq_result_get.argtypes = [p, f32p, ctypes.POINTER(i32), u32p, u32p]
    lib.drq_result_stats.argtypes = [p, ctypes.POINTER(ctypes.c_double)]
    lib.drq_free.argtypes = [p]
    _lib = lib
    return lib


def _ptr(a, ctype):
    return a.ctypes.data_as(ctypes.POINTER(ctype))


STAT_NAMES = ("quads", "triangles", "seconds", "symmetry_used", "symmetry_center", "singularities",
              "fallback_pieces", "pieces", "poles", "valence3", "valence5", "angle_deviation",
              "hausdorff_pct", "mean_distance_pct", "non_manifold_edges", "boundary_edges")


def remesh(positions, triangles, options, groups=None, colors=None, progress=None):
    """positions: (N,3) float; triangles: (M,3) int; groups: (M,) int ou None; colors: (N,3) float linear ou None.
    options: dict com as chaves de DrqOptions. progress(fração) -> False cancela.
    Devolve dict: positions (V,3), face_sizes (F,), loops (L,), groups (F,) ou None, stats (dict)."""
    lib = load()
    pos = np.ascontiguousarray(positions, dtype=np.float32).reshape(-1, 3)
    tri = np.ascontiguousarray(triangles, dtype=np.uint32).reshape(-1, 3)
    grp = None if groups is None else np.ascontiguousarray(groups, dtype=np.uint32).reshape(-1)
    col = None if colors is None else np.ascontiguousarray(colors, dtype=np.float32).reshape(-1, 3)

    opt = DrqOptions()
    for name, _ in DrqOptions._fields_:
        if name in options:
            setattr(opt, name, options[name])

    def _cb(fraction, _user):
        if progress is None:
            return 1
        try:
            return 1 if progress(float(fraction)) is not False else 0
        except Exception:
            return 0

    cb = PROGRESS(_cb)  # (mantido vivo durante a chamada)
    err = ctypes.create_string_buffer(512)
    h = lib.drq_remesh(_ptr(pos, ctypes.c_float), len(pos), _ptr(tri, ctypes.c_uint32), len(tri),
                       None if grp is None else _ptr(grp, ctypes.c_uint32),
                       None if col is None else _ptr(col, ctypes.c_float),
                       ctypes.byref(opt), cb, None, err, len(err))
    if not h:
        raise RuntimeError(err.value.decode("utf-8", "replace") or "falha no remesh")
    try:
        nv, nf, nl, hg = (ctypes.c_int32() for _ in range(4))
        lib.drq_result_counts(h, ctypes.byref(nv), ctypes.byref(nf), ctypes.byref(nl), ctypes.byref(hg))
        out_pos = np.empty((nv.value, 3), dtype=np.float32)
        out_sizes = np.empty(nf.value, dtype=np.int32)
        out_loops = np.empty(nl.value, dtype=np.uint32)
        out_groups = np.empty(nf.value, dtype=np.uint32) if hg.value else None
        lib.drq_result_get(h, _ptr(out_pos, ctypes.c_float), _ptr(out_sizes, ctypes.c_int32),
                           _ptr(out_loops, ctypes.c_uint32),
                           None if out_groups is None else _ptr(out_groups, ctypes.c_uint32))
        st = (ctypes.c_double * 16)()
        lib.drq_result_stats(h, st)
        stats = dict(zip(STAT_NAMES, list(st)))
    finally:
        lib.drq_free(h)
    return {"positions": out_pos, "face_sizes": out_sizes, "loops": out_loops, "groups": out_groups, "stats": stats}
