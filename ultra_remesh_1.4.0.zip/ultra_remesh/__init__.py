# Ultra Remesh - automatic quad retopology for Blender (Windows + Linux, one package)
# Engine: SculptForge's QRemesh (src/core/QRemesh*), built as a native library in bin/<system>/ and called
# through ctypes (engine.py). Controls: the viewport card of Remesh Ultimate (overlay.py), with orange buttons.
# License: GPL-3.0-or-later

bl_info = {
    "name": "Ultra Remesh",
    "author": "Drimah",
    "version": (1, 4, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Ultra Remesh",
    "description": "Automatic quad retopology with SculptForge's QRemesh engine",
    "category": "Mesh",
}

import math
import os
import shutil
import threading

import bmesh
import bpy
import numpy as np
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup

from . import engine

ADDON_ID = __package__ or __name__
VERSION_STR = ".".join(str(v) for v in bl_info["version"])
RESULT_SUFFIX = "_UR"
WAIT_TEXT = "Aguarde... Processando..."

# Shared with the card (overlay.py): True while a remesh runs.
_running = {"on": False}


# --------------------------------------------------------------------------
#  Settings (per scene)
# --------------------------------------------------------------------------
# Quad edge length as a fraction of the object's bounding-box diagonal.
SIZE_PRESETS = {"XS": 0.008, "S": 0.012, "M": 0.018, "L": 0.026, "XL": 0.04}
_quiet = {"on": False}  # True while code (not the user) changes target_faces


def _target_for_size(context, obj, code, use_modifiers=True):
    """Target quads so that quads of preset `code` cover `obj` (world space)."""
    k = SIZE_PRESETS.get(code)
    if k is None or obj is None or obj.type != "MESH":
        return None
    try:
        src = obj.evaluated_get(context.evaluated_depsgraph_get()) if use_modifiers else obj
        me = src.to_mesh()
        try:
            n = len(me.vertices)
            if n == 0:
                return None
            co = np.empty(n * 3, dtype=np.float64)
            me.vertices.foreach_get("co", co)
            co = co.reshape(-1, 3)
            m = np.array(obj.matrix_world, dtype=np.float64)
            co = co @ m[:3, :3].T + m[:3, 3]
            me.calc_loop_triangles()
            t = np.empty(len(me.loop_triangles) * 3, dtype=np.int32)
            me.loop_triangles.foreach_get("vertices", t)
            t = t.reshape(-1, 3)
        finally:
            src.to_mesh_clear()
        area = 0.5 * np.linalg.norm(np.cross(co[t[:, 1]] - co[t[:, 0]], co[t[:, 2]] - co[t[:, 0]]), axis=1).sum()
        diag = float(np.linalg.norm(co.max(0) - co.min(0)))
        if area <= 0.0 or diag <= 0.0:
            return None
        edge = diag * k
        return int(max(16, min(2000000, round(area / (edge * edge)))))
    except Exception as e:
        print("[Ultra Remesh] size preset:", e)
        return None


# Viewport looks: (matcap, background sRGB-ish linear value, cavity ridge, cavity valley)
VIEW_STYLES = {
    "CLAY": ("red_wax.exr", 0.012, 0.8, 1.2),
    "GREY": ("ceramic_lightbulb.exr", 0.012, 0.5, 0.9),
    "WHITE": ("pearl.exr", 0.012, 0.5, 0.9),
}
_SHADING_KEYS = ("type", "light", "studio_light", "show_cavity", "cavity_type", "cavity_ridge_factor",
                 "cavity_valley_factor", "background_type", "background_color", "color_type")
_saved_shading = {}  # area pointer -> settings before a look was applied
_DEFAULT_SHADING = {"light": "STUDIO", "studio_light": "Default", "show_cavity": False,
                    "background_type": "THEME", "color_type": "MATERIAL"}


def _view_areas(context):
    try:
        for win in context.window_manager.windows:
            for a in win.screen.areas:
                if a.type == "VIEW_3D":
                    yield a
    except Exception:
        return


def _view_style_changed(self, context):
    code = self.view_style
    for a in _view_areas(context):
        sh = a.spaces[0].shading
        key = a.as_pointer()
        if code == "OFF":
            old = _saved_shading.pop(key, None)
            if not old and sh.light == "MATCAP" and sh.studio_light in {v[0] for v in VIEW_STYLES.values()}:
                # Nothing saved (Blender or the add-on was restarted): back to Blender's defaults.
                old = dict(_DEFAULT_SHADING)
            if old:
                for k, v in old.items():
                    try:
                        setattr(sh, k, v)
                    except Exception:
                        pass
            continue
        if key not in _saved_shading:
            if sh.light == "MATCAP" and sh.studio_light in {v[0] for v in VIEW_STYLES.values()}:
                # One of our looks is already on (Blender was restarted): remember the defaults instead.
                _saved_shading[key] = dict(_DEFAULT_SHADING)
            else:
                _saved_shading[key] = {k: (tuple(getattr(sh, k)) if k == "background_color" else getattr(sh, k))
                                       for k in _SHADING_KEYS}
        matcap, bg, ridge, valley = VIEW_STYLES[code]
        try:
            sh.type = "SOLID"
            sh.light = "MATCAP"
            sh.studio_light = matcap
            sh.color_type = "MATERIAL"
            sh.show_cavity = True
            sh.cavity_type = "WORLD"
            sh.cavity_ridge_factor = ridge
            sh.cavity_valley_factor = valley
            sh.background_type = "VIEWPORT"
            sh.background_color = (bg, bg, bg)
        except Exception as e:
            print("[Ultra Remesh] view style:", e)
        a.tag_redraw()


def _set_target(s, value):
    _quiet["on"] = True
    try:
        s.target_faces = value
    finally:
        _quiet["on"] = False


def _size_changed(self, context):
    if self.size_preset == "CUSTOM":
        return
    n = _target_for_size(context, context.active_object, self.size_preset, self.use_modifiers)
    if n is not None:
        _set_target(self, n)


def _target_changed(self, context):
    # The user typed / dragged a count: that is a custom size now.
    if not _quiet["on"] and self.size_preset != "CUSTOM":
        self["size_preset"] = 0  # CUSTOM, without firing _size_changed


class UR_Settings(PropertyGroup):
    view_style: EnumProperty(name="View", default="OFF", update=_view_style_changed, items=[
        ("OFF", "Off", "Blender's own viewport look"),
        ("CLAY", "Clay", "Red-brown sculpting clay, like ZBrush"),
        ("GREY", "Grey", "Shiny grey"),
        ("WHITE", "White", "Glossy white plastic"),
    ], description="How the 3D View shows the models (viewport only - materials and renders are not changed)")
    size_preset: EnumProperty(name="Quad Size", default="M", update=_size_changed, items=[
        ("CUSTOM", "Custom", "Use the Target Quads count as typed"),
        ("XS", "XS", "Very small quads - lots of detail"),
        ("S", "S", "Small quads"),
        ("M", "M", "Medium quads"),
        ("L", "L", "Large quads"),
        ("XL", "XL", "Very large quads - light mesh"),
    ], description="Size of the quads, measured on the model itself (the count follows the model)")
    target_faces: IntProperty(name="Target Quads", default=5000, min=16, max=2000000, soft_min=100,
                              soft_max=50000, update=_target_changed,
                              description="Approximate number of quads in the result")
    weld: BoolProperty(name="Weld Split Vertices", default=True,
                       description="Join vertices that sit on the same spot (OBJ/FBX imports often come split "
                                   "into hundreds of loose pieces). The original is not changed")
    method: EnumProperty(name="Method", default="V2", items=[
        ("V2", "QRemesh 2", "Curvature-aligned cross field and integer-grid map: poles only where the form needs them"),
        ("LEGACY", "Legacy", "The older field-aligned method (Instant Meshes style)"),
    ])
    adaptive: FloatProperty(name="Size Variation", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
                            description="0 = every quad the same size; 1 = small quads on curves, big ones on flat areas")
    smooth: IntProperty(name="Smooth", default=15, min=0, max=30, description="Relax passes on the surface")
    detect_edges: BoolProperty(name="Keep Hard Edges", default=False,
                               description="Faces meeting at a strong angle get an edge loop. For hard-surface "
                                           "models (machines, props); leave off for characters - on eyes and "
                                           "lashes it dents the face")
    keep_groups: BoolProperty(name="Follow Materials", default=False,
                              description="Edge loops follow the borders between materials; the result keeps them")
    use_vertex_paint: BoolProperty(name="Density from Paint", default=False,
                                   description="Active color attribute: red = up to 4x the quads, blue = down to 1/4")
    symmetry: EnumProperty(name="Symmetry", default="NONE", items=[
        ("NONE", "Off", ""), ("X", "X", ""), ("Y", "Y", ""), ("Z", "Z", "")])
    symmetry_auto: BoolProperty(name="Auto Plane", default=True,
                                description="Find the mirror plane from the model itself (object space)")
    symmetry_center: FloatProperty(name="Mirror Center", default=0.0,
                                   description="Mirror plane position on the axis (object space), when Auto Plane is off")
    seed: IntProperty(name="Seed", default=1, min=0, max=9999, description="Legacy method only")
    use_modifiers: BoolProperty(name="Apply Modifiers", default=True,
                                description="Remesh the object with its modifiers (the original is not changed)")
    hide_original: BoolProperty(name="Hide Original", default=True,
                                description="Hide the original once the result is made")
    measure_quality: BoolProperty(name="Quality Report", default=True,
                                  description="Report poles, corner angles and the distance to the original")


# --------------------------------------------------------------------------
#  Blender mesh <-> arrays
# --------------------------------------------------------------------------
def _read_mesh(obj, depsgraph, use_modifiers, want_colors):
    src = obj.evaluated_get(depsgraph) if use_modifiers else obj
    me = src.to_mesh()
    try:
        me.calc_loop_triangles()
        nv, nt = len(me.vertices), len(me.loop_triangles)
        pos = np.empty(nv * 3, dtype=np.float32)
        me.vertices.foreach_get("co", pos)
        tri = np.empty(nt * 3, dtype=np.int32)
        me.loop_triangles.foreach_get("vertices", tri)
        mat = np.empty(nt, dtype=np.int32)
        me.loop_triangles.foreach_get("material_index", mat)
        colors = None
        if want_colors:
            attr = me.color_attributes.active_color
            if attr is not None and len(attr.data):
                c = np.empty(len(attr.data) * 4, dtype=np.float32)
                attr.data.foreach_get("color", c)
                c = c.reshape(-1, 4)[:, :3]
                if attr.domain == "POINT":
                    colors = c
                elif attr.domain == "CORNER":
                    vi = np.empty(len(me.loops), dtype=np.int32)
                    me.loops.foreach_get("vertex_index", vi)
                    acc = np.zeros((nv, 3), dtype=np.float64)
                    cnt = np.zeros(nv, dtype=np.float64)
                    np.add.at(acc, vi, c)
                    np.add.at(cnt, vi, 1.0)
                    colors = (acc / np.maximum(cnt, 1.0)[:, None]).astype(np.float32)
        return pos.reshape(-1, 3), tri.reshape(-1, 3), mat, colors
    finally:
        src.to_mesh_clear()


def _weld(pos, tri, mat, colors, rel=1e-6):
    """Merge vertices closer than rel * bbox diagonal and drop the triangles that collapse."""
    if len(pos) == 0:
        return pos, tri, mat, colors
    diag = float(np.linalg.norm(pos.max(0) - pos.min(0))) or 1.0
    q = np.round(pos.astype(np.float64) / (diag * rel)).astype(np.int64)
    _u, first, inv = np.unique(q, axis=0, return_index=True, return_inverse=True)
    inv = inv.reshape(-1)
    t = inv[tri]
    ok = (t[:, 0] != t[:, 1]) & (t[:, 1] != t[:, 2]) & (t[:, 0] != t[:, 2])
    return (pos[first], t[ok].astype(np.int32), mat[ok] if mat is not None else None,
            colors[first] if colors is not None else None)


def _build_mesh(name, result):
    me = bpy.data.meshes.new(name)
    pos, sizes, loops = result["positions"], result["face_sizes"], result["loops"]
    me.vertices.add(len(pos))
    me.vertices.foreach_set("co", pos.reshape(-1).astype(np.float32))
    me.loops.add(len(loops))
    me.loops.foreach_set("vertex_index", loops.astype(np.int32))
    me.polygons.add(len(sizes))
    starts = np.zeros(len(sizes), dtype=np.int32)
    if len(sizes) > 1:
        starts[1:] = np.cumsum(sizes[:-1])
    me.polygons.foreach_set("loop_start", starts)
    if result["groups"] is not None:
        me.polygons.foreach_set("material_index", result["groups"].astype(np.int32))
    me.update(calc_edges=True)
    me.validate(clean_customdata=False)
    return me


def _redraw_views():
    try:
        for win in bpy.context.window_manager.windows:
            for a in win.screen.areas:
                if a.type == "VIEW_3D":
                    a.tag_redraw()
    except Exception:
        pass


# --------------------------------------------------------------------------
#  Remesh (the engine runs on a thread; the screen only says "Aguarde... Processando...")
# --------------------------------------------------------------------------
class UR_OT_remesh(Operator):
    bl_idname = "ultra_remesh.remesh"
    bl_label = "Remesh"
    bl_description = "Make a quad-remeshed copy of the active object (the original is not changed)"
    bl_options = {"REGISTER", "UNDO"}

    _timer = None
    _thread = None

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == "MESH" and context.mode == "OBJECT"
                and not _running["on"])

    def _options(self, s):
        return {
            "method": 1 if s.method == "LEGACY" else 0,
            "targetQuads": int(s.target_faces),
            "adaptive": float(s.adaptive),
            "keepGroups": int(s.keep_groups),
            "detectEdges": int(s.detect_edges),
            "useVertexPaint": int(s.use_vertex_paint),
            "symmetryAxis": {"NONE": -1, "X": 0, "Y": 1, "Z": 2}[s.symmetry],
            "symmetryAuto": int(s.symmetry_auto),
            "symmetryCenter": float(s.symmetry_center),
            "smoothIterations": int(s.smooth),
            "seed": int(s.seed),
            "measureQuality": int(s.measure_quality),
        }

    def execute(self, context):
        # Direct call (scripts, background): run and return.
        if not self._prepare(context):
            return {"CANCELLED"}
        self._work()
        return self._finish(context)

    def invoke(self, context, event):
        if not self._prepare(context):
            return {"CANCELLED"}
        _running["on"] = True
        self._thread = threading.Thread(target=self._work, daemon=True)
        self._thread.start()
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.2, window=context.window)
        wm.modal_handler_add(self)
        context.workspace.status_text_set(WAIT_TEXT + "  (Esc)")
        context.window.cursor_modal_set("WAIT")
        _redraw_views()
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC":
            self._cancel = True
        if event.type == "TIMER" and self._thread is not None and not self._thread.is_alive():
            self._cleanup_ui(context)
            return self._finish(context)
        return {"RUNNING_MODAL"}  # the scene is locked while it works

    def _cleanup_ui(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.workspace.status_text_set(None)
        context.window.cursor_modal_restore()

    def _prepare(self, context):
        try:
            engine.load()
        except Exception as e:
            self.report({"ERROR"}, "Ultra Remesh: %s" % e)
            return False
        obj = context.active_object
        s = context.scene.ultra_remesh
        if s.size_preset != "CUSTOM":
            n = _target_for_size(context, obj, s.size_preset, s.use_modifiers)
            if n is not None:
                _set_target(s, n)
        self._obj_name = obj.name
        self._opts = self._options(s)
        self._hide = s.hide_original
        self._cancel = False
        self._result = None
        self._error = None
        try:
            pos, tri, mat, col = _read_mesh(obj, context.evaluated_depsgraph_get(), s.use_modifiers,
                                            s.use_vertex_paint)
        except Exception as e:
            self.report({"ERROR"}, "Ultra Remesh: could not read the mesh (%s)" % e)
            return False
        if s.weld:
            pos, tri, mat, col = _weld(pos, tri, mat, col)
        if len(tri) == 0:
            self.report({"ERROR"}, "Ultra Remesh: the object has no faces")
            return False
        if s.use_vertex_paint and col is None:
            self.report({"WARNING"}, "Ultra Remesh: no active color attribute - Density from Paint ignored")
        self._data = (pos, tri, mat if s.keep_groups else None, col)
        return True

    def _work(self):
        pos, tri, grp, col = self._data
        try:
            self._result = engine.remesh(pos, tri, self._opts, groups=grp, colors=col,
                                         progress=lambda f: not self._cancel)
        except Exception as e:
            self._error = str(e)

    def _finish(self, context):
        _running["on"] = False
        _redraw_views()
        if self._cancel:
            self.report({"INFO"}, "Ultra Remesh: cancelled")
            return {"CANCELLED"}
        if self._error or self._result is None:
            self.report({"ERROR"}, "Ultra Remesh: %s" % (self._error or "no result"))
            return {"CANCELLED"}
        src = bpy.data.objects.get(self._obj_name)
        if src is None:
            self.report({"ERROR"}, "Ultra Remesh: the original object is gone")
            return {"CANCELLED"}
        name = src.name + RESULT_SUFFIX
        me = _build_mesh(name, self._result)
        for m in src.data.materials:
            me.materials.append(m)
        new = bpy.data.objects.new(name, me)
        new.matrix_world = src.matrix_world.copy()
        coll = src.users_collection[0] if src.users_collection else context.scene.collection
        coll.objects.link(new)
        for o in context.selected_objects:
            o.select_set(False)
        new.select_set(True)
        context.view_layer.objects.active = new
        if self._hide:
            src.hide_set(True)

        st = self._result["stats"]
        faces = int(st["quads"] + st["triangles"])
        parts = ["%d faces" % faces,
                 "%.0f%% quads" % (100.0 * st["quads"] / max(1, faces))]
        if self._opts["measureQuality"]:
            parts += ["%d poles" % st["poles"], "corners %.1f° off" % st["angle_deviation"],
                      "dev %.3f%%" % st["mean_distance_pct"]]
        parts.append("%.1fs" % st["seconds"])
        if self._opts["symmetryAxis"] >= 0 and not st["symmetry_used"]:
            parts.append("symmetry off: model not symmetric")
        new["ur_source"] = src.name
        new["ur_report"] = " | ".join(parts)
        self.report({"INFO"}, "Ultra Remesh: " + new["ur_report"])
        return {"FINISHED"}


def _pair(context):
    """(original, result) for the active object, whichever of the two it is."""
    ob = context.active_object
    if ob is None:
        return None, None
    src_name = ob.get("ur_source")
    if src_name:
        return bpy.data.objects.get(src_name), ob
    res = bpy.data.objects.get(ob.name + RESULT_SUFFIX)
    if res is not None and res.get("ur_source") == ob.name:
        return ob, res
    return None, None


class UR_OT_compare(Operator):
    bl_idname = "ultra_remesh.compare"
    bl_label = "Compare"
    bl_description = "Switch between the original and the remeshed result"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        src, res = _pair(context)
        return src is not None and res is not None

    def execute(self, context):
        src, res = _pair(context)
        show_src = not src.visible_get()
        src.hide_set(not show_src)
        res.hide_set(show_src)
        target = src if show_src else res
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {"FINISHED"}


class UR_OT_revert(Operator):
    bl_idname = "ultra_remesh.revert"
    bl_label = "Revert"
    bl_description = "Delete the remeshed result and show the original again"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        src, res = _pair(context)
        return src is not None and res is not None

    def execute(self, context):
        src, res = _pair(context)
        me = res.data
        bpy.data.objects.remove(res)
        if me.users == 0:
            bpy.data.meshes.remove(me)
        src.hide_set(False)
        src.select_set(True)
        context.view_layer.objects.active = src
        return {"FINISHED"}


def _repair_bmesh(bm, diag):
    """Weld split vertices, remove fin faces, fill holes, fix normals. Returns a stats dict."""
    def count():
        b = sum(1 for e in bm.edges if e.is_boundary)
        n = sum(1 for e in bm.edges if not e.is_manifold and not e.is_boundary and not e.is_wire)
        return b, n
    v0 = len(bm.verts)
    b0 = None
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=diag * 1e-6)
    welded = v0 - len(bm.verts)
    b0, n0 = count()
    # Fins: faces that touch an open edge and an edge shared by 3+ faces (stray overlapping triangles)
    removed = 0
    for _ in range(4):
        fins = [f for f in bm.faces
                if any(e.is_boundary for e in f.edges)
                and any(not e.is_manifold and not e.is_boundary for e in f.edges)]
        if not fins:
            break
        removed += len(fins)
        bmesh.ops.delete(bm, geom=fins, context="FACES")
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context="VERTS")
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=diag * 1e-7)
    f_before = len(bm.faces)
    be = [e for e in bm.edges if e.is_boundary]
    if be:
        bmesh.ops.holes_fill(bm, edges=be, sides=0)
    filled = len(bm.faces) - f_before
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    b1, n1 = count()
    return {"welded": welded, "holes_edges": b0, "bad_edges": n0, "removed": removed,
            "filled": filled, "open_left": b1, "bad_left": n1}


def _clear_custom_normals(me):
    try:
        if me.has_custom_normals:
            for name in ("custom_normal",):
                a = me.attributes.get(name)
                if a is not None:
                    me.attributes.remove(a)
            if me.has_custom_normals and hasattr(me, "free_normals_split"):
                me.free_normals_split()
    except Exception as e:
        print("[Ultra Remesh] custom normals:", e)


class UR_OT_repair(Operator):
    bl_idname = "ultra_remesh.repair"
    bl_label = "Repair"
    bl_description = ("Fix the active mesh itself: weld split vertices, remove stray overlapping faces, "
                      "fill holes and recalculate normals (Ctrl+Z undoes it)")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == "MESH" and context.mode == "OBJECT"
                and not _running["on"])

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        if me.users > 1:
            self.report({"WARNING"}, "Ultra Remesh: mesh is shared by other objects - they change too")
        bm = bmesh.new()
        bm.from_mesh(me)
        try:
            if not bm.verts:
                self.report({"ERROR"}, "Ultra Remesh: the object is empty")
                return {"CANCELLED"}
            co = np.array([v.co[:] for v in bm.verts])
            diag = float(np.linalg.norm(co.max(0) - co.min(0))) or 1.0
            st = _repair_bmesh(bm, diag)
            bm.to_mesh(me)
        finally:
            bm.free()
        # Imported normals (OBJ/FBX) no longer match the welded mesh and make it look dented:
        # drop them so Blender shades from the real surface.
        _clear_custom_normals(me)
        me.update()
        parts = ["%d vertices welded" % st["welded"]]
        if st["removed"]:
            parts.append("%d stray faces removed" % st["removed"])
        if st["filled"]:
            parts.append("%d holes filled" % st["filled"])
        if st["open_left"] or st["bad_left"]:
            parts.append("still open: %d edges, %d bad" % (st["open_left"], st["bad_left"]))
        else:
            parts.append("closed, no holes")
        self.report({"INFO"}, "Ultra Remesh: " + ", ".join(parts))
        return {"FINISHED"}


class UR_OT_scale_target(Operator):
    bl_idname = "ultra_remesh.scale_target"
    bl_label = "Scale Target"
    bl_description = "Halve or double the target quad count"
    bl_options = {"INTERNAL"}

    factor: FloatProperty(default=2.0)

    def execute(self, context):
        s = context.scene.ultra_remesh
        s.size_preset = "CUSTOM"
        s.target_faces = max(16, min(2000000, int(round(s.target_faces * self.factor))))
        return {"FINISHED"}


def _face_count(context, obj, use_modifiers):
    """Faces of `obj` as it will be remeshed (with its modifiers when they are applied)."""
    if use_modifiers:
        ev = obj.evaluated_get(context.evaluated_depsgraph_get())
        me = ev.to_mesh()
        try:
            return len(me.polygons)
        finally:
            ev.to_mesh_clear()
    return len(obj.data.polygons)


class UR_OT_same_target(Operator):
    bl_idname = "ultra_remesh.same_target"
    bl_label = "Same"
    bl_description = "Target quads = the face count of the active object (same density)"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        s = context.scene.ultra_remesh
        n = _face_count(context, context.active_object, s.use_modifiers)
        s.size_preset = "CUSTOM"
        s.target_faces = max(16, min(2000000, int(n)))
        self.report({"INFO"}, "Ultra Remesh: target = %d quads" % s.target_faces)
        return {"FINISHED"}


class UR_OT_uninstall(Operator):
    bl_idname = "ultra_remesh.uninstall"
    bl_label = "Uninstall Ultra Remesh"
    bl_description = "Disable and completely remove Ultra Remesh from Blender"

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_confirm(
                self, event, title="Uninstall Ultra Remesh?",
                message="The add-on will be disabled and its files deleted.",
                confirm_text="Uninstall", icon='WARNING')
        except TypeError:
            return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        mod = ADDON_ID
        path = os.path.dirname(os.path.abspath(__file__))

        def _do():
            try:
                bpy.ops.preferences.addon_disable(module=mod)
            except Exception as ex:
                print("[Ultra Remesh] disable:", ex)
            if mod.startswith("bl_ext."):
                try:
                    _b, repo_mod, pkg = mod.split(".", 2)
                    for i, r in enumerate(bpy.context.preferences.extensions.repos):
                        if r.module == repo_mod:
                            bpy.ops.extensions.package_uninstall(repo_index=i, pkg_id=pkg)
                            break
                except Exception as ex:
                    print("[Ultra Remesh] extension uninstall:", ex)
            else:
                try:
                    bpy.ops.preferences.addon_remove(module=mod)
                except Exception as ex:
                    print("[Ultra Remesh] addon_remove:", ex)
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            try:
                if not bpy.context.preferences.use_preferences_save:
                    bpy.ops.wm.save_userpref()
            except Exception:
                pass
            return None

        bpy.app.timers.register(_do, first_interval=0.2)
        self.report({'INFO'}, "Ultra Remesh uninstalled")
        return {'FINISHED'}


# --------------------------------------------------------------------------
#  UI: the viewport card (overlay.py) by default; the classic panel when the
#  card is switched off in Preferences.
# --------------------------------------------------------------------------
def _use_card(context):
    try:
        return bool(context.preferences.addons[ADDON_ID].preferences.use_card)
    except Exception:
        return True


class UR_PT_main(Panel):
    bl_label = "Ultra Remesh " + VERSION_STR
    bl_idname = "UR_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ultra Remesh"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        if _use_card(context):
            return
        s = context.scene.ultra_remesh
        lay = self.layout
        lay.label(text="Ultra Remesh " + VERSION_STR, icon='MOD_REMESH')
        r = lay.row()
        r.scale_y = 2.0
        if _running["on"]:
            r.label(text=WAIT_TEXT)
        else:
            r.operator(UR_OT_remesh.bl_idname, text="REMESH", icon='MOD_REMESH')
        row = lay.row(align=True)
        row.operator(UR_OT_repair.bl_idname, icon='TOOL_SETTINGS')
        row.operator(UR_OT_compare.bl_idname, icon='HIDE_OFF')
        row.operator(UR_OT_revert.bl_idname, icon='LOOP_BACK')
        ob = context.active_object
        if ob is not None and "ur_report" in ob:
            b = lay.box()
            for part in str(ob["ur_report"]).split(" | "):
                b.label(text=part)
        box = lay.box()
        box.label(text="View")
        row = box.row(align=True)
        for code in ("CLAY", "GREY", "WHITE"):
            row.prop_enum(s, "view_style", code)
        if s.view_style != "OFF":
            row.prop_enum(s, "view_style", "OFF", text="", icon='X')
        box = lay.box()
        box.label(text="Quad Size")
        box.row(align=True).prop(s, "size_preset", expand=True)
        row = box.row(align=True)
        row.prop(s, "target_faces")
        row = box.row(align=True)
        op = row.operator(UR_OT_scale_target.bl_idname, text="Half")
        op.factor = 0.5
        row.operator(UR_OT_same_target.bl_idname, text="Same")
        op = row.operator(UR_OT_scale_target.bl_idname, text="Double")
        op.factor = 2.0
        box.prop(s, "adaptive", slider=True)
        box.prop(s, "smooth")
        box.label(text="Method")
        box.row(align=True).prop(s, "method", expand=True)
        box.label(text="Symmetry")
        box.row(align=True).prop(s, "symmetry", expand=True)
        if s.symmetry != "NONE":
            box.prop(s, "symmetry_auto")
            if not s.symmetry_auto:
                box.prop(s, "symmetry_center")
        box = lay.box()
        box.prop(s, "detect_edges")
        box.prop(s, "keep_groups")
        box.prop(s, "use_vertex_paint")
        box = lay.box()
        box.prop(s, "weld")
        box.prop(s, "use_modifiers")
        box.prop(s, "hide_original")
        box.prop(s, "measure_quality")
        if s.method == "LEGACY":
            box.prop(s, "seed")


def _card_toggled(self, context):
    try:
        from . import overlay
        overlay.redraw_all()
    except Exception:
        pass


class UR_Preferences(AddonPreferences):
    bl_idname = ADDON_ID

    use_card: BoolProperty(
        name="Viewport Card", default=True, update=_card_toggled,
        description="Draw the controls as a card over the 3D View (capsule buttons, tips). "
                    "Off = classic sidebar panel")

    def draw(self, context):
        lay = self.layout
        lay.label(text="Ultra Remesh %s  -  Windows / Linux" % VERSION_STR)
        lay.label(text="Panel: 3D View > Sidebar (N) > Ultra Remesh")
        try:
            engine.load()
            lay.label(text="Engine: QRemesh (SculptForge) loaded", icon='CHECKMARK')
        except Exception as e:
            lay.label(text="Engine: %s" % e, icon='ERROR')
        lay.prop(self, "use_card")
        row = lay.row()
        row.alert = True
        row.scale_y = 1.4
        row.operator(UR_OT_uninstall.bl_idname, text="Uninstall Ultra Remesh", icon='TRASH')


classes = (UR_Settings, UR_OT_remesh, UR_OT_repair, UR_OT_compare, UR_OT_revert, UR_OT_scale_target, UR_OT_same_target,
           UR_OT_uninstall,
           UR_PT_main, UR_Preferences)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.ultra_remesh = PointerProperty(type=UR_Settings)
    try:
        from . import overlay
        overlay.register()
    except Exception:
        import traceback
        traceback.print_exc()


def unregister():
    try:
        from . import overlay
        overlay.unregister()
    except Exception:
        pass
    if hasattr(bpy.types.Scene, "ultra_remesh"):
        del bpy.types.Scene.ultra_remesh
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
