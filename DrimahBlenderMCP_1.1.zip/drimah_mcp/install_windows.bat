@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 goto usepy
where python >nul 2>nul
if not errorlevel 1 goto usepython
echo Python nao encontrado. Instale em https://www.python.org/downloads/
echo e marque "Add python.exe to PATH".
goto end
:usepy
py -3 install.py
goto end
:usepython
python install.py
:end
echo.
pause
