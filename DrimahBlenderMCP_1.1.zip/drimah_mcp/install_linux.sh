#!/usr/bin/env bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 nao encontrado. Rode: sudo apt install python3 python3-venv python3-pip"
    exit 1
fi
python3 install.py
