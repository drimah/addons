# Drimah Blender MCP - add-on + conector para ligar o Blender ao Claude (MCP).
# Compatível com o servidor oficial "Blender MCP" do Blender Lab
# (ferramentas execute_blender_code, get_objects_summary, screenshots etc.).
# Funciona em Windows e Linux. Sem assets, sem IA de terceiros, sem rede externa.

bl_info = {
    "name": "Drimah Blender MCP",
    "author": "Drimah",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Drimah MCP",
    "description": "Minimal socket server that lets Claude run Python in Blender via MCP",
    "category": "Interface",
}

import glob
import io
import json
import os
import queue
import shutil
import subprocess
import socket
import threading
import time
import traceback
from contextlib import redirect_stderr, redirect_stdout

import bpy

ADDON_ID = __name__
DEFAULT_PORT = 9876
MAX_MESSAGE_BYTES = 64 * 1024 * 1024
DEFERRED_TIMEOUT_S = 600.0
TICK_S = 0.05

_server = None


# ---------------------------------------------------------------------------
# Socket server
# ---------------------------------------------------------------------------
class MCPServer:
    def __init__(self, host="localhost", port=DEFAULT_PORT):
        self.host = host
        self.port = port
        self.running = False
        self.sock = None
        self.thread = None
        self.inbox = queue.Queue()
        self.pending = []  # deferred jobs (check_is_finished)
        self.clients = set()
        self.lock = threading.Lock()
        self.last_error = ""

    # -- lifecycle ---------------------------------------------------------
    def start(self):
        if self.running:
            return True
        if bpy.app.background:
            self.last_error = "Blender is in background mode"
            return False
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((self.host, self.port))
            s.listen(5)
            s.settimeout(1.0)
        except OSError as e:
            self.last_error = f"Port {self.port} unavailable: {e}"
            print(f"[Drimah MCP] {self.last_error}")
            return False
        self.sock = s
        self.running = True
        self.last_error = ""
        self.thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.thread.start()
        if not bpy.app.timers.is_registered(_tick):
            bpy.app.timers.register(_tick, persistent=True)
        print(f"[Drimah MCP] listening on {self.host}:{self.port}")
        return True

    def stop(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        with self.lock:
            clients = list(self.clients)
            self.clients.clear()
        for c in clients:
            try:
                c.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                c.close()
            except Exception:
                pass
        while not self.inbox.empty():
            try:
                self.inbox.get_nowait()
            except queue.Empty:
                break
        self.pending.clear()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.5)
        self.thread = None
        print("[Drimah MCP] stopped")

    # -- network threads ---------------------------------------------------
    def _accept_loop(self):
        while self.running:
            try:
                client, addr = self.sock.accept()
            except (socket.timeout, TimeoutError):
                continue
            except OSError:
                break
            print(f"[Drimah MCP] client connected {addr}")
            client.settimeout(1.0)
            with self.lock:
                self.clients.add(client)
            threading.Thread(target=self._client_loop, args=(client,), daemon=True).start()

    def _client_loop(self, client):
        buf = b""
        try:
            while self.running:
                try:
                    data = client.recv(65536)
                except (socket.timeout, TimeoutError):
                    continue
                except OSError:
                    break
                if not data:
                    break
                buf += data
                # Accept both framings: NUL-terminated (Blender Lab server)
                # and newline-terminated (older servers). JSON never contains
                # raw NUL or raw newline bytes, so splitting is safe.
                while True:
                    i0 = buf.find(b"\0")
                    i1 = buf.find(b"\n")
                    cands = [i for i in (i0, i1) if i >= 0]
                    if not cands:
                        break
                    i = min(cands)
                    term = buf[i:i + 1]
                    frame, buf = buf[:i], buf[i + 1:]
                    if frame.strip():
                        self._queue_frame(frame, client, term)
                if len(buf) > MAX_MESSAGE_BYTES:
                    print("[Drimah MCP] oversized message, closing client")
                    break
        finally:
            with self.lock:
                self.clients.discard(client)
            try:
                client.close()
            except Exception:
                pass
            print("[Drimah MCP] client disconnected")

    def _queue_frame(self, frame, client, term):
        try:
            msg = json.loads(frame.decode("utf-8"))
            if not isinstance(msg, dict):
                raise ValueError("message must be a JSON object")
        except Exception as e:
            _send(client, term, {"status": "error", "message": f"Bad message: {e}"})
            return
        self.inbox.put((msg, client, term))


def _send(client, term, payload, strict=False):
    try:
        data = json.dumps(payload) if strict else json.dumps(payload, default=_fallback)
    except Exception as e:
        data = json.dumps({
            "status": "error",
            "message": f"Result is not JSON-serialisable: {e}",
            "stdout": payload.get("stdout", ""),
            "stderr": payload.get("stderr", ""),
        })
    try:
        client.sendall(data.encode("utf-8") + term)
    except Exception:
        print("[Drimah MCP] failed to send response (client gone)")


def _fallback(obj):
    try:
        if hasattr(obj, "__len__") and not isinstance(obj, (str, bytes)):
            return list(obj)
    except Exception:
        pass
    return repr(obj)


# ---------------------------------------------------------------------------
# Main-thread execution
# ---------------------------------------------------------------------------
class Job:
    def __init__(self, msg, client, term):
        self.msg = msg
        self.client = client
        self.term = term
        self.ns = {"bpy": bpy, "__name__": "__mcp__"}
        self.out = io.StringIO()
        self.err = io.StringIO()
        self.started = time.monotonic()
        self.check = None

    def reply(self, payload):
        if "id" in self.msg:
            payload["id"] = self.msg["id"]
        payload.setdefault("stdout", self.out.getvalue())
        payload.setdefault("stderr", self.err.getvalue())
        _send(self.client, self.term, payload, strict=bool(self.msg.get("strict_json")))

    def ok(self):
        self.reply({"status": "ok", "result": self.ns.get("result")})

    def fail(self, message):
        self.reply({"status": "error", "message": message})


def _extract_code(msg):
    if isinstance(msg.get("code"), str):
        return msg["code"]
    params = msg.get("params") or {}
    if isinstance(params, dict) and isinstance(params.get("code"), str):
        return params["code"]
    return None


def _run(job):
    mtype = job.msg.get("type", "execute")
    if mtype in ("ping", "get_version"):
        job.ns["result"] = {"pong": True, "blender": bpy.app.version_string, "addon": "drimah-1.0.0"}
        job.ok()
        return None
    code = _extract_code(job.msg)
    if code is None:
        job.fail(f"Unsupported message type '{mtype}' (only Python execution is supported)")
        return None
    try:
        with redirect_stdout(job.out), redirect_stderr(job.err):
            exec(compile(code, "<mcp>", "exec"), job.ns)
    except Exception:
        job.fail(traceback.format_exc())
        return None
    check = job.ns.get("check_is_finished")
    if callable(check):
        job.check = check
        return job  # deferred
    job.ok()
    return None


def _poll(job):
    """Return True when the deferred job is done (and answered)."""
    if time.monotonic() - job.started > DEFERRED_TIMEOUT_S:
        job.fail("Deferred task timed out")
        return True
    try:
        with redirect_stdout(job.out), redirect_stderr(job.err):
            done = job.check()
    except Exception:
        job.fail(traceback.format_exc())
        return True
    if done:
        job.ok()
        return True
    return False


def _tick():
    srv = _server
    if srv is None or not srv.running:
        return None
    # deferred jobs first
    if srv.pending:
        srv.pending = [j for j in srv.pending if not _poll(j)]
    deadline = time.monotonic() + 0.03
    while time.monotonic() < deadline:
        try:
            msg, client, term = srv.inbox.get_nowait()
        except queue.Empty:
            break
        job = Job(msg, client, term)
        try:
            deferred = _run(job)
        except Exception:
            job.fail(traceback.format_exc())
            deferred = None
        if deferred:
            srv.pending.append(deferred)
    return TICK_S


# ---------------------------------------------------------------------------
# Preferences / UI
# ---------------------------------------------------------------------------
def _prefs():
    addon = bpy.context.preferences.addons.get(ADDON_ID)
    return addon.preferences if addon else None


def _start():
    global _server
    p = _prefs()
    port = p.port if p else DEFAULT_PORT
    if _server and _server.running:
        if _server.port == port:
            return True
        _server.stop()
    _server = MCPServer(port=port)
    return _server.start()


def _stop():
    global _server
    if _server:
        _server.stop()
    _server = None


class DRIMAHMCP_Preferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID

    port: bpy.props.IntProperty(name="Port", default=DEFAULT_PORT, min=1024, max=65535)
    auto_start: bpy.props.BoolProperty(
        name="Start automatically",
        description="Start the server when Blender opens",
        default=True,
    )

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "port")
        col.prop(self, "auto_start")


class DRIMAHMCP_OT_start(bpy.types.Operator):
    bl_idname = "drimahmcp.start"
    bl_label = "Start Server"
    bl_description = "Start the MCP socket server"

    def execute(self, context):
        if _start():
            self.report({"INFO"}, f"MCP server running on port {_server.port}")
            return {"FINISHED"}
        self.report({"ERROR"}, _server.last_error if _server else "Could not start")
        return {"CANCELLED"}


class DRIMAHMCP_OT_stop(bpy.types.Operator):
    bl_idname = "drimahmcp.stop"
    bl_label = "Stop Server"
    bl_description = "Stop the MCP socket server"

    def execute(self, context):
        _stop()
        return {"FINISHED"}


ROOT = os.path.dirname(os.path.abspath(__file__))
IS_WIN = os.name == "nt"


def _claude_configured():
    """True if the 'drimah-blender' server is in some Claude Desktop config."""
    if IS_WIN:
        dirs = [os.path.join(os.environ.get("APPDATA", ""), "Claude")]
        dirs += glob.glob(os.path.join(os.environ.get("LOCALAPPDATA", ""), "Packages",
                                       "Claude_*", "LocalCache", "Roaming", "Claude"))
    else:
        dirs = [os.path.expanduser("~/.config/Claude")]
    for d in dirs:
        cfg = os.path.join(d, "claude_desktop_config.json")
        try:
            with open(cfg, encoding="utf-8") as f:
                if "drimah-blender" in (json.load(f).get("mcpServers") or {}):
                    return True
        except Exception:
            pass
    return False


def _venv_ready():
    py = os.path.join(ROOT, ".venv", "Scripts" if IS_WIN else "bin", "python.exe" if IS_WIN else "python")
    return os.path.exists(py)


class DRIMAHMCP_OT_setup_claude(bpy.types.Operator):
    bl_idname = "drimahmcp.setup_claude"
    bl_label = "Setup Claude Connector"
    bl_description = "Open a terminal that installs the Drimah MCP server and registers it in Claude Desktop"

    def execute(self, context):
        try:
            if IS_WIN:
                subprocess.Popen(["cmd", "/c", "start", "Drimah MCP Setup", "cmd", "/k", "install_windows.bat"],
                                 cwd=ROOT)
            else:
                sh = os.path.join(ROOT, "install_linux.sh")
                inner = f'bash "{sh}"; echo; read -p "Enter para fechar..."'
                for term, args in (
                    ("x-terminal-emulator", ["-e", "bash", "-c", inner]),
                    ("gnome-terminal", ["--", "bash", "-c", inner]),
                    ("mate-terminal", ["-e", f"bash -c '{inner}'"]),
                    ("xfce4-terminal", ["-e", f"bash -c '{inner}'"]),
                    ("konsole", ["-e", "bash", "-c", inner]),
                    ("xterm", ["-e", "bash", "-c", inner]),
                ):
                    if shutil.which(term):
                        subprocess.Popen([term] + args, cwd=ROOT)
                        break
                else:
                    self.report({"ERROR"}, f"No terminal found. Run: bash {sh}")
                    return {"CANCELLED"}
        except Exception as e:
            self.report({"ERROR"}, f"Could not open installer: {e}")
            return {"CANCELLED"}
        self.report({"INFO"}, "Installer opened. When it finishes, restart the Claude app.")
        return {"FINISHED"}


class DRIMAHMCP_PT_panel(bpy.types.Panel):
    bl_label = "Drimah Blender MCP"
    bl_idname = "DRIMAHMCP_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Drimah MCP"

    def draw(self, context):
        layout = self.layout
        p = _prefs()
        running = bool(_server and _server.running)
        if p:
            row = layout.row()
            row.enabled = not running
            row.prop(p, "port")
            layout.prop(p, "auto_start")
        if running:
            layout.label(text=f"Running on port {_server.port}", icon="CHECKMARK")
            if _server.clients:
                layout.label(text="Claude connected", icon="LINKED")
            layout.operator("drimahmcp.stop", icon="PAUSE")
        else:
            layout.label(text="Stopped", icon="X")
            if _server and _server.last_error:
                layout.label(text=_server.last_error, icon="ERROR")
            layout.operator("drimahmcp.start", icon="PLAY")

        box = layout.box()
        box.label(text="Claude connector", icon="PLUGIN")
        ok = _venv_ready() and _claude_configured()
        if ok:
            box.label(text="Installed in Claude", icon="CHECKMARK")
            box.label(text="(restart Claude after setup)")
        else:
            box.label(text="Not installed yet", icon="INFO")
        box.operator("drimahmcp.setup_claude", icon="CONSOLE",
                     text="Reinstall Connector" if ok else "Setup Claude Connector")


def _auto_start():
    p = _prefs()
    if p and p.auto_start:
        _start()
    return None


classes = (DRIMAHMCP_Preferences, DRIMAHMCP_OT_start, DRIMAHMCP_OT_stop,
           DRIMAHMCP_OT_setup_claude, DRIMAHMCP_PT_panel)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.app.timers.register(_auto_start, first_interval=1.0)


def unregister():
    _stop()
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    if bpy.app.timers.is_registered(_auto_start):
        bpy.app.timers.unregister(_auto_start)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
