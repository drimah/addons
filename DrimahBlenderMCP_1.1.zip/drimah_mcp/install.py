"""Instalador do Drimah Blender MCP (Windows e Linux).

1. Cria um ambiente Python (.venv) nesta pasta e instala o pacote "mcp".
2. Registra o servidor "drimah-blender" na configuração do Claude Desktop
   (com backup .bak do arquivo original).

Uso:  python install.py        (o install_windows.bat / install_linux.sh já chamam isto)
"""

import glob
import json
import os
import shutil
import subprocess
import sys
import venv

ROOT = os.path.dirname(os.path.abspath(__file__))
VENV = os.path.join(ROOT, ".venv")
SERVER = os.path.join(ROOT, "server", "server.py")
IS_WIN = os.name == "nt"
SERVER_KEY = "drimah-blender"


def step(msg):
    print(f"\n==> {msg}")


def venv_python():
    if IS_WIN:
        return os.path.join(VENV, "Scripts", "python.exe")
    return os.path.join(VENV, "bin", "python")


def make_venv():
    step("Criando ambiente Python (.venv)")
    if not os.path.exists(venv_python()):
        try:
            venv.EnvBuilder(with_pip=True).create(VENV)
        except Exception as e:
            print(f"ERRO ao criar o .venv: {e}")
            if not IS_WIN:
                print("No Linux Mint rode antes:  sudo apt install python3-venv python3-pip")
            sys.exit(1)
    py = venv_python()
    step("Instalando o pacote 'mcp' (pode levar um minuto)")
    subprocess.check_call([py, "-m", "pip", "install", "--upgrade", "pip", "-q"])
    subprocess.check_call([py, "-m", "pip", "install", "mcp>=1.2,<2", "-q"])
    subprocess.check_call([py, "-c", "import mcp.server.fastmcp; print('   mcp OK')"])
    return py


def claude_config_paths():
    paths = []
    if IS_WIN:
        appdata = os.environ.get("APPDATA", "")
        local = os.environ.get("LOCALAPPDATA", "")
        paths.append(os.path.join(appdata, "Claude"))
        paths += glob.glob(os.path.join(local, "Packages", "Claude_*", "LocalCache", "Roaming", "Claude"))
    else:
        paths.append(os.path.expanduser("~/.config/Claude"))
    return [p for p in paths if os.path.isdir(p)]


def register_claude(py):
    step("Registrando o servidor no Claude Desktop")
    entry = {"command": py, "args": [SERVER], "env": {"DRIMAH_BLENDER_PORT": "9876"}}
    dirs = claude_config_paths()
    if not dirs:
        print("   Pasta do Claude Desktop não encontrada - pulei esta etapa.")
    for d in dirs:
        cfg = os.path.join(d, "claude_desktop_config.json")
        data = {}
        if os.path.exists(cfg):
            try:
                with open(cfg, encoding="utf-8") as f:
                    data = json.load(f) or {}
            except Exception as e:
                print(f"   AVISO: não consegui ler {cfg} ({e}); não alterei o arquivo.")
                continue
            shutil.copy2(cfg, cfg + ".bak")
        data.setdefault("mcpServers", {})[SERVER_KEY] = entry
        with open(cfg, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"   OK: {cfg}")
        others = [k for k in data["mcpServers"] if k != SERVER_KEY and "blender" in k.lower()]
        if others:
            print(f"   Obs.: também existe(m) {others} - pode remover para não confundir.")
    print("\n   Para o Claude Code (terminal), se usar:")
    print(f'   claude mcp add {SERVER_KEY} -- "{py}" "{SERVER}"')


def main():
    print("Drimah Blender MCP - instalador")
    if sys.version_info < (3, 10):
        print("ERRO: precisa de Python 3.10 ou mais novo.")
        sys.exit(1)
    py = make_venv()
    register_claude(py)
    print("\nPronto! Agora:")
    print(" 1) Feche e abra o app do Claude (inclusive na bandeja do sistema).")
    print(" 2) No Blender, aba 'Drimah MCP' deve mostrar 'Running on port 9876'.")
    print("\nSe reinstalar o add-on no Blender, clique de novo em 'Setup Claude Connector'.")


if __name__ == "__main__":
    main()
