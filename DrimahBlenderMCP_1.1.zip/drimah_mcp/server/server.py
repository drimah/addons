"""Drimah Blender MCP - servidor MCP (lado do Claude).

Conversa com o add-on "Drimah Blender MCP" que roda dentro do Blender,
via socket TCP (localhost:9876 por padrão). Windows e Linux.

Variáveis de ambiente opcionais:
  DRIMAH_BLENDER_HOST   (padrão: localhost)
  DRIMAH_BLENDER_PORT   (padrão: 9876)
  DRIMAH_BLENDER_TIMEOUT segundos por comando (padrão: 180)
"""

import base64
import json
import os
import socket
import textwrap

from mcp.server.fastmcp import FastMCP, Image

HOST = os.environ.get("DRIMAH_BLENDER_HOST", "localhost")
PORT = int(os.environ.get("DRIMAH_BLENDER_PORT", "9876"))
TIMEOUT = float(os.environ.get("DRIMAH_BLENDER_TIMEOUT", "180"))

mcp = FastMCP(
    "drimah-blender",
    instructions=(
        "Controls a running Blender through the Drimah Blender MCP add-on. "
        "Use execute_blender_code for modeling (bpy). Assign a JSON-serialisable "
        "value to a variable named `result` to get data back. Use "
        "get_viewport_screenshot to check the visual result after changes."
    ),
)


class BlenderError(RuntimeError):
    pass


def _send(code: str, timeout: float = TIMEOUT) -> dict:
    """Send Python code to Blender and return the decoded response."""
    msg = json.dumps({"type": "execute", "code": code, "strict_json": False}).encode("utf-8") + b"\0"
    try:
        sock = socket.create_connection((HOST, PORT), timeout=10)
    except OSError as e:
        raise BlenderError(
            f"Cannot connect to Blender at {HOST}:{PORT}. Open Blender, enable the "
            f"'Drimah Blender MCP' add-on and press Start Server in the 'Drimah MCP' tab. ({e})"
        )
    try:
        sock.settimeout(timeout)
        sock.sendall(msg)
        buf = b""
        while b"\0" not in buf:
            try:
                chunk = sock.recv(1 << 20)
            except socket.timeout:
                raise BlenderError(
                    f"Blender did not answer within {timeout:.0f}s. It may be busy, frozen, "
                    "or showing a popup dialog."
                )
            if not chunk:
                raise BlenderError("Blender closed the connection without answering.")
            buf += chunk
    finally:
        sock.close()
    return json.loads(buf.split(b"\0", 1)[0].decode("utf-8"))


def _run(code: str):
    resp = _send(code)
    if resp.get("status") != "ok":
        raise BlenderError(resp.get("message", "Unknown error"))
    return resp


def _fmt(resp: dict) -> str:
    out = {"result": resp.get("result")}
    if resp.get("stdout"):
        out["stdout"] = resp["stdout"]
    if resp.get("stderr"):
        out["stderr"] = resp["stderr"]
    return json.dumps(out, ensure_ascii=False, indent=1, default=str)


@mcp.tool()
def ping_blender() -> str:
    """Check the connection to Blender and return its version."""
    resp = _run("import bpy\nresult = {'blender': bpy.app.version_string, 'file': bpy.data.filepath or '(unsaved)'}")
    return _fmt(resp)


@mcp.tool()
def execute_blender_code(code: str) -> str:
    """Run Python code inside the open Blender (full bpy access).

    Assign a JSON-serialisable value to `result` to return data.
    print() output is returned as stdout. For long tasks, define a function
    `check_is_finished()` that returns True when done; `result` is read after.
    """
    return _fmt(_run(code))


@mcp.tool()
def get_scene_info(limit: int = 200) -> str:
    """List scene objects with type, location, rotation, scale, dimensions and collections."""
    code = textwrap.dedent(f"""
        import bpy
        sc = bpy.context.scene
        objs = []
        for o in list(sc.objects)[:{int(limit)}]:
            objs.append({{
                'name': o.name, 'type': o.type,
                'parent': o.parent.name if o.parent else None,
                'location': [round(v, 4) for v in o.location],
                'rotation_deg': [round(v * 57.29578, 2) for v in o.rotation_euler],
                'scale': [round(v, 4) for v in o.scale],
                'dimensions': [round(v, 4) for v in o.dimensions],
                'collections': [c.name for c in o.users_collection],
                'materials': [s.material.name for s in getattr(o, 'material_slots', []) if s.material],
                'visible': o.visible_get(),
            }})
        result = {{
            'scene': sc.name, 'file': bpy.data.filepath or '(unsaved)',
            'unit_scale': sc.unit_settings.scale_length,
            'object_count': len(sc.objects), 'objects': objs,
        }}
    """)
    return _fmt(_run(code))


@mcp.tool()
def get_object_info(name: str) -> str:
    """Detailed info for one object: transform, mesh stats, modifiers, materials."""
    code = textwrap.dedent(f"""
        import bpy
        o = bpy.data.objects.get({name!r})
        if o is None:
            result = {{'error': 'Object not found: ' + {name!r}}}
        else:
            info = {{
                'name': o.name, 'type': o.type,
                'location': list(o.location), 'rotation_euler': list(o.rotation_euler),
                'scale': list(o.scale), 'dimensions': list(o.dimensions),
                'parent': o.parent.name if o.parent else None,
                'children': [c.name for c in o.children],
                'modifiers': [{{'name': m.name, 'type': m.type}} for m in o.modifiers],
                'materials': [s.material.name for s in o.material_slots if s.material],
            }}
            if o.type == 'MESH':
                me = o.data
                info['mesh'] = {{'vertices': len(me.vertices), 'edges': len(me.edges),
                                 'faces': len(me.polygons)}}
                bb = [o.matrix_world @ __import__('mathutils').Vector(c) for c in o.bound_box]
                info['world_bbox_min'] = [min(v[i] for v in bb) for i in range(3)]
                info['world_bbox_max'] = [max(v[i] for v in bb) for i in range(3)]
            result = info
    """)
    return _fmt(_run(code))


_SHOT_CODE = """
import bpy, os, tempfile, base64
max_size = {max_size}
path = os.path.join(tempfile.gettempdir(), 'drimah_mcp_viewport.png')
win = None; area = None
for w in bpy.context.window_manager.windows:
    for a in w.screen.areas:
        if a.type == 'VIEW_3D' and (area is None or a.width * a.height > area.width * area.height):
            win, area = w, a
if area is None:
    result = {{'error': 'No 3D Viewport open'}}
else:
    region = [r for r in area.regions if r.type == 'WINDOW'][0]
    with bpy.context.temp_override(window=win, screen=win.screen, area=area, region=region):
        bpy.ops.screen.screenshot_area(filepath=path)
    img = bpy.data.images.load(path, check_existing=False)
    w, h = img.size
    if max(w, h) > max_size:
        k = max_size / max(w, h)
        img.scale(max(1, int(w * k)), max(1, int(h * k)))
        img.filepath_raw = path
        img.file_format = 'PNG'
        img.save()
    size = list(img.size)
    bpy.data.images.remove(img)
    with open(path, 'rb') as f:
        data = base64.b64encode(f.read()).decode('ascii')
    result = {{'png_base64': data, 'size': size}}
"""


@mcp.tool()
def get_viewport_screenshot(max_size: int = 1000) -> Image:
    """Screenshot of the largest 3D Viewport (PNG), to visually check the model."""
    resp = _run(_SHOT_CODE.format(max_size=int(max_size)))
    res = resp.get("result") or {}
    if "error" in res:
        raise BlenderError(res["error"])
    return Image(data=base64.b64decode(res["png_base64"]), format="png")


@mcp.tool()
def save_blend_file(filepath: str = "") -> str:
    """Save the current .blend. Empty filepath = save in place (must already have a path)."""
    code = textwrap.dedent(f"""
        import bpy
        fp = {filepath!r}
        if fp:
            bpy.ops.wm.save_as_mainfile(filepath=fp)
        elif bpy.data.filepath:
            bpy.ops.wm.save_mainfile()
        else:
            raise RuntimeError('File was never saved: pass a filepath')
        result = {{'saved': bpy.data.filepath}}
    """)
    return _fmt(_run(code))


def main():
    mcp.run()


if __name__ == "__main__":
    main()
