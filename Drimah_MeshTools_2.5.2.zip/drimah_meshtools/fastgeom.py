"""Fast (numpy) geometry helpers for Drimah MeshTools 2.5 - Decimate and Remesh.

Works on bpy Mesh data with foreach_get/foreach_set instead of per-vertex Python
objects, so relax and projection stay fast on dense meshes (100k+ vertices).
"""
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree


def get_co(me):
    co = np.empty(len(me.vertices) * 3, dtype=np.float64)
    me.vertices.foreach_get("co", co)
    return co.reshape(-1, 3)


def set_co(me, co):
    me.vertices.foreach_set("co", np.ascontiguousarray(co, dtype=np.float64).ravel())
    me.update()


def get_edges(me):
    e = np.empty(len(me.edges) * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", e)
    return e.reshape(-1, 2)


def get_vertex_normals(me):
    n = np.empty(len(me.vertices) * 3, dtype=np.float64)
    try:
        me.vertex_normals.foreach_get("vector", n)
    except (AttributeError, RuntimeError, TypeError):
        me.vertices.foreach_get("normal", n)
    return n.reshape(-1, 3)


def surface_area(me):
    if not me.polygons:
        return 0.0
    a = np.empty(len(me.polygons), dtype=np.float64)
    me.polygons.foreach_get("area", a)
    return float(a.sum())


def bvh_from_bmesh(bm):
    return BVHTree.FromBMesh(bm)


def project(me, bvh, mask=None, max_dist=None, co=None):
    """Snap vertices (mask: bool array) to the nearest point of the bvh surface.
    Points farther than max_dist are left where they are (avoids pulling the
    surface into closed gaps). Returns the number of moved vertices."""
    own = co is None
    if own:
        co = get_co(me)
    idx = np.nonzero(mask)[0] if mask is not None else range(len(co))
    find = bvh.find_nearest
    moved = 0
    for i in idx:
        p = Vector(co[i])
        hit = find(p, max_dist) if max_dist else find(p)
        if hit[0] is not None:
            co[i] = hit[0]
            moved += 1
    if own:
        set_co(me, co)
    return moved


def boundary_vertex_mask(me):
    """True for vertices on open borders (edges used by one face only)."""
    nv = len(me.vertices)
    mask = np.zeros(nv, dtype=bool)
    if not me.polygons:
        return mask
    loops_e = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", loops_e)
    count = np.bincount(loops_e, minlength=len(me.edges))
    edges = get_edges(me)
    b = edges[count == 1]
    mask[b.ravel()] = True
    return mask


def relax(me, iterations, strength, pinned=None, bvh=None, max_dist=None):
    """Tangent Laplacian relax (no shrinking), each pass projected onto `bvh`
    (the original surface) when given. pinned: bool array of fixed vertices."""
    nv = len(me.vertices)
    if nv == 0 or iterations <= 0 or strength <= 0.0:
        return 0
    edges = get_edges(me)
    if len(edges) == 0:
        return 0
    a, b = edges[:, 0], edges[:, 1]
    deg = np.bincount(a, minlength=nv) + np.bincount(b, minlength=nv)
    free = deg > 0
    if pinned is not None:
        free &= ~pinned
    if not free.any():
        return 0
    deg = np.maximum(deg, 1).astype(np.float64)
    co = get_co(me)
    for it in range(iterations):
        acc = np.zeros_like(co)
        for k in range(3):
            acc[:, k] = np.bincount(a, weights=co[b, k], minlength=nv) + \
                np.bincount(b, weights=co[a, k], minlength=nv)
        delta = acc / deg[:, None] - co
        if it % 2 == 0:
            set_co(me, co)
            nrm = get_vertex_normals(me)
        delta -= nrm * np.einsum("ij,ij->i", delta, nrm)[:, None]
        co[free] += delta[free] * strength
        if bvh is not None:
            project(me, bvh, free, max_dist, co=co)
    set_co(me, co)
    return int(free.sum())


def remove_small_parts(bm, min_fraction):
    """Delete loose parts with fewer than min_fraction of all faces.
    The largest part is always kept. Returns the number of removed parts."""
    import bmesh
    if min_fraction <= 0.0 or not bm.faces:
        return 0
    total = len(bm.faces)
    seen = set()
    parts = []
    for f in bm.faces:
        if f in seen:
            continue
        stack = [f]
        seen.add(f)
        comp = []
        while stack:
            x = stack.pop()
            comp.append(x)
            for e in x.edges:
                for g in e.link_faces:
                    if g not in seen:
                        seen.add(g)
                        stack.append(g)
        parts.append(comp)
    if len(parts) < 2:
        return 0
    parts.sort(key=len, reverse=True)
    limit = total * min_fraction
    dead = [c for c in parts[1:] if len(c) < limit]
    if not dead:
        return 0
    faces = [f for c in dead for f in c]
    verts = list({v for f in faces for v in f.verts})
    bmesh.ops.delete(bm, geom=verts, context='VERTS')
    return len(dead)
