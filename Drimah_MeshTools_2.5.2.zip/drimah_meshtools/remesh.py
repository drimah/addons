"""Drimah MeshTools - Remesh module (2.5).

Built on Blender's own remeshers (Voxel, QuadriFlow and the Blocks / Smooth /
Sharp octree modes) and adds:
- Target Face Count for Voxel (the voxel size is computed and refined).
- Quad mode (QuadriFlow) with Auto Repair: when QuadriFlow refuses the mesh
  ("needs to be manifold..."), a clean voxel base is built and retried.
- Keep Detail: the new vertices are projected back onto the original surface.
- Smooth along the original surface (relax + projection, no shrinking).
- Fill Holes before remeshing, Remove Small Parts after.
- Standard Drimah symmetry (exact result, works on models that are not at zero).
- Keep Original, presets with Save / Delete / Export / Import.
"""
import math

import bpy
import bmesh
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import common, fastgeom

VOXEL_FACTOR = 1.4          # faces ~= VOXEL_FACTOR * area / voxel_size^2 (measured)
MAX_FACES = 3_000_000       # safety limit against freezing Blender

BUILTINS = {
    "SCULPT_BASE": {"label": "Sculpt Base", "mode": 'VOXEL', "detail_mode": 'FACES', "target_faces": 20000,
                    "adaptivity": 0.0, "fix_poles": True, "preserve_volume": True, "fill_holes": True,
                    "keep_detail": True, "smooth_iterations": 2, "smooth_strength": 0.5,
                    "remove_small": True, "smooth_shade": True},
    "CLEAN_QUADS": {"label": "Clean Quads", "mode": 'QUAD', "detail_mode": 'FACES', "target_faces": 5000,
                    "auto_repair": True, "preserve_sharp": False, "preserve_boundary": True,
                    "fill_holes": False, "keep_detail": True, "smooth_iterations": 3,
                    "smooth_strength": 0.4, "remove_small": True, "smooth_shade": True},
    "HARD_SURFACE": {"label": "Hard Surface", "mode": 'QUAD', "detail_mode": 'FACES', "target_faces": 8000,
                     "auto_repair": True, "preserve_sharp": True, "preserve_boundary": True,
                     "fill_holes": False, "keep_detail": True, "smooth_iterations": 0,
                     "remove_small": True, "smooth_shade": False},
    "BLOCKY": {"label": "Blocks", "mode": 'BLOCKS', "octree_depth": 5, "scale": 0.9,
               "remove_small": True, "keep_detail": False, "smooth_iterations": 0, "smooth_shade": False},
}

PRESET_PROPS = {
    "mode": (str, None, None),
    "detail_mode": (str, None, None),
    "voxel_size": (float, 0.0001, 100.0),
    "target_faces": (int, 50, MAX_FACES),
    "adaptivity": (float, 0.0, 1.0),
    "fix_poles": (bool, None, None),
    "preserve_volume": (bool, None, None),
    "preserve_attributes": (bool, None, None),
    "octree_depth": (int, 1, 10),
    "scale": (float, 0.0, 0.99),
    "sharpness": (float, 0.0, 10.0),
    "auto_repair": (bool, None, None),
    "preserve_sharp": (bool, None, None),
    "preserve_boundary": (bool, None, None),
    "seed": (int, 0, 255),
    "fill_holes": (bool, None, None),
    "keep_detail": (bool, None, None),
    "smooth_iterations": (int, 0, 50),
    "smooth_strength": (float, 0.0, 1.0),
    "remove_small": (bool, None, None),
    "small_size": (float, 0.0, 0.5),
    "smooth_shade": (bool, None, None),
    "keep_original": (bool, None, None),
    **common.SYM_PRESET_PROPS,
}
CHOICES = {
    "mode": {'BLOCKS', 'SMOOTH', 'SHARP', 'VOXEL', 'QUAD'},
    "detail_mode": {'SIZE', 'FACES'},
    **common.SYM_CHOICES,
}

STORE = common.PresetStore("remesh_presets.json", BUILTINS, PRESET_PROPS, CHOICES,
                           "SCULPT_BASE", "Remesh")


def _preset_items(self, context):
    return STORE.items()


def _preset_update(self, context):
    STORE.apply(self)


class RemeshError(Exception):
    pass


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

def _bm_area(bm):
    return sum(f.calc_area() for f in bm.faces)


def _restore(me, src):
    bm = bmesh.new()
    bm.from_mesh(src)
    bm.to_mesh(me)
    bm.free()
    me.update()


def _voxel(target, size, s):
    me = target.data
    keep = (me.remesh_voxel_size, me.remesh_voxel_adaptivity, me.use_remesh_fix_poles,
            me.use_remesh_preserve_volume, me.use_remesh_preserve_attributes)
    me.remesh_voxel_size = size
    me.remesh_voxel_adaptivity = s.adaptivity
    me.use_remesh_fix_poles = s.fix_poles
    me.use_remesh_preserve_volume = s.preserve_volume
    me.use_remesh_preserve_attributes = s.preserve_attributes
    try:
        with bpy.context.temp_override(**common.override(target)):
            res = bpy.ops.object.voxel_remesh()
    finally:
        me = target.data
        (me.remesh_voxel_size, me.remesh_voxel_adaptivity, me.use_remesh_fix_poles,
         me.use_remesh_preserve_volume, me.use_remesh_preserve_attributes) = keep
    if 'FINISHED' not in res or not target.data.polygons:
        raise RemeshError("Voxel remesh failed (is the mesh empty or too thin for this voxel size?).")


def _octree(context, target, s):
    me = target.data
    tmp = bpy.data.objects.new("_dmt_remesh_tmp", me)
    context.scene.collection.objects.link(tmp)
    try:
        mod = tmp.modifiers.new("DMT Remesh", 'REMESH')
        mod.mode = s.mode
        mod.octree_depth = s.octree_depth
        mod.scale = s.scale
        mod.sharpness = s.sharpness
        mod.use_remove_disconnected = False      # done by Remove Small Parts
        mod.use_smooth_shade = s.smooth_shade
        dg = context.evaluated_depsgraph_get()
        dg.update()
        result = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg))
    finally:
        bpy.data.objects.remove(tmp)
    try:
        if not result.polygons:
            raise RemeshError("Remesh produced no faces. Try a higher Octree Depth.")
        _restore(me, result)
    finally:
        bpy.data.meshes.remove(result)


def _quadriflow(target, s, faces, edge_len):
    args = dict(use_mesh_symmetry=False, use_preserve_sharp=s.preserve_sharp,
                use_preserve_boundary=s.preserve_boundary, preserve_attributes=False,
                smooth_normals=s.smooth_shade, seed=s.seed)
    if s.detail_mode == 'SIZE':
        args.update(mode='EDGE', target_edge_length=edge_len)
    else:
        args.update(mode='FACES', target_faces=faces)
    try:
        with bpy.context.temp_override(**common.override(target)):
            res = bpy.ops.object.quadriflow_remesh(**args)
    except RuntimeError:
        return False
    return 'FINISHED' in res and len(target.data.polygons) > 0


def _is_clean_manifold(me):
    bm = bmesh.new()
    bm.from_mesh(me)
    ok = all(e.is_manifold or e.is_boundary for e in bm.edges) and \
        all(v.is_manifold or v.is_boundary for v in bm.verts) and bool(bm.faces)
    bm.free()
    return ok


def _light_smooth(me):
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.smooth_vert(bm, verts=bm.verts[:], factor=0.5,
                          use_axis_x=True, use_axis_y=True, use_axis_z=True)
    bm.to_mesh(me)
    bm.free()
    me.update()


def _quad(target, s, area, src, stats):
    me = target.data
    faces = s.target_faces
    edge_len = s.voxel_size if s.detail_mode == 'SIZE' else math.sqrt(area / max(1, faces))
    if s.detail_mode == 'SIZE' and area / (edge_len * edge_len) > MAX_FACES:
        raise RemeshError(f"Edge length too small: about {int(area / edge_len ** 2):,} faces.")
    if _is_clean_manifold(me) and _quadriflow(target, s, faces, edge_len):
        return
    if not s.auto_repair:
        raise RemeshError("QuadriFlow could not remesh this mesh (it must be manifold). "
                          "Turn on Auto Repair.")
    # Auto Repair: clean watertight voxel base (3 voxels per final edge), lightly
    # smoothed (QuadriFlow is unstable on raw voxel steps), then QuadriFlow again.
    size = edge_len / 3.0
    size = max(size, math.sqrt(VOXEL_FACTOR * area / 2_000_000))
    for attempt in range(4):
        _restore(me, src)
        _voxel(target, size, s)
        _light_smooth(me)
        if _quadriflow(target, s, faces, edge_len):
            stats["repaired"] = attempt + 1
            return
        size *= 1.2
    raise RemeshError("QuadriFlow failed even after Auto Repair. Try Voxel mode or another Target Faces.")


def run_remesh(context, target, s):
    me = target.data
    stats = {"faces_before": len(me.polygons)}
    bm = bmesh.new()
    bm.from_mesh(me)
    if not bm.faces:
        bm.free()
        raise RemeshError("The mesh has no faces.")
    sym = common.Symmetry(s, target, context.scene.cursor.location.copy())
    sym.begin(bm)
    if sym.on:
        sym.make_symmetric(bm)          # symmetric input (a half model is completed)
    if s.fill_holes:
        res = bmesh.ops.holes_fill(bm, edges=bm.edges[:], sides=0)
        stats["holes"] = len(res.get("faces", []))
    area = _bm_area(bm)
    if area <= 1e-12:
        bm.free()
        raise RemeshError("The mesh has no area.")
    bvh = fastgeom.bvh_from_bmesh(bm) if (s.keep_detail or s.smooth_iterations) else None
    bm.to_mesh(me)
    bm.free()
    me.update()
    src = me.copy()                      # input kept for refinement / repair retries
    try:
        cell = None
        if s.mode == 'VOXEL':
            if s.detail_mode == 'SIZE':
                size = s.voxel_size
            else:
                size = math.sqrt(VOXEL_FACTOR * area / max(1, s.target_faces))
            est = VOXEL_FACTOR * area / (size * size)
            if est > MAX_FACES:
                raise RemeshError(f"Voxel size too small: about {int(est):,} faces "
                                  f"(limit {MAX_FACES:,}). Use a larger size.")
            _voxel(target, size, s)
            if s.detail_mode == 'FACES':
                got = len(target.data.polygons)
                if abs(got - s.target_faces) > 0.1 * s.target_faces:
                    size *= math.sqrt(got / s.target_faces)
                    _restore(target.data, src)
                    _voxel(target, size, s)
            cell = size
            stats["voxel_size"] = size
        elif s.mode == 'QUAD':
            _quad(target, s, area, src, stats)
            cell = math.sqrt(area / max(1, len(target.data.polygons)))
        else:
            _octree(context, target, s)
            co = fastgeom.get_co(src)
            cell = float((co.max(axis=0) - co.min(axis=0)).max()) / (2 ** s.octree_depth) / max(0.01, s.scale)
    finally:
        bpy.data.meshes.remove(src)

    me = target.data
    bm = bmesh.new()
    bm.from_mesh(me)
    if s.remove_small:
        stats["parts_removed"] = fastgeom.remove_small_parts(bm, s.small_size)
    bm.to_mesh(me)
    bm.free()
    me.update()

    if bvh is not None and s.mode != 'BLOCKS' and len(me.vertices):
        reach = cell * 2.0
        if s.keep_detail:
            fastgeom.project(me, bvh, None, reach)
        if s.smooth_iterations:
            fastgeom.relax(me, s.smooth_iterations, s.smooth_strength,
                           pinned=fastgeom.boundary_vertex_mask(me),
                           bvh=bvh if s.keep_detail else None, max_dist=reach)

    bm = bmesh.new()
    bm.from_mesh(me)
    sym.finish(bm)
    sym.end(bm)
    for f in bm.faces:
        f.smooth = s.smooth_shade
    bm.to_mesh(me)
    bm.free()
    me.update()
    stats.update(sym.apply_object(target))
    if sym.on and not sym.modifier:
        stats["welded"] = True
    stats["faces_after"] = len(me.polygons)
    return stats


# ---------------------------------------------------------------------------
# Panel estimate (cached)
# ---------------------------------------------------------------------------

_AREA_CACHE = {}


def _cached_area(obj):
    me = obj.data
    key = (me.as_pointer(), len(me.vertices), len(me.polygons))
    hit = _AREA_CACHE.get(obj.name)
    if hit and hit[0] == key:
        return hit[1]
    if len(me.polygons) > 2_000_000:
        return None
    area = fastgeom.surface_area(me)
    _AREA_CACHE.clear()
    _AREA_CACHE[obj.name] = (key, area)
    return area


# ---------------------------------------------------------------------------
# Blender classes
# ---------------------------------------------------------------------------

class DMT_REMESH_Settings(PropertyGroup):
    preset: EnumProperty(name="Preset", items=_preset_items, update=_preset_update)
    mode: EnumProperty(
        name="Mode",
        items=[('BLOCKS', "Blocks", "Octree remesh: blocky voxels"),
               ('SMOOTH', "Smooth", "Octree remesh: smooth surface"),
               ('SHARP', "Sharp", "Octree remesh: keeps sharp corners"),
               ('VOXEL', "Voxel", "Even quad surface from a voxel volume (watertight)"),
               ('QUAD', "Quad", "Clean quad flow that follows the shape (QuadriFlow)")],
        default='VOXEL')
    detail_mode: EnumProperty(
        name="Detail",
        items=[('SIZE', "Size", "Set the voxel size / edge length"),
               ('FACES', "Target Faces", "Set the approximate number of faces")],
        default='FACES')
    voxel_size: FloatProperty(name="Voxel Size", description="Voxel size (Quad: target edge length)",
                              default=0.05, min=0.0001, max=100.0, soft_min=0.001, soft_max=1.0,
                              unit='LENGTH', precision=4)
    target_faces: IntProperty(name="Target Faces", default=5000, min=50, max=MAX_FACES)
    adaptivity: FloatProperty(name="Adaptivity",
                              description="Fewer faces in flat areas (adds triangles)",
                              default=0.0, min=0.0, max=1.0, unit='LENGTH')
    fix_poles: BoolProperty(name="Fix Poles", default=True)
    preserve_volume: BoolProperty(name="Preserve Volume", default=True)
    preserve_attributes: BoolProperty(name="Preserve Attributes",
                                      description="Transfer color attributes and masks", default=False)
    octree_depth: IntProperty(name="Octree Depth", default=4, min=1, max=10)
    scale: FloatProperty(name="Scale", default=0.9, min=0.0, max=0.99)
    sharpness: FloatProperty(name="Sharpness", default=1.0, min=0.0, max=10.0)
    auto_repair: BoolProperty(
        name="Auto Repair",
        description="If QuadriFlow refuses the mesh, build a clean voxel base and try again",
        default=True)
    preserve_sharp: BoolProperty(name="Preserve Sharp", default=False)
    preserve_boundary: BoolProperty(name="Preserve Boundary", default=True)
    seed: IntProperty(name="Seed", description="Random seed of QuadriFlow", default=0, min=0, max=255)
    fill_holes: BoolProperty(name="Fill Holes", description="Close open holes before remeshing",
                             default=False)
    keep_detail: BoolProperty(
        name="Keep Detail",
        description="Project the new vertices back onto the original surface (recovers detail)",
        default=True)
    smooth_iterations: IntProperty(name="Smooth",
                                   description="Relax passes along the surface after remeshing (0 = off)",
                                   default=2, min=0, max=50)
    smooth_strength: FloatProperty(name="Strength", default=0.5, min=0.0, max=1.0, subtype='FACTOR')
    remove_small: BoolProperty(name="Remove Small Parts",
                               description="Delete loose floating pieces after remeshing", default=True)
    small_size: FloatProperty(name="Smaller Than",
                              description="Parts with fewer faces than this fraction of the result are removed",
                              default=0.01, min=0.0, max=0.5, subtype='FACTOR')
    smooth_shade: BoolProperty(name="Smooth Shading", default=True)
    keep_original: BoolProperty(
        name="Keep Original",
        description="Leave the original object untouched (hidden) and put the result in a new object",
        default=False)


common.add_symmetry_props(DMT_REMESH_Settings)


class DMT_REMESH_OT_remesh(Operator):
    bl_idname = "dmt_remesh.remesh"
    bl_label = "Remesh"
    bl_description = "Rebuild the whole object with a new, even topology"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        obj = context.active_object
        s = context.scene.dmt_remesh_settings
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        target = common.make_target(obj, s.keep_original, "_Remesh")
        context.window_manager.progress_begin(0, 1)
        context.workspace.status_text_set("Processing... Remesh")
        try:
            stats = run_remesh(context, target, s)
        except RemeshError as exc:
            common.discard_target(obj, target)
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:
            common.discard_target(obj, target)
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'ERROR'}, f"Remesh failed: {exc}")
            return {'CANCELLED'}
        finally:
            context.window_manager.progress_end()
            context.workspace.status_text_set(None)
        common.finalize_target(context, obj, target)
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        msg = f"Remesh: {stats['faces_before']:,} -> {stats['faces_after']:,} faces"
        if stats.get("voxel_size"):
            msg += f" (voxel {stats['voxel_size']:.4g})"
        if stats.get("repaired"):
            msg += ", Auto Repair used"
        if stats.get("holes"):
            msg += f", {stats['holes']} hole(s) filled"
        if stats.get("parts_removed"):
            msg += f", {stats['parts_removed']} small part(s) removed"
        extra = common.symmetry_message(stats)
        if extra:
            msg += "; " + ", ".join(extra)
        if target is not obj:
            msg += f". Result: {target.name} (original hidden)"
        self.report({'INFO'}, msg + ".")
        return {'FINISHED'}


_PRESET_OPS = common.make_preset_operators("DMT_REMESH", "dmt_remesh", "dmt_remesh_settings",
                                           STORE, "drimah_remesh_presets.json")


class DMT_REMESH_PT_panel(Panel):
    bl_label = "Remesh"
    bl_idname = "DMT_REMESH_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drimah MeshTools"
    bl_parent_id = "DMT_PT_meshtools_root"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.dmt_remesh_settings
        obj = context.active_object
        layout.prop(s, "preset", text="Preset")
        row = layout.row(align=True)
        row.prop(s, "mode", expand=True)

        if s.mode in {'VOXEL', 'QUAD'}:
            row = layout.row(align=True)
            row.prop(s, "detail_mode", expand=True)
            if s.detail_mode == 'SIZE':
                layout.prop(s, "voxel_size", text="Voxel Size" if s.mode == 'VOXEL' else "Edge Length")
            else:
                layout.prop(s, "target_faces")
            if obj is not None and obj.type == 'MESH' and s.mode == 'VOXEL':
                area = _cached_area(obj)
                if area:
                    if s.detail_mode == 'SIZE':
                        est = VOXEL_FACTOR * area / (s.voxel_size ** 2)
                        layout.label(text=f"About {int(est):,} faces", icon='INFO')
                    else:
                        size = math.sqrt(VOXEL_FACTOR * area / max(1, s.target_faces))
                        layout.label(text=f"Voxel size about {size:.4g}", icon='INFO')
        else:
            layout.prop(s, "octree_depth")
            layout.prop(s, "scale")
            if s.mode == 'SHARP':
                layout.prop(s, "sharpness")

        if s.mode == 'VOXEL':
            layout.prop(s, "adaptivity")
            grid = layout.grid_flow(columns=2, align=True)
            grid.prop(s, "fix_poles")
            grid.prop(s, "preserve_volume")
            grid.prop(s, "preserve_attributes")
        elif s.mode == 'QUAD':
            grid = layout.grid_flow(columns=2, align=True)
            grid.prop(s, "auto_repair")
            grid.prop(s, "preserve_sharp")
            grid.prop(s, "preserve_boundary")
            grid.prop(s, "seed")

        box = layout.box()
        box.label(text="Quality", icon='MOD_SMOOTH')
        box.prop(s, "fill_holes")
        row = box.row()
        row.enabled = s.mode != 'BLOCKS'
        row.prop(s, "keep_detail")
        row = box.row(align=True)
        row.enabled = s.mode != 'BLOCKS'
        row.prop(s, "smooth_iterations")
        sub = row.row(align=True)
        sub.enabled = s.smooth_iterations > 0 and s.mode != 'BLOCKS'
        sub.prop(s, "smooth_strength", slider=True)
        row = box.row(align=True)
        row.prop(s, "remove_small")
        sub = row.row(align=True)
        sub.enabled = s.remove_small
        sub.prop(s, "small_size", slider=True)
        box.prop(s, "smooth_shade")
        layout.prop(s, "keep_original")

        common.draw_symmetry(layout, s, obj)
        common.draw_preset_buttons(layout, "dmt_remesh")

        if obj is not None and obj.type == 'MESH' and context.mode == 'OBJECT':
            layout.label(text=f"Faces: {len(obj.data.polygons):,}", icon='MESH_DATA')
        layout.separator()
        row = layout.row()
        row.scale_y = 1.35
        row.operator("dmt_remesh.remesh", text="Remesh", icon='MOD_REMESH')


CLASSES = (DMT_REMESH_Settings, DMT_REMESH_OT_remesh) + tuple(_PRESET_OPS) + (DMT_REMESH_PT_panel,)
