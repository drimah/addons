"""Shared pieces for the Decimate and Remesh modules (Drimah MeshTools 2.5).

- Preset store (built-ins + custom JSON with Save / Delete / Export / Import).
- Standard Drimah symmetry (None | X | Y | Z, Weld | Mirror Modifier,
  Side + | Side -, Auto Center | Origin | 3D Cursor) reusing the tested
  helpers of the Redraw module.
- Keep Original helper.
"""
import json
import os
import re

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Operator
from mathutils import Matrix, Vector

from . import redraw


# ---------------------------------------------------------------------------
# Presets
# ---------------------------------------------------------------------------

class PresetStore:
    def __init__(self, filename, builtins, props, choices, default_key, kind):
        self.filename = filename
        self.builtins = builtins
        self.props = props            # name -> (type, lo, hi)
        self.choices = choices        # name -> set of enum ids
        self.default_key = default_key
        self.kind = kind
        self._cache = []

    def path(self):
        base = bpy.utils.user_resource('CONFIG', path="drimah_meshtools", create=True)
        return os.path.join(base, self.filename)

    def load(self):
        try:
            with open(self.path(), "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def write(self, data):
        path = self.path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def items(self, _self=None, _context=None):
        items = [(k, v["label"], "Built-in %s preset" % self.kind) for k, v in self.builtins.items()]
        custom = self.load()
        for key, value in sorted(custom.items(), key=lambda kv: str(kv[1].get("label", "")).lower()
                                 if isinstance(kv[1], dict) else ""):
            if isinstance(value, dict) and isinstance(value.get("label"), str):
                items.append((key, value["label"], "Custom %s preset" % self.kind))
        # Keep dynamic enum strings alive; Blender can retain pointers between redraws.
        self._cache = items
        return self._cache

    def clean(self, prop, value, fallback):
        kind, lo, hi = self.props[prop]
        try:
            if kind is bool:
                return bool(value)
            if kind is str:
                return value if value in self.choices.get(prop, ()) else fallback
            value = kind(value)
            return max(lo, min(hi, value))
        except (TypeError, ValueError):
            return fallback

    def apply(self, settings):
        data = self.builtins.get(settings.preset) or self.load().get(settings.preset)
        if not isinstance(data, dict):
            return
        for prop in self.props:
            if prop in data:
                setattr(settings, prop, self.clean(prop, data[prop], getattr(settings, prop)))

    def snapshot(self, settings, label):
        return {"label": label, **{p: getattr(settings, p) for p in self.props}}


def make_preset_operators(prefix, idname_prefix, settings_attr, store, export_name):
    """Build Save / Delete / Export / Import operators for one module."""

    def _settings(context):
        return getattr(context.scene, settings_attr)

    class _Save(Operator):
        bl_idname = idname_prefix + ".save_preset"
        bl_label = "Save Preset"
        bl_description = "Save the current values as a custom preset"
        name: StringProperty(name="Preset Name", default="My Preset", maxlen=64)

        def invoke(self, context, event):
            return context.window_manager.invoke_props_dialog(self, width=320)

        def draw(self, context):
            self.layout.prop(self, "name", text="")

        def execute(self, context):
            label = self.name.strip()
            if not label:
                self.report({'WARNING'}, "Enter a preset name.")
                return {'CANCELLED'}
            key = "CUSTOM_" + re.sub(r'[^A-Z0-9]+', '_', label.upper()).strip('_')[:40]
            s = _settings(context)
            data = store.load()
            data[key] = store.snapshot(s, label)
            try:
                store.write(data)
            except OSError as exc:
                self.report({'ERROR'}, f"Could not save: {exc}")
                return {'CANCELLED'}
            s.preset = key
            self.report({'INFO'}, "Preset saved.")
            return {'FINISHED'}

    class _Delete(Operator):
        bl_idname = idname_prefix + ".delete_preset"
        bl_label = "Delete Preset"
        bl_description = "Delete the selected custom preset"

        @classmethod
        def poll(cls, context):
            return _settings(context).preset in store.load()

        def execute(self, context):
            s = _settings(context)
            data = store.load()
            if s.preset not in data:
                return {'CANCELLED'}
            del data[s.preset]
            try:
                store.write(data)
            except OSError as exc:
                self.report({'ERROR'}, f"Could not delete: {exc}")
                return {'CANCELLED'}
            s.preset = store.default_key
            return {'FINISHED'}

    class _Export(Operator):
        bl_idname = idname_prefix + ".export_presets"
        bl_label = "Export Presets"
        bl_description = "Export the custom presets to a JSON file"
        filepath: StringProperty(subtype='FILE_PATH')

        def invoke(self, context, event):
            self.filepath = os.path.join(os.path.expanduser("~"), export_name)
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        def execute(self, context):
            try:
                with open(self.filepath, "w", encoding="utf-8") as f:
                    json.dump(store.load(), f, ensure_ascii=False, indent=2)
                return {'FINISHED'}
            except OSError as exc:
                self.report({'ERROR'}, f"Export failed: {exc}")
                return {'CANCELLED'}

    class _Import(Operator):
        bl_idname = idname_prefix + ".import_presets"
        bl_label = "Import Presets"
        bl_description = "Import custom presets from a JSON file"
        filepath: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})

        def invoke(self, context, event):
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        def execute(self, context):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    incoming = json.load(f)
                if not isinstance(incoming, dict):
                    raise ValueError("Invalid preset file")
                existing = store.load()
                defaults = store.builtins[store.default_key]
                s = _settings(context)
                for key, value in incoming.items():
                    if not isinstance(value, dict) or not isinstance(value.get("label"), str):
                        continue
                    safe_key = re.sub(r'[^A-Z0-9_]+', '_', str(key).upper())[:48] or "IMPORTED"
                    item = {"label": value["label"][:64]}
                    for prop in store.props:
                        fallback = defaults.get(prop, getattr(s, prop))
                        item[prop] = store.clean(prop, value.get(prop, fallback), fallback)
                    existing[safe_key] = item
                store.write(existing)
                store.items()
                return {'FINISHED'}
            except (OSError, ValueError, TypeError) as exc:
                self.report({'ERROR'}, f"Import failed: {exc}")
                return {'CANCELLED'}

    for cls, suffix in ((_Save, "save_preset"), (_Delete, "delete_preset"),
                        (_Export, "export_presets"), (_Import, "import_presets")):
        cls.__name__ = f"{prefix}_OT_{suffix}"
        cls.__qualname__ = cls.__name__
    return (_Save, _Delete, _Export, _Import)


def draw_preset_buttons(layout, idname_prefix):
    row = layout.row(align=True)
    row.operator(idname_prefix + ".save_preset", text="Save", icon='FILE_TICK')
    row.operator(idname_prefix + ".delete_preset", text="Delete", icon='TRASH')
    row = layout.row(align=True)
    row.operator(idname_prefix + ".export_presets", text="Export", icon='EXPORT')
    row.operator(idname_prefix + ".import_presets", text="Import", icon='IMPORT')


# ---------------------------------------------------------------------------
# Symmetry (standard Drimah pattern)
# ---------------------------------------------------------------------------

SYM_PRESET_PROPS = {
    "symmetry_axis": (str, None, None),
    "mirror_result": (str, None, None),
    "mirror_side": (str, None, None),
    "mirror_center": (str, None, None),
}
SYM_CHOICES = {
    "symmetry_axis": {'NONE', 'X', 'Y', 'Z'},
    "mirror_result": {'WELD', 'MODIFIER'},
    "mirror_center": {'AUTO', 'ORIGIN', 'CURSOR'},
    "mirror_side": {'POSITIVE', 'NEGATIVE'},
}
SYM_DEFAULTS = {"symmetry_axis": 'NONE', "mirror_result": 'WELD',
                "mirror_side": 'POSITIVE', "mirror_center": 'AUTO'}
MIRROR_TOL = 0.001


def symmetry_props():
    """Property definitions shared by both modules (identical to Redraw)."""
    return dict(
        symmetry_axis=EnumProperty(
            name="Symmetry", description="Mirror axis (object local space)",
            items=[('NONE', "None", "No symmetry"),
                   ('X', "X", "Mirror across the local X axis"),
                   ('Y', "Y", "Mirror across the local Y axis"),
                   ('Z', "Z", "Mirror across the local Z axis")],
            default='NONE'),
        mirror_result=EnumProperty(
            name="Result", description="How the mirrored side is created",
            items=[('WELD', "Weld", "Create the mirrored geometry and weld it at the center"),
                   ('MODIFIER', "Mirror Modifier",
                    "Keep only the chosen side and add a live Mirror modifier "
                    "(can be turned off or applied later)")],
            default='WELD'),
        mirror_side=EnumProperty(
            name="Side", description="Which side is processed and copied to the other side",
            items=[('POSITIVE', "Side +", "Use the positive side and mirror it to the negative side"),
                   ('NEGATIVE', "Side -", "Use the negative side and mirror it to the positive side")],
            default='POSITIVE'),
        mirror_center=EnumProperty(
            name="Center", description="Where the mirror plane is",
            items=[('AUTO', "Auto Center", "Center of the model itself: no need to place it at zero "
                                           "(a half model uses its flat open side)"),
                   ('ORIGIN', "Origin", "Object origin"),
                   ('CURSOR', "3D Cursor", "3D cursor position")],
            default='AUTO'),
    )


def add_symmetry_props(cls):
    """Add the symmetry properties as annotations (required by Blender)."""
    ann = cls.__dict__.get("__annotations__")
    if ann is None:
        ann = {}
        cls.__annotations__ = ann
    for key, prop in symmetry_props().items():
        ann[key] = prop
    return cls


def draw_symmetry(layout, s, obj, note=None):
    box = layout.box()
    box.label(text="Symmetry", icon='MOD_MIRROR')
    row = box.row(align=True)
    row.prop(s, "symmetry_axis", expand=True)
    on = s.symmetry_axis != 'NONE'
    for prop in ("mirror_result", "mirror_side", "mirror_center"):
        row = box.row(align=True)
        row.enabled = on
        row.prop(s, prop, expand=True)
    if note and on:
        box.label(text=note, icon='INFO')
    mod = obj.modifiers.get(redraw.MIRROR_MOD_NAME) if obj is not None and obj.type == 'MESH' else None
    if mod is not None:
        row = box.row(align=True)
        row.prop(mod, "show_viewport", text="Mirror On", toggle=True)
        row.operator("dmt_redraw.apply_mirror", text="Apply", icon='CHECKMARK')
        row.operator("dmt_redraw.remove_mirror", text="", icon='X')


class Symmetry:
    """Runs the standard symmetry around an operation on a bmesh.

    begin(): computes the plane (Auto Center / Origin / 3D Cursor) and moves the
    mesh so the plane is at 0 on the axis.  finish(): makes the result exact:
    Weld -> chosen side mirrored and welded; Modifier -> other side removed.
    end(): moves the mesh back; after writing the mesh, call apply_object()."""

    def __init__(self, settings, obj, cursor_world):
        self.s = settings
        self.obj = obj
        self.cursor = cursor_world
        self.axes = redraw._mirror_axes(settings)
        self.on = bool(self.axes)
        self.ax = self.axes[0] if self.on else 0
        self.sign = 1 if settings.mirror_side == 'POSITIVE' else -1
        self.modifier = self.on and settings.mirror_result == 'MODIFIER'
        self.center = 0.0
        self.shifted = False

    def begin(self, bm):
        if not self.on:
            return
        self.center = redraw.mirror_center_value(self.obj, bm, self.s, self.cursor)
        if abs(self.center) >= 1e-12:
            for v in bm.verts:
                v.co[self.ax] -= self.center
            self.shifted = True

    def plane_eps(self, bm):
        if not bm.verts:
            return 1e-6
        vals = [v.co[self.ax] for v in bm.verts]
        return max((max(vals) - min(vals)) * 1e-5, 1e-6)

    def make_symmetric(self, bm):
        """Chosen side replaces the other one (also restores a half model)."""
        if self.on:
            redraw._symmetrize_whole(bm, self.axes, self.sign, MIRROR_TOL)

    def cut_half(self, bm):
        if self.on:
            redraw._cut_half(bm, self.axes, self.sign, MIRROR_TOL)

    def finish(self, bm):
        if not self.on:
            return
        if self.modifier:
            self.cut_half(bm)
        else:
            self.make_symmetric(bm)

    def end(self, bm):
        if self.shifted:
            for v in bm.verts:
                v.co[self.ax] += self.center
            self.shifted = False

    def apply_object(self, target):
        """After the mesh is written: origin + live modifier, or modifier cleanup."""
        info = {}
        if not self.on:
            return info
        if self.modifier:
            if abs(self.center) > 1e-12:
                off = Vector((0.0, 0.0, 0.0))
                off[self.ax] = self.center
                target.data.transform(Matrix.Translation(-off))
                target.data.update()
                target.matrix_world = target.matrix_world @ Matrix.Translation(off)
                info["origin_moved"] = True
            redraw._setup_mirror_modifier(target, self.axes, MIRROR_TOL)
            info["modifier"] = True
        else:
            mod = target.modifiers.get(redraw.MIRROR_MOD_NAME)
            if mod is not None and mod.type == 'MIRROR' and mod.use_axis[self.ax]:
                target.modifiers.remove(mod)
                info["removed_mod"] = True
        return info


def symmetry_message(info):
    parts = []
    if info.get("modifier"):
        parts.append("live Mirror modifier added")
    if info.get("welded"):
        parts.append("mirrored and welded")
    if info.get("origin_moved"):
        parts.append("object origin moved to the mirror center")
    if info.get("removed_mod"):
        parts.append("Drimah Mirror modifier removed (the mirror is now real geometry)")
    return parts


# ---------------------------------------------------------------------------
# Keep Original
# ---------------------------------------------------------------------------

def make_target(obj, keep_original, suffix):
    if not keep_original:
        return obj
    target = obj.copy()
    target.data = obj.data.copy()
    target.name = obj.name + suffix
    target.data.name = obj.data.name + suffix
    for coll in obj.users_collection:
        coll.objects.link(target)
    return target


def discard_target(obj, target):
    if target is not obj:
        me = target.data
        bpy.data.objects.remove(target)
        if me.users == 0:
            bpy.data.meshes.remove(me)


def finalize_target(context, obj, target):
    if target is obj:
        return
    for o in context.selected_objects:
        o.select_set(False)
    target.select_set(True)
    context.view_layer.objects.active = target
    obj.hide_set(True)


def override(obj):
    return dict(object=obj, active_object=obj, selected_objects=[obj],
                selected_editable_objects=[obj])
