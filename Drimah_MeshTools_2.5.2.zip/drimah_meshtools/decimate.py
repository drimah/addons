"""Drimah MeshTools - Decimate module (2.5).

Built on Blender's own decimation (Collapse / Un-Subdivide / Planar) and adds:
- Target Face Count (not only a ratio), counted for the whole object.
- Works on the selected faces in Edit Mode (the rest is not touched), or on the
  whole object in Object Mode.
- Protect Borders / UV Seams / Sharp Edges / Material borders (vertices locked).
- Result faces: Triangles | Mixed | Quads (quad-dominant clean-up).
- Smooth along the original surface (relax + projection, no shrinking).
- Standard Drimah symmetry: exact, works on models that are not at zero.
- Keep Original, presets with Save / Delete / Export / Import.
"""
import bpy
import bmesh
import math
import numpy as np
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import common, fastgeom, geom

TMP_GROUP = "_dmt_decimate_lock"

BUILTINS = {
    "BALANCED": {"label": "Balanced", "method": 'COLLAPSE', "target_mode": 'RATIO', "ratio": 0.5,
                 "face_type": 'QUADS', "protect_borders": True, "protect_seams": True,
                 "protect_sharp": False, "protect_materials": True, "smooth_iterations": 2,
                 "smooth_strength": 0.4},
    "GAME_LOD": {"label": "Game LOD", "method": 'COLLAPSE', "target_mode": 'RATIO', "ratio": 0.25,
                 "face_type": 'TRIS', "protect_borders": True, "protect_seams": True,
                 "protect_sharp": True, "protect_materials": True, "smooth_iterations": 0,
                 "smooth_strength": 0.4},
    "SCULPT_TO_LOW": {"label": "Sculpt to Low", "method": 'COLLAPSE', "target_mode": 'FACES',
                      "target_faces": 5000, "face_type": 'QUADS', "protect_borders": True,
                      "protect_seams": False, "protect_sharp": False, "protect_materials": False,
                      "smooth_iterations": 4, "smooth_strength": 0.5},
    "HARD_SURFACE": {"label": "Hard Surface", "method": 'PLANAR', "angle_limit": math.radians(5.0),
                     "protect_borders": True, "protect_seams": True, "protect_sharp": True,
                     "protect_materials": True, "smooth_iterations": 0},
    "UNSUBDIVIDE": {"label": "Un-Subdivide", "method": 'UNSUBDIV', "iterations": 1,
                    "smooth_iterations": 0},
}

PRESET_PROPS = {
    "method": (str, None, None),
    "target_mode": (str, None, None),
    "ratio": (float, 0.0001, 1.0),
    "target_faces": (int, 4, 10000000),
    "iterations": (int, 1, 20),
    "angle_limit": (float, 0.0, math.pi),
    "face_type": (str, None, None),
    "protect_borders": (bool, None, None),
    "protect_seams": (bool, None, None),
    "protect_sharp": (bool, None, None),
    "protect_materials": (bool, None, None),
    "smooth_iterations": (int, 0, 50),
    "smooth_strength": (float, 0.0, 1.0),
    "keep_original": (bool, None, None),
    **common.SYM_PRESET_PROPS,
}
CHOICES = {
    "method": {'COLLAPSE', 'UNSUBDIV', 'PLANAR'},
    "target_mode": {'RATIO', 'FACES'},
    "face_type": {'TRIS', 'MIXED', 'QUADS'},
    **common.SYM_CHOICES,
}

STORE = common.PresetStore("decimate_presets.json", BUILTINS, PRESET_PROPS, CHOICES,
                           "BALANCED", "Decimate")


def _preset_items(self, context):
    return STORE.items()


def _preset_update(self, context):
    STORE.apply(self)


class DecimateError(Exception):
    pass


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

def _material_border(edge):
    fs = edge.link_faces
    return len(fs) == 2 and fs[0].material_index != fs[1].material_index


def _locked_verts(bm, s, sym, eps):
    locked = set()
    for e in bm.edges:
        if (s.protect_borders and e.is_boundary) or \
                (s.protect_seams and e.seam) or \
                (s.protect_sharp and geom.is_hard_edge(e)) or \
                (s.protect_materials and _material_border(e)):
            locked.update(e.verts)
    if sym.on:
        # The center line must stay on the mirror plane.
        locked.update(v for v in bm.verts if abs(v.co[sym.ax]) <= eps)
    return locked


def _set_lock_weights(target, bm, locked):
    """Weight 0 = locked, 1 = free (Blender's decimate uses the active group)."""
    bm.verts.index_update()
    locked_idx = {v.index for v in locked}
    vg = target.vertex_groups.get(TMP_GROUP) or target.vertex_groups.new(name=TMP_GROUP)
    # Adding a layer invalidates Python vertex references: go through indices.
    dl = bm.verts.layers.deform.verify()
    bm.verts.ensure_lookup_table()
    gi = vg.index
    for i, v in enumerate(bm.verts):
        v[dl][gi] = 0.0 if i in locked_idx else 1.0
    return vg


def _remove_lock_group(target):
    vg = target.vertex_groups.get(TMP_GROUP)
    if vg is not None:
        target.vertex_groups.remove(vg)


def run_decimate(context, target, s, use_selection):
    """Decimate `target` (Object Mode on entry and exit). Returns stats."""
    stats = {"faces_before": len(target.data.polygons)}
    me = target.data
    bm = bmesh.new()
    bm.from_mesh(me)
    sym = common.Symmetry(s, target, context.scene.cursor.location.copy())
    sym.begin(bm)
    if sym.on:
        sym.cut_half(bm)        # work on one side only, mirror at the end
    if not bm.faces:
        bm.free()
        raise DecimateError("Nothing to decimate on the chosen side.")
    if not use_selection:
        for f in bm.faces:
            f.select_set(True)
    else:
        for f in bm.faces:
            f.select_set(f.select)
    bm.select_mode = {'FACE'}
    bm.select_flush_mode()
    sel = [f for f in bm.faces if f.select]
    if not sel:
        bm.free()
        raise DecimateError("No faces selected on the chosen side.")
    eps = sym.plane_eps(bm)
    locked = _locked_verts(bm, s, sym, eps)
    if use_selection:
        # The border of the selection stays connected to the untouched faces.
        locked.update(v for f in sel for v in f.verts if any(not g.select for g in v.link_faces))
    bvh = fastgeom.bvh_from_bmesh(bm) if s.smooth_iterations > 0 else None
    sel_tris = sum(len(f.verts) - 2 for f in sel)
    unsel = len(bm.faces) - len(sel)

    ratio = s.ratio
    if s.method == 'COLLAPSE' and s.target_mode == 'FACES':
        total = s.target_faces / (2.0 if sym.on else 1.0)
        want = max(1.0, total - unsel)
        if s.face_type == 'QUADS':
            want *= 2.0
        ratio = max(0.0001, min(1.0, want / max(1, sel_tris)))
    stats["ratio"] = ratio

    use_lock = s.method == 'COLLAPSE' and bool(locked)
    if use_lock:
        _set_lock_weights(target, bm, locked)
    bm.to_mesh(me)
    bm.free()
    me.update()

    # Run Blender's decimation in Edit Mode on the selection only.
    view_layer = context.view_layer
    prev_sel = [o for o in context.selected_objects]
    for o in prev_sel:
        o.select_set(False)
    target.select_set(True)
    view_layer.objects.active = target
    try:
        bpy.ops.object.mode_set(mode='EDIT')
        if s.method == 'COLLAPSE':
            if ratio < 0.9999:
                if use_lock:
                    target.vertex_groups.active_index = target.vertex_groups[TMP_GROUP].index
                bpy.ops.mesh.decimate(ratio=ratio, use_vertex_group=use_lock,
                                      vertex_group_factor=1.0, invert_vertex_group=False)
        elif s.method == 'UNSUBDIV':
            bpy.ops.mesh.unsubdivide(iterations=s.iterations)
        else:
            delimit = {'NORMAL'}
            if s.protect_seams:
                delimit.add('SEAM')
            if s.protect_sharp:
                delimit.add('SHARP')
            if s.protect_materials:
                delimit.add('MATERIAL')
            bpy.ops.mesh.dissolve_limited(angle_limit=s.angle_limit,
                                          use_dissolve_boundaries=not s.protect_borders,
                                          delimit=delimit)
        if s.method != 'PLANAR':
            if s.face_type == 'QUADS':
                bpy.ops.mesh.tris_convert_to_quads(
                    face_threshold=math.radians(40.0), shape_threshold=math.radians(40.0),
                    seam=s.protect_seams, sharp=s.protect_sharp, materials=s.protect_materials)
            elif s.face_type == 'TRIS':
                bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
        bpy.ops.object.mode_set(mode='OBJECT')
    finally:
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
        _remove_lock_group(target)
        for o in prev_sel:
            try:
                o.select_set(True)
            except ReferenceError:
                pass

    # Smooth along the original surface (selected vertices, locks pinned).
    if bvh is not None and s.method != 'PLANAR' and len(me.vertices):
        bm = bmesh.new()
        bm.from_mesh(me)
        pinned = np.ones(len(bm.verts), dtype=bool)
        free_set = {v for f in bm.faces if f.select for v in f.verts}
        hard = _locked_verts(bm, s, sym, eps)
        for v in bm.verts:
            # Free = inside the decimated area (all faces around it selected), not locked.
            if v in free_set and v not in hard and not v.is_boundary and \
                    all(f.select for f in v.link_faces):
                pinned[v.index] = False
        bm.free()
        fastgeom.relax(me, s.smooth_iterations, s.smooth_strength, pinned=pinned, bvh=bvh)

    bm = bmesh.new()
    bm.from_mesh(me)
    sym.finish(bm)
    sym.end(bm)
    bm.to_mesh(me)
    bm.free()
    me.update()
    stats.update(sym.apply_object(target))
    if sym.on and not sym.modifier:
        stats["welded"] = True
    stats["faces_after"] = len(me.polygons)
    return stats


# ---------------------------------------------------------------------------
# Blender classes
# ---------------------------------------------------------------------------

class DMT_DECIMATE_Settings(PropertyGroup):
    preset: EnumProperty(name="Preset", items=_preset_items, update=_preset_update)
    method: EnumProperty(
        name="Method",
        items=[('COLLAPSE', "Collapse", "Merge vertices progressively, keeping the shape (best general reduction)"),
               ('UNSUBDIV', "Un-Subdivide", "Undo subdivisions on quad grids"),
               ('PLANAR', "Planar", "Dissolve faces that are flat within the angle limit")],
        default='COLLAPSE')
    target_mode: EnumProperty(
        name="Target",
        items=[('RATIO', "Ratio", "Keep this fraction of the triangles"),
               ('FACES', "Face Count", "Reach about this many faces on the whole object")],
        default='RATIO')
    ratio: FloatProperty(name="Ratio", default=0.5, min=0.0001, max=1.0, subtype='FACTOR', precision=4)
    target_faces: IntProperty(name="Face Count", default=5000, min=4, max=10000000)
    iterations: IntProperty(name="Iterations", description="Un-Subdivide passes", default=1, min=1, max=20)
    angle_limit: FloatProperty(name="Angle Limit", default=math.radians(5.0), min=0.0, max=math.pi,
                               subtype='ANGLE')
    face_type: EnumProperty(
        name="Faces",
        items=[('TRIS', "Triangles", "Triangulate the result"),
               ('MIXED', "Mixed", "Leave the result as Blender makes it"),
               ('QUADS', "Quads", "Join triangles into quads where they form good quads")],
        default='QUADS')
    protect_borders: BoolProperty(name="Borders", description="Lock open borders", default=True)
    protect_seams: BoolProperty(name="UV Seams", description="Lock vertices on UV seams", default=True)
    protect_sharp: BoolProperty(name="Sharp Edges",
                                description="Lock edges marked sharp or with a strong angle (35 degrees+)",
                                default=False)
    protect_materials: BoolProperty(name="Materials", description="Lock borders between materials",
                                    default=True)
    smooth_iterations: IntProperty(
        name="Smooth", description="Relax passes along the ORIGINAL surface after decimating (0 = off)",
        default=2, min=0, max=50)
    smooth_strength: FloatProperty(name="Strength", default=0.4, min=0.0, max=1.0, subtype='FACTOR')
    keep_original: BoolProperty(
        name="Keep Original",
        description="Leave the original object untouched (hidden) and put the result in a new object",
        default=False)


common.add_symmetry_props(DMT_DECIMATE_Settings)


class DMT_DECIMATE_OT_decimate(Operator):
    bl_idname = "dmt_decimate.decimate"
    bl_label = "Decimate"
    bl_description = ("Reduce the faces of the selection (Edit Mode) or of the whole object (Object Mode), "
                      "keeping borders, seams and shape")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        obj = context.active_object
        s = context.scene.dmt_decimate_settings
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        use_selection = was_edit and any(p.select for p in obj.data.polygons)
        if was_edit and not use_selection:
            self.report({'WARNING'}, "No faces selected: select faces, or use Object Mode for the whole object.")
            bpy.ops.object.mode_set(mode='EDIT')
            return {'CANCELLED'}
        target = common.make_target(obj, s.keep_original, "_Decimate")
        context.window_manager.progress_begin(0, 1)
        context.workspace.status_text_set("Processing... Decimate")
        try:
            stats = run_decimate(context, target, s, use_selection)
        except DecimateError as exc:
            common.discard_target(obj, target)
            context.view_layer.objects.active = obj
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:
            common.discard_target(obj, target)
            context.view_layer.objects.active = obj
            if was_edit and context.mode != 'EDIT_MESH':
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'ERROR'}, f"Decimate failed: {exc}")
            return {'CANCELLED'}
        finally:
            context.window_manager.progress_end()
            context.workspace.status_text_set(None)
        common.finalize_target(context, obj, target)
        if not target.hide_get():
            context.view_layer.objects.active = target
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        msg = f"Decimate: {stats['faces_before']:,} -> {stats['faces_after']:,} faces"
        if use_selection:
            msg += " (selection only)"
        extra = common.symmetry_message(stats)
        if extra:
            msg += "; " + ", ".join(extra)
        if target is not obj:
            msg += f". Result: {target.name} (original hidden)"
        self.report({'INFO'}, msg + ".")
        return {'FINISHED'}


_PRESET_OPS = common.make_preset_operators("DMT_DECIMATE", "dmt_decimate", "dmt_decimate_settings",
                                           STORE, "drimah_decimate_presets.json")


class DMT_DECIMATE_PT_panel(Panel):
    bl_label = "Decimate"
    bl_idname = "DMT_DECIMATE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drimah MeshTools"
    bl_parent_id = "DMT_PT_meshtools_root"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.dmt_decimate_settings
        obj = context.active_object
        layout.prop(s, "preset", text="Preset")
        row = layout.row(align=True)
        row.prop(s, "method", expand=True)
        if s.method == 'COLLAPSE':
            row = layout.row(align=True)
            row.prop(s, "target_mode", expand=True)
            if s.target_mode == 'RATIO':
                layout.prop(s, "ratio", slider=True)
            else:
                layout.prop(s, "target_faces")
        elif s.method == 'UNSUBDIV':
            layout.prop(s, "iterations")
        else:
            layout.prop(s, "angle_limit")
        if s.method != 'PLANAR':
            row = layout.row(align=True)
            row.prop(s, "face_type", expand=True)

        box = layout.box()
        box.label(text="Protect", icon='LOCKED')
        grid = box.grid_flow(columns=2, align=True)
        grid.prop(s, "protect_borders")
        grid.prop(s, "protect_seams")
        grid.prop(s, "protect_sharp")
        grid.prop(s, "protect_materials")

        if s.method != 'PLANAR':
            row = layout.row(align=True)
            row.prop(s, "smooth_iterations")
            sub = row.row(align=True)
            sub.enabled = s.smooth_iterations > 0
            sub.prop(s, "smooth_strength", slider=True)
        layout.prop(s, "keep_original")

        common.draw_symmetry(layout, s, obj, note="Mirrors the whole model")
        common.draw_preset_buttons(layout, "dmt_decimate")

        if obj is not None and obj.type == 'MESH' and context.mode == 'OBJECT':
            layout.label(text=f"Faces: {len(obj.data.polygons):,}", icon='MESH_DATA')
        layout.separator()
        row = layout.row()
        row.scale_y = 1.35
        row.operator("dmt_decimate.decimate", text="Decimate", icon='MOD_DECIM')


CLASSES = (DMT_DECIMATE_Settings, DMT_DECIMATE_OT_decimate) + tuple(_PRESET_OPS) + (DMT_DECIMATE_PT_panel,)
