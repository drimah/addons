"""Shared geometry helpers for Drimah MeshTools 2.0.

Goal: keep round and circular shapes round.
- relax_keep_shape: relaxes vertices only along the surface (tangent plane) and
  projects them back onto the original surface, so spheres, cylinders and
  circular areas do not shrink.
- smooth_normal: vertex normal that ignores faces across hard edges.
- curve_point: position on a smooth curve between two vertices (cubic Hermite
  from their normals), used to place new vertices on arcs instead of chords.
"""
import math

import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree

HARD_ANGLE = math.radians(35.0)


def is_hard_edge(edge, angle=HARD_ANGLE):
    try:
        if not edge.smooth:
            return True
    except (AttributeError, ReferenceError):
        pass
    if len(edge.link_faces) == 2:
        try:
            return edge.link_faces[0].normal.angle(edge.link_faces[1].normal) >= angle
        except (ValueError, RuntimeError):
            return False
    return False


def smooth_normal(vert, ref_faces=None, angle=HARD_ANGLE):
    """Average normal of the faces around vert that are smoothly connected to
    ref_faces (faces of the edge being processed). Faces across a hard edge are
    ignored, so a box corner does not bend a flat side."""
    faces = list(vert.link_faces)
    if not faces:
        return vert.normal.copy()
    refs = [f for f in (ref_faces or []) if f in faces] or faces
    acc = Vector((0.0, 0.0, 0.0))
    for f in faces:
        n = f.normal
        if n.length < 1e-12:
            continue
        if any(n.dot(r.normal) >= math.cos(angle) for r in refs):
            acc += n * max(f.calc_area(), 1e-12)
    if acc.length < 1e-12:
        return vert.normal.copy()
    return acc.normalized()


def curve_point(a, b, na, nb, t):
    """Cubic Hermite point between a and b whose tangents lie in the planes
    perpendicular to the end normals. For a chord of a circle this follows the
    arc; for a flat or straight edge it stays a straight line."""
    d = b - a
    length = d.length
    if length < 1e-12:
        return a.lerp(b, t)
    ta = d - na * d.dot(na)
    tb = d - nb * d.dot(nb)
    if ta.length < 1e-12 or tb.length < 1e-12:
        return a.lerp(b, t)
    ta = ta.normalized() * length
    tb = tb.normalized() * length
    t2 = t * t
    t3 = t2 * t
    h00 = 2 * t3 - 3 * t2 + 1
    h10 = t3 - 2 * t2 + t
    h01 = -2 * t3 + 3 * t2
    h11 = t3 - t2
    return a * h00 + ta * h10 + b * h01 + tb * h11


def surface_bvh(bm):
    """BVH of the current surface (copy of the coordinates).
    2.5: built in C from the BMesh (was a Python copy of every vertex/face)."""
    try:
        return BVHTree.FromBMesh(bm)
    except (TypeError, ValueError, RuntimeError):
        verts = [v.co.copy() for v in bm.verts]
        bm.verts.index_update()
        polys = [[v.index for v in f.verts] for f in bm.faces]
        return BVHTree.FromPolygons(verts, polys, all_triangles=False)


def _boundary_segments(bm):
    return [(e.verts[0].co.copy(), e.verts[1].co.copy()) for e in bm.edges if e.is_boundary]


def _nearest_on_segments(p, segments):
    best = None
    best_d = None
    for a, b in segments:
        ab = b - a
        L = ab.length_squared
        t = 0.0 if L < 1e-24 else max(0.0, min(1.0, (p - a).dot(ab) / L))
        q = a + ab * t
        d = (p - q).length_squared
        if best_d is None or d < best_d:
            best, best_d = q, d
    return best


def relax_keep_shape(bm, movable, intensity, iterations, slide_boundary=False, pinned=()):
    """Relax only along the surface, then project onto the original surface.

    movable: interior vertices allowed to move.
    slide_boundary: open-boundary vertices in movable slide along the boundary
    (using only their boundary neighbours) and are projected back onto the
    original boundary, so round holes and rims keep their shape.

    2.5: same result as before, but only the vertices around the movable ones
    are copied and only their normals are updated each pass, so relaxing a small
    area of a big mesh no longer costs a full-mesh update per iteration.
    """
    bvh = surface_bvh(bm)
    segments = _boundary_segments(bm) if slide_boundary else []
    pinned = set(pinned)
    bm.verts.index_update()
    # 2.5: fixed order (a set of vertices iterates differently on every run).
    movable = sorted((v for v in movable if v.is_valid and v not in pinned), key=lambda v: v.index)
    boundary = {v for v in movable if v.is_boundary}
    # Topology does not change here: neighbours and touched faces are fixed.
    nbrs = {}
    for v in movable:
        if v in boundary:
            if slide_boundary:
                nbrs[v] = [e.other_vert(v) for e in v.link_edges if e.is_boundary]
        else:
            nbrs[v] = [e.other_vert(v) for e in v.link_edges]
    touched = set(movable)
    for lst in nbrs.values():
        touched.update(lst)
    faces = {f for v in movable for f in v.link_faces}
    # Vertices whose normal can change when the movable ones move.
    normal_verts = {u for f in faces for u in f.verts}
    moved = 0
    for _ in range(iterations):
        old = {v: v.co.copy() for v in touched}
        updates = {}
        for v in movable:
            if v in boundary:
                if not slide_boundary:
                    continue
                nbs = nbrs[v]
                if len(nbs) != 2:
                    continue
                avg = (old[nbs[0]] + old[nbs[1]]) * 0.5
                target = old[v].lerp(avg, intensity)
                q = _nearest_on_segments(target, segments) if segments else None
                updates[v] = q if q is not None else target
                continue
            nbs = nbrs[v]
            if not nbs:
                continue
            avg = sum((old[n] for n in nbs), Vector((0.0, 0.0, 0.0))) / len(nbs)
            delta = avg - old[v]
            n = v.normal
            if n.length > 1e-12:
                delta = delta - n * delta.dot(n)   # tangent only: no shrinking
            target = old[v] + delta * intensity
            hit = bvh.find_nearest(target)
            updates[v] = hit[0] if hit[0] is not None else target
        for v, co in updates.items():
            v.co = co
        moved = max(moved, len(updates))
        if len(faces) * 4 < len(bm.faces):
            for f in faces:
                f.normal_update()
            for u in normal_verts:
                u.normal_update()
        else:
            bm.normal_update()
    return moved


def falloff_weights(bm, verts, mode='SMOOTH'):
    """Weight 0..1 per selected vertex by edge-distance from the selection border
    (Dijkstra over edge lengths). The border gets 0, the deepest point 1, so a
    circular selection inflates into a dome instead of a plateau with a cliff."""
    import heapq
    verts = set(verts)
    if mode == 'CONSTANT' or not verts:
        return {v: 1.0 for v in verts}
    border = set()
    for v in verts:
        if v.is_boundary or any(e.other_vert(v) not in verts for e in v.link_edges):
            border.add(v)
    if not border or border == verts:
        return {v: 1.0 for v in verts}
    # 2.5: deterministic order (sorted by index, ties broken by a counter, not id()).
    bm.verts.index_update()
    border = sorted(border, key=lambda v: v.index)
    dist = {v: 0.0 for v in border}
    heap = [(0.0, i, v) for i, v in enumerate(border)]
    tick = len(heap)
    heapq.heapify(heap)
    while heap:
        d, _i, v = heapq.heappop(heap)
        if d > dist.get(v, float('inf')):
            continue
        for e in v.link_edges:
            o = e.other_vert(v)
            if o not in verts:
                continue
            nd = d + e.calc_length()
            if nd < dist.get(o, float('inf')):
                dist[o] = nd
                tick += 1
                heapq.heappush(heap, (nd, tick, o))
    dmax = max(dist.values()) or 1.0
    out = {}
    for v in verts:
        x = min(1.0, dist.get(v, dmax) / dmax)
        if mode == 'SPHERE':
            out[v] = math.sqrt(max(0.0, 1.0 - (1.0 - x) ** 2))   # round (circular) profile
        else:
            out[v] = x * x * (3.0 - 2.0 * x)                     # smoothstep
    return out
