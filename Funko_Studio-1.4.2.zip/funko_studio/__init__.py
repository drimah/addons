bl_info = {
    "name": "Funko Studio",
    "author": "Funko Studio Project",
    "version": (1, 4, 2),
    "blender": (4, 2, 0),
    "location": "Funko Studio workspace",
    "description": "A dedicated character customizer workspace",
    "category": "3D View",
}

_MODULES = ("constants", "state", "eyes", "materials", "workspace", "characters", "thumbnails",
            "icons", "ui_draw", "events", "operators", "print_tools", "export", "startup")

# Add-on reloaded or upgraded inside a running Blender: submodules from the
# previous version may still be cached, so refresh the ones that exist and then
# import everything (new modules included).
import importlib
import sys as _sys
for _name in _MODULES:
    _mod = _sys.modules.get(__name__ + "." + _name)
    if _mod is not None:
        importlib.reload(_mod)

from . import (constants, state, eyes, materials, workspace, characters, thumbnails, icons,
               ui_draw, events, operators, print_tools, export, startup)

import bpy

_CLASSES = events.CLASSES + operators.CLASSES + print_tools.CLASSES + export.CLASSES


def register():
    state.register()
    for c in _CLASSES:
        bpy.utils.register_class(c)
    startup.register()


def unregister():
    startup.unregister()
    for c in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
    state.unregister()
    thumbnails.clear()


if __name__ == "__main__":
    register()
