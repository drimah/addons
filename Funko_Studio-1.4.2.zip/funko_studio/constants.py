"""Shared names, categories and colour tables for Funko Studio."""
import os

ADDON_DIR = os.path.dirname(__file__)
ASSET_DIR = os.path.join(ADDON_DIR, "assets")

SCENE_NAME = "Funko Studio Scene"
WORKSPACE_NAME = "Funko Studio"
COLLECTION_NAME = "FUNKO_CHARACTER"
LAYOUT_MARKER = "funko_studio_layout"
LAYOUT_VERSION = 2
VIEWPORT_FACTOR = 0.65          # left viewport share of the workspace width
MENU_SPACE = 'TEXT_EDITOR'      # light editor used only as the Funko canvas

CATEGORIES = ["BODY", "LASHES", "HAIR_HATS", "GLASSES", "TOPS", "BOTTOMS",
              "ACCESSORY_1", "ACCESSORY_2", "BUDDIES", "NAME", "PRINT_STUDIO"]
CATEGORY_LABELS = {"BODY": "BODY", "LASHES": "LASHES", "HAIR_HATS": "HAIR & HATS",
                   "GLASSES": "GLASSES", "TOPS": "TOPS & OUTFITS", "BOTTOMS": "BOTTOMS",
                   "ACCESSORY_1": "ACCESSORY 1", "ACCESSORY_2": "ACCESSORY 2",
                   "BUDDIES": "BUDDIES", "NAME": "NAME", "PRINT_STUDIO": "PRINT STUDIO"}
# Tab groups in the icon rail (visual spacing between groups, like Blender's Properties editor)
TAB_GROUPS = [["BODY", "LASHES"],
              ["HAIR_HATS", "GLASSES", "TOPS", "BOTTOMS"],
              ["ACCESSORY_1", "ACCESSORY_2", "BUDDIES"],
              ["NAME"],
              ["PRINT_STUDIO"]]

SKIN_TONES = {
    "PORCELAIN": (0.96, 0.86, 0.78, 1), "IVORY": (0.91, 0.75, 0.62, 1),
    "LIGHT": (0.82, 0.61, 0.46, 1), "MEDIUM": (0.67, 0.43, 0.29, 1),
    "TAN": (0.53, 0.32, 0.20, 1), "BROWN": (0.37, 0.21, 0.13, 1),
    "DEEP": (0.22, 0.12, 0.08, 1), "PINK": (0.92, 0.43, 0.55, 1),
    "RED": (0.78, 0.08, 0.10, 1), "ORANGE": (0.98, 0.36, 0.06, 1),
    "YELLOW": (0.98, 0.78, 0.08, 1), "GREEN": (0.12, 0.55, 0.24, 1),
    "MINT": (0.28, 0.82, 0.63, 1), "CYAN": (0.05, 0.68, 0.82, 1),
    "BLUE": (0.08, 0.30, 0.88, 1), "VIOLET": (0.38, 0.22, 0.78, 1),
    "PURPLE": (0.62, 0.20, 0.72, 1), "GRAY": (0.48, 0.50, 0.54, 1),
    "WHITE": (0.94, 0.94, 0.94, 1), "BLACK": (0.035, 0.035, 0.04, 1),
}
EYE_TONES = {
    "BLACK": (0.025, 0.02, 0.018, 1), "BROWN": (0.20, 0.075, 0.025, 1),
    "HAZEL": (0.38, 0.25, 0.08, 1), "GREEN": (0.08, 0.42, 0.12, 1),
    "BLUE": (0.04, 0.24, 0.78, 1), "GRAY": (0.36, 0.42, 0.48, 1),
    "VIOLET": (0.38, 0.12, 0.65, 1), "RED": (0.72, 0.025, 0.04, 1),
    "PINK": (0.92, 0.25, 0.48, 1),
}

# Approved visual identity
COL_BG = (.055, .06, .07, 1.0)
COL_RAIL = (.040, .044, .052, 1.0)
COL_PANEL = (.075, .082, .098, 1.0)
COL_CARD = (.10, .11, .13, 1.0)
COL_BUTTON = (.16, .17, .20, 1.0)
COL_BUTTON_HOVER = (.22, .23, .27, 1.0)
COL_BLUE = (.02, .36, .96, 1.0)
COL_BLUE_HOVER = (.10, .45, 1.0, 1.0)
COL_RING = (.28, .29, .32, 1.0)
COL_TEXT = (.93, .94, .97, 1.0)
COL_TEXT_DIM = (.72, .75, .81, 1.0)
COL_ACCENT_TEXT = (.35, .66, 1.0, 1.0)
