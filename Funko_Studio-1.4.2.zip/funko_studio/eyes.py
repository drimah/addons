"""Eye-disc detection on the single-surface Funko OBJ models.

The bundled models are one mesh: the eyes are slightly raised discs on the
front of the head, surrounded by a groove. Detection works in world space:

1. Build a depth map (front-most surface) of the forward-facing head faces.
2. Protrusion = smoothed surface - real surface (what sticks out locally).
3. In the eye band of each side, the protrusion peak gives the eye centre
   and radius (ears and brows lie outside the band).
4. Grow a region over the mesh from the centre face while faces keep sticking
   out; the groove around the eye stops the growth, so lashes and brows are
   never included.
"""
import numpy as np


def _adjacency(me):
    """Face neighbours through shared edges (CSR arrays)."""
    n = len(me.polygons)
    le = np.empty(len(me.loops), dtype=np.int64); me.loops.foreach_get("edge_index", le)
    lt = np.empty(n, dtype=np.int64); me.polygons.foreach_get("loop_total", lt)
    lf = np.repeat(np.arange(n), lt)
    order = np.argsort(le, kind="stable")
    e_sorted = le[order]; f_sorted = lf[order]
    same = e_sorted[1:] == e_sorted[:-1]
    a = f_sorted[:-1][same]; b = f_sorted[1:][same]
    src = np.concatenate([a, b]); dst = np.concatenate([b, a])
    o = np.argsort(src, kind="stable"); src = src[o]; dst = dst[o]
    ptr = np.searchsorted(src, np.arange(n + 1))
    return ptr, dst


def _grow(adj, seed, ok):
    ptr, dst = adj
    seen = np.zeros(len(ok), dtype=bool); seen[seed] = True
    stack = [seed]; out = [seed]
    while stack:
        f = stack.pop()
        for g in dst[ptr[f]:ptr[f + 1]]:
            if not seen[g] and ok[g]:
                seen[g] = True; stack.append(g); out.append(g)
    return np.array(out, dtype=np.int64)


def _box_blur(img, r):
    k = np.ones(2 * r + 1) / (2 * r + 1)
    out = np.apply_along_axis(lambda v: np.convolve(np.pad(v, r, mode='edge'), k, 'valid'), 1, img)
    return np.apply_along_axis(lambda v: np.convolve(np.pad(v, r, mode='edge'), k, 'valid'), 0, out)


def eye_faces(ob, x_lo=0.08, x_hi=0.32, z_lo=0.62, z_hi=0.79, fb_factor=0.45, limit=0.95):
    """Return the polygon indices of both eye discs of `ob`."""
    me = ob.data
    n = len(me.polygons)
    if n == 0:
        return np.array([], dtype=np.int64)
    M = np.array(ob.matrix_world)
    co = np.empty(n * 3); me.polygons.foreach_get("center", co)
    co = co.reshape(n, 3) @ M[:3, :3].T + M[:3, 3]
    nr = np.empty(n * 3); me.polygons.foreach_get("normal", nr)
    nr = nr.reshape(n, 3) @ M[:3, :3].T
    nr /= np.linalg.norm(nr, axis=1, keepdims=True) + 1e-12

    zmin, zmax = co[:, 2].min(), co[:, 2].max(); H = zmax - zmin
    xmin, xmax = co[:, 0].min(), co[:, 0].max(); W = xmax - xmin; xc = (xmin + xmax) / 2
    if H <= 0 or W <= 0:
        return np.array([], dtype=np.int64)
    head = (co[:, 2] > zmin + 0.5 * H) & (nr[:, 1] < -0.2)     # front faces of the head (-Y is front)

    N = 96; z0 = zmin + 0.5 * H; zh = 0.5 * H
    gi = np.clip(((co[:, 0] - xmin) / W * N).astype(int), 0, N - 1)
    gj = np.clip(((co[:, 2] - z0) / zh * N).astype(int), 0, N - 1)
    depth = np.full((N, N), np.inf)
    hk = np.nonzero(head)[0]
    np.minimum.at(depth, (gj[hk], gi[hk]), co[hk, 1])
    valid = np.isfinite(depth)
    if not valid.any():
        return np.array([], dtype=np.int64)
    filled = np.where(valid, depth, np.nan)
    for _ in range(6):
        m = np.isnan(filled)
        if not m.any():
            break
        pad = np.pad(filled, 1, constant_values=np.nan)
        st = np.stack([pad[:-2, 1:-1], pad[2:, 1:-1], pad[1:-1, :-2], pad[1:-1, 2:]])
        cnt = (~np.isnan(st)).sum(0)
        sm = np.where(np.isnan(st), 0.0, st).sum(0)
        fill = np.where(cnt > 0, sm / np.maximum(cnt, 1), np.nan)
        filled[m] = fill[m]
    filled = np.where(np.isnan(filled), np.nanmax(filled), filled)
    base = _box_blur(filled, max(2, int(N * 0.07)))
    prot = base - filled

    xs_rel = (np.arange(N) + .5) / N * W + xmin - xc
    zs_rel = ((np.arange(N) + .5) / N * zh + z0 - zmin) / H
    fb = base[gj, gi] - co[:, 1]
    adj = None
    result = []
    for side in (-1, 1):
        band = ((zs_rel[:, None] > z_lo) & (zs_rel[:, None] < z_hi) &
                (side * xs_rel[None, :] > x_lo * W) & (side * xs_rel[None, :] < x_hi * W))
        p = np.where(band & valid, prot, 0)
        if p.max() <= 0:
            continue
        thr = 0.35 * p.max()
        wts = np.where(p > thr, p, 0)
        jj, ii = np.nonzero(wts)
        cz = z0 + (np.average(jj, weights=wts[jj, ii]) + .5) / N * zh
        cx = xmin + (np.average(ii, weights=wts[jj, ii]) + .5) / N * W
        rad = np.sqrt((wts > 0).sum() / np.pi) * W / N * 1.15
        d = np.hypot(co[:, 0] - cx, co[:, 2] - cz)
        cand = np.nonzero(head & (d < rad * 0.5))[0]
        if not len(cand):
            continue
        if adj is None:
            adj = _adjacency(me)
        seed = cand[np.argmax(fb[cand])]
        ok = head & (fb > thr * fb_factor) & (d < rad * limit)
        result.append(_grow(adj, seed, ok))
    return np.concatenate(result) if result else np.array([], dtype=np.int64)
