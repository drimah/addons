"""Skin and eye material management."""
import bpy
import numpy as np
from .constants import COLLECTION_NAME, SKIN_TONES, EYE_TONES
from . import eyes

SKIN_MAT = "Funko Studio · Skin Tone"
EYE_MAT = "Funko Studio · Eyes"


def current_skin_color(st):
    if st.skin_tone == 'CUSTOM':
        return tuple(st.custom_skin_color)
    return SKIN_TONES.get(st.skin_tone, SKIN_TONES["MEDIUM"])


def current_eye_color(st):
    if st.eye_color == 'CUSTOM':
        return tuple(st.custom_eye_color)
    return EYE_TONES.get(st.eye_color, EYE_TONES["BLACK"])


def _set_material(name, color):
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.diffuse_color = color
    try:
        if not mat.use_nodes:
            mat.use_nodes = True
    except Exception:
        pass
    if mat.node_tree:
        bsdf = next((n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf:
            bsdf.inputs["Base Color"].default_value = color
            bsdf.inputs["Roughness"].default_value = 0.42
    return mat


def _base_meshes():
    col = bpy.data.collections.get(COLLECTION_NAME)
    if not col:
        return []
    return [ob for ob in col.objects if ob.type == "MESH" and ob.get("funko_studio_base")]


def apply_skin_tone(context):
    st = context.scene.funko_studio
    mat = _set_material(SKIN_MAT, current_skin_color(st))
    for ob in _base_meshes():
        if len(ob.data.materials) == 0:
            ob.data.materials.append(mat)
        else:
            ob.data.materials[0] = mat
    apply_eye_color(context)


def apply_eye_color(context):
    """Assign the eye material to the eye patches only (slot 1); skin stays in slot 0."""
    st = context.scene.funko_studio
    mat = _set_material(EYE_MAT, current_eye_color(st))
    for ob in _base_meshes():
        me = ob.data
        if not me.vertices:
            continue
        if len(me.materials) == 0:
            me.materials.append(_set_material(SKIN_MAT, current_skin_color(st)))
        if len(me.materials) < 2:
            me.materials.append(mat)
        else:
            me.materials[1] = mat
        if ob.get("funko_eyes_assigned") and len(me.polygons) == ob.get("funko_eyes_faces", -1):
            continue
        # Eye discs only (slot 1); everything else stays skin (slot 0).
        index = np.zeros(len(me.polygons), dtype=np.int32)
        index[eyes.eye_faces(ob)] = 1
        me.polygons.foreach_set("material_index", index)
        me.update()
        ob["funko_eyes_assigned"] = True
        ob["funko_eyes_faces"] = len(me.polygons)
