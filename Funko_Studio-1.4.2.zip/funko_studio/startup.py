"""Startup, watcher timer and file-load handlers.

A light persistent timer keeps the Funko workspace healthy: it builds the
two-area layout once, loads the first character once, and makes sure exactly
one interface modal and one draw handler exist.
"""
import bpy
from bpy.app.handlers import persistent
from .constants import SCENE_NAME, COLLECTION_NAME
from . import workspace, characters, events

_state = {"switch": False}


def _first_window():
    wm = bpy.context.window_manager
    if wm is None or not wm.windows:
        return None
    return bpy.context.window or wm.windows[0]


def _start_modal(window):
    rt = events._rt()
    if rt.get("running"):
        return
    with bpy.context.temp_override(window=window, screen=window.screen):
        bpy.ops.funko_studio.interface('INVOKE_DEFAULT')


def _ensure_character(window):
    scene = window.scene
    if scene is None or scene.name != SCENE_NAME or scene.get("funko_initialized"):
        return
    col = bpy.data.collections.get(COLLECTION_NAME)
    if not (col and any(o.get("funko_studio_base") for o in col.objects)):
        with bpy.context.temp_override(window=window, screen=window.screen, scene=scene):
            characters.load_character(bpy.context, scene.funko_studio.gender)
    scene["funko_initialized"] = True


def _tick():
    try:
        window = _first_window()
        if window is None:
            return 0.5
        if _state["switch"]:
            if workspace.ensure_workspace(bpy.context, switch=True) is None:
                return 0.5
            _state["switch"] = False
            return 0.2          # let Blender build the new screen first
        if events._rt().get("draw") is None:
            events.add_draw_handler()
        for win in bpy.context.window_manager.windows:
            if not workspace.is_funko_window(win):
                continue
            if not workspace.ensure_layout(win):
                return 0.3
            _ensure_character(win)
            if win.screen.get("funko_framed") is None:
                with bpy.context.temp_override(window=win, screen=win.screen):
                    characters.frame_character(bpy.context)
                win.screen["funko_framed"] = True
        _start_modal(window)
    except Exception as exc:          # never let the timer die silently
        print("Funko Studio:", exc)
        return 1.0
    return 1.0


def schedule(switch=False):
    _state["switch"] = _state["switch"] or switch
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.3, persistent=True)


@persistent
def _on_load_pre(*_args):
    events.stop_modal()


@persistent
def _on_load_post(*_args):
    schedule(switch=False)


def register():
    if _on_load_pre not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(_on_load_pre)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    schedule(switch=True)


def unregister():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    for lst, fn in ((bpy.app.handlers.load_pre, _on_load_pre),
                    (bpy.app.handlers.load_post, _on_load_post)):
        while fn in lst:
            lst.remove(fn)
    events.stop_modal()
    events.remove_draw_handler()
