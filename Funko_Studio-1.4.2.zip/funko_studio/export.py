"""STL export of selected parts in millimetres (unchanged from 1.4.1)."""
import os
import bpy
from bpy.types import Operator


class FUNKO_OT_print_export_parts(Operator):
    bl_idname = "funko_studio.print_export_parts"
    bl_label = "Export Selected Parts (STL)"
    bl_description = "Export each selected mesh as an individual STL in millimetres"
    bl_options = {'REGISTER'}
    directory: bpy.props.StringProperty(subtype='DIR_PATH')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if not meshes:
            self.report({'ERROR'}, "Select one or more mesh parts")
            return {'CANCELLED'}
        os.makedirs(self.directory, exist_ok=True)
        old = list(context.selected_objects); active = context.view_layer.objects.active
        exported = 0
        for ob in meshes:
            bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); context.view_layer.objects.active = ob
            path = os.path.join(self.directory, bpy.path.clean_name(ob.name) + '.stl')
            try:
                if hasattr(bpy.ops.wm, 'stl_export'):
                    bpy.ops.wm.stl_export(filepath=path, export_selected_objects=True, global_scale=1000.0 * context.scene.unit_settings.scale_length)
                else:
                    bpy.ops.export_mesh.stl(filepath=path, use_selection=True, global_scale=1000.0 * context.scene.unit_settings.scale_length)
                exported += 1
            except Exception as exc:
                self.report({'WARNING'}, f"Could not export {ob.name}: {exc}")
        bpy.ops.object.select_all(action='DESELECT')
        for ob in old:
            if ob.name in bpy.data.objects: ob.select_set(True)
        if active and active.name in bpy.data.objects: context.view_layer.objects.active = active
        self.report({'INFO'}, f"Exported {exported} STL file(s)")
        return {'FINISHED'}


CLASSES = (FUNKO_OT_print_export_parts,)
