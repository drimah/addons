"""Custom Funko Studio interface, drawn only inside the right-hand editor.

Layout (region coordinates, y up):
    [icon tab rail] [ header: category title            ]
                    [ scrollable content (clipped)      ]
                    [ footer: BACK  HELP  NEXT           ]

Every interactive element registers a hit box while it is drawn, so the
click handler (events.py) never duplicates layout maths.
"""
import math
import bpy
import blf
import gpu
from gpu_extras.batch import batch_for_shader
from .constants import (CATEGORIES, CATEGORY_LABELS, TAB_GROUPS, SKIN_TONES, EYE_TONES,
                        COL_BG, COL_RAIL, COL_PANEL, COL_CARD, COL_BUTTON, COL_BUTTON_HOVER,
                        COL_BLUE, COL_BLUE_HOVER, COL_RING, COL_TEXT, COL_TEXT_DIM, COL_ACCENT_TEXT)
from . import workspace, thumbnails, icons

# Interaction state shared with events.py
HITS = []            # list of (x, y, w, h, action)
UI = {"hover": None, "mouse": (-1, -1), "content_h": 0.0, "view_h": 0.0, "area": 0}

PRINT_GROUPS = [
    ("01  INSPECT", [("ANALYZE MODEL", "funko_studio.print_analyze"),
                     ("REPAIR GEOMETRY", "funko_studio.print_repair")]),
    ("02  ORGANIZE", [("SEPARATE LOOSE PARTS", "funko_studio.print_split_loose"),
                      ("DETECT REGIONS · REMESH ULTIMATE", "funko_studio.ru_detect"),
                      ("REMESH REGIONS · REMESH ULTIMATE", "funko_studio.ru_remesh")]),
    ("03  EXPORT", [("EXPORT SELECTED PARTS · STL", "funko_studio.print_export_parts")]),
]

_shader = None


def _sh():
    global _shader
    if _shader is None:
        _shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    return _shader


def rounded_rect(x, y, w, h, r, color):
    if w <= 0 or h <= 0:
        return
    r = max(0.0, min(r, w / 2, h / 2))
    if r < 0.5:
        verts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
        tris = [(0, 1, 2), (0, 2, 3)]
    else:
        poly = []
        for cx, cy, a0, a1 in ((x + w - r, y + r, -90, 0), (x + w - r, y + h - r, 0, 90),
                               (x + r, y + h - r, 90, 180), (x + r, y + r, 180, 270)):
            for i in range(9):
                a = math.radians(a0 + (a1 - a0) * i / 8)
                poly.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
        verts = [(x + w / 2, y + h / 2)] + poly
        n = len(poly)
        tris = [(0, i + 1, 1 + (i + 1) % n) for i in range(n)]
    sh = _sh()
    batch = batch_for_shader(sh, 'TRIS', {"pos": verts}, indices=tris)
    sh.bind()
    sh.uniform_float("color", color)
    batch.draw(sh)


def text(s, x, y, size, color=COL_TEXT):
    blf.size(0, size)
    blf.color(0, *color)
    blf.position(0, x, y, 0)
    blf.draw(0, s)


def text_w(s, size):
    blf.size(0, size)
    return blf.dimensions(0, s)[0]


def _hit(x, y, w, h, action, clip=None):
    if clip is not None:
        cy0, cy1 = clip
        if y + h < cy0 or y > cy1:
            return
        y0 = max(y, cy0); y1 = min(y + h, cy1)
        HITS.append((x, y0, w, y1 - y0, action))
    else:
        HITS.append((x, y, w, h, action))


def _hovered(action):
    return UI["hover"] == action


# ----------------------------------------------------------------- sections

def _draw_rail(u, h, st):
    rail_w = 46 * u
    rounded_rect(0, 0, rail_w, h, 0, COL_RAIL)
    tab = 34 * u
    x = (rail_w - tab) / 2
    y = h - 12 * u - tab
    for gi, group in enumerate(TAB_GROUPS):
        if gi:
            y -= 10 * u
        for key in group:
            action = ("tab", key)
            if st.category == key:
                bg = COL_BLUE
                tint = (1, 1, 1, 1)
            else:
                bg = COL_BUTTON_HOVER if _hovered(action) else COL_RAIL
                tint = (.70, .73, .78, 1)
            rounded_rect(x, y, tab, tab, 8 * u, bg)
            pad = 7 * u
            if not icons.draw_icon(key, x + pad, y + pad, tab - 2 * pad, tint, bg):
                label = CATEGORY_LABELS[key][:2]
                text(label, x + tab / 2 - text_w(label, 10 * u) / 2, y + tab / 2 - 4 * u, 10 * u, tint)
            _hit(x, y, tab, tab, action)
            y -= tab + 4 * u
    return rail_w


def _draw_tooltip(u, w, rail_w):
    hov = UI["hover"]
    if not (hov and hov[0] == "tab"):
        return
    box = next((b for b in HITS if b[4] == hov), None)
    if not box:
        return
    label = CATEGORY_LABELS[hov[1]]
    size = 11 * u
    tw = text_w(label, size) + 20 * u
    th = 24 * u
    tx = rail_w + 6 * u
    ty = box[1] + box[3] / 2 - th / 2
    rounded_rect(tx, ty, tw, th, th / 2, (.02, .022, .028, 1.0))
    text(label, tx + 10 * u, ty + 8 * u, size)


def _swatch_row(u, x0, cw, y, items, size, clip, ring_sel, on_click, buttons=None):
    """Draw a wrapped row of round swatches. Returns the y below the block."""
    gap = 8 * u
    max_per_row = max(1, int((cw + gap) // (size + gap)))
    cells = list(items) + (buttons or [])
    rows = max(1, math.ceil(len(cells) / max_per_row))
    per_row = max(1, math.ceil(len(cells) / rows))      # balanced rows
    for idx, cell in enumerate(cells):
        r, c = divmod(idx, per_row)
        sx = x0 + c * (size + gap)
        sy = y - size - r * (size + gap)
        if sy + size < clip[0] or sy > clip[1]:
            continue
        kind = cell[0]
        if kind == "btn":
            _, label, action, primary = cell
            col = (COL_BLUE_HOVER if _hovered(action) else COL_BLUE) if primary else \
                  (COL_BUTTON_HOVER if _hovered(action) else COL_BUTTON)
            rounded_rect(sx, sy, size, size, size / 2, col)
            fs = 15 * u
            text(label, sx + size / 2 - text_w(label, fs) / 2, sy + size / 2 - fs * 0.36, fs)
            _hit(sx, sy, size, size, action, clip)
        else:
            _, key, color = cell
            sel = ring_sel(key)
            ring = COL_BLUE if sel else ((.45, .47, .52, 1) if _hovered(on_click(key)) else COL_RING)
            b = (3 if sel else 2) * u
            rounded_rect(sx - b, sy - b, size + 2 * b, size + 2 * b, size / 2 + b, ring)
            rounded_rect(sx, sy, size, size, size / 2, color)
            _hit(sx - b, sy - b, size + 2 * b, size + 2 * b, on_click(key), clip)
    return y - rows * (size + gap)


def _draw_body(u, x0, cw, y, clip, st):
    # Character cards
    gap = 12 * u
    card_w = min((cw - gap) / 2, 230 * u)
    img_w = card_w - 16 * u
    img_h = img_w * 1.25
    card_h = img_h + 46 * u
    cards_x = x0 + (cw - (2 * card_w + gap)) / 2
    cy = y - card_h
    for i, gender in enumerate(("FEMALE", "MALE")):
        gx = cards_x + i * (card_w + gap)
        action = ("gender", gender)
        sel = st.gender == gender
        border = COL_BLUE if sel else (COL_BUTTON_HOVER if _hovered(action) else (.12, .13, .15, 1))
        rounded_rect(gx, cy, card_w, card_h, 14 * u, border)
        rounded_rect(gx + 3 * u, cy + 3 * u, card_w - 6 * u, card_h - 6 * u, 12 * u, COL_CARD)
        ix, iy = gx + 8 * u, cy + 38 * u
        rounded_rect(ix, iy, img_w, img_h, 4 * u, (0, 0, 0, 1))
        thumbnails.draw_image(thumbnails.thumbnail(gender), ix, iy, img_w, img_h)
        fs = 11 * u
        text(gender, gx + card_w / 2 - text_w(gender, fs) / 2, cy + 15 * u, fs)
        _hit(gx, cy, card_w, card_h, action, clip)
    y = cy - 26 * u

    sw = 22 * u
    # Skin tone
    text("SKIN TONE", x0, y - 10 * u, 10 * u, COL_TEXT_DIM)
    y -= 24 * u
    y = _swatch_row(u, x0, cw, y, [("sw", k, c) for k, c in SKIN_TONES.items()], sw, clip,
                    lambda k: st.skin_tone == k, lambda k: ("skin", k))
    customs = [("sw", i, tuple(s.color)) for i, s in enumerate(st.custom_skin_swatches)]
    y = _swatch_row(u, x0, cw, y, customs, sw, clip,
                    lambda i: st.skin_tone == 'CUSTOM' and st.custom_skin_index == i,
                    lambda i: ("skin_custom", i),
                    buttons=[("btn", "+", ("skin_add",), True), ("btn", "−", ("skin_del",), False)])
    y -= 14 * u
    # Eye colour
    text("EYE COLOR", x0, y - 10 * u, 10 * u, COL_TEXT_DIM)
    y -= 24 * u
    y = _swatch_row(u, x0, cw, y, [("sw", k, c) for k, c in EYE_TONES.items()], sw, clip,
                    lambda k: st.eye_color == k, lambda k: ("eye", k))
    customs = [("sw", i, tuple(s.color)) for i, s in enumerate(st.custom_eye_swatches)]
    y = _swatch_row(u, x0, cw, y, customs, sw, clip,
                    lambda i: st.eye_color == 'CUSTOM' and st.custom_eye_index == i,
                    lambda i: ("eye_custom", i),
                    buttons=[("btn", "+", ("eye_add",), True), ("btn", "−", ("eye_del",), False)])
    return y


def _draw_print(u, x0, cw, y, clip):
    for heading, buttons in PRINT_GROUPS:
        y -= 14 * u
        text(heading, x0, y, 10 * u, COL_ACCENT_TEXT)
        y -= 14 * u
        for label, opid in buttons:
            bh = 36 * u
            by = y - bh
            action = ("op", opid)
            primary = "EXPORT" in label
            if by + bh >= clip[0] and by <= clip[1]:
                col = (COL_BLUE_HOVER if _hovered(action) else COL_BLUE) if primary else \
                      (COL_BUTTON_HOVER if _hovered(action) else COL_BUTTON)
                rounded_rect(x0, by, cw, bh, bh / 2, col)
                text(label, x0 + 16 * u, by + bh / 2 - 4 * u, 10 * u)
                _hit(x0, by, cw, bh, action, clip)
            y = by - 8 * u
        y -= 6 * u
    y -= 6 * u
    text("Remesh Ultimate connection is optional.", x0, y - 10 * u, 9 * u, (.65, .68, .73, 1))
    return y - 20 * u


def _draw_empty(u, x0, cw, y):
    bh = 120 * u
    rounded_rect(x0, y - bh, cw, bh, 14 * u, COL_CARD)
    msg = "No items available in this category yet."
    fs = 11 * u
    text(msg, x0 + cw / 2 - text_w(msg, fs) / 2, y - bh / 2 - 4 * u, fs, COL_TEXT_DIM)
    return y - bh


def _draw_footer(u, x0, cw, st):
    fh = 64 * u
    rounded_rect(x0 - 14 * u, 0, cw + 28 * u, fh, 0, COL_BG)
    bh = 36 * u
    by = (fh - bh) / 2
    idx = CATEGORIES.index(st.category)
    specs = [("BACK", ("back",), 96 * u, False, idx > 0),
             ("HELP", ("help",), 84 * u, False, True),
             ("NEXT", ("next",), 108 * u, True, idx < len(CATEGORIES) - 1)]
    total = sum(s[2] for s in specs) + 10 * u * (len(specs) - 1)
    bx = x0 + max(0, (cw - total) / 2)
    for label, action, bw, primary, enabled in specs:
        if primary:
            col = COL_BLUE_HOVER if _hovered(action) and enabled else COL_BLUE
        else:
            col = COL_BUTTON_HOVER if _hovered(action) and enabled else COL_BUTTON
        if not enabled:
            col = (col[0] * .6, col[1] * .6, col[2] * .6, 1)
        rounded_rect(bx, by, bw, bh, bh / 2, col)
        fs = 12 * u
        tc = COL_TEXT if enabled else (.5, .52, .56, 1)
        text(label, bx + bw / 2 - text_w(label, fs) / 2, by + bh / 2 - 4.5 * u, fs, tc)
        if enabled:
            _hit(bx, by, bw, bh, action)
        bx += bw + 10 * u
    return fh


def _draw_help(u, w, h, x0, cw):
    rounded_rect(0, 0, w, h, 0, (.035, .038, .045, 1.0))
    lines = [("Tabs", "jump to a step"),
             ("BACK / NEXT", "previous / next step"),
             ("Card", "load FEMALE or MALE"),
             ("+", "add a custom color"),
             ("−", "remove the selected custom color"),
             ("Mouse wheel", "scroll this panel")]
    lh = 24 * u
    bh = 56 * u + lh * len(lines)
    bw = min(cw, 340 * u)
    bx = x0 + (cw - bw) / 2
    by = h / 2 - bh / 2
    rounded_rect(bx, by, bw, bh, 16 * u, COL_PANEL)
    text("HELP", bx + 18 * u, by + bh - 30 * u, 13 * u, COL_ACCENT_TEXT)
    yy = by + bh - 58 * u
    for k, v in lines:
        text(k, bx + 18 * u, yy, 10 * u)
        text(v, bx + 130 * u, yy, 10 * u, COL_TEXT_DIM)
        yy -= lh
    HITS.clear()
    _hit(0, 0, w, h, ("help",))


# ----------------------------------------------------------------- entry point

def draw_callback():
    ctx = bpy.context
    area = ctx.area
    region = ctx.region
    if area is None or region is None or region.type != 'WINDOW':
        return
    if not workspace.is_funko_window(ctx.window):
        return
    if workspace.find_menu_area(ctx.screen) != area:
        return
    scene = ctx.scene
    if scene is None or not hasattr(scene, "funko_studio"):
        return
    st = scene.funko_studio
    u = ctx.preferences.system.ui_scale
    w, h = region.width, region.height
    HITS.clear()
    UI["area"] = area.as_pointer()

    gpu.state.blend_set('ALPHA')
    rounded_rect(0, 0, w, h, 0, COL_BG)
    rail_w = _draw_rail(u, h, st)

    pad = 16 * u
    x0 = rail_w + pad
    cw = max(120 * u, w - x0 - pad)
    # Header
    title = CATEGORY_LABELS[st.category]
    text(title, x0, h - 38 * u, 20 * u)
    header_h = 58 * u
    footer_h = 64 * u
    clip = (footer_h, h - header_h)
    view_h = clip[1] - clip[0]
    UI["view_h"] = view_h

    # Scrollable content, clipped between header and footer
    max_scroll = max(0.0, UI["content_h"] - view_h)
    scroll = min(max(st.scroll, 0.0), max_scroll)
    top = clip[1] - 6 * u + scroll
    gpu.state.scissor_test_set(True)
    gpu.state.scissor_set(int(rail_w), int(clip[0]), int(w - rail_w), int(view_h))
    if st.category == 'BODY':
        bottom = _draw_body(u, x0, cw, top, clip, st)
    elif st.category == 'PRINT_STUDIO':
        bottom = _draw_print(u, x0, cw, top, clip)
    else:
        bottom = _draw_empty(u, x0, cw, top)
    gpu.state.scissor_test_set(False)
    UI["content_h"] = (top - bottom) + 12 * u

    # Scrollbar, only when needed
    if UI["content_h"] > view_h + 1:
        track_h = view_h - 8 * u
        bar_h = max(30 * u, track_h * view_h / UI["content_h"])
        frac = scroll / max_scroll if max_scroll else 0
        bar_y = clip[1] - 4 * u - bar_h - frac * (track_h - bar_h)
        rounded_rect(w - 7 * u, bar_y, 4 * u, bar_h, 2 * u, (.30, .32, .36, 1))

    _draw_footer(u, x0, cw, st)
    _draw_tooltip(u, w, rail_w)
    if st.show_help:
        _draw_help(u, w, h, x0, cw)
    gpu.state.blend_set('NONE')


def hit_test(x, y):
    for bx, by, bw, bh, action in reversed(HITS):
        if bx <= x <= bx + bw and by <= y <= by + bh:
            return action
    return None
