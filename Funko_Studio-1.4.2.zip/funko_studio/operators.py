"""Public operators: open workspace, choose character, custom colours."""
import bpy
from bpy.props import EnumProperty, FloatVectorProperty
from bpy.types import Operator
from .constants import LAYOUT_MARKER, WORKSPACE_NAME
from . import workspace, characters, materials, events


def _redraw(context):
    for win in context.window_manager.windows:
        for area in win.screen.areas:
            area.tag_redraw()


class FUNKO_OT_open(Operator):
    bl_idname = "funko_studio.open"
    bl_label = "Open Funko Studio"
    bl_description = "Create (once) and open the Funko Studio workspace"

    def execute(self, context):
        window = workspace.ensure_workspace(context, switch=True)
        if window is None:
            self.report({'ERROR'}, "Blender could not create the Funko Studio workspace")
            return {'CANCELLED'}
        # Rebuild the two-area layout only if the Funko editor is missing.
        ws = bpy.data.workspaces.get(WORKSPACE_NAME)
        screen = ws.screens[0] if ws and len(ws.screens) else None
        if ws is not None and workspace.find_menu_area(screen) is None and LAYOUT_MARKER in ws:
            del ws[LAYOUT_MARKER]
        from . import startup
        startup.schedule()
        return {'FINISHED'}


class FUNKO_OT_choose(Operator):
    bl_idname = "funko_studio.choose"
    bl_label = "Choose Character"
    gender: EnumProperty(items=[('FEMALE', "Female", ""), ('MALE', "Male", "")])

    def execute(self, context):
        characters.load_character(context, self.gender)
        _redraw(context)
        return {'FINISHED'}


class FUNKO_OT_custom_skin(Operator):
    bl_idname = "funko_studio.custom_skin"
    bl_label = "Custom Skin Color"
    bl_options = {'REGISTER', 'UNDO'}
    color: FloatVectorProperty(name="Skin Color", subtype='COLOR', size=4, min=0, max=1,
                               default=(0.67, 0.43, 0.29, 1))

    def invoke(self, context, event):
        self.color = context.scene.funko_studio.custom_skin_color
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        self.layout.template_color_picker(self, "color", value_slider=True)
        self.layout.prop(self, "color", text="")

    def execute(self, context):
        st = context.scene.funko_studio
        sw = st.custom_skin_swatches.add()
        sw.color = self.color
        st.custom_skin_index = len(st.custom_skin_swatches) - 1
        st.custom_skin_color = self.color
        st.skin_tone = 'CUSTOM'
        materials.apply_skin_tone(context)
        _redraw(context)
        return {'FINISHED'}


class FUNKO_OT_custom_eyes(Operator):
    bl_idname = "funko_studio.custom_eyes"
    bl_label = "Custom Eye Color"
    bl_options = {'REGISTER', 'UNDO'}
    color: FloatVectorProperty(name="Eye Color", subtype='COLOR', size=4, min=0, max=1,
                               default=(0.025, 0.02, 0.018, 1))

    def invoke(self, context, event):
        self.color = context.scene.funko_studio.custom_eye_color
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        self.layout.template_color_picker(self, "color", value_slider=True)
        self.layout.prop(self, "color", text="")

    def execute(self, context):
        st = context.scene.funko_studio
        sw = st.custom_eye_swatches.add()
        sw.color = self.color
        st.custom_eye_index = len(st.custom_eye_swatches) - 1
        st.custom_eye_color = self.color
        st.eye_color = 'CUSTOM'
        materials.apply_eye_color(context)
        _redraw(context)
        return {'FINISHED'}


CLASSES = (FUNKO_OT_open, FUNKO_OT_choose, FUNKO_OT_custom_skin, FUNKO_OT_custom_eyes)
