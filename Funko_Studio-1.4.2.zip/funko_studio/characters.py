"""Character loading (bundled OBJ models) and viewport framing."""
import math
import os
import bpy
from mathutils import Vector, Euler
from .constants import ASSET_DIR, COLLECTION_NAME
from . import materials, workspace


def ensure_collection(scene):
    col = bpy.data.collections.get(COLLECTION_NAME)
    if col is None:
        col = bpy.data.collections.new(COLLECTION_NAME)
    if col.name not in scene.collection.children:
        try:
            scene.collection.children.link(col)
        except RuntimeError:
            pass
    return col


def _remove_previous(col):
    old_meshes = []
    for ob in list(col.objects):
        if ob.get("funko_studio_base") or ob.name.startswith(("Funko Female Base", "Funko Male Base")):
            if ob.type == 'MESH':
                old_meshes.append(ob.data)
            bpy.data.objects.remove(ob, do_unlink=True)
    for me in old_meshes:
        if me.users == 0:
            bpy.data.meshes.remove(me)


def load_character(context, gender):
    """Replace the current base character with the bundled OBJ for `gender`."""
    scene = context.scene
    col = ensure_collection(scene)
    path = os.path.join(ASSET_DIR, 'female.obj' if gender == 'FEMALE' else 'male.obj')
    if not os.path.exists(path):
        raise RuntimeError(f"Missing model: {path}")
    _remove_previous(col)
    before = set(bpy.data.objects)
    if hasattr(bpy.ops.wm, 'obj_import'):
        bpy.ops.wm.obj_import(filepath=path)
    else:
        bpy.ops.import_scene.obj(filepath=path)
    imported = [o for o in bpy.data.objects if o not in before]
    if not imported:
        raise RuntimeError("The character OBJ could not be imported.")
    for ob in imported:
        for old in list(ob.users_collection):
            old.objects.unlink(ob)
        col.objects.link(ob)
        ob.name = 'Funko ' + ('Female' if gender == 'FEMALE' else 'Male') + ' Base'
        ob['funko_studio_base'] = gender
    scene.funko_studio.gender = gender
    # Re-apply the colours already chosen, so switching gender keeps them.
    materials.apply_skin_tone(context)
    frame_character(context)


def frame_character(context):
    col = bpy.data.collections.get(COLLECTION_NAME)
    objs = [o for o in col.objects if o.type == 'MESH'] if col else []
    if not objs:
        return
    pts = [o.matrix_world @ Vector(c) for o in objs for c in o.bound_box]
    center = sum(pts, Vector()) / len(pts)
    for win in context.window_manager.windows:
        view = workspace.find_viewport_area(win.screen) if workspace.is_funko_window(win) else None
        if view is None:
            continue
        workspace.configure_viewport(view, win)
        rv = view.spaces.active.region_3d
        rv.view_perspective = 'ORTHO'
        rv.view_location = center
        rv.view_distance = 1.65
        rv.view_rotation = Euler((math.radians(90), 0, 0), 'XYZ').to_quaternion()
        view.tag_redraw()
