"""Workspace creation and the one-time split: 3D viewport (left) | Funko Studio (right).

Areas are always identified by their real screen coordinates, never by the
order of `screen.areas`.
"""
import bpy
from .constants import (WORKSPACE_NAME, SCENE_NAME, LAYOUT_MARKER, LAYOUT_VERSION,
                        VIEWPORT_FACTOR, MENU_SPACE)


def is_funko_window(window):
    return bool(window and window.workspace and window.workspace.name == WORKSPACE_NAME)


def find_menu_area(screen):
    """Rightmost Funko canvas area of the screen, or None."""
    if screen is None:
        return None
    cands = [a for a in screen.areas if a.type == MENU_SPACE]
    if not cands:
        return None
    menu = max(cands, key=lambda a: a.x)
    view = find_viewport_area(screen)
    if view is not None and menu.x < view.x:
        return None          # a canvas left of the viewport is not the Funko menu
    return menu


def find_viewport_area(screen):
    """Leftmost (largest on ties) 3D viewport of the screen, or None."""
    if screen is None:
        return None
    views = [a for a in screen.areas if a.type == 'VIEW_3D']
    if not views:
        return None
    return min(views, key=lambda a: (a.x, -a.width * a.height))


def window_region(area):
    return next((r for r in area.regions if r.type == 'WINDOW'), None) if area else None


def _set(obj, attr, value):
    """Assign only when different (region visibility changes re-initialise the area)."""
    try:
        if getattr(obj, attr) != value:
            setattr(obj, attr, value)
    except (AttributeError, TypeError):
        pass


def configure_viewport(area, window=None):
    s = area.spaces.active
    # Region visibility updates need a window in context (Blender 5.3 crashes otherwise).
    window = window or bpy.context.window
    if window is None:
        return
    with bpy.context.temp_override(window=window):
        for attr in ("show_region_ui", "show_region_toolbar", "show_region_tool_header"):
            _set(s, attr, False)
    _set(s, "show_gizmo", True)
    _set(s, "show_gizmo_navigate", True)
    _set(s.overlay, "show_overlays", False)
    _set(s.shading, "type", 'SOLID')
    _set(s.shading, "light", 'STUDIO')
    _set(s.shading, "show_cavity", True)
    _set(s.shading, "cavity_type", 'BOTH')


def configure_menu(area, window=None):
    s = area.spaces.active
    window = window or bpy.context.window
    if window is None:
        return
    with bpy.context.temp_override(window=window):
        for attr in ("show_region_header", "show_region_footer", "show_region_ui"):
            _set(s, attr, False)
    try:
        if s.text is not None:
            s.text = None
    except (AttributeError, TypeError):
        pass


def _close_extra_areas(window, screen, keep):
    """Close every area except `keep` (timeline, outliner, properties...)."""
    for _ in range(12):
        others = [a for a in screen.areas if a != keep]
        if not others:
            return
        area = others[0]
        try:
            with bpy.context.temp_override(window=window, screen=screen, area=area,
                                           region=window_region(area)):
                bpy.ops.screen.area_close()
        except Exception:
            return


def _split(window, screen, view):
    region = window_region(view)
    cursor = (view.x + int(view.width * VIEWPORT_FACTOR), view.y + view.height // 2)
    with bpy.context.temp_override(window=window, screen=screen, area=view, region=region):
        result = bpy.ops.screen.area_split(direction='VERTICAL', factor=VIEWPORT_FACTOR, cursor=cursor)
    return 'FINISHED' in result


def ensure_layout(window):
    """Build the two-area layout once. Returns True when the layout is ready.

    Step 1 (one tick): close the extra editors and split the viewport once.
    Step 2 (next tick, when Blender has refreshed the real area coordinates):
    turn the rightmost of the two viewports into the Funko Studio editor.
    """
    screen = window.screen
    ws = window.workspace
    menu = find_menu_area(screen)
    view = find_viewport_area(screen)
    if menu is not None and view is not None:
        configure_menu(menu, window)
        return True
    stage = ws.get(LAYOUT_MARKER)
    views = [a for a in screen.areas if a.type == 'VIEW_3D']
    if stage == "split" and len(views) >= 2:
        right = max(views, key=lambda a: a.x)      # real screen coordinates
        right.type = MENU_SPACE
        ws[LAYOUT_MARKER] = LAYOUT_VERSION
        return False                                # configure on the next tick
    if stage == LAYOUT_VERSION or stage == "split":
        return True     # already split once: never split again automatically
    if view is None:
        return False
    _close_extra_areas(window, screen, view)
    view = find_viewport_area(screen)
    if view is not None and _split(window, screen, view):
        ws[LAYOUT_MARKER] = "split"
    return False


def ensure_workspace(context, switch=True):
    """Create (once) and optionally activate the Funko Studio workspace and scene."""
    wm = context.window_manager
    if wm is None or not wm.windows:
        return None
    window = context.window or wm.windows[0]
    ws = bpy.data.workspaces.get(WORKSPACE_NAME)
    if ws is None:
        before = set(bpy.data.workspaces)
        with context.temp_override(window=window):
            result = bpy.ops.workspace.duplicate()
        if 'CANCELLED' in result:
            return None
        created = [w for w in bpy.data.workspaces if w not in before]
        if not created:
            return None
        ws = created[0]            # rename the copy, never the user's original workspace
        ws.name = WORKSPACE_NAME
    if switch and window.workspace != ws:
        window.workspace = ws
    scene = bpy.data.scenes.get(SCENE_NAME) or bpy.data.scenes.new(SCENE_NAME)
    if switch and window.scene != scene:
        window.scene = scene
    return window
