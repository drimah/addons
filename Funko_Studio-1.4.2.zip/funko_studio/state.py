"""Scene-stored customisation state."""
import bpy
from bpy.props import (EnumProperty, FloatVectorProperty, CollectionProperty,
                       IntProperty, FloatProperty, BoolProperty)
from bpy.types import PropertyGroup
from .constants import CATEGORIES, CATEGORY_LABELS


class FunkoColorSwatch(PropertyGroup):
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=4, min=0.0, max=1.0,
                               default=(0.5, 0.5, 0.5, 1.0))


class FunkoStudioState(PropertyGroup):
    gender: EnumProperty(name="Character", items=[('FEMALE', "Female", ""), ('MALE', "Male", "")],
                         default='FEMALE')
    category: EnumProperty(name="Category", items=[(x, CATEGORY_LABELS[x], "") for x in CATEGORIES],
                           default='BODY')
    skin_tone: EnumProperty(name="Skin Tone", items=[
        ('PORCELAIN', "Porcelain", ""), ('IVORY', "Ivory", ""),
        ('LIGHT', "Light", ""), ('MEDIUM', "Medium", ""),
        ('TAN', "Tan", ""), ('BROWN', "Brown", ""), ('DEEP', "Deep", ""),
        ('PINK', "Pink", ""), ('RED', "Red", ""), ('ORANGE', "Orange", ""),
        ('YELLOW', "Yellow", ""), ('GREEN', "Green", ""), ('MINT', "Mint", ""),
        ('CYAN', "Cyan", ""), ('BLUE', "Blue", ""), ('VIOLET', "Violet", ""),
        ('PURPLE', "Purple", ""), ('GRAY', "Gray", ""), ('WHITE', "White", ""),
        ('BLACK', "Black", ""), ('CUSTOM', "Custom", "")
    ], default='MEDIUM')
    custom_skin_color: FloatVectorProperty(name="Custom Skin Color", subtype='COLOR', size=4,
                                           min=0.0, max=1.0, default=(0.67, 0.43, 0.29, 1.0))
    eye_color: EnumProperty(name="Eye Color", items=[
        ('BLACK', "Black", ""), ('BROWN', "Brown", ""), ('HAZEL', "Hazel", ""),
        ('GREEN', "Green", ""), ('BLUE', "Blue", ""), ('GRAY', "Gray", ""),
        ('VIOLET', "Violet", ""), ('RED', "Red", ""), ('PINK', "Pink", ""), ('CUSTOM', "Custom", "")
    ], default='BLACK')
    custom_eye_color: FloatVectorProperty(name="Custom Eye Color", subtype='COLOR', size=4,
                                          min=0.0, max=1.0, default=(0.025, 0.02, 0.018, 1.0))
    custom_skin_swatches: CollectionProperty(type=FunkoColorSwatch)
    custom_eye_swatches: CollectionProperty(type=FunkoColorSwatch)
    # Which custom swatch is selected (-1 = none). The "-" button removes exactly this one.
    custom_skin_index: IntProperty(default=-1)
    custom_eye_index: IntProperty(default=-1)
    scroll: FloatProperty(default=0.0)
    show_help: BoolProperty(default=False)


CLASSES = (FunkoColorSwatch, FunkoStudioState)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.funko_studio = bpy.props.PointerProperty(type=FunkoStudioState)


def unregister():
    if hasattr(bpy.types.Scene, "funko_studio"):
        del bpy.types.Scene.funko_studio
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
