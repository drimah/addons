"""Vector icons for the step tabs, drawn with the GPU (crisp at any UI scale).

Each icon is defined on a 64x64 grid (y down, like an image) and built from
polylines, outlined circles/arcs and filled circles.
"""
import math
import gpu
from gpu_extras.batch import batch_for_shader


def _arc(cx, cy, rx, ry, a0, a1, n=24):
    return [(cx + rx * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def _rrect(x0, y0, x1, y1, r):
    pts = []
    for cx, cy, a0 in ((x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)):
        pts += _arc(cx, cy, r, r, a0, a0 + 90, 6)
    return pts + [pts[0]]


def _ellipse(x0, y0, x1, y1):
    return _arc((x0 + x1) / 2, (y0 + y1) / 2, (x1 - x0) / 2, (y1 - y0) / 2, 0, 360, 32)


# Each icon: list of ("line", points) or ("dot", cx, cy, r)
ICONS = {
    "BODY": [("line", _ellipse(22, 6, 42, 26)), ("line", _rrect(16, 30, 48, 58, 9))],
    "LASHES": [("line", _arc(32, 40, 26, 20, 200, 340)), ("line", _arc(32, 24, 26, 20, 20, 160)),
               ("dot", 32, 32, 7), ("line", [(16, 22), (11, 12)]), ("line", [(32, 22), (32, 12)]),
               ("line", [(48, 22), (53, 12)])],
    "HAIR_HATS": [("line", _rrect(18, 12, 46, 44, 5)), ("line", [(18, 34), (46, 34)]),
                  ("line", [(8, 47), (56, 47)])],
    "GLASSES": [("line", _ellipse(4, 22, 28, 44)), ("line", _ellipse(36, 22, 60, 44)),
                ("line", _arc(32, 30, 6, 6, 200, 340))],
    "TOPS": [("line", [(22, 8), (14, 10), (4, 22), (12, 30), (16, 26), (16, 58), (48, 58), (48, 26),
                       (52, 30), (60, 22), (50, 10), (42, 8), (38, 14), (26, 14), (22, 8)])],
    "BOTTOMS": [("line", [(14, 8), (50, 8), (54, 58), (38, 58), (32, 26), (26, 58), (10, 58), (14, 8)]),
                ("line", [(14, 16), (50, 16)])],
    "ACCESSORY_1": [("line", _rrect(8, 22, 46, 56, 6)), ("line", _arc(27, 20, 10, 12, 180, 360)),
                    ("dot", 51, 47, 11), ("cut", [(51, 40), (51, 54)]), ("cut", [(47, 43), (51, 40)])],
    "ACCESSORY_2": [("line", _rrect(8, 22, 46, 56, 6)), ("line", _arc(27, 20, 10, 12, 180, 360)),
                    ("dot", 51, 47, 11), ("cut", _arc(51, 44, 5, 5, 200, 390, 10) + [(46, 54), (57, 54)])],
    "BUDDIES": [("dot", 32, 43, 13), ("dot", 13, 29, 5), ("dot", 25, 15, 5), ("dot", 41, 15, 5),
                ("dot", 53, 29, 5)],
    "NAME": [("line", [(6, 20), (42, 20), (58, 32), (42, 44), (6, 44), (6, 20)]), ("dot", 43, 32, 3),
             ("line", [(14, 28), (30, 28)]), ("line", [(14, 36), (26, 36)])],
    "PRINT_STUDIO": [("line", _rrect(6, 24, 58, 46, 5)), ("line", [(18, 24), (18, 8), (46, 8), (46, 24)]),
                     ("line", [(18, 38), (18, 58), (46, 58), (46, 38), (18, 38)]), ("dot", 50, 32, 3)],
}


def _poly_shader():
    try:
        return gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    except Exception:
        return None


def draw_icon(key, x, y, size, color, cut_color):
    """Draw icon `key` in the square (x, y, size) of region space."""
    spec = ICONS.get(key)
    if not spec:
        return False
    s = size / 64.0

    def tr(p):
        return (x + p[0] * s, y + size - p[1] * s)

    line_sh = _poly_shader()
    fill_sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    vp = gpu.state.viewport_get()
    for item in spec:
        kind = item[0]
        if kind == "dot":
            cx, cy, r = item[1:]
            c = tr((cx, cy)); rr = r * s
            ring = [(c[0] + rr * math.cos(a * math.pi / 12), c[1] + rr * math.sin(a * math.pi / 12)) for a in range(24)]
            verts = [c] + ring
            tris = [(0, i + 1, (i + 1) % 24 + 1) for i in range(24)]
            b = batch_for_shader(fill_sh, 'TRIS', {"pos": verts}, indices=tris)
            fill_sh.bind(); fill_sh.uniform_float("color", color); b.draw(fill_sh)
        elif line_sh is not None:
            pts = [tr(p) for p in item[1]]
            col = cut_color if kind == "cut" else color
            width = max(1.0, (3.4 if kind == "cut" else 4.6) * s)
            b = batch_for_shader(line_sh, 'LINE_STRIP', {"pos": pts})
            line_sh.bind()
            line_sh.uniform_float("viewportSize", (vp[2], vp[3]))
            line_sh.uniform_float("lineWidth", width)
            line_sh.uniform_float("color", col)
            b.draw(line_sh)
    return True
