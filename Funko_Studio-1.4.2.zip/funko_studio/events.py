"""Mouse handling for the right-hand Funko Studio editor and handler lifecycle.

One window-level modal operator listens for events, but it only reacts when the
mouse is inside the WINDOW region of the Funko editor (the rightmost canvas).
Everything else - including the whole 3D viewport - passes through untouched.
"""
import bpy
from bpy.types import Operator
from .constants import CATEGORIES, SKIN_TONES, EYE_TONES
from . import ui_draw, workspace, materials, characters

_NS = "funko_studio_runtime"   # survives module reloads (bpy.app.driver_namespace)


def _rt():
    return bpy.app.driver_namespace.setdefault(_NS, {"draw": None, "token": 0, "running": False})


# ----------------------------------------------------------------- draw handler

def add_draw_handler():
    rt = _rt()
    remove_draw_handler()
    rt["draw"] = bpy.types.SpaceTextEditor.draw_handler_add(
        ui_draw.draw_callback, (), 'WINDOW', 'POST_PIXEL')
    wm = bpy.context.window_manager
    for win in (wm.windows if wm else []):
        area = workspace.find_menu_area(win.screen)
        if area:
            area.tag_redraw()


def remove_draw_handler():
    rt = _rt()
    if rt.get("draw") is not None:
        try:
            bpy.types.SpaceTextEditor.draw_handler_remove(rt["draw"], 'WINDOW')
        except (ValueError, RuntimeError):
            pass
        rt["draw"] = None


# ----------------------------------------------------------------- modal lifecycle

def stop_modal():
    rt = _rt()
    rt["token"] += 1          # any running instance cancels itself on its next event
    rt["running"] = False


def _redraw_menu(window):
    area = workspace.find_menu_area(window.screen)
    if area:
        area.tag_redraw()


def _redraw_all(context):
    for area in context.window.screen.areas:
        area.tag_redraw()


class FUNKO_OT_interface(Operator):
    bl_idname = "funko_studio.interface"
    bl_label = "Funko Studio Interface"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        rt = _rt()
        if rt.get("running"):
            return {'CANCELLED'}
        rt["token"] += 1
        self._token = rt["token"]
        rt["running"] = True
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _finish(self):
        rt = _rt()
        if rt.get("token") == self._token:
            rt["running"] = False

    def modal(self, context, event):
        rt = _rt()
        if rt.get("token") != self._token:
            return {'CANCELLED'}
        window = context.window
        if not workspace.is_funko_window(window):
            return {'PASS_THROUGH'}
        area = workspace.find_menu_area(window.screen)
        region = workspace.window_region(area)
        if region is None:
            return {'PASS_THROUGH'}
        x = event.mouse_x - region.x
        y = event.mouse_y - region.y
        inside = 0 <= x <= region.width and 0 <= y <= region.height
        st = context.scene.funko_studio if hasattr(context.scene, "funko_studio") else None

        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            hover = ui_draw.hit_test(x, y) if inside else None
            if hover != ui_draw.UI["hover"]:
                ui_draw.UI["hover"] = hover
                area.tag_redraw()
            return {'PASS_THROUGH'}

        if not inside or st is None:
            return {'PASS_THROUGH'}

        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN'}:
            step = 48 * context.preferences.system.ui_scale
            if event.type == 'TRACKPADPAN':
                delta = (event.mouse_y - event.mouse_prev_y)
            else:
                delta = step if event.type == 'WHEELDOWNMOUSE' else -step
            max_scroll = max(0.0, ui_draw.UI["content_h"] - ui_draw.UI["view_h"])
            st.scroll = min(max(st.scroll + delta, 0.0), max_scroll)
            area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                action = ui_draw.hit_test(x, y)
                if action:
                    try:
                        self.handle(context, st, action)
                    except Exception as exc:
                        self.report({'ERROR'}, str(exc))
                    area.tag_redraw()
            return {'RUNNING_MODAL'}   # the canvas owns its clicks

        if event.type in {'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

    def cancel(self, context):
        self._finish()

    # ------------------------------------------------------------- actions
    def handle(self, context, st, action):
        kind = action[0]
        if st.show_help:
            st.show_help = False
            return
        if kind == "tab":
            self.go(st, action[1])
        elif kind == "back":
            self.go(st, CATEGORIES[max(0, CATEGORIES.index(st.category) - 1)])
        elif kind == "next":
            self.go(st, CATEGORIES[min(len(CATEGORIES) - 1, CATEGORIES.index(st.category) + 1)])
        elif kind == "help":
            st.show_help = True
        elif kind == "gender":
            if action[1] != st.gender or not _has_character():
                characters.load_character(context, action[1])
        elif kind == "skin":
            st.skin_tone = action[1]; st.custom_skin_index = -1
            materials.apply_skin_tone(context)
        elif kind == "skin_custom":
            i = action[1]
            st.custom_skin_index = i
            st.custom_skin_color = st.custom_skin_swatches[i].color
            st.skin_tone = 'CUSTOM'
            materials.apply_skin_tone(context)
        elif kind == "skin_add":
            bpy.ops.funko_studio.custom_skin('INVOKE_DEFAULT')
        elif kind == "skin_del":
            self.remove_custom(st, "skin")
        elif kind == "eye":
            st.eye_color = action[1]; st.custom_eye_index = -1
            materials.apply_eye_color(context)
        elif kind == "eye_custom":
            i = action[1]
            st.custom_eye_index = i
            st.custom_eye_color = st.custom_eye_swatches[i].color
            st.eye_color = 'CUSTOM'
            materials.apply_eye_color(context)
        elif kind == "eye_add":
            bpy.ops.funko_studio.custom_eyes('INVOKE_DEFAULT')
        elif kind == "eye_del":
            self.remove_custom(st, "eye")
        elif kind == "op":
            ns, name = action[1].split(".", 1)
            op = getattr(getattr(bpy.ops, ns), name)
            if action[1] == "funko_studio.print_export_parts":
                op('INVOKE_DEFAULT')
            else:
                op()
        _redraw_all(context)

    def go(self, st, cat):
        if cat != st.category:
            st.category = cat
            st.scroll = 0.0

    def remove_custom(self, st, which):
        coll = st.custom_skin_swatches if which == "skin" else st.custom_eye_swatches
        idx = st.custom_skin_index if which == "skin" else st.custom_eye_index
        if not (0 <= idx < len(coll)):
            self.report({'INFO'}, "Select a custom color first")
            return
        coll.remove(idx)
        # The material keeps its current colour; only the saved swatch is removed.
        if which == "skin":
            st.custom_skin_index = -1
        else:
            st.custom_eye_index = -1


def _has_character():
    from .constants import COLLECTION_NAME
    col = bpy.data.collections.get(COLLECTION_NAME)
    return bool(col and any(o.get("funko_studio_base") for o in col.objects))


CLASSES = (FUNKO_OT_interface,)
