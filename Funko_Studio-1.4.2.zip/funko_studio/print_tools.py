"""Print preparation tools (unchanged from 1.4.1). Integrates with Remesh Ultimate when installed."""
import bpy
import bmesh
from bpy.props import FloatProperty
from bpy.types import Operator


class FUNKO_OT_print_analyze(Operator):
    bl_idname = "funko_studio.print_analyze"
    bl_label = "Analyze for Printing"
    bl_description = "Inspect mesh integrity and use Remesh Ultimate analysis when available"
    bl_options = {'REGISTER'}

    def execute(self, context):
        ob = context.active_object
        if not ob or ob.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        # Prefer the user's Remesh Ultimate analysis, without making it mandatory.
        try:
            if hasattr(bpy.ops.remesh_ultimate, "analyze_model"):
                result = bpy.ops.remesh_ultimate.analyze_model()
                if 'CANCELLED' not in result:
                    self.report({'INFO'}, "Analysis delegated to Remesh Ultimate")
                    return {'FINISHED'}
        except Exception:
            pass
        bm = bmesh.new(); bm.from_mesh(ob.data)
        bm.normal_update()
        boundary = sum(1 for e in bm.edges if len(e.link_faces) == 1)
        wire = sum(1 for e in bm.edges if len(e.link_faces) == 0)
        nonmanifold = sum(1 for e in bm.edges if not e.is_manifold)
        loose = sum(1 for v in bm.verts if not v.link_edges)
        faces = len(bm.faces); verts = len(bm.verts)
        bm.free()
        msg = f"{verts} verts | {faces} faces | {boundary} borders | {wire} wire edges | {nonmanifold} non-manifold edges | {loose} loose verts"
        ob["funko_print_report"] = msg
        self.report({'WARNING'} if nonmanifold or wire or boundary else {'INFO'}, msg[:240])
        return {'FINISHED'}

class FUNKO_OT_print_repair(Operator):
    bl_idname = "funko_studio.print_repair"
    bl_label = "Repair Mesh"
    bl_description = "Weld doubles, remove loose geometry and recalculate normals"
    bl_options = {'REGISTER', 'UNDO'}
    merge_distance: FloatProperty(name="Merge distance", default=0.0001, min=0.0, precision=6)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        ob = context.active_object
        if ob.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
        bm = bmesh.new(); bm.from_mesh(ob.data)
        before = len(bm.verts)
        if self.merge_distance > 0:
            bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=self.merge_distance)
        loose_edges = [e for e in bm.edges if len(e.link_faces) == 0]
        if loose_edges: bmesh.ops.delete(bm, geom=loose_edges, context='EDGES')
        loose_verts = [v for v in bm.verts if not v.link_edges]
        if loose_verts: bmesh.ops.delete(bm, geom=loose_verts, context='VERTS')
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        bm.to_mesh(ob.data); bm.free(); ob.data.update()
        self.report({'INFO'}, f"Mesh repaired. Removed/welded {max(0, before-len(ob.data.vertices))} vertices")
        return {'FINISHED'}

class FUNKO_OT_print_split_loose(Operator):
    bl_idname = "funko_studio.print_split_loose"
    bl_label = "Separate Disconnected Parts"
    bl_description = "Separate disconnected mesh islands into individual objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        ob = context.active_object
        if ob.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
        before = set(bpy.data.objects)
        bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.separate(type='LOOSE'); bpy.ops.object.mode_set(mode='OBJECT')
        made = [o for o in context.scene.objects if o not in before and o.type == 'MESH']
        self.report({'INFO'}, f"Separated into {1+len(made)} object(s)")
        return {'FINISHED'}


class FUNKO_OT_ru_detect(Operator):
    bl_idname = "funko_studio.ru_detect"
    bl_label = "Detect Areas (Remesh Ultimate)"
    bl_description = "Run Remesh Ultimate semantic/crease-based area detection"
    def execute(self, context):
        try:
            if not hasattr(bpy.ops.remesh_ultimate, 'detect_areas'):
                raise RuntimeError("Remesh Ultimate is not installed or enabled")
            result = bpy.ops.remesh_ultimate.detect_areas()
            if 'CANCELLED' in result: return {'CANCELLED'}
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc)); return {'CANCELLED'}

class FUNKO_OT_ru_remesh(Operator):
    bl_idname = "funko_studio.ru_remesh"
    bl_label = "Remesh Areas (Remesh Ultimate)"
    bl_description = "Create separate remeshed objects for detected areas"
    def execute(self, context):
        try:
            if not hasattr(bpy.ops.remesh_ultimate, 'remesh_areas'):
                raise RuntimeError("Remesh Ultimate is not installed or enabled")
            result = bpy.ops.remesh_ultimate.remesh_areas()
            if 'CANCELLED' in result: return {'CANCELLED'}
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc)); return {'CANCELLED'}


CLASSES = (FUNKO_OT_print_analyze, FUNKO_OT_print_repair, FUNKO_OT_print_split_loose,
           FUNKO_OT_ru_detect, FUNKO_OT_ru_remesh)
