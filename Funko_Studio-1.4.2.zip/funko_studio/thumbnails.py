"""Character thumbnail images drawn by the interface.

Thumbnails are opaque RGB renders of the bundled OBJ models on a black
background, so nothing behind the card can show through.
"""
import os
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from .constants import ASSET_DIR

_images = {}


def _image(key, path):
    img = _images.get(key)
    try:
        if img is not None and img.name in bpy.data.images and bpy.data.images[img.name] == img:
            return img
    except ReferenceError:
        pass
    if not os.path.exists(path):
        return None
    name = "." + key   # hidden datablock name
    img = bpy.data.images.get(name)
    if img is None or bpy.path.abspath(img.filepath) != path:
        img = bpy.data.images.load(path, check_existing=False)
        img.name = name
    _images[key] = img
    return img


def thumbnail(gender):
    return _image("funko_thumb_" + gender.lower(),
                  os.path.join(ASSET_DIR, gender.lower() + "_thumbnail.png"))


def draw_image(img, x, y, w, h, tint=None):
    if img is None:
        return False
    try:
        tex = gpu.texture.from_image(img)
        if tint is None:
            shader = gpu.shader.from_builtin('IMAGE')
        else:
            shader = gpu.shader.from_builtin('IMAGE_COLOR')
        batch = batch_for_shader(shader, 'TRI_FAN', {
            "pos": ((x, y), (x + w, y), (x + w, y + h), (x, y + h)),
            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1))})
        shader.bind()
        shader.uniform_sampler("image", tex)
        if tint is not None:
            shader.uniform_float("color", tint)
        batch.draw(shader)
        return True
    except Exception:
        return False


def clear():
    for img in list(_images.values()):
        try:
            if img.users == 0:
                bpy.data.images.remove(img)
        except (ReferenceError, RuntimeError):
            pass
    _images.clear()
