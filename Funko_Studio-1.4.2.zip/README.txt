FUNKO STUDIO — RELEASE NOTES (latest at the end)

FUNKO STUDIO 1.3.1
==================

Incremental update based on Funko Studio 1.3.0.

PRESERVATION
- The original male.obj and female.obj files from 1.3.0 are included unchanged.
- Existing workspace, character loading, overlay, print operators and Remesh Ultimate integration are retained.
- This release does not replace the character assets with procedural substitutes.

UNIFIED INTERFACE
- Adds PRINT STUDIO as a category in the existing custom Funko Studio interface.
- Print actions use the same dark panels, blue accents and rounded capsule controls as the existing customizer.
- The original sidebar Print Studio panel is retained as a fallback; it has not been removed.

PRINT ACTIONS
- Analyze Mesh
- Repair Mesh
- Separate Loose Parts
- Detect Areas (Remesh Ultimate, optional)
- Remesh & Separate Areas (Remesh Ultimate, optional)
- Export Selected Parts (STL)

INSTALLATION
1. Install the ZIP in Blender Preferences > Add-ons > Install from Disk.
2. Enable Funko Studio.
3. Open the Funko Studio workspace.
4. Select PRINT STUDIO in the category rail.

LIMITATIONS
- This is a preservation-focused incremental update, not a completed Funko character configurator.
- Existing customization categories without supplied assets remain placeholders.
- Cleave-style interactive cut planes, automatic male/female connector pairs, ball joints, clearance calibration and 3MF plate packing are not implemented yet.
- Remesh Ultimate must be installed and enabled separately for its two integration actions.
- Python syntax and ZIP contents were checked; Blender runtime testing was not performed in this environment.

Compatibility target: Blender 4.2+.
License: GPL-3.0-or-later.


FUNKO STUDIO 1.3.2 — BODY CHARACTER CHOICE FIX
- Replaced the Female/Male text pills in BODY with visual cards.
- The cards show previews generated from the bundled female.obj and male.obj files.
- Clicking a card loads that exact bundled OBJ into the main 3D viewport.
- The existing model assets and other 1.3.1 features remain included.


FUNKO STUDIO 1.3.3 — UNIFIED PRINT WORKSHOP UI
- Removed the separate native Blender "Funko Print Studio" sidebar panel.
- Print preparation now appears only inside the custom Funko Studio interface, under PRINT STUDIO.
- Redesigned that page as a branded workshop with INSPECT, ORGANIZE and EXPORT groups.
- Uses the same dark surfaces, blue accents, spacing and capsule controls as the creator.
- Female/Male visual character cards and the bundled original OBJ models are preserved.


FUNKO STUDIO 1.3.4 — WORKSPACE TAB FIX
- Makes the Funko Studio launcher tab/panel explicit and easy to locate in the 3D View sidebar (N).
- Adds a clearly named Create / Open Funko Studio action.
- Clicking it creates a real "Funko Studio" workspace tab in Blender's top workspace bar (or switches to the existing one).
- Existing character assets and custom interface are preserved.


FUNKO STUDIO 1.3.5 — CLEAN VIEWPORT AND BODY SELECTION
- Removed the permanent left category rail entirely.
- Character preview has the full left side of the viewport unobstructed.
- BACK and NEXT now navigate sequentially between customization stages.
- BODY selection cards use neutral grayscale previews.
- Clicking either card loads the corresponding bundled OBJ and updates gender state.
- Male and female OBJ assets remain unchanged.


FUNKO STUDIO 1.3.6 — LAUNCHER PANEL REFINEMENT
- Redesigned the N-panel launcher hierarchy with a branded BUILD YOUR POP! heading.
- Replaced the default compact launcher button with a larger flat OPEN CHARACTER CREATOR action.
- Added a concise product workflow caption.
- Preserves the character assets and all 1.3.5 customizer/print workflow code.
Note: Blender's native sidebar widgets do not support arbitrary capsule geometry. The launcher uses Blender's flat, unembossed control styling to reduce the default-button appearance.


FUNKO STUDIO 1.3.7 — DIRECT WORKSPACE START
- Removed the N-panel launcher and its Create/Open button entirely.
- When the add-on is enabled, it creates or reuses the dedicated "Funko Studio" workspace tab.
- Automatically switches to that workspace, creates/reuses the Funko Studio scene, loads the original female OBJ if empty, and starts the custom interface.
- The original Blender workspaces remain available; Funko Studio is added as its own workspace.
- Original male.obj and female.obj assets remain unchanged.


FUNKO STUDIO 1.3.8 — BODY SELECTION AND SKIN TONES
- Removed instructional copy from the BODY screen.
- Added seven skin-tone swatches.
- Skin tone is stored in Scene.funko_studio.skin_tone and applied to the current base model.
- Reworked character selection hit-testing and made import errors visible in Blender's operator report.
- Existing male/female OBJ files and all prior features are preserved.


FUNKO STUDIO 1.3.9 — INTERACTIVE COLOR STUDIO
- Expanded skin/body palette with 20 colors, including fantasy green, blue, purple, red, yellow, pink, mint and cyan.
- Added custom color dialogs for skin/body and eyes.
- Added eye-color palette with nine colors and custom picker.
- Eye tint is assigned to estimated symmetric eye-face regions on the supplied single-mesh OBJ; verify visually on the model before production.
- Reworked mouse hit testing to use absolute coordinates relative to the exact 3D WINDOW region used by the overlay.
- Overlay clicks are consumed instead of passing through to Blender tools.
- Original male/female OBJ assets remain unchanged.


FUNKO STUDIO 1.3.9 — CONSOLIDATED CORRECTION
- Retained release number 1.3.9.
- Removed unnecessary explanatory headings.
- Kept skin and eye palettes and added custom + / - swatches.
- Kept the custom color dialogs and saved reusable colors.
- Shifted the options panel left to preserve the XYZ gizmo.
- Moved BACK beside HELP and NEXT.
- Changed character thumbnails to white figures on black.
- Reworked modal hit testing against the area's WINDOW region.
- Python syntax and ZIP integrity checked; Blender runtime testing remains outstanding.


VISUAL FIX — 1.3.9
- Restored the shaded 3D grayscale character thumbnails; removed the flat white silhouette versions.
- Right-aligned the options panel again. Gizmo clearance is handled vertically, not by shifting the entire panel left.
- Fitted the BODY panel to its actual controls to reduce the large empty area.
- Kept the 1.3.9 version number and retained the existing character OBJ models and color controls.
- Python syntax and ZIP integrity checked; Blender runtime rendering still requires confirmation.


FUNKO STUDIO 1.4.0 — DEDICATED MENU EDITOR
- Workspace now creates a real side-by-side editor split: the left editor is the unobstructed 3D character preview, and the right editor is a dedicated Funko Studio menu canvas.
- The menu is drawn and receives clicks only in the right-hand editor; it no longer overlays the character viewport or navigation gizmo.
- The menu canvas uses a dark graphite background and centered controls.
- Existing character OBJ assets, color palettes, custom swatches, and print tools are retained.
- Version incremented to 1.4.0.
- Python syntax and ZIP integrity checked. Blender 5.3 runtime layout/operator verification remains necessary.


FUNKO STUDIO 1.4.1 — RIGHT-HAND MENU LAYOUT
- The workspace split now uses an explicit screen cursor at 66% width, reserving the larger left area for the character preview and placing the Funko menu in the rightmost editor.
- The menu area is identified by its actual screen X position after the split.
- Added an opaque black thumbnail backing so transparent PNG pixels cannot reveal the red-shaded character mesh behind the cards.
- Kept the original grayscale 3D thumbnail images, skin/eye palettes, custom swatches, and male/female OBJ models.
- Version incremented to 1.4.1.
- Python syntax and ZIP integrity checked; Blender 5.3 visual runtime test still required.


FUNKO STUDIO 1.4.2 — WORKSPACE SPLIT, STEP TABS AND EYE COLOUR FIX
===================================================================

WORKSPACE
- Two independent areas: 3D viewport on the LEFT (~65%), Funko Studio editor on the RIGHT (~35%).
- Areas are identified by their real screen X coordinates, never by the order of screen.areas.
- The split is done once per workspace (two-step: split, then identify left/right after Blender
  refreshes the area coordinates). Reopening the workspace or reinstalling never splits again.
- The Funko editor is its own area (a blank Text Editor used only as a canvas), so the character is
  no longer rendered behind the menu. The viewport keeps the XYZ navigation gizmo; toolbar, sidebar,
  overlays and timeline are hidden.
- Fixed: creating the workspace renamed the user's original "Layout" workspace to "Funko Studio"
  (the copy was left as "Layout.001"). The new copy is now the one renamed.
- Fixed: Blender 5.3 crashed when region visibility (header) was changed from a timer.

INTERFACE
- Step tabs with vector icons in a left rail, in the style of Blender's Properties editor:
  BODY, LASHES, HAIR & HATS, GLASSES, TOPS & OUTFITS, BOTTOMS, ACCESSORY 1/2, BUDDIES, NAME,
  PRINT STUDIO. Active tab in blue; the step name appears on hover.
- Scrollable content (mouse wheel), fixed BACK / HELP / NEXT footer. HELP opens a short help card.
- Thumbnails are opaque grey renders of the bundled OBJ models on a black background
  (no transparency, no red/scene showing through).
- Every interactive element registers its hit box while drawn: drawing and clicking share one layout.
- Clicks and wheel events are handled only inside the Funko editor; the viewport is left untouched.
- One draw handler and one interface modal at a time (stored in bpy.app.driver_namespace,
  safe across reloads and file loads).

COLOURS
- All 20 skin colours and 9 eye colours are kept.
- "+" opens Blender's colour picker and adds the colour as a custom swatch (selected and applied).
- "−" removes the SELECTED custom swatch only; with nothing selected it removes nothing.
- Fixed: eye colour never reached the model (the old rule used the wrong axis and selected 0 faces).
  Eyes are now detected as the raised discs on the face (eyes.py) and only those faces get the eye
  material; skin, lashes and brows are not changed.
- Switching FEMALE / MALE replaces the model (no duplicates) and keeps the chosen colours.

CODE LAYOUT
  workspace.py   workspace creation and area split      ui_draw.py    interface drawing
  events.py      clicks, wheel, handler lifecycle       icons.py      tab icons
  characters.py  OBJ loading and framing                materials.py  skin / eye materials
  eyes.py        eye-disc detection                     thumbnails.py character thumbnails
  print_tools.py print preparation + Remesh Ultimate    export.py     STL export
  operators.py   public operators                       startup.py    timer / load handlers
  state.py       scene properties                       constants.py  names, palettes, colours

PRESERVED
- Original female.obj and male.obj (byte-identical to 1.4.1).
- Print preparation, Remesh Ultimate integration and STL export code (unchanged from 1.4.1).

TESTS RUN IN BLENDER 5.3.0 (Windows)
- Install over 1.4.1 from the ZIP and enable: OK (also a hot upgrade without restarting Blender).
- Fresh Blender start: workspace created automatically, viewport left, Funko editor right, gizmo visible.
- FEMALE/MALE: real mouse click on the MALE card loaded the male model and moved the blue border.
- Skin, eye colour, custom colours (+ / −), BACK / HELP / NEXT and tabs: tested by calling the
  interface's click handler directly, with material values checked; eyes checked visually.
- Hover on tabs (tooltip) with real mouse movement: OK.
- Reopen / reinstall: still 2 areas, 1 interface modal, 1 draw handler.
- Print tools on a copy of the character: Analyze, Repair and STL export OK; Remesh Ultimate
  operators available.
- NOT confirmed: real mouse clicks on the small colour swatches (see release notes).

Compatibility target: Blender 4.2+ (tested on 5.3.0). License: GPL-3.0-or-later.
