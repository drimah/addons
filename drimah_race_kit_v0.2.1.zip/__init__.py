# Drimah Race Kit - monte pistas de corrida kawaii num tabuleiro, para Blender
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Drimah Race Kit",
    "author": "Drimah",
    "version": (0, 2, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Drimah Race Kit",
    "description": "Pistas de corrida kawaii com peças de encaixe e modo tabuleiro",
    "category": "Add Mesh",
}

import os
import math
import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
import gpu
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils
from mathutils import Vector, geometry

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_DIR, "assets", "drk_library.blend")
THUMB_DIR = os.path.join(ADDON_DIR, "thumbs")
TARGET_COLLECTION = "Drimah Race Kit"
BOARD_NAME = "DRK_Tabuleiro"
CELL = 10.0
TILE_TOP = 0.8

# (nome na biblioteca, rótulo, encaixe)  encaixe: "cell" = centro da casa, "sub" = sub-grade
CATEGORIES = [
    ("PISTA", "Pista", "CURVE_PATH", [
        ("DRK_Reta", "Reta", "cell"),
        ("DRK_Curva_Pequena", "Curva fechada", "cell"),
        ("DRK_Curva_Grande", "Curva aberta", "cell"),
        ("DRK_Largada", "Largada", "cell"),
        ("DRK_Grid_Largada", "Grid de largada", "cell"),
        ("DRK_Grama_Tile", "Grama", "cell"),
    ]),
    ("PROTECOES", "Proteções", "MESH_CONE", [
        ("DRK_GuardRail_Reta", "Guard rail reto", "cell"),
        ("DRK_GuardRail_Curva", "Guard rail curvo", "cell"),
        ("DRK_Cone", "Cone", "sub"),
        ("DRK_Pilha_Pneus", "Pneus", "sub"),
        ("DRK_Fardo_Feno", "Fardo de feno", "sub"),
    ]),
    ("ITENS", "Itens", "SOLO_ON", [
        ("DRK_Moeda_Pata", "Moeda pata", "sub"),
        ("DRK_Caixa_Pata", "Caixa pata", "sub"),
    ]),
    ("NATUREZA", "Natureza", "WORLD", [
        ("DRK_Arvore", "Árvore", "sub"),
        ("DRK_Pinheiro", "Pinheiro", "sub"),
        ("DRK_Arbusto", "Arbusto", "sub"),
        ("DRK_Pedra", "Pedra", "sub"),
    ]),
    ("ESTRUTURAS", "Estruturas", "HOME", [
        ("DRK_Portico", "Pórtico raposa", "cell"),
        ("DRK_Arco_Pata", "Arco pata", "cell"),
        ("DRK_Arquibancada", "Arquibancada", "sub"),
        ("DRK_Tenda", "Tenda", "sub"),
        ("DRK_Placa", "Placa", "sub"),
        ("DRK_Bandeira", "Bandeira", "sub"),
        ("DRK_Garagem_Box", "Garagem do box", "sub"),
    ]),
]
CAT_BY_ID = {c[0]: c for c in CATEGORIES}
ITEM_INFO = {n: (cid, label, snap) for cid, _l, _i, items in CATEGORIES for n, label, snap in items}

_previews = None


# ------------------------------------------------------------------ utilidades
def _icon(name):
    if _previews is None:
        return 0
    if name not in _previews:
        path = os.path.join(THUMB_DIR, name + ".png")
        if not os.path.exists(path):
            return 0
        _previews.load(name, path, "IMAGE")
    return _previews[name].icon_id


def _get_mesh(name):
    for me in bpy.data.meshes:
        if me.get("drk_name") == name and me.library is None:
            return me
    with bpy.data.libraries.load(LIB_PATH, link=False) as (data_from, data_to):
        if name not in data_from.objects:
            return None
        data_to.objects = [name]
    ob = data_to.objects[0]
    me = ob.data
    bpy.data.objects.remove(ob)
    return me


def _target_collection(context):
    col = bpy.data.collections.get(TARGET_COLLECTION)
    if col is None:
        col = bpy.data.collections.new(TARGET_COLLECTION)
    if col.name not in context.scene.collection.children:
        try:
            context.scene.collection.children.link(col)
        except RuntimeError:
            pass
    return col


def _is_kit(ob):
    return ob is not None and ob.type == "MESH" and ob.data.get("drk_name") is not None


def _is_track(ob):
    return _is_kit(ob) and "drk_exit" in ob.data


def _is_tile(ob):
    return _is_kit(ob) and ob.data.get("drk_cat") == "PISTA"


def _exit_of(ob):
    ex, ey = ob.data["drk_exit"]
    turn = math.radians(ob.data.get("drk_turn", 0.0))
    mirror = -1.0 if ob.scale.x < 0 else 1.0
    pos = ob.matrix_world @ Vector((ex, ey, 0.0))
    return pos, ob.rotation_euler.z + turn * mirror


def _place_after(new_ob, prev_ob):
    pos, heading = _exit_of(prev_ob)
    fwd = Vector((-math.sin(heading), math.cos(heading), 0.0))
    new_ob.location = pos + fwd * CELL / 2
    new_ob.location.z = prev_ob.location.z
    new_ob.rotation_euler = (0.0, 0.0, heading)


# ------------------------------------------------------------------ tabuleiro
def _board(context=None):
    ob = bpy.data.objects.get(BOARD_NAME)
    return ob if ob is not None and ob.get("drk_cols") else None


def _board_dims(board):
    cols, rows = int(board["drk_cols"]), int(board["drk_rows"])
    x0 = board.location.x - cols * CELL / 2
    y0 = board.location.y - rows * CELL / 2
    return cols, rows, x0, y0


def _cell_at(board, p):
    cols, rows, x0, y0 = _board_dims(board)
    i = math.floor((p.x - x0) / CELL)
    j = math.floor((p.y - y0) / CELL)
    if 0 <= i < cols and 0 <= j < rows:
        return i, j
    return None


def _cell_center(board, i, j):
    cols, rows, x0, y0 = _board_dims(board)
    return Vector((x0 + (i + 0.5) * CELL, y0 + (j + 0.5) * CELL, 0.0))


def _snap_point(board, p, mode, sub):
    cols, rows, x0, y0 = _board_dims(board)
    step = CELL if mode == "cell" else CELL / max(1, sub)
    x = x0 + (math.floor((p.x - x0) / step) + 0.5) * step
    y = y0 + (math.floor((p.y - y0) / step) + 0.5) * step
    x = min(max(x, x0 + step / 2), x0 + cols * CELL - step / 2)
    y = min(max(y, y0 + step / 2), y0 + rows * CELL - step / 2)
    return Vector((x, y, 0.0))


def _ground_z(p, ignore=None):
    """Altura do chão: em cima de um tile de pista ou no tabuleiro."""
    col = bpy.data.collections.get(TARGET_COLLECTION)
    if col is None:
        return 0.0
    for ob in col.objects:
        if ob is ignore or not _is_tile(ob):
            continue
        lp = ob.matrix_world.inverted() @ Vector((p.x, p.y, 0.0))
        bb = ob.bound_box
        if min(v[0] for v in bb) - 1e-3 <= lp.x <= max(v[0] for v in bb) + 1e-3 and \
           min(v[1] for v in bb) - 1e-3 <= lp.y <= max(v[1] for v in bb) + 1e-3:
            return ob.location.z + TILE_TOP
    return 0.0


def _snap_target(ob, board, p, settings):
    name = ob.data.get("drk_name")
    snap = ITEM_INFO.get(name, (None, None, "sub"))[2]
    c = _snap_point(board, p, snap, settings.sub_grid)
    c.z = 0.0 if _is_tile(ob) else _ground_z(c, ignore=ob)
    return c


def _place_on_board(ob, board, p, settings):
    c = _snap_target(ob, board, p, settings)
    if (ob.location - c).length > 1e-5:
        ob.location = c


_in_snap = False


@persistent
def _snap_handler(scene, depsgraph):
    """Prende as peças do kit nas casas do tabuleiro, inclusive ao mover com G e girar com R."""
    global _in_snap
    if _in_snap:
        return
    s = getattr(scene, "drk_settings", None)
    if s is None or not s.auto_snap:
        return
    board = _board()
    col = bpy.data.collections.get(TARGET_COLLECTION)
    if board is None or col is None:
        return
    moved = []
    for u in depsgraph.updates:
        if u.is_updated_transform and isinstance(u.id, bpy.types.Object):
            ob = u.id.original
            if _is_kit(ob) and col.objects.get(ob.name) is ob:
                moved.append(ob)
    if not moved:
        return
    _in_snap = True
    try:
        quarter = math.pi / 2
        for ob in moved:
            _place_on_board(ob, board, ob.location, s)
            rz = ob.rotation_euler.z
            snapped = round(rz / quarter) * quarter
            if abs(snapped - rz) > 1e-4:
                ob.rotation_euler.z = snapped
            if abs(ob.rotation_euler.x) > 1e-4 or abs(ob.rotation_euler.y) > 1e-4:
                ob.rotation_euler.x = 0.0
                ob.rotation_euler.y = 0.0
    finally:
        _in_snap = False


def _replace_tile(ob):
    """Uma peça de pista nova substitui a que já está na mesma casa."""
    col = bpy.data.collections.get(TARGET_COLLECTION)
    if col is None or not _is_tile(ob):
        return
    for o in list(col.objects):
        if o is not ob and _is_tile(o) and (o.location.xy - ob.location.xy).length < 0.1:
            bpy.data.objects.remove(o)


def _make_board(context, cols, rows):
    old = bpy.data.objects.get(BOARD_NAME)
    if old is not None:
        bpy.data.objects.remove(old)
    import bmesh
    me = bpy.data.meshes.new(BOARD_NAME)
    bm = bmesh.new()
    mats = []
    for key, rgb in (("claro", (0.80, 0.95, 0.78)), ("escuro", (0.62, 0.86, 0.62)), ("borda", (0.58, 0.40, 0.26))):
        m = bpy.data.materials.get("DRK_Tabuleiro_" + key) or bpy.data.materials.new("DRK_Tabuleiro_" + key)
        m.diffuse_color = (*rgb, 1)
        m.use_nodes = True
        bsdf = m.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            bsdf.inputs["Base Color"].default_value = (*rgb, 1)
            bsdf.inputs["Roughness"].default_value = 0.6
        mats.append(m)
    W, H = cols * CELL, rows * CELL
    for i in range(cols):
        for j in range(rows):
            x0, y0 = -W / 2 + i * CELL, -H / 2 + j * CELL
            vs = [bm.verts.new((x0, y0, 0)), bm.verts.new((x0 + CELL, y0, 0)),
                  bm.verts.new((x0 + CELL, y0 + CELL, 0)), bm.verts.new((x0, y0 + CELL, 0))]
            f = bm.faces.new(vs)
            f.material_index = (i + j) % 2
    # moldura
    t, hgt = 2.0, 0.6
    for (cx, cy, sx, sy) in ((0, -H / 2 - t / 2, W + 2 * t, t), (0, H / 2 + t / 2, W + 2 * t, t),
                             (-W / 2 - t / 2, 0, t, H), (W / 2 + t / 2, 0, t, H)):
        res = bmesh.ops.create_cube(bm, size=1)
        for v in res["verts"]:
            v.co = Vector((cx + v.co.x * sx, cy + v.co.y * sy, -0.4 + (v.co.z + 0.5) * (hgt + 0.4)))
        for f in {f for v in res["verts"] for f in v.link_faces}:
            f.material_index = 2
    res = bmesh.ops.create_cube(bm, size=1)
    for v in res["verts"]:
        v.co = Vector((v.co.x * W, v.co.y * H, -0.4 + (v.co.z + 0.5) * 0.38))
    for f in {f for v in res["verts"] for f in v.link_faces}:
        f.material_index = 2
    bm.to_mesh(me)
    bm.free()
    for m in mats:
        me.materials.append(m)
    ob = bpy.data.objects.new(BOARD_NAME, me)
    context.scene.collection.objects.link(ob)
    ob["drk_cols"] = cols
    ob["drk_rows"] = rows
    ob.hide_select = True
    return ob


# ------------------------------------------------------------------ operadores
class DRK_OT_add_item(bpy.types.Operator):
    bl_idname = "drk.add_item"
    bl_label = "Adicionar objeto"
    bl_description = "Adiciona este objeto do Drimah Race Kit"
    bl_options = {"REGISTER", "UNDO"}

    item: bpy.props.StringProperty()
    label: bpy.props.StringProperty()
    use_pos: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    x: bpy.props.FloatProperty(options={"SKIP_SAVE"})
    y: bpy.props.FloatProperty(options={"SKIP_SAVE"})

    def execute(self, context):
        if not os.path.exists(LIB_PATH):
            self.report({"ERROR"}, "Biblioteca do kit não encontrada")
            return {"CANCELLED"}
        me = _get_mesh(self.item)
        if me is None:
            self.report({"ERROR"}, f"{self.item} não está na biblioteca")
            return {"CANCELLED"}
        s = context.scene.drk_settings
        prev = context.view_layer.objects.active
        ob = bpy.data.objects.new(self.label or self.item, me)
        _target_collection(context).objects.link(ob)
        if me.get("drk_turn", 0) != 0 and s.curve_left:
            ob.scale.x = -1.0
        ob.rotation_euler.z = math.radians(float(s.rotation))
        board = _board()
        if self.use_pos and board is not None:
            _place_on_board(ob, board, Vector((self.x, self.y, 0)), s)
            _replace_tile(ob)
        elif "drk_exit" in me and s.snap and _is_track(prev):
            _place_after(ob, prev)
        else:
            p = context.scene.cursor.location.copy()
            if board is not None:
                _place_on_board(ob, board, p, s)
            else:
                ob.location = p
        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        return {"FINISHED"}


def _draw_picker(layout, context, op_kwargs):
    s = context.scene.drk_settings
    row = layout.row(align=True)
    row.prop(s, "category", expand=True)
    cid, label, icon, items = CAT_BY_ID[s.category]
    opt = layout.row(align=True)
    opt.prop(s, "rotation", expand=True)
    if cid == "PISTA":
        opt.prop(s, "curve_left", toggle=True, icon="LOOP_BACK")
    grid = layout.grid_flow(row_major=True, columns=4, even_columns=True, even_rows=True, align=False)
    for name, text, _snap in items:
        box = grid.box()
        col = box.column(align=True)
        icon_id = _icon(name)
        if icon_id:
            col.template_icon(icon_value=icon_id, scale=5.0)
        op = col.operator(DRK_OT_add_item.bl_idname, text=text)
        op.item = name
        op.label = text
        for k, v in op_kwargs.items():
            setattr(op, k, v)


class DRK_OT_open_category(bpy.types.Operator):
    bl_idname = "drk.open_category"
    bl_label = "Drimah Race Kit"
    bl_description = "Abre a janela com os objetos deste módulo"

    category: bpy.props.StringProperty()

    def invoke(self, context, event):
        if self.category:
            context.scene.drk_settings.category = self.category
        return context.window_manager.invoke_popup(self, width=640)

    def draw(self, context):
        _draw_picker(self.layout, context, {})

    def execute(self, context):
        return {"FINISHED"}


class DRK_OT_pick_piece(bpy.types.Operator):
    bl_idname = "drk.pick_piece"
    bl_label = "Escolher peça"
    bl_description = "Escolha a peça para esta casa do tabuleiro"

    x: bpy.props.FloatProperty()
    y: bpy.props.FloatProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=640)

    def draw(self, context):
        self.layout.label(text="Escolha a peça para esta casa", icon="RESTRICT_SELECT_OFF")
        _draw_picker(self.layout, context, {"use_pos": True, "x": self.x, "y": self.y})

    def execute(self, context):
        return {"FINISHED"}


class DRK_OT_board_create(bpy.types.Operator):
    bl_idname = "drk.board_create"
    bl_label = "Criar tabuleiro"
    bl_description = "Cria o tabuleiro onde a pista será montada"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.drk_settings
        _make_board(context, s.board_cols, s.board_rows)
        return {"FINISHED"}


_draw_handle = None
_hover = None      # (i, j)
_selected = None   # (i, j)


def _draw_cells():
    board = _board()
    if board is None:
        return
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    gpu.state.depth_test_set("NONE")
    for cell, rgba in ((_hover, (1.0, 0.85, 0.2, 0.35)), (_selected, (0.2, 0.75, 1.0, 0.45))):
        if cell is None:
            continue
        c = _cell_center(board, *cell)
        h = CELL / 2 - 0.15
        z = 0.05
        tile = [o for o in bpy.data.collections.get(TARGET_COLLECTION).objects] if bpy.data.collections.get(TARGET_COLLECTION) else []
        if any(_is_tile(o) and (o.location.xy - c.xy).length < 0.1 for o in tile):
            z = TILE_TOP + 0.4
        quad = [(c.x - h, c.y - h, z), (c.x + h, c.y - h, z), (c.x + h, c.y + h, z), (c.x - h, c.y + h, z)]
        batch = batch_for_shader(shader, "TRIS", {"pos": quad}, indices=((0, 1, 2), (0, 2, 3)))
        shader.uniform_float("color", rgba)
        batch.draw(shader)
        edge = [quad[0], quad[1], quad[1], quad[2], quad[2], quad[3], quad[3], quad[0]]
        batch = batch_for_shader(shader, "LINES", {"pos": edge})
        shader.uniform_float("color", (rgba[0], rgba[1], rgba[2], 1.0))
        gpu.state.line_width_set(3.0)
        batch.draw(shader)
        gpu.state.line_width_set(1.0)
    gpu.state.depth_test_set("LESS_EQUAL")
    gpu.state.blend_set("NONE")


class DRK_OT_board_mode(bpy.types.Operator):
    bl_idname = "drk.board_mode"
    bl_label = "Modo Tabuleiro"
    bl_description = ("Clique numa casa para escolher a peça; clique e arraste uma peça para movê-la "
                      "(R gira, F inverte curva, X apaga, Esc sai)")
    bl_options = {"REGISTER", "UNDO"}

    HELP = ("Modo Tabuleiro  |  Clique numa casa: escolher peça  |  Clique e arraste uma peça: mover  |  "
            "R: girar  |  F: inverter curva  |  X: apagar  |  Esc / botão direito: sair")

    def _ray(self, context, event):
        region, rv3d = context.region, context.region_data
        co = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co)
        direc = view3d_utils.region_2d_to_vector_3d(region, rv3d, co)
        return origin, direc

    def _ground(self, origin, direc):
        return geometry.intersect_line_plane(origin, origin + direc * 10000.0, Vector((0, 0, 0)), Vector((0, 0, 1)))

    def _pick(self, context, origin, direc):
        dg = context.evaluated_depsgraph_get()
        o, d = origin.copy(), direc.copy()
        for _ in range(8):
            hit, loc, _n, _i, ob, _m = context.scene.ray_cast(dg, o, d)
            if not hit:
                return None
            ob = getattr(ob, "original", ob)
            if ob.name != BOARD_NAME and _is_kit(ob):
                # preferir objetos que estão em cima dos tiles
                return ob
            if ob.name == BOARD_NAME:
                return None
            o = loc + d * 0.01
        return None

    def _open_picker(self, board, gp, s):
        global _selected
        _selected = _cell_at(board, gp)
        c = _cell_center(board, *_selected)
        # para itens pequenos, o ponto clicado define a sub-casa
        x, y = (gp.x, gp.y) if s.sub_grid > 1 else (c.x, c.y)
        bpy.ops.drk.pick_piece("INVOKE_DEFAULT", x=x, y=y)

    def invoke(self, context, event):
        global _draw_handle
        self.press_xy = (0, 0)
        self.press_gp = None
        self.moved = False
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"WARNING"}, "Use o Modo Tabuleiro na Viewport 3D")
            return {"CANCELLED"}
        if _board() is None:
            s = context.scene.drk_settings
            _make_board(context, s.board_cols, s.board_rows)
        self.drag = None
        self.drag_start = None
        if _draw_handle is None:
            _draw_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_cells, (), "WINDOW", "POST_VIEW")
        context.area.header_text_set(self.HELP)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _finish(self, context):
        global _draw_handle, _hover, _selected
        if _draw_handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
            _draw_handle = None
        _hover = _selected = None
        if context.area:
            context.area.header_text_set(None)
            context.area.tag_redraw()

    def modal(self, context, event):
        global _hover, _selected
        if context.area is None:
            self._finish(context)
            return {"CANCELLED"}
        board = _board()
        if board is None:
            self._finish(context)
            return {"CANCELLED"}
        s = context.scene.drk_settings

        # navegação da viewport continua funcionando
        if event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE", "TRACKPADPAN", "TRACKPADZOOM",
                          "NUMPAD_1", "NUMPAD_3", "NUMPAD_7", "NUMPAD_5", "NUMPAD_PERIOD", "HOME"}:
            return {"PASS_THROUGH"}

        # fora da área da viewport: deixa os cliques passarem (painéis, popups)
        if not (0 <= event.mouse_region_x <= context.region.width and 0 <= event.mouse_region_y <= context.region.height):
            return {"PASS_THROUGH"}

        origin, direc = self._ray(context, event)
        gp = self._ground(origin, direc)

        if event.type == "MOUSEMOVE":
            _hover = _cell_at(board, gp) if gp is not None else None
            if self.drag is not None and gp is not None:
                dx = event.mouse_region_x - self.press_xy[0]
                dy = event.mouse_region_y - self.press_xy[1]
                if self.moved or dx * dx + dy * dy > 64:
                    self.moved = True
                    _place_on_board(self.drag, board, gp, s)
            context.area.tag_redraw()
            return {"RUNNING_MODAL"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            ob = self._pick(context, origin, direc)
            if ob is not None:
                # clicar e arrastar = mover; clicar e soltar = escolher peça nessa casa
                self.drag = ob
                self.drag_start = ob.location.copy()
                self.press_xy = (event.mouse_region_x, event.mouse_region_y)
                self.press_gp = gp
                self.moved = False
                for o in context.selected_objects:
                    o.select_set(False)
                ob.select_set(True)
                context.view_layer.objects.active = ob
                return {"RUNNING_MODAL"}
            if gp is not None and _cell_at(board, gp) is not None:
                self._open_picker(board, gp, s)
                return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}

        if event.type == "LEFTMOUSE" and event.value == "RELEASE" and self.drag is not None:
            ob, moved, pgp = self.drag, self.moved, self.press_gp
            self.drag = None
            if moved:
                _replace_tile(ob)
            elif pgp is not None and _cell_at(board, pgp) is not None:
                self._open_picker(board, pgp, s)
            return {"RUNNING_MODAL"}

        target = self.drag or self._pick(context, origin, direc)
        if event.value == "PRESS" and target is not None:
            if event.type == "R":
                target.rotation_euler.z += math.radians(-90 if event.shift else 90)
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}
            if event.type == "F" and target.data.get("drk_turn", 0) != 0:
                target.scale.x *= -1
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}
            if event.type in {"X", "DEL"}:
                if target is self.drag:
                    self.drag = None
                bpy.data.objects.remove(target)
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}

        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            if self.drag is not None and self.drag_start is not None:
                self.drag.location = self.drag_start
                self.drag = None
                return {"RUNNING_MODAL"}
            self._finish(context)
            return {"FINISHED"}

        return {"RUNNING_MODAL"} if event.type in {"R", "F", "X", "DEL"} else {"PASS_THROUGH"}


class DRK_OT_rotate(bpy.types.Operator):
    bl_idname = "drk.rotate"
    bl_label = "Girar 90°"
    bl_description = "Gira os objetos selecionados 90 graus"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for ob in context.selected_objects:
            ob.rotation_euler.z += math.radians(90)
        return {"FINISHED"}


class DRK_OT_flip_curve(bpy.types.Operator):
    bl_idname = "drk.flip_curve"
    bl_label = "Inverter curva"
    bl_description = "Troca a curva selecionada entre direita e esquerda"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for ob in context.selected_objects:
            if _is_kit(ob) and ob.data.get("drk_turn", 0) != 0:
                ob.scale.x *= -1
        return {"FINISHED"}


# ------------------------------------------------------------------ interface
class DRK_Settings(bpy.types.PropertyGroup):
    category: bpy.props.EnumProperty(
        name="Módulo",
        items=[(c[0], c[1], "", c[2], i) for i, c in enumerate(CATEGORIES)])
    rotation: bpy.props.EnumProperty(
        name="Rotação",
        items=[("0", "0°", ""), ("90", "90°", ""), ("180", "180°", ""), ("270", "270°", "")],
        default="0")
    snap: bpy.props.BoolProperty(
        name="Encaixar na peça selecionada", default=True,
        description="Fora do tabuleiro: encaixa a nova peça de pista na ponta da peça selecionada")
    curve_left: bpy.props.BoolProperty(
        name="Curva à esquerda", default=False,
        description="Adiciona as curvas virando para a esquerda")
    board_cols: bpy.props.IntProperty(name="Colunas", default=12, min=2, max=64)
    board_rows: bpy.props.IntProperty(name="Linhas", default=12, min=2, max=64)
    auto_snap: bpy.props.BoolProperty(
        name="Prender no tabuleiro", default=True,
        description="As peças do kit sempre se encaixam nas casas, mesmo movendo com G e girando com R")
    sub_grid: bpy.props.IntProperty(
        name="Sub-grade dos objetos", default=2, min=1, max=4,
        description="Divide cada casa para posicionar objetos pequenos (árvores, cones...)")


class DRK_PT_main(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Drimah Race Kit"
    bl_label = "Drimah Race Kit"

    def draw(self, context):
        layout = self.layout
        s = context.scene.drk_settings

        box = layout.box()
        box.label(text="Tabuleiro", icon="VIEW_ORTHO")
        row = box.row(align=True)
        row.prop(s, "board_cols")
        row.prop(s, "board_rows")
        box.prop(s, "sub_grid")
        box.prop(s, "auto_snap", icon="SNAP_ON")
        box.operator(DRK_OT_board_create.bl_idname, icon="MESH_GRID")
        big = box.column()
        big.scale_y = 2.2
        big.operator(DRK_OT_board_mode.bl_idname, text="Modo Tabuleiro", icon="PLAY")

        layout.label(text="Módulos")
        col = layout.column(align=True)
        col.scale_y = 1.8
        for cid, label, icon, _items in CATEGORIES:
            op = col.operator(DRK_OT_open_category.bl_idname, text=label, icon=icon)
            op.category = cid

        box = layout.box()
        box.label(text="Ajustes", icon="TOOL_SETTINGS")
        box.prop(s, "snap")
        box.prop(s, "curve_left")
        row = box.row(align=True)
        row.operator(DRK_OT_rotate.bl_idname, icon="FILE_REFRESH")
        row.operator(DRK_OT_flip_curve.bl_idname, icon="MOD_MIRROR")


classes = (
    DRK_Settings,
    DRK_OT_add_item,
    DRK_OT_open_category,
    DRK_OT_pick_piece,
    DRK_OT_board_create,
    DRK_OT_board_mode,
    DRK_OT_rotate,
    DRK_OT_flip_curve,
    DRK_PT_main,
)


def register():
    global _previews
    _previews = bpy.utils.previews.new()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.drk_settings = bpy.props.PointerProperty(type=DRK_Settings)
    if _snap_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_snap_handler)


def unregister():
    global _previews, _draw_handle
    if _snap_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_snap_handler)
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
        _draw_handle = None
    del bpy.types.Scene.drk_settings
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None
