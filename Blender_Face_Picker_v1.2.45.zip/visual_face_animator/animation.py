import bpy
import uuid
import math
import json
from collections import Counter
from bpy.app.handlers import persistent

SETTINGS = ('frame_offset', 'frame_duration', 'frame_start', 'use_cyclic', 'use_auto_refresh')

_normalized = set()
_editing = False


def action_curves(action, slot=None):
    if not action:
        return
    if getattr(action, 'is_action_layered', False):
        for layer in action.layers:
            for strip in layer.strips:
                for bag in getattr(strip, 'channelbags', ()):
                    if slot is None or bag.slot_handle == slot.handle:
                        for curve in bag.fcurves:
                            yield bag.fcurves, curve
    else:
        for curve in action.fcurves:
            yield action.fcurves, curve


def paths(node):
    return {node.image_user.path_from_id(prop) for prop in SETTINGS}


def has_sequence_animation(node):
    ad = node.id_data.animation_data
    if not ad:
        return False
    controlled = paths(node)
    if any(c.data_path in controlled for c in ad.drivers):
        return True
    if any(c.data_path in controlled for _, c in action_curves(ad.action, ad.action_slot)):
        return True
    return any(c.data_path in controlled for track in ad.nla_tracks for strip in track.strips
               for _, c in action_curves(strip.action))


def check_takeover(node, replace):
    ad = node.id_data.animation_data
    if ad and any(c.data_path in paths(node) for track in ad.nla_tracks for strip in track.strips
                  for _, c in action_curves(strip.action)):
        raise ValueError("This node has NLA sequence animation. Use a fresh Image Texture node for V1.")
    if has_sequence_animation(node) and not replace:
        raise ValueError("This node has sequence animation. Choose Clear Animation under Options to take control.")


def can_keep_animation(node, numbers):
    """Recognize managed holds even after their channel has been disconnected."""
    user = node.image_user
    if not node.get('vfa_id') or not (user.frame_duration == 1 and user.use_cyclic and user.use_auto_refresh):
        return False
    ad = node.id_data.animation_data
    if not ad:
        return user.frame_offset + 1 in numbers
    controlled = paths(node)
    offset = user.path_from_id('frame_offset')
    if any(c.data_path in controlled for c in ad.drivers):
        return False
    if any(c.data_path in controlled for track in ad.nla_tracks for strip in track.strips
           for _, c in action_curves(strip.action)):
        return False
    has_keys = False
    for _, curve in action_curves(ad.action, ad.action_slot):
        if curve.data_path not in controlled:
            continue
        if curve.data_path != offset or curve.modifiers or curve.mute or curve.sampled_points:
            return False
        for key in curve.keyframe_points:
            has_keys = True
            number = round(key.co.y) + 1
            if abs(key.co.y - round(key.co.y)) > 0.0001 or number not in numbers or key.interpolation != 'CONSTANT':
                return False
    # Unkeyed holds outside the new range need to reset on reconnect.
    return has_keys or user.frame_offset + 1 in numbers


def configure(node, number, replace=False, transaction=None):
    check_takeover(node, replace)
    ad = node.id_data.animation_data
    if ad and replace:
        # Copy the action before removing only this node's sequence channels.
        if ad.action:
            old_slot = ad.action_slot
            identifier = old_slot.identifier if old_slot else None
            ad.action = ad.action.copy()
            if transaction:
                transaction.track(bpy.data.actions, ad.action)
            if identifier:
                ad.action_slot = next(s for s in ad.action.slots if s.identifier == identifier)
            for owner, curve in list(action_curves(ad.action, ad.action_slot)):
                if curve.data_path in paths(node):
                    owner.remove(curve)
        for curve in list(ad.drivers):
            if curve.data_path in paths(node):
                ad.drivers.remove(curve)
    user = node.image_user
    # A one-frame cyclic sequence wraps to 1 before adding frame_offset.
    # Offset N-1 therefore holds file N, including at negative timeline frames.
    user.frame_duration = 1
    user.frame_start = 1
    user.use_cyclic = True
    user.use_auto_refresh = True
    user.frame_offset = number - 1
    node.id_data.update_tag()


def validate_key(node):
    tree = node.id_data
    ad = tree.animation_data
    if ad and ad.use_tweak_mode:
        raise ValueError("Exit NLA tweak mode before inserting an expression keyframe.")
    if ad and ad.action and ad.action.users - int(ad.action.use_fake_user) > 1:
        raise ValueError("The node animation action is shared. Click Make Independent first.")
    if ad and any(c.data_path in paths(node) for c in ad.drivers):
        raise ValueError("Sequence settings are driven externally. Reconnect the sequence first.")
    path = node.image_user.path_from_id('frame_offset')
    if ad and any(c.lock or c.mute or len(c.modifiers) for _, c in action_curves(ad.action, ad.action_slot)
                  if c.data_path == path):
        raise ValueError("Unlock and unmute the expression curve and remove its modifiers before keying.")


def find_curve(tree, path):
    ad = tree.animation_data
    if not ad or not ad.action or (ad.action.is_action_layered and not ad.action_slot):
        return None, None
    return next(((owner, curve) for owner, curve in action_curves(ad.action, ad.action_slot)
                 if curve.data_path == path), (None, None))


def point_index(curve, frame):
    """Locate a key or its insertion position without walking all keys."""
    points = curve.keyframe_points
    low, high = 0, len(points)
    while low < high:
        middle = (low + high) // 2
        if points[middle].co.x < frame:
            low = middle + 1
        else:
            high = middle
    for index in (low, low - 1):
        if 0 <= index < len(points) and abs(points[index].co.x - frame) < 0.0001:
            return index, True
    return low, False


def curve_identity(tree, curve):
    ad = tree.animation_data
    return (ad.action.as_pointer(), curve.as_pointer())


def save_point(point):
    values = {name: getattr(point, name) for name in
              ('interpolation', 'easing', 'type', 'amplitude', 'back', 'period',
               'handle_left_type', 'handle_right_type')}
    values.update(co=tuple(point.co), handle_left=tuple(point.handle_left),
                  handle_right=tuple(point.handle_right))
    return values


def snapshot_key(node, frame):
    tree = node.id_data
    path = node.image_user.path_from_id('frame_offset')
    _, curve = find_curve(tree, path)
    saved = dict(tree=tree, path=path, frame=frame, existed=curve is not None,
                 had_key=False, neighbors=[], repairs=[], extrapolation=None)
    if curve is not None:
        index, exact = point_index(curve, frame)
        saved['had_key'] = exact
        saved['extrapolation'] = curve.extrapolation
        saved['neighbors'] = [save_point(curve.keyframe_points[i])
                              for i in range(max(0, index - 1),
                                             min(len(curve.keyframe_points), index + (2 if exact else 1)))]
        # Repair legacy linear keys once per curve, not at every selection.
        if curve_identity(tree, curve) not in _normalized:
            saved['repairs'] = [(float(p.co.x), p.interpolation) for p in curve.keyframe_points
                                if p.interpolation != 'CONSTANT']
    return saved


def key(node, saved, keyframe_type):
    tree = node.id_data
    frame = saved['frame']
    value = node.image_user.frame_offset
    path = saved['path']
    if not tree.keyframe_insert(data_path=path, frame=frame, group="Blender Face Picker"):
        raise ValueError("Blender could not insert the keyframe. Check animation channel locks.")
    ad = tree.animation_data
    ensure = getattr(ad.action, 'fcurve_ensure_for_datablock', None)
    curve = ensure(tree, path, index=0, group_name="Blender Face Picker") if ensure else find_curve(tree, path)[1]
    if curve is None:
        raise ValueError("Could not resolve the inserted expression key.")
    index, exact = point_index(curve, frame)
    if not exact:
        raise ValueError("Could not resolve the inserted expression key.")
    for old_frame, _ in saved['repairs']:
        old_index, found = point_index(curve, old_frame)
        if found:
            curve.keyframe_points[old_index].interpolation = 'CONSTANT'
    point = curve.keyframe_points[index]
    point.interpolation = 'CONSTANT'
    point.type = keyframe_type
    point.co.y = value
    curve.extrapolation = 'CONSTANT'
    curve.update()
    return curve_identity(tree, curve)


def restore_key(saved):
    owner, curve = find_curve(saved['tree'], saved['path'])
    if curve is None:
        return
    if not saved['existed']:
        owner.remove(curve)
        return
    index, exact = point_index(curve, saved['frame'])
    if exact and not saved['had_key']:
        curve.keyframe_points.remove(curve.keyframe_points[index])
    for old_frame, interpolation in saved['repairs']:
        index, found = point_index(curve, old_frame)
        if found:
            curve.keyframe_points[index].interpolation = interpolation
    for values in saved['neighbors']:
        index, found = point_index(curve, values['co'][0])
        if found:
            point = curve.keyframe_points[index]
            for name, value in values.items():
                setattr(point, name, value)
    curve.extrapolation = saved['extrapolation']
    curve.update()


_MARKER_STATE = 'vfa_marker_registry'
_marker_registry = {}


def marker_signature(scene):
    return [[m.name, m.frame, m.camera.name_full if m.camera else None]
            for m in scene.timeline_markers]


def marker_registry(scene):
    """TimelineMarker has no ID properties; store UUID ownership on its scene.

    Live edits use marker pointers. Load/undo restores saved collection indices
    only when the complete saved marker snapshot matches. Ambiguous entries and
    legacy markers remain unmanaged, rather than claiming them by visible name.
    """
    pointer = scene.as_pointer()
    if pointer not in _marker_registry:
        registry = {}
        try:
            saved = json.loads(scene.get(_MARKER_STATE, '{}'))
            signature = marker_signature(scene)
            indices = saved.get('ids', {})
            if saved.get('markers') == signature:
                index_counts = Counter(indices.values())
                signatures = Counter(tuple(row) for row in signature)
                for ident, index in indices.items():
                    if (isinstance(index, int) and 0 <= index < len(signature)
                            and index_counts[index] == 1
                            and signatures[tuple(signature[index])] == 1
                            and scene.timeline_markers[index].camera is None):
                        registry[ident] = scene.timeline_markers[index].as_pointer()
        except (ValueError, TypeError, AttributeError):
            pass
        _marker_registry[pointer] = registry
    return _marker_registry[pointer]


def save_marker_registry(scene):
    registry = marker_registry(scene)
    indices = {m.as_pointer(): i for i, m in enumerate(scene.timeline_markers)}
    for ident in list(registry):
        if registry[ident] not in indices:
            del registry[ident]
    scene[_MARKER_STATE] = json.dumps(dict(markers=marker_signature(scene),
        ids={ident: indices[pointer] for ident, pointer in registry.items()}))


@persistent
def clear_marker_registry(*_args):
    _marker_registry.clear()


@persistent
def save_marker_registries(*_args):
    for scene in bpy.data.scenes:
        if not scene.library and (scene.as_pointer() in _marker_registry or _MARKER_STATE in scene):
            save_marker_registry(scene)


def marker_label(expressions, limit):
    order = ('full_face', 'eyes', 'left_eye', 'right_eye', 'mouth')
    parts = [expressions[key] or 'Expression' for key in order if key in expressions]
    text = ' | '.join(parts)
    if len(text.encode('utf-8')) <= limit:
        return text
    share = max(1, (limit - 3 * (len(parts) - 1)) // max(1, len(parts)))
    return ' | '.join(part if len(part.encode('utf-8')) <= share else
                      part.encode('utf-8')[:max(0, share - 1)].decode('utf-8', errors='ignore') + '~'
                      for part in parts)


class MarkerEdit:
    """Only edit uniquely identified managed markers; names are never ownership."""
    def __init__(self, scene, request, frame=None):
        self.scene = scene
        self.owner, self.updates = request
        self.frame = scene.frame_current if frame is None else frame
        self.links = scene.vfa_settings.marker_links
        self.saved_links = [(link.channel_key, link.marker_name, link.expression_name, link.marker_id)
                            for link in self.links if link.owner == self.owner and link.frame == self.frame]
        ids = {ident for _key, _name, _expression, ident in self.saved_links if ident}
        protected = {link.marker_id for link in self.links if link.owner != self.owner and link.marker_id}
        self.registry = marker_registry(scene)
        by_id = {}
        pointers = {m.as_pointer(): m for m in scene.timeline_markers}
        counts = Counter(self.registry.values())
        for ident in ids:
            pointer = self.registry.get(ident)
            by_id[ident] = [pointers[pointer]] if pointer in pointers and counts[pointer] == 1 else []
        self.owned = [matches[0] for ident, matches in by_id.items()
                      if len(matches) == 1 and ident not in protected
                      and matches[0].frame == self.frame and matches[0].camera is None]
        self.identities = {m.as_pointer(): ident for ident, matches in by_id.items()
                           for m in matches if m in self.owned}
        verified = set(self.identities.values())
        self.expressions = {key: expression for key, _name, expression, ident in self.saved_links
                            if ident in verified}
        self.marker = self.owned[0] if self.owned else None
        self.old_name = self.marker.name if self.marker is not None else None
        self.created_marker = False
        self.main_removed = False
        self.removed = []
        self.links_changed = False
        self.ident = self.identities.get(self.marker.as_pointer()) if self.marker is not None else None

    def clear_links(self):
        for index in reversed(range(len(self.links))):
            link = self.links[index]
            if link.owner == self.owner and link.frame == self.frame:
                self.links.remove(index)

    def add_link(self, key, name, expression, ident):
        link = self.links.add()
        link.owner, link.channel_key, link.frame = self.owner, key, self.frame
        link.marker_name, link.expression_name, link.marker_id = name, expression, ident

    def remove_marker(self, marker):
        ident = self.identities[marker.as_pointer()]
        self.removed.append((marker.name, marker.frame, marker.select, ident))
        if marker == self.marker:
            self.main_removed = True
        self.scene.timeline_markers.remove(marker)
        self.registry.pop(ident, None)

    def apply(self):
        expressions = dict(self.expressions)
        if 'left_eye' in self.updates or 'right_eye' in self.updates:
            expressions.pop('eyes', None)
        for key, expression in self.updates.items():
            if expression is None:
                expressions.pop(key, None)
            else:
                expressions[key] = expression
        self.links_changed = True
        self.clear_links()
        if not expressions:
            for marker in self.owned:
                self.remove_marker(marker)
            save_marker_registry(self.scene)
            return
        limit = bpy.types.TimelineMarker.bl_rna.properties['name'].length_max
        limit = max(1, limit - 1) if limit else 255
        used = {marker.name for marker in self.scene.timeline_markers
                if marker.frame == self.frame and marker not in self.owned}
        name = marker_label(expressions, limit)
        suffix = 2
        while name in used:
            tail = f' ({suffix})'
            name = marker_label(expressions, max(1, limit - len(tail))) + tail
            suffix += 1
        if self.marker is None:
            self.marker = self.scene.timeline_markers.new(name, frame=self.frame)
            self.created_marker = True
            self.ident = uuid.uuid4().hex
            self.registry[self.ident] = self.marker.as_pointer()
        else:
            self.marker.name = name
        for key, expression in expressions.items():
            self.add_link(key, self.marker.name, expression, self.ident)
        for marker in self.owned[1:]:
            self.remove_marker(marker)
        save_marker_registry(self.scene)

    def rollback(self):
        if self.created_marker and self.marker is not None:
            self.scene.timeline_markers.remove(self.marker)
            self.registry.pop(self.ident, None)
        elif self.marker is not None and not self.main_removed:
            self.marker.name = self.old_name
        for name, frame, selected, ident in self.removed:
            marker = self.scene.timeline_markers.new(name, frame=frame)
            marker.select = selected
            self.registry[ident] = marker.as_pointer()
        try:
            if self.links_changed:
                self.clear_links()
                for key, name, expression, ident in self.saved_links:
                    self.add_link(key, name, expression, ident)
        finally:
            save_marker_registry(self.scene)


def associated_marker_edits(scene, owner, node):
    """Only clear this node's tracked parts on frames where it actually has keys."""
    from .data import all_channels
    from .materials import resolve
    parts = {key for key, ch in all_channels(owner) if key != 'nose' and resolve(ch) == node}
    if not parts:
        return []
    ad = node.id_data.animation_data
    if not ad:
        return []
    offset = node.image_user.path_from_id('frame_offset')
    frames = {math.floor(point.co.x) for _, curve in action_curves(ad.action, ad.action_slot)
              if curve.data_path == offset for point in curve.keyframe_points}
    tracked = {link.frame for link in scene.vfa_settings.marker_links
               if link.owner == owner and link.channel_key in parts and link.frame in frames}
    return [MarkerEdit(scene, (owner, {key: None for key in parts}), frame=frame)
            for frame in sorted(tracked)]


def apply_expressions(context, targets, insert_key, marker=None, keyframe_type='KEYFRAME'):
    """Back up only the keys being edited, leaving the material action in place."""
    global _editing
    if insert_key:
        for node, _ in targets:
            validate_key(node)
    previous_values = [(node, node.image_user.frame_offset) for node, _ in targets]
    frame = context.scene.frame_current + context.scene.frame_subframe
    keys = [snapshot_key(node, frame) for node, _ in targets] if insert_key else []
    trees = {node.id_data.as_pointer(): node.id_data for node, _ in targets}
    actions = []
    if insert_key:
        for tree in trees.values():
            ad = tree.animation_data
            actions.append((tree, ad is not None, ad.action if ad else None,
                            ad.action_slot if ad else None))
    marker_edit = MarkerEdit(context.scene, marker) if insert_key and marker else None
    normalized = []
    _editing = True
    try:
        for node, number in targets:
            node.image_user.frame_offset = number - 1
        for (node, _), saved in zip(targets, keys):
            normalized.append(key(node, saved, keyframe_type))
        if marker_edit:
            marker_edit.apply()
        for tree in trees.values():
            tree.update_tag()
        refresh(context, targets[0][0])
        _normalized.update(normalized)
    except Exception as error:
        rollback_errors = []
        def restore(callback, *args):
            try:
                callback(*args)
            except Exception as exc:
                rollback_errors.append(str(exc))
        if marker_edit:
            restore(marker_edit.rollback)
        for saved in reversed(keys):
            restore(restore_key, saved)
        def restore_action(tree, had_data, old, slot):
            ad = tree.animation_data
            if ad:
                created = ad.action if ad.action != old else None
                ad.action = old
                if old:
                    ad.action_slot = slot
                if not had_data:
                    tree.animation_data_clear()
                if created and created.users == 0:
                    bpy.data.actions.remove(created)
        for tree, had_data, old, slot in actions:
            restore(restore_action, tree, had_data, old, slot)
        def restore_value(node, value):
            node.image_user.frame_offset = value
            node.id_data.update_tag()
        for node, value in previous_values:
            restore(restore_value, node, value)
        _normalized.clear()
        if rollback_errors:
            raise RuntimeError(f'{error}; rollback could not fully restore: ' + '; '.join(rollback_errors)) from error
        raise
    finally:
        _editing = False


def current_number(node):
    # Blender evaluates animated RNA. Calling frame_set or updating the depsgraph
    # from panel drawing would trigger extra evaluation.
    return node.image_user.frame_offset + 1


def refresh(context, node):
    node.id_data.update_tag()
    context.view_layer.update()
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in {'VIEW_3D', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
                area.tag_redraw()


@persistent
def clear_normalized(*_args):
    _normalized.clear()


@persistent
def action_changed(_scene, depsgraph):
    if _editing or not _normalized:
        return
    changed = {entry.id.original.as_pointer() for entry in depsgraph.updates
               if isinstance(entry.id.original, bpy.types.Action)}
    if changed:
        _normalized.difference_update({key for key in _normalized if key[0] in changed})


def register():
    clear_normalized()
    clear_marker_registry()
    for handlers, callback in ((bpy.app.handlers.load_post, clear_normalized),
                               (bpy.app.handlers.load_post, clear_marker_registry),
                               (bpy.app.handlers.undo_post, clear_marker_registry),
                               (bpy.app.handlers.redo_post, clear_marker_registry),
                               (bpy.app.handlers.save_pre, save_marker_registries),
                               (bpy.app.handlers.undo_post, clear_normalized),
                               (bpy.app.handlers.redo_post, clear_normalized),
                               (bpy.app.handlers.depsgraph_update_post, action_changed)):
        handlers.append(callback)


def unregister():
    for handlers, callback in ((bpy.app.handlers.load_post, clear_normalized),
                               (bpy.app.handlers.load_post, clear_marker_registry),
                               (bpy.app.handlers.undo_post, clear_marker_registry),
                               (bpy.app.handlers.redo_post, clear_marker_registry),
                               (bpy.app.handlers.save_pre, save_marker_registries),
                               (bpy.app.handlers.undo_post, clear_normalized),
                               (bpy.app.handlers.redo_post, clear_normalized),
                               (bpy.app.handlers.depsgraph_update_post, action_changed)):
        if callback in handlers:
            handlers.remove(callback)
    clear_normalized()
    clear_marker_registry()
