bl_info = {
    'name': 'Blender Face Picker',
    'version': (1, 2, 45),
    'blender': (4, 5, 0),
    'location': '3D Viewport > Sidebar > Blender Face Picker',
    'description': 'Pick and key full-face or separate facial parts with linked eye controls',
    'category': 'Animation',
}

import importlib
import sys
import bpy
from bpy.props import PointerProperty

_MODULE_NAMES = ('previews', 'data', 'sequence', 'animation', 'ownership',
                 'materials', 'operators', 'ui')
_SERVICE_NAMES = ('sequence', 'animation', 'ownership', 'previews')


def _cleanup(classes, services):
    # Also handles a previous enable attempt that stopped partway through.
    for module in services:
        callback = getattr(module, 'unregister', None)
        if callback:
            try:
                callback()
            except (RuntimeError, ReferenceError):
                pass
    if hasattr(bpy.types.Scene, 'vfa_settings'):
        del bpy.types.Scene.vfa_settings
    if hasattr(bpy.types.Object, 'vfa_character'):
        del bpy.types.Object.vfa_character
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            # Unregistered classes are expected after a partial enable.
            pass


# Child modules survive package reloads; unregister old RNA classes and handlers first.
_previous_classes = globals().get('CLASSES', ())
if not _previous_classes:
    _previous_classes = tuple(cls for name in ('data', 'operators', 'ui')
                              for cls in getattr(sys.modules.get(f'{__name__}.{name}'), 'CLASSES', ()))
_previous_services = tuple(sys.modules.get(f'{__name__}.{name}') for name in _SERVICE_NAMES)
if _previous_classes:
    _cleanup(_previous_classes, _previous_services)
del _previous_classes, _previous_services

importlib.invalidate_caches()
for _name in _MODULE_NAMES:
    _full_name = f'{__name__}.{_name}'
    _cached = sys.modules.get(_full_name)
    globals()[_name] = (importlib.reload(_cached) if _cached is not None
                       else importlib.import_module(f'.{_name}', __name__))
del _name, _full_name, _cached

CLASSES = (*data.CLASSES, *operators.CLASSES, *ui.CLASSES)


def register():
    registered = []
    started = []
    try:
        for cls in CLASSES:
            bpy.utils.register_class(cls)
            registered.append(cls)
        bpy.types.Object.vfa_character = PointerProperty(type=data.VFA_Character)
        bpy.types.Scene.vfa_settings = PointerProperty(type=data.VFA_Settings)
        for module in (previews, ownership, animation, sequence):
            started.append(module)
            module.register()
    except Exception:
        _cleanup(registered, reversed(started))
        raise


def unregister():
    _cleanup(CLASSES, (sequence, animation, ownership, previews))
    operators._expression_names = ()
    operators._node_items.clear()
    operators._retired_items.clear()
    operators._candidate_cache.clear()
    previews._enum_items.clear()
