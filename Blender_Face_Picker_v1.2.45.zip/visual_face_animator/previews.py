import os
import time
from collections import OrderedDict, deque
import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent

_cache = None
_failed = set()
_enum_items = OrderedDict()
_retired = deque(maxlen=64)
_files = OrderedDict()
_icon_usage = OrderedDict()
_pending_files = OrderedDict()
_file_revision = 0
_checks_scheduled = False
PAGE_SIZE = 64
MAX_ICONS = 512


def check_files():
    """Check a bounded batch between UI events; never scan a library in draw."""
    global _file_revision, _checks_scheduled
    deadline = time.monotonic() + 0.004
    changed = False
    for _ in range(32):
        if not _pending_files or time.monotonic() >= deadline:
            break
        path, _ = _pending_files.popitem(last=False)
        previous = _files.get(path)
        exists = os.path.isfile(path)
        _files[path] = (time.monotonic(), exists)
        _files.move_to_end(path)
        if len(_files) > 50000:
            _files.popitem(last=False)
        if exists != (previous[1] if previous else True):
            changed = True
            _failed.discard(path)
    if changed:
        _file_revision += 1
        manager = bpy.context.window_manager
        if manager:
            for window in manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
    if _pending_files:
        return 0.05
    _checks_scheduled = False
    return None


def file_exists(filepath):
    global _checks_scheduled
    path = bpy.path.abspath(filepath)
    now = time.monotonic()
    saved = _files.get(path)
    if saved is None or now - saved[0] > 2.0:
        _pending_files[path] = None
        if len(_pending_files) > 50000:
            _pending_files.popitem(last=False)
        if not _checks_scheduled:
            bpy.app.timers.register(check_files, first_interval=0.05)
            _checks_scheduled = True
    # Unknown files remain usable while checking. The selection operator still
    # verifies the chosen file synchronously before changing or keying a node.
    return saved[1] if saved else True


def invalidate_library(owner=None):
    for key in list(_enum_items):
        saved = _enum_items[key]
        if owner is None or saved['owner'] == owner.as_pointer():
            _retired.append(saved.get('items', []))
            del _enum_items[key]


def library_info(ch):
    key = (ch.as_pointer(), bpy.data.filepath)
    now = time.monotonic()
    saved = _enum_items.get(key)
    if saved is None or now >= saved['check']:
        entries = tuple((item.name, item.filepath, item.file_number) for item in ch.expressions)
        if saved is None or entries != saved['entries']:
            if saved:
                _retired.append(saved.get('items', []))
            saved = dict(owner=ch.id_data.as_pointer(), entries=entries, check=now + 0.5,
                         by_number={item[2]: index for index, item in enumerate(entries)},
                         items=None, missing=None, blocked=None, file_check=0.0)
            _enum_items[key] = saved
        else:
            saved['check'] = now + 0.5
    if now >= saved['file_check'] or saved.get('file_revision') != _file_revision:
        missing = frozenset(i for i, item in enumerate(saved['entries']) if not file_exists(item[1]))
        blocked = set(missing)
        from .data import channel_key, channel, linked
        role = channel_key(ch)
        if linked(ch.id_data, role):
            other = channel(ch.id_data, 'right_eye' if role == 'left_eye' else 'left_eye')
            blocked.update(i for i in range(min(len(saved['entries']), len(other.expressions)))
                           if not file_exists(other.expressions[i].filepath))
        blocked = frozenset(blocked)
        if blocked != saved['blocked']:
            if saved['items']:
                _retired.append(saved['items'])
            saved['items'] = None
        saved['missing'] = missing
        saved['blocked'] = blocked
        saved['file_check'] = now + 2.0
        saved['file_revision'] = _file_revision
    _enum_items.move_to_end(key)
    while len(_enum_items) > 64:
        _retired.append(_enum_items.popitem(last=False)[1].get('items', []))
    return saved


def page_count(ch):
    return max(1, (len(ch.expressions) + PAGE_SIZE - 1) // PAGE_SIZE)


def page_get(ch):
    return max(1, min(ch.get('_picker_page', 1), page_count(ch)))


def page_set(ch, value):
    ch['_picker_page'] = max(1, min(value, page_count(ch)))
    invalidate_library(ch.id_data)


def expression_items(ch, context):
    saved = library_info(ch)
    page = page_get(ch)
    current = selected_get(ch)
    signature = (page, current)
    if saved['items'] is None or saved.get('page') != signature:
        if saved['items']:
            _retired.append(saved['items'])
        start = (page - 1) * PAGE_SIZE
        indexes = list(range(start, min(start + PAGE_SIZE, len(saved['entries']))))
        # Keep the large preview correct even when browsing another page.
        if current >= 0 and current not in indexes:
            indexes.append(current)
        saved['items'] = [(str(index), name, path, icon(path), index)
                          for index in indexes
                          for name, path, _number in (saved['entries'][index],)
                          if index not in saved['blocked']]
        saved['items'].append(('UNKNOWN', 'No matching expression', '', 0, -1))
        saved['page'] = signature
    return saved['items']


def selected_get(ch):
    from .materials import resolve
    node = resolve(ch)
    if node:
        saved = library_info(ch)
        index = saved['by_number'].get(node.image_user.frame_offset + 1, -1)
        return index if index not in saved['blocked'] else -1
    return -1


def expression_available(ch, index):
    return index not in library_info(ch)['blocked']


def selected_set(ch, index):
    from .data import channel_key, target_object
    if index >= 0 and ch.id_data == target_object(bpy.context):
        result = bpy.ops.vfa.select_expression(index=index, channel_key=channel_key(ch))
        if 'FINISHED' in result and page_get(ch) != index // PAGE_SIZE + 1:
            page_set(ch, index // PAGE_SIZE + 1)


def icon(filepath):
    global _cache
    path = bpy.path.abspath(filepath)
    if not file_exists(filepath):
        return 0
    if _cache is None:
        _cache = bpy.utils.previews.new()
    if path in _failed:
        return 0
    if path not in _cache:
        if len(_icon_usage) >= MAX_ICONS:
            oldest, _ = _icon_usage.popitem(last=False)
            del _cache[oldest]
            # Cached enums contain native icon IDs. Rebuild them after eviction.
            for saved in _enum_items.values():
                if saved['items']:
                    _retired.append(saved['items'])
                    saved['items'] = None
        try:
            _cache.load(path, path, 'IMAGE')
        except (OSError, RuntimeError, KeyError):
            if len(_failed) >= MAX_ICONS:
                _failed.pop()
            _failed.add(path)
            return 0
    _icon_usage[path] = None
    _icon_usage.move_to_end(path)
    return _cache[path].icon_id


@persistent
def clear(*_args):
    global _cache, _checks_scheduled
    if bpy.app.timers.is_registered(check_files):
        bpy.app.timers.unregister(check_files)
    _checks_scheduled = False
    _pending_files.clear()
    invalidate_library()
    if _cache is not None:
        bpy.utils.previews.remove(_cache)
        _cache = None
    _failed.clear()
    _files.clear()
    _icon_usage.clear()


@persistent
def history_changed(*_args):
    invalidate_library()
    _failed.clear()
    _files.clear()
    _pending_files.clear()


def register():
    bpy.app.handlers.load_post.append(clear)
    bpy.app.handlers.undo_post.append(history_changed)
    bpy.app.handlers.redo_post.append(history_changed)


def unregister():
    for handlers, callback in ((bpy.app.handlers.load_post, clear),
                               (bpy.app.handlers.undo_post, history_changed),
                               (bpy.app.handlers.redo_post, history_changed)):
        if callback in handlers:
            handlers.remove(callback)
    clear()
    _retired.clear()
