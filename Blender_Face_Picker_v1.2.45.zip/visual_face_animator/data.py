import bpy
import os
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from . import previews

CHANNELS = (('full_face', 'Full Face'), ('left_eye', 'Left Eye'),
            ('right_eye', 'Right Eye'), ('nose', 'Nose'), ('mouth', 'Mouth'))
LABELS = dict(CHANNELS)
# Keep native key types and their strings alive for RNA enums.
KEYFRAME_TYPES = tuple((item.identifier, item.name, item.description, item.icon, item.value)
                       for item in bpy.types.Keyframe.bl_rna.properties['type'].enum_items)


def ownership_changed(self, context):
    from .ownership import changed
    changed(self, context)


def thumbnail_size_get(ch):
    # Preserve saved numeric sizes, mapping intermediate values to presets.
    value = ch.get('thumbnail_size', 1)
    return 1 if value <= 1 else 3 if value <= 3 else 5


def thumbnail_size_set(ch, value):
    ch['thumbnail_size'] = value


def expression_changed(self, context):
    previews.invalidate_library(self.id_data)


def expression_path_get(item):
    saved = item.get('filepath', '')
    if not saved:
        return saved
    # A native Image tracks path remapping on Save As; old libraries use the saved string.
    channel_path = item.path_from_id().rsplit('.expressions[', 1)[0]
    ch = item.id_data.path_resolve(channel_path)
    source = ch.source_image
    if source:
        directory = os.path.dirname(bpy.path.abspath(source.filepath, library=source.library))
        # Blender's // prefix is relative, not a Windows UNC share.
        filename = saved.replace('\\', '/').rsplit('/', 1)[-1]
        return os.path.join(directory, filename)
    return saved


def expression_path_set(item, value):
    item['filepath'] = value


class VFA_Expression(bpy.types.PropertyGroup):
    name: StringProperty(name="Expression Name", update=expression_changed)
    filepath: StringProperty(subtype='FILE_PATH', options={'PATH_SUPPORTS_BLEND_RELATIVE'},
                             get=expression_path_get, set=expression_path_set)
    sequence_frame: IntProperty(min=1)
    file_number: IntProperty(min=0)


class VFA_Channel(bpy.types.PropertyGroup):
    name: StringProperty(default="Full Face")
    source_image: PointerProperty(type=bpy.types.Image)
    surface_object: PointerProperty(type=bpy.types.Object, update=ownership_changed)
    material: PointerProperty(type=bpy.types.Material, update=ownership_changed)
    recovery_surface: PointerProperty(type=bpy.types.Object, update=ownership_changed)
    node_name: StringProperty()
    node_id: StringProperty()
    expressions: CollectionProperty(type=VFA_Expression)
    auto_key: BoolProperty(name="Auto Keyframe", default=False)
    show_thumbnails: BoolProperty(name="Expression List", default=True, options=set())
    thumbnail_size: EnumProperty(name="Thumbnail Size", items=(
        ('1', 'Small', 'Compact previews', 1),
        ('3', 'Medium', 'Standard previews', 3),
        ('5', 'Large', 'Large previews', 5)),
        get=thumbnail_size_get, set=thumbnail_size_set, options=set())
    list_index: IntProperty(name="Expression", get=previews.selected_get,
                            set=previews.selected_set, min=-1, options={'SKIP_SAVE'})
    picker: EnumProperty(name="Expressions", items=previews.expression_items,
                         get=previews.selected_get, set=previews.selected_set,
                         options={'SKIP_SAVE'})
    picker_page: IntProperty(name="Thumbnail Page", min=1, max=157,
                             get=previews.page_get, set=previews.page_set,
                             description="Browse groups of 64 thumbnails; the expression list includes every entry",
                             options={'SKIP_SAVE'})


class VFA_Character(bpy.types.PropertyGroup):
    surface_owner: PointerProperty(type=bpy.types.Object, update=ownership_changed)
    full_face: PointerProperty(type=VFA_Channel)
    left_eye: PointerProperty(type=VFA_Channel)
    right_eye: PointerProperty(type=VFA_Channel)
    # Retained only for compatibility with saved projects and existing animation.
    nose: PointerProperty(type=VFA_Channel)
    mouth: PointerProperty(type=VFA_Channel)
    mode: EnumProperty(name="Mode", items=(
        ('FULL', 'Simple', 'Control the whole face with one expression library'),
        ('PARTS', 'Advanced', 'Control separate eyes and mouth')), options=set())
    active_part: EnumProperty(name="Editing", items=[(key, label, '') for key, label in CHANNELS[1:]],
                             default='left_eye', options=set())
    link_eyes: BoolProperty(name="Link Eyes", default=True, options=set(), update=expression_changed,
        description="Select and key both eyes by expression order; existing keys are preserved")
    show_nose: BoolProperty(name="Show Nose", default=True, options=set())
    show_animation: BoolProperty(name="Animation", default=True, options=set())
    show_material_setup: BoolProperty(name="Material Setup", default=True, options=set())
    auto_key_parts: BoolProperty(name="Auto Keyframe", default=False, options=set())
    keyframe_type: EnumProperty(name="Keyframe Type", items=KEYFRAME_TYPES,
        default='KEYFRAME', options=set(),
        description="Type and theme color for inserted or updated expression keys")
    add_markers: BoolProperty(name="Add Timeline Markers", default=False, options=set(),
        description="Label keyed frames with the expression name, for manual and automatic keys")


class VFA_MarkerLink(bpy.types.PropertyGroup):
    owner: PointerProperty(type=bpy.types.Object)
    channel_key: StringProperty()
    frame: IntProperty()
    marker_name: StringProperty()
    expression_name: StringProperty()
    marker_id: StringProperty()


class VFA_Settings(bpy.types.PropertyGroup):
    thumbnail_size: EnumProperty(name="Thumbnail Size", items=(
        ('1', 'Small', 'Compact previews', 1),
        ('3', 'Medium', 'Standard previews', 3),
        ('5', 'Large', 'Large previews', 5)),
        get=thumbnail_size_get, set=thumbnail_size_set,
        description="Shared thumbnail size for all face parts and characters in this scene")
    marker_links: CollectionProperty(type=VFA_MarkerLink)
    pinned: BoolProperty(name="Pin Object", default=False, options=set())
    pinned_object: PointerProperty(type=bpy.types.Object, options=set())


def target_object(context):
    """Resolve the panel target without changing Blender's active selection."""
    scene = context.scene if context else None
    settings = getattr(scene, 'vfa_settings', None)
    if settings and settings.pinned:
        obj = settings.pinned_object
        # A missing pinned object must not fall back to the selection.
        return obj if obj and scene.objects.get(obj.name) == obj else None
    obj = context.object if context else None
    if not obj or not scene or scene.objects.get(obj.name) != obj:
        return None
    view_layer = context.view_layer
    if view_layer.objects.get(obj.name) != obj or not obj.select_get(view_layer=view_layer):
        return None
    return obj


def control_owners(context, surface):
    """Find explicit bindings to a selected surface, without guessing a parent."""
    if not context or not surface:
        return []
    from . import ownership
    cache = ownership.get()
    result = []
    for ident in cache['controls'].get(surface.as_pointer(), ()):
        obj = cache['states'][ident][0]
        if obj != surface and context.scene.objects.get(obj.name) == obj:
            result.append(obj)
    return result


def validate_linked_eyes(obj):
    left = obj.vfa_character.left_eye.expressions
    right = obj.vfa_character.right_eye.expressions
    if not left or len(left) != len(right):
        raise ValueError(f'Eye counts differ: {len(left)} / {len(right)}. Repair the libraries or unlink eyes.')


def active_key(obj):
    cfg = obj.vfa_character
    if cfg.mode == 'FULL':
        return 'full_face'
    # Map the retired nose control to mouth in older files.
    return 'mouth' if cfg.active_part == 'nose' else cfg.active_part


def channel(obj, key=''):
    key = key or active_key(obj)
    if key not in LABELS:
        raise ValueError("Unknown face part.")
    return getattr(obj.vfa_character, key)


def all_channels(obj):
    return [(key, channel(obj, key)) for key, _ in CHANNELS]


def channel_key(ch):
    return next(key for key, candidate in all_channels(ch.id_data)
                if candidate.as_pointer() == ch.as_pointer())


def linked(obj, key):
    return obj.vfa_character.link_eyes and key in {'left_eye', 'right_eye'}


def auto_key(obj, key):
    return channel(obj, key).auto_key if key == 'full_face' else obj.vfa_character.auto_key_parts


CLASSES = (VFA_Expression, VFA_Channel, VFA_Character, VFA_MarkerLink, VFA_Settings)
