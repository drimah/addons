import json
import os
import time
from collections import Counter, OrderedDict, deque
import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from . import animation, materials, previews, sequence
from .data import channel, active_key, linked, auto_key, LABELS, target_object, validate_linked_eyes, control_owners

# Retain enum strings for Blender's dynamic-enum lifetime requirements.
_node_items = OrderedDict()
_retired_items = deque(maxlen=64)
_candidate_cache = OrderedDict()
_expression_names = ()


def expression_name_channel(context, writable=False):
    obj = target_object(context)
    if (not obj or not hasattr(obj.data, 'materials')
            or (writable and not obj.is_editable)):
        return None
    ch = channel(obj)
    if not ch.expressions or not materials.surface_available(obj, ch, context.scene):
        return None
    return ch


class VFA_OT_copy_expression_names(bpy.types.Operator):
    bl_idname = 'vfa.copy_expression_names'
    bl_label = 'Copy Names'
    bl_description = 'Copy every expression name in the current list to paste onto another character or face part'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return expression_name_channel(context) is not None

    def execute(self, context):
        global _expression_names
        ch = expression_name_channel(context)
        if ch is None:
            self.report({'ERROR'}, 'Choose an active expression list to copy.')
            return {'CANCELLED'}
        _expression_names = tuple(item.name for item in ch.expressions)
        self.report({'INFO'}, f'Names copied: {len(_expression_names)}.')
        return {'FINISHED'}


class VFA_OT_paste_expression_names(bpy.types.Operator):
    bl_idname = 'vfa.paste_expression_names'
    bl_label = 'Paste Names'
    bl_description = 'Paste names onto the current list in order; stop at the shorter list and retain remaining names'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_expression_names) and expression_name_channel(context, writable=True) is not None

    def execute(self, context):
        ch = expression_name_channel(context, writable=True)
        if ch is None or not _expression_names:
            self.report({'ERROR'}, 'Copy names first, then choose an editable expression list.')
            return {'CANCELLED'}
        pairs = list(zip(ch.expressions, _expression_names))
        if any(item.is_property_readonly('name') for item, _name in pairs):
            self.report({'ERROR'}, 'This expression list is read-only.')
            return {'CANCELLED'}
        for item, name in pairs:
            if item.name != name:
                item.name = name
        self.report({'INFO'}, f'Names pasted: {len(pairs)}.')
        return {'FINISHED'}


def retain_items(key, items):
    previous = _node_items.get(key)
    if previous == items:
        return previous
    if previous:
        _retired_items.append(previous)
    _node_items[key] = items
    _node_items.move_to_end(key)
    while len(_node_items) > 64:
        _retired_items.append(_node_items.popitem(last=False)[1])
    return items


def object_identity(obj):
    return str(getattr(obj, 'session_uid', obj.as_pointer()))


def capture_target(operator, context):
    obj = target_object(context)
    operator.target_name = obj.name if obj else ''
    operator.target_identity = object_identity(obj) if obj else ''
    operator.target_captured = True


def operation_object(operator, context):
    if context is None:
        return None
    if getattr(operator, 'target_captured', False):
        if not operator.target_identity:
            return None
        obj = context.scene.objects.get(operator.target_name)
        if obj and object_identity(obj) == operator.target_identity:
            return obj
        # A rename must not redirect an open browser or connection dialog.
        return next((obj for obj in context.scene.objects
                     if object_identity(obj) == operator.target_identity), None)
    return target_object(context)


def candidate_surfaces(obj, context):
    result = [obj]
    for child in obj.children_recursive:
        if child not in result and context.scene.objects.get(child.name) == child:
            result.append(child)
    for key in ('full_face', 'left_eye', 'right_eye', 'mouth'):
        ch = channel(obj, key)
        for surface in (ch.surface_object, ch.recovery_surface):
            if surface and surface not in result and context.scene.objects.get(surface.name) == surface:
                result.append(surface)
    return [surface for surface in result if hasattr(surface.data, 'materials')]


def candidate_node(operator, context):
    obj = operation_object(operator, context)
    ident, material_ident, name = json.loads(operator.node)
    surface = next((item for item in candidate_surfaces(obj, context)
                    if object_identity(item) == ident), None)
    if surface is None:
        raise ValueError('The selected surface is no longer available. Choose the sequence again.')
    mat = next((slot.material for slot in surface.material_slots
                if slot.material and object_identity(slot.material) == material_ident), None)
    node = mat.node_tree.nodes.get(name) if mat and mat.node_tree else None
    if not node or node.type != 'TEX_IMAGE' or not node.image or node.image.source != 'SEQUENCE':
        raise ValueError('The selected node is no longer an image sequence.')
    return surface, mat, node


def build_candidates(_self, context):
    records = []
    obj = operation_object(_self, context)
    if obj:
        for surface in candidate_surfaces(obj, context):
            seen = set()
            for slot in surface.material_slots:
                mat = slot.material
                if not mat or not mat.use_nodes or mat.as_pointer() in seen:
                    continue
                seen.add(mat.as_pointer())
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.image and node.image.source == 'SEQUENCE':
                        identifier = json.dumps([object_identity(surface), object_identity(mat), node.name])
                        filename = os.path.basename(node.image.filepath.replace(chr(92), '/')) or node.image.name
                        description = f'Object: {surface.name}\nFile: {node.image.filepath}\nMaterial: {mat.name}\nNode: {node.name}'
                        records.append((identifier, filename, surface.name, mat.name, node.name, description))
    filenames = Counter(record[1].casefold() for record in records)
    surfaces = Counter((record[1].casefold(), record[2]) for record in records)
    materials_seen = Counter((record[1].casefold(), record[2], record[3]) for record in records)
    result = []
    for identifier, filename, surface, mat, node, description in records:
        label = filename
        if filenames[filename.casefold()] > 1:
            label += f' - {surface}'
            if surfaces[(filename.casefold(), surface)] > 1:
                label += f' / {mat}'
                if materials_seen[(filename.casefold(), surface, mat)] > 1:
                    label += f' / {node}'
        item = (identifier, label, description)
        result.append(item)
    return result or [('NONE', 'No image sequences found', '')]


def candidates(self, context):
    obj = operation_object(self, context)
    if not obj or not context:
        return [('NONE', 'No image sequences found', '')]
    key = (context.scene.as_pointer(), obj.as_pointer())
    cached = _candidate_cache.get(key)
    now = time.monotonic()
    if cached is None or now >= cached[0]:
        items = retain_items(('sequences', *key), build_candidates(self, context))
        cached = (now + 0.5, items)
        _candidate_cache[key] = cached
    _candidate_cache.move_to_end(key)
    while len(_candidate_cache) > 32:
        _candidate_cache.popitem(last=False)
    return cached[1]


class CharacterOperator:
    @classmethod
    def poll(cls, context):
        obj = target_object(context)
        return obj is not None and hasattr(obj.data, 'materials')


def selection_targets(obj, key, index):
    ch = channel(obj, key)
    if not 0 <= index < len(ch.expressions):
        raise ValueError('Choose an expression from the library before keying.')
    choices = [(ch, ch.expressions[index])]
    if linked(obj, key):
        validate_linked_eyes(obj)
        choices = [(channel(obj, 'left_eye'), channel(obj, 'left_eye').expressions[index]),
                   (channel(obj, 'right_eye'), channel(obj, 'right_eye').expressions[index])]
    result = []
    for target, item in choices:
        node = materials.require_safe(obj, target)
        if not os.path.isfile(bpy.path.abspath(item.filepath)):
            raise ValueError("Source PNG is missing. Use Relink Source Folder for the affected part.")
        if any(existing == node for existing, _ in result):
            raise ValueError("Each eye must use a separate Image Texture node.")
        result.append((node, item.file_number))
    return result


def expression_marker(obj, key, index):
    if not obj.vfa_character.add_markers:
        return None
    if linked(obj, key):
        updates = {eye: channel(obj, eye).expressions[index].name
                   for eye in ('left_eye', 'right_eye')}
    else:
        updates = {key: channel(obj, key).expressions[index].name}
    return obj, updates


class VFA_OT_pin(bpy.types.Operator):
    bl_idname = 'vfa.pin_object'
    bl_label = 'Pin Blender Face Picker Object'
    bl_description = 'Keep Blender Face Picker on this object while selecting others; click again to unpin'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        settings = context.scene.vfa_settings
        obj = target_object(context)
        return settings.pinned or (obj is not None and hasattr(obj.data, 'materials'))

    def execute(self, context):
        settings = context.scene.vfa_settings
        if settings.pinned:
            settings.pinned = False
            settings.pinned_object = None
        else:
            obj = target_object(context)
            if not obj or not hasattr(obj.data, 'materials'):
                self.report({'ERROR'}, "Choose a character to pin.")
                return {'CANCELLED'}
            settings.pinned_object = obj
            settings.pinned = True
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}


class VFA_OT_edit_part(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.edit_part'
    bl_label = 'Edit Face Part'
    bl_description = 'Show this part\'s expression library'
    bl_options = {'UNDO'}
    part: StringProperty()
    show_setup: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):
        result = self.execute(context)
        if result == {'FINISHED'} and self.show_setup:
            part = self.part

            def draw(menu, _context):
                layout = menu.layout
                layout.operator_context = 'INVOKE_DEFAULT'
                op = layout.operator('vfa.import_sequence', text='Create New Image Plane...', icon='FILE_FOLDER')
                op.channel_key = part
                op = layout.operator('vfa.connect_sequence', text='Choose Existing Sequence', icon='NODE_TEXTURE')
                op.channel_key = part

            context.window_manager.popup_menu(draw, title=f'Set Up {LABELS[part]}', icon='IMAGE_DATA')
        return result

    def execute(self, context):
        if self.part not in LABELS or self.part == 'full_face':
            return {'CANCELLED'}
        target_object(context).vfa_character.active_part = self.part
        return {'FINISHED'}


class VFA_OT_import(CharacterOperator, bpy.types.Operator, ImportHelper):
    bl_idname = 'vfa.import_sequence'
    bl_label = 'Create New Image Plane'
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = '.png'
    filter_glob: StringProperty(default='*.png', options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement)
    directory: StringProperty(subtype='DIR_PATH')
    channel_key: StringProperty(options={'HIDDEN'})
    target_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_identity: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_captured: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    plane_width: FloatProperty(name="Plane Width", default=1.0, min=0.001,
                               subtype='DISTANCE', unit='LENGTH')
    replace_library: BoolProperty(name="Replace Expression List", default=False)
    standalone: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        if context.scene is None:
            return False
        settings = context.scene.vfa_settings
        obj = target_object(context)
        # A missing pin requires an explicit unpin, never silent retargeting.
        return not settings.pinned or (obj is not None and hasattr(obj.data, 'materials'))

    def invoke(self, context, event):
        obj = target_object(context)
        self.standalone = not obj or not hasattr(obj.data, 'materials')
        capture_target(self, context)
        self.channel_key = ('full_face' if self.standalone else
                            self.channel_key or active_key(obj))
        return ImportHelper.invoke(self, context, event)

    def draw(self, context):
        obj = None if self.standalone else operation_object(self, context)
        if not self.standalone and obj is None:
            self.layout.label(text="The setup object is no longer available.", icon='ERROR')
            return
        ch = channel(obj, self.channel_key) if obj else None
        key = 'full_face' if self.standalone else self.channel_key or active_key(obj)
        reuse = ch and (ch.surface_object or (obj.get('vfa_standalone_face') and key == 'full_face'))
        if reuse:
            self.layout.label(text="Reuses the current plane and its placement.")
            self.layout.label(text="Replacement resets this part's expression keys.")
        else:
            self.layout.prop(self, 'plane_width')
            self.layout.label(text="Creates a plane at the 3D cursor.")
        self.layout.label(text=f'Part: {LABELS[key]}')
        if ch and ch.expressions:
            self.layout.prop(self, 'replace_library')

    def execute(self, context):
        obj = operation_object(self, context)
        if not self.target_captured:
            self.standalone = not obj or not hasattr(obj.data, 'materials')
        if not self.standalone and obj is None:
            self.report({'ERROR'}, "The setup object is no longer in this scene.")
            return {'CANCELLED'}
        if self.standalone:
            obj = None
        key = 'full_face' if self.standalone else self.channel_key or active_key(obj)
        ch = channel(obj, key) if obj else None
        transaction = materials.SetupTransaction(obj)
        replacing_plane = bool(ch and (ch.surface_object or
                               (obj.get('vfa_standalone_face') and key == 'full_face')))
        previous_active = context.view_layer.objects.active
        previous_selection = tuple(context.selected_objects)
        selection_changed = False
        try:
            if obj:
                materials.require_local(obj)
            if ch and ch.expressions and not self.replace_library:
                raise ValueError("Enable Replace Expression List in the file browser options.")
            paths = sequence.validate([os.path.join(self.directory, f.name) for f in self.files]
                                      or [self.filepath])
            image = sequence.load_native_sequence(context, paths, transaction)
            if replacing_plane:
                node = materials.resolve(ch)
                if not node:
                    raise ValueError("The plane's sequence node is missing. Reconnect it before replacing its library.")
                animation.check_takeover(node, True)
                mat, node = materials.independent(materials.surface(obj, ch), ch.material, node,
                                                  owner=obj, transaction=transaction)
                plane = materials.surface(obj, ch)
                node.image = image
                animation.configure(node, int(sequence.parts(paths[0])[1]), replace=True,
                                    transaction=transaction)
            else:
                plane, mat, node = materials.new_plane(
                    context, obj, LABELS[key], image, self.plane_width, transaction)
                animation.configure(node, int(sequence.parts(paths[0])[1]))
            if self.standalone:
                obj = plane
                obj['vfa_standalone_face'] = True
                ch = channel(obj, key)
            node.label = LABELS[key]
            sequence.fill_library(ch, paths, transaction, native_image=image)
            materials.bind(ch, mat, node)
            ch.surface_object = None if plane == obj else plane
            ch.recovery_surface = None
            previews.clear()
            animation.refresh(context, node)
            if self.standalone:
                selection_changed = True
                for selected in previous_selection:
                    selected.select_set(False)
                plane.select_set(True)
                context.view_layer.objects.active = plane
        except Exception as exc:
            transaction.rollback()
            if selection_changed:
                for selected in previous_selection:
                    selected.select_set(True)
                context.view_layer.objects.active = previous_active
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        transaction.cleanup()
        self.report({'INFO'}, "Library replaced on the existing plane." if replacing_plane else
                    "Image plane created at the 3D cursor.")
        return {'FINISHED'}


def connection_changed(operator, context):
    if not context or not operation_object(operator, context) or operator.node == 'NONE':
        return
    try:
        target, mat, node = candidate_node(operator, context)
        obj = operation_object(operator, context)
        ch = channel(obj, operator.channel_key)
        if (ch.expressions and materials.resolve(ch) == node and ch.material == mat
                and materials.surface(obj, ch) == target
                and sequence.matches_library(ch, node.image)):
            operator.first_number = ch.expressions[0].file_number
            operator.count = len(ch.expressions)
            return
        operator.first_number, count = sequence.discovered_range(node.image)
        operator.count = max(1, count)
    except (ValueError, OSError, IndexError, KeyError, AttributeError):
        operator.first_number = 1
        operator.count = 1


class VFA_OT_connect(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.connect_sequence'
    bl_label = 'Choose Existing Sequence'
    bl_options = {'UNDO'}
    node: EnumProperty(name="Sequence", items=candidates, update=connection_changed)
    show_options: BoolProperty(name="Options", default=False, options={'HIDDEN', 'SKIP_SAVE'})
    channel_key: StringProperty(options={'HIDDEN'})
    target_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_identity: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_captured: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    first_number: IntProperty(name="First Image Number", default=1, min=0, max=1048573,
        description="Number in the first PNG filename to include in this expression library")
    count: IntProperty(name="Sequence Total", default=1, min=1, max=10000,
                       description="Number of contiguous PNGs starting at First Image Number")
    make_independent: BoolProperty(name="Protect Shared Data", default=True,
        description="Copy shared materials and images so this setup cannot change another character")
    animation_mode: EnumProperty(name="Animation", items=(
        ('KEEP', 'Keep Animation', 'Preserve compatible sequence animation already on the selected node'),
        ('CLEAR', 'Clear Animation', 'Remove the selected node sequence keys/drivers and start fresh; other animation is preserved')),
        default='KEEP')
    clear_keyframes: BoolProperty(name="Keyframes", default=True,
        description="Clear only the selected image node sequence keys and drivers")
    clear_markers: BoolProperty(name="Associated Markers", default=True,
        description="Remove only this node's verified Blender Face Picker marker contributions at its keyed frames")
    replace_library: BoolProperty(name="Replace Expression List", default=False,
        description="Allow changing the images while keeping names for matching images or carrying them over in list order")

    def invoke(self, context, event):
        self.animation_mode = 'KEEP'
        _candidate_cache.clear()
        capture_target(self, context)
        self.channel_key = self.channel_key or active_key(operation_object(self, context))
        items = candidates(self, context)
        obj = operation_object(self, context)
        ch = channel(obj, self.channel_key)
        bound_node = materials.resolve(ch)
        chosen = items[0][0]
        if bound_node:
            target = materials.surface(obj, ch)
            for identifier, _label, _description in items:
                if identifier == 'NONE':
                    continue
                surface_id, mat_id, node_name = json.loads(identifier)
                if (surface_id == object_identity(target) and mat_id == object_identity(ch.material)
                        and node_name == bound_node.name):
                    chosen = identifier
                    break
        previous = self.node
        self.node = chosen
        if previous == chosen:
            connection_changed(self, context)
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context):
        obj = operation_object(self, context)
        if obj is None:
            self.layout.label(text="The setup object is no longer available.", icon='ERROR')
            return
        layout = self.layout
        layout.prop(self, 'node')
        layout.prop(self, 'count')
        ch = channel(obj, self.channel_key)
        if ch.expressions:
            layout.prop(self, 'replace_library')
        header = layout.row()
        header.alignment = 'LEFT'
        header.prop(self, 'show_options', emboss=False, text='Options',
                    icon='TRIA_DOWN' if self.show_options else 'TRIA_RIGHT')
        if self.show_options:
            layout.prop(self, 'first_number')
            layout.prop(self, 'make_independent')
            layout.prop(self, 'animation_mode', expand=True)
            if self.animation_mode == 'CLEAR':
                layout.prop(self, 'clear_keyframes')
                layout.prop(self, 'clear_markers')

    def execute(self, context):
        obj = operation_object(self, context)
        if obj is None:
            self.report({'ERROR'}, "The setup object is no longer in this scene.")
            return {'CANCELLED'}
        ch = channel(obj, self.channel_key)
        transaction = materials.SetupTransaction(obj)
        try:
            if self.node == 'NONE':
                raise ValueError("No image sequence node found in the character's materials.")
            surface, mat, node = candidate_node(self, context)
            materials.require_local(obj)
            materials.require_local(surface, mat)
            materials.require_unused(obj, ch, node)
            # Reuse saved frames when clearing this binding, even if PNGs are missing.
            # New bindings and ranges still need source validation.
            clearing_saved = (self.animation_mode == 'CLEAR' and ch.expressions
                              and materials.resolve(ch) == node and ch.material == mat
                              and materials.surface(obj, ch) == surface
                              and sequence.matches_library(ch, node.image)
                              and self.count == len(ch.expressions)
                              and self.first_number == ch.expressions[0].file_number)
            paths = ([bpy.path.abspath(item.filepath) for item in ch.expressions] if clearing_saved
                     else sequence.existing_paths(node.image, self.count, self.first_number))
            normalize = lambda p: os.path.normcase(os.path.realpath(bpy.path.abspath(p)))
            same_library = bool(ch.expressions) and [normalize(item.filepath) for item in ch.expressions] == [normalize(p) for p in paths]
            if ch.expressions and not same_library and not self.replace_library:
                raise ValueError("This selection changes the saved library. Enable Replace Expression List in this dialog, then click OK.")
            clearing_keys = self.animation_mode == 'CLEAR' and self.clear_keyframes
            clearing_markers = self.animation_mode == 'CLEAR' and self.clear_markers
            if self.animation_mode == 'CLEAR' and not (clearing_keys or clearing_markers):
                raise ValueError('Choose Keyframes, Associated Markers, or both under Clear Animation.')
            marker_edits = animation.associated_marker_edits(context.scene, obj, node) if clearing_markers else []
            preserve_animation = not clearing_keys and animation.can_keep_animation(
                node, {int(sequence.parts(path)[1]) for path in paths})
            replace_animation = clearing_keys
            if not preserve_animation:
                if not clearing_keys and animation.has_sequence_animation(node):
                    raise ValueError('Existing animation is not compatible with the selected library. '
                                     'Keep the original frame range, or choose Clear Animation under Options to start fresh.')
                animation.check_takeover(node, replace_animation)
            shared_mat = materials.shared_material(surface, mat, obj)
            shared_image = materials.shared_image(node.image) or node.image.library
            if (shared_mat or shared_image) and not self.make_independent:
                raise ValueError('Enable Protect Shared Data under Options to protect other characters.')
            # Bind before copying so the transaction can redirect the surface.
            materials.bind(ch, mat, node)
            ch.surface_object = None if surface == obj else surface
            if shared_mat or shared_image or not preserve_animation or materials.shared_surface(surface, obj):
                mat, node = materials.independent(surface, mat, node, owner=obj, transaction=transaction)
            if not preserve_animation:
                animation.configure(node, int(sequence.parts(paths[0])[1]), replace_animation,
                                    transaction=transaction)
            if not same_library:
                sequence.fill_library(ch, paths, transaction, native_image=node.image)
            materials.bind(ch, mat, node)
            ch.recovery_surface = None
            # Fix the filename template on a private image.
            if normalize(node.image.filepath) != normalize(paths[0]):
                staged = transaction.track(bpy.data.images, node.image.copy())
                staged.filepath = sequence.stored_path(paths[0])
                transaction.remember_image(node)
                node.image = staged
            for edit in marker_edits:
                transaction.marker_edits.append(edit)
                edit.apply()
            previews.clear()
            animation.refresh(context, node)
        except Exception as exc:
            transaction.rollback()
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        transaction.cleanup()
        return {'FINISHED'}


class VFA_OT_select(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.select_expression'
    bl_label = 'Select Expression'
    bl_description = 'Display this expression; insert or update a key when Auto Keyframe is on'
    bl_options = {'UNDO'}
    index: IntProperty()
    channel_key: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        obj = target_object(context)
        key = self.channel_key or active_key(obj)
        try:
            targets = selection_targets(obj, key, self.index)
            animation.apply_expressions(context, targets, auto_key(obj, key),
                                        marker=expression_marker(obj, key, self.index),
                                        keyframe_type=obj.vfa_character.keyframe_type)
            if key != 'full_face':
                obj.vfa_character.active_part = key
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class VFA_OT_key(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.key_expression'
    bl_label = 'Insert Expression Keyframe'
    bl_options = {'UNDO'}

    def execute(self, context):
        try:
            obj = target_object(context)
            key = active_key(obj)
            index = previews.selected_get(channel(obj, key))
            targets = selection_targets(obj, key, index)
            animation.apply_expressions(context, targets, True,
                                        marker=expression_marker(obj, key, index),
                                        keyframe_type=obj.vfa_character.keyframe_type)
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class VFA_OT_independent(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.make_independent'
    bl_label = 'Make Independent'
    bl_description = 'Copy a shared face plane, material, animation action and sequence image for this character'
    bl_options = {'UNDO'}
    channel_key: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        obj = target_object(context)
        ch = channel(obj, self.channel_key)
        transaction = materials.SetupTransaction(obj)
        try:
            materials.require_local(obj)
            node = materials.resolve(ch)
            if not node:
                raise ValueError("Connect a face sequence first.")
            mat, node = materials.independent(materials.surface(obj, ch), ch.material, node,
                                              owner=obj, transaction=transaction)
            materials.bind(ch, mat, node)
            animation.refresh(context, node)
        except Exception as exc:
            transaction.rollback()
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        transaction.cleanup()
        return {'FINISHED'}


class VFA_OT_relink(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.relink_sources'
    bl_label = 'Relink Source Folder'
    bl_description = 'Choose the source folder or its first numbered PNG; retain expression names and keyframes'
    bl_options = {'UNDO'}
    directory: StringProperty(subtype='DIR_PATH')
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.png', options={'HIDDEN'})
    filter_image: BoolProperty(default=True, options={'HIDDEN'})
    channel_key: StringProperty(options={'HIDDEN'})
    target_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_identity: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_captured: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    filter_folder: BoolProperty(default=True, options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = ''
        capture_target(self, context)
        self.channel_key = self.channel_key or active_key(operation_object(self, context))
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        obj = operation_object(self, context)
        if obj is None:
            self.report({'ERROR'}, "The setup object is no longer in this scene.")
            return {'CANCELLED'}
        ch = channel(obj, self.channel_key)
        transaction = materials.SetupTransaction(obj)
        try:
            node = materials.require_safe(obj, ch)
            paths, first_path = sequence.relink_paths(ch, node.image, self.directory, self.filepath)
            # Reload a staged image before changing the live image or paths.
            image = transaction.track(bpy.data.images, node.image.copy())
            image.filepath = sequence.stored_path(first_path)
            image.reload()
            transaction.remember_image(node)
            node.image = image
            for item, path in zip(ch.expressions, paths):
                item.filepath = sequence.stored_path(path)
            sequence.set_library_source(ch, first_path, transaction, native_image=image)
            previews.clear()
            animation.refresh(context, node)
        except Exception as exc:
            transaction.rollback()
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        transaction.cleanup()
        return {'FINISHED'}


class VFA_OT_disconnect(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.disconnect_sequence'
    bl_label = 'Disconnect Sequence'
    bl_description = "Clear this part's Blender Face Picker library and binding; keep its objects, materials, images and animation"
    bl_options = {'REGISTER', 'UNDO'}
    channel_key: StringProperty(options={'HIDDEN'})
    target_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_identity: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target_captured: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):
        capture_target(self, context)
        obj = operation_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        self.channel_key = self.channel_key or active_key(obj)
        return self.execute(context)

    def execute(self, context):
        obj = operation_object(self, context)
        if obj is None:
            self.report({'ERROR'}, "The setup object is no longer in this scene.")
            return {'CANCELLED'}
        key = self.channel_key or active_key(obj)
        if key not in {'full_face', 'left_eye', 'right_eye', 'mouth'}:
            self.report({'ERROR'}, "Choose a face part to disconnect.")
            return {'CANCELLED'}
        ch = channel(obj, key)
        ch.recovery_surface = ch.surface_object or ch.recovery_surface
        ch.expressions.clear()
        source = ch.source_image
        ch.source_image = None
        if source and source.get('vfa_library_source') and source.users == 0:
            bpy.data.images.remove(source)
        ch.node_name = ''
        ch.node_id = ''
        ch.material = None
        ch.surface_object = None
        previews.clear()
        if context.area:
            context.area.tag_redraw()
        self.report({'INFO'}, f'{LABELS[key]} disconnected. Choose Existing Sequence to reconnect it.')
        return {'FINISHED'}


class VFA_OT_go_controls(bpy.types.Operator):
    bl_idname = 'vfa.go_face_controls'
    bl_label = 'Go to Face Controls'
    bl_description = 'Select the character that owns these face controls'
    bl_options = {'UNDO'}
    owner_identity: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    source_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    source_identity: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    owner_choice: EnumProperty(name='Character', items=lambda self, context: owner_choices(self, context))

    @classmethod
    def poll(cls, context):
        return bool(control_owners(context, context.object))

    def invoke(self, context, event):
        self.owner_identity = ''
        self.source_name = context.object.name if context.object else ''
        self.source_identity = object_identity(context.object) if context.object else ''
        owners = control_owners(context, context.object)
        if len(owners) == 1:
            self.owner_identity = object_identity(owners[0])
            return self.execute(context)
        if not owners:
            return {'CANCELLED'}
        self.owner_choice = object_identity(owners[0])
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.label(text='More than one character uses this surface.')
        self.layout.prop(self, 'owner_choice')

    def execute(self, context):
        ident = self.owner_identity or self.owner_choice
        source = next((item for item in context.scene.objects
                       if object_identity(item) == self.source_identity), None) if self.source_identity else context.object
        owner = next((obj for obj in control_owners(context, source)
                      if object_identity(obj) == ident), None)
        if owner is None or context.view_layer.objects.get(owner.name) != owner:
            self.report({'ERROR'}, 'The chosen character is not available in this view layer.')
            return {'CANCELLED'}
        if owner.hide_get() or owner.hide_select:
            self.report({'ERROR'}, 'Unhide and enable selection for the character first.')
            return {'CANCELLED'}
        for obj in context.selected_objects:
            obj.select_set(False)
        owner.select_set(True)
        context.view_layer.objects.active = owner
        settings = context.scene.vfa_settings
        if settings.pinned:
            settings.pinned_object = owner
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


def owner_choices(self, context):
    result = []
    source = next((obj for obj in context.scene.objects
                   if object_identity(obj) == self.source_identity), None) if self.source_identity else context.object
    for obj in control_owners(context, source):
        item = (object_identity(obj), obj.name, 'Show this character face controls')
        result.append(item)
    return retain_items(('owners', source.as_pointer() if source else 0),
                        result or [('NONE', 'No character found', '')])


class VFA_OT_link_eyes(CharacterOperator, bpy.types.Operator):
    bl_idname = 'vfa.toggle_link_eyes'
    bl_label = 'Link Eyes'
    bl_description = 'Select and key both eyes by expression order; click again to unlink'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = target_object(context)
        cfg = obj.vfa_character
        if not cfg.link_eyes:
            try:
                validate_linked_eyes(obj)
            except ValueError as exc:
                self.report({'ERROR'}, str(exc))
                return {'CANCELLED'}
        cfg.link_eyes = not cfg.link_eyes
        return {'FINISHED'}


class VFA_OT_previews(bpy.types.Operator):
    bl_idname = 'vfa.refresh_previews'
    bl_label = 'Refresh Thumbnails'

    def execute(self, context):
        previews.clear()
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


CLASSES = (VFA_OT_pin, VFA_OT_edit_part, VFA_OT_import, VFA_OT_connect, VFA_OT_select, VFA_OT_key,
           VFA_OT_independent, VFA_OT_relink, VFA_OT_disconnect, VFA_OT_go_controls, VFA_OT_link_eyes, VFA_OT_previews,
           VFA_OT_copy_expression_names, VFA_OT_paste_expression_names)
