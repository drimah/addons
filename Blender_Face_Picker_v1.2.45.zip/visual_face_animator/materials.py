import uuid
import bpy
from .data import all_channels
from . import ownership


def resolve(ch):
    mat = ch.material
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    node = mat.node_tree.nodes.get(ch.node_name)
    if node and node.type == 'TEX_IMAGE' and node.get('vfa_id') == ch.node_id:
        return node
    return next((n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE'
                 and n.get('vfa_id') == ch.node_id and ch.node_id), None)


def surface(obj, ch):
    return ch.surface_object or obj


def borrowers(obj, owner):
    cache = ownership.get()
    return [cache['states'][ident][0]
            for ident in cache['surfaces'].get(obj.as_pointer(), ())
            if ident != owner.as_pointer()]


def surface_owner(obj):
    # Older planes use parenting; new planes store their controller directly.
    return obj.vfa_character.surface_owner or obj.parent


def shared_surface(obj, owner):
    if obj == owner:
        return False
    primary = surface_owner(obj)
    return (primary is not None and primary != owner
            or obj.parent is not None and obj.parent != owner
            or bool(borrowers(obj, owner)))


def require_copy_owner(obj, owner):
    # Isolate the borrower first, or the original would leave it pointing at the old plane.
    if obj != owner and surface_owner(obj) == owner:
        others = borrowers(obj, owner)
        if others:
            raise ValueError(f'This plane belongs to {owner.name}. Select {others[0].name} '
                             'and use Make Independent there first.')


class SetupTransaction:
    """Keep previous bindings and slots intact until setup and refresh succeed."""
    def __init__(self, owner):
        self.owner = owner
        self.channels = []
        for _, ch in (all_channels(owner) if owner else ()):
            binding = (ch.surface_object, ch.material, ch.node_name, ch.node_id, ch.recovery_surface,
                       ch.source_image)
            expressions = [(e.name, e.filepath, e.sequence_frame, e.file_number)
                           for e in ch.expressions]
            self.channels.append((ch, binding, expressions))
        self.slots = []
        self.created = []
        self.images = []
        self.marker_edits = []

    def track(self, collection, item):
        item.use_fake_user = False
        self.created.append((collection, item))
        return item

    def remember_slots(self, obj):
        if not any(saved == obj for saved, _, _ in self.slots):
            self.slots.append((obj, [(s.link, s.material) for s in obj.material_slots],
                               obj.active_material_index))

    def remember_image(self, node):
        self.images.append((node, node.image))

    def cleanup(self):
        # Removing a mesh or material may release another staged datablock.
        for _ in range(5):
            remaining = []
            for collection, item in reversed(self.created):
                try:
                    if item.users == 0:
                        collection.remove(item)
                    else:
                        remaining.append((collection, item))
                except ReferenceError:
                    pass
            self.created = list(reversed(remaining))

    def rollback(self):
        marker_errors = []
        for edit in reversed(self.marker_edits):
            try:
                edit.rollback()
            except Exception as exc:
                marker_errors.append(str(exc))
        for node, image in self.images:
            node.image = image
        for obj, slots, active in self.slots:
            for slot, (link, mat) in zip(obj.material_slots, slots):
                slot.link = link
                slot.material = mat
            obj.active_material_index = active
        for ch, binding, expressions in self.channels:
            (ch.surface_object, ch.material, ch.node_name, ch.node_id, ch.recovery_surface,
             ch.source_image) = binding
            ch.expressions.clear()
            for name, filepath, frame, number in expressions:
                e = ch.expressions.add()
                e.name, e.filepath = name, filepath
                e.sequence_frame, e.file_number = frame, number
        for collection, item in self.created:
            if collection == bpy.data.objects:
                bpy.data.objects.remove(item, do_unlink=True)
        self.cleanup()
        ownership.invalidate()
        if marker_errors:
            raise RuntimeError('Setup restored, but marker cleanup failed: ' + '; '.join(marker_errors))


def shared_material(obj, mat, owner=None):
    allowed = {obj.as_pointer(), (owner or obj).as_pointer()}
    cache = ownership.get()
    if cache['material_counts'].get(mat.as_pointer()) != mat.users:
        ownership.invalidate()
        cache = ownership.get()
    return bool(cache['materials'].get(mat.as_pointer(), set()) - allowed)


def shared_image(image):
    # Fake User saves the image but does not share it with another consumer.
    return image.users - int(image.use_fake_user) > 1


def copy_action(tree, transaction=None):
    ad = tree.animation_data
    if ad and ad.action:
        identifier = ad.action_slot.identifier if ad.action_slot else None
        ad.action = ad.action.copy()
        if transaction:
            transaction.track(bpy.data.actions, ad.action)
        if identifier:
            ad.action_slot = next(s for s in ad.action.slots if s.identifier == identifier)


def independent(obj, mat, node=None, owner=None, transaction=None):
    owner = owner or obj
    own_transaction = transaction is None
    transaction = transaction or SetupTransaction(owner)
    try:
        result = _independent(obj, mat, node, owner, transaction)
    except Exception:
        if own_transaction:
            transaction.rollback()
        raise
    if own_transaction:
        transaction.cleanup()
    return result


def _independent(obj, mat, node, owner, transaction):
    require_local(obj, mat)
    require_copy_owner(obj, owner)
    indices = [i for i, slot in enumerate(obj.material_slots) if slot.material == mat]
    if not indices:
        raise ValueError("The connected material is no longer assigned to this surface.")
    bound = [ch for _, ch in all_channels(owner)
             if ch.material == mat and surface(owner, ch) == obj]
    bound_names = {resolve(ch).name for ch in bound if resolve(ch)}
    if node:
        bound_names.add(node.name)
    if shared_surface(obj, owner):
        source = obj
        obj = transaction.track(bpy.data.objects, source.copy())
        obj.data = transaction.track(bpy.data.meshes, source.data.copy())
        (owner.users_collection[0] if owner.users_collection else bpy.context.collection).objects.link(obj)
        copy_action(obj, transaction)
        # Keep the part in the equivalent position on the duplicate character.
        previous_owner = surface_owner(source)
        world = (owner.matrix_world @ previous_owner.matrix_world.inverted_safe() @ source.matrix_world
                 if previous_owner else source.matrix_world.copy())
        obj.parent = owner if source.parent else None
        if obj.parent:
            obj.matrix_parent_inverse = owner.matrix_world.inverted_safe()
        obj.vfa_character.surface_owner = owner
        obj.matrix_world = world
        for modifier in obj.modifiers:
            if modifier.type == 'SHRINKWRAP' and previous_owner and modifier.target == previous_owner:
                modifier.target = owner
        for _, ch in all_channels(owner):
            if ch.surface_object == source:
                ch.surface_object = obj
    transaction.remember_slots(obj)
    copied = transaction.track(bpy.data.materials, mat.copy())
    part = mat.get('vfa_material_type')
    if part:
        copied.name = (mat.name if obj == owner and owner.get('vfa_standalone_face') else
                       generated_material_name(owner.name, part))
    else:
        copied.name = f'{mat.name} - {owner.name}'
    copy_action(copied.node_tree, transaction)
    copied_node = copied.node_tree.nodes.get(node.name) if node else None
    for name in bound_names:
        image_node = copied.node_tree.nodes.get(name)
        if image_node and image_node.image:
            image_node.image = transaction.track(bpy.data.images, image_node.image.copy())
    for index in indices:
        obj.material_slots[index].link = 'OBJECT'
        obj.material_slots[index].material = copied
    for ch in bound:
        ch.material = copied
    ownership.invalidate()
    return copied, copied_node


def require_unused(obj, ch, node):
    for _, other in all_channels(obj):
        if other.as_pointer() != ch.as_pointer() and resolve(other) == node:
            raise ValueError("This Image Texture node already controls another face part. Use a separate node.")


def require_local(obj, mat=None):
    if not obj or not hasattr(obj.data, 'materials'):
        raise ValueError("Select a character object that supports materials.")
    if not obj.is_editable or (mat and (not mat.is_editable or not mat.node_tree
                                      or not mat.node_tree.is_editable)):
        raise ValueError("Use a local editable character and material.")


def surface_available(obj, ch, scene):
    target = surface(obj, ch)
    return bool(scene and target and scene.objects.get(target.name) == target)


def require_safe(obj, ch):
    owner = obj
    require_local(owner)
    if not surface_available(owner, ch, bpy.context.scene):
        raise ValueError('The connected face surface is not in this scene. Disconnect or choose an existing sequence.')
    obj = surface(owner, ch)
    require_local(obj, ch.material)
    node = resolve(ch)
    if not node or not node.image or node.image.source != 'SEQUENCE':
        raise ValueError("Reconnect a valid Image Texture sequence in Setup.")
    if not any(s.material == ch.material for s in obj.material_slots):
        raise ValueError("The connected material is no longer on this character.")
    if shared_surface(obj, owner):
        require_copy_owner(obj, owner)
        raise ValueError("This plane belongs to another character. Click Make Independent first.")
    if shared_material(obj, ch.material, owner) or shared_image(node.image):
        raise ValueError("The material or image is shared. Click Make Independent first.")
    if node.image.library:
        raise ValueError("The image is linked. Click Make Independent first.")
    user = node.image_user
    if user.frame_duration != 1 or not user.use_cyclic or not user.use_auto_refresh:
        raise ValueError("Sequence settings were changed externally. Reconnect in Setup.")
    ad = node.id_data.animation_data
    if ad:
        from .animation import SETTINGS, action_curves, paths
        if any(c.data_path in paths(node) for c in ad.drivers):
            raise ValueError("Sequence settings are driven externally. Reconnect in Setup.")
        fixed = {node.image_user.path_from_id(p) for p in SETTINGS if p != 'frame_offset'}
        if any(c.data_path in fixed for _, c in action_curves(ad.action, ad.action_slot)):
            raise ValueError("Sequence hold settings are animated externally. Reconnect in Setup.")
        if any(c.data_path in paths(node) for track in ad.nla_tracks for strip in track.strips
               for _, c in action_curves(strip.action)):
            raise ValueError("NLA sequence animation is not supported in V1.")
    return node


def connection_status(obj, ch):
    if not ch.expressions:
        return False, 'Disconnected'
    try:
        require_safe(obj, ch)
    except (ValueError, RuntimeError, ReferenceError) as exc:
        return False, str(exc)
    return True, 'Connected'


def bind(ch, mat, node):
    if not node.get('vfa_id'):
        node['vfa_id'] = uuid.uuid4().hex
    ch.material = mat
    ch.node_name = node.name
    ch.node_id = node['vfa_id']


def generated_material_name(object_name, part):
    return f'{"_".join(object_name.split())}_{"_".join(part.split())}'


def new_material(obj, image, transaction=None, name=None):
    mat = bpy.data.materials.new(name or obj.name)
    if transaction:
        transaction.track(bpy.data.materials, mat)
    mat.use_nodes = True
    mat.surface_render_method = 'DITHERED'
    node = mat.node_tree.nodes.new('ShaderNodeTexImage')
    node.name = "Face Sequence"
    node.label = "Full Face"
    node.image = image
    node.extension = 'CLIP'
    shader = next(n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
    output = next(n for n in mat.node_tree.nodes if n.type == 'OUTPUT_MATERIAL')
    # New node dimensions are unavailable until drawn, so use fixed spacing.
    node.location = (-520, 220)
    node.width = 280
    shader.location = (-100, 220)
    shader.width = 280
    output.location = (320, 220)
    output.width = 200
    mat.node_tree.links.new(node.outputs['Color'], shader.inputs['Base Color'])
    mat.node_tree.links.new(node.outputs['Alpha'], shader.inputs['Alpha'])
    # Appending a slot must not change another object's shared mesh data.
    if obj.data.users > 1:
        obj.data = obj.data.copy()
    obj.data.materials.append(mat)
    obj.active_material_index = len(obj.material_slots) - 1
    return mat, node


def new_plane(context, owner, label, image, width, transaction):
    """Create a UV-mapped surface without changing the active character."""
    name = f'{owner.name} - {label}' if owner else f'Face - {label}'
    mesh = transaction.track(bpy.data.meshes, bpy.data.meshes.new(name))
    plane = transaction.track(bpy.data.objects, bpy.data.objects.new(mesh.name, mesh))
    collection = owner.users_collection[0] if owner and owner.users_collection else context.collection
    collection.objects.link(plane)
    # A fresh native sequence copy may not have a loaded pixel buffer yet.
    from .sequence import png_dimensions
    image_width, image_height = png_dimensions(bpy.path.abspath(image.filepath))
    half_width = width / 2
    half_height = half_width * image_height / image_width
    # Two cuts per axis produce 3 x 3 quads with a continuous 0..1 UV map.
    vertices = [(-half_width + 2 * half_width * x / 3,
                 -half_height + 2 * half_height * y / 3, 0)
                for y in range(4) for x in range(4)]
    faces = [(y * 4 + x, y * 4 + x + 1, (y + 1) * 4 + x + 1, (y + 1) * 4 + x)
             for y in range(3) for x in range(3)]
    mesh.from_pydata(vertices, [], faces)
    uv = mesh.uv_layers.new(name='UVMap')
    for loop in mesh.loops:
        index = loop.vertex_index
        uv.data[loop.index].uv = ((index % 4) / 3, (index // 4) / 3)
    mesh.update()
    plane.vfa_character.surface_owner = owner
    plane.matrix_world = context.scene.cursor.matrix.copy()
    mat, node = new_material(plane, image, transaction,
                             name=generated_material_name(owner.name if owner else 'Face', label))
    mat['vfa_material_type'] = label
    node.label = label
    return plane, mat, node
