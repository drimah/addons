"""Lazy ownership lookup, invalidated by assignments rather than playback."""
import bpy
from bpy.app.handlers import persistent
from .data import all_channels

_cache = None


def pointer(value):
    return value.as_pointer() if value else 0


def state(obj):
    return (pointer(obj.parent), pointer(obj.data),
            tuple((slot.link, pointer(slot.material)) for slot in obj.material_slots),
            tuple((pointer(ch.material), pointer(ch.surface_object), pointer(ch.recovery_surface))
                  for _, ch in all_channels(obj)))


@persistent
def invalidate(*_args):
    global _cache
    _cache = None


def changed(_self, _context):
    invalidate()


def get():
    global _cache
    if _cache is None or _cache['count'] != len(bpy.data.objects):
        materials, surfaces, states, data_users, controls = {}, {}, {}, {}, {}
        for obj in bpy.data.objects:
            ident = pointer(obj)
            signature = state(obj)
            states[ident] = (obj, signature)
            data_users.setdefault(signature[1], []).append(obj)
            for _, mat in signature[2]:
                if mat:
                    materials.setdefault(mat, set()).add(ident)
            for mat, surface, recovery in signature[3]:
                if mat:
                    materials.setdefault(mat, set()).add(ident)
                if surface:
                    surfaces.setdefault(surface, set()).add(ident)
                for target in (surface, recovery):
                    if target:
                        controls.setdefault(target, set()).add(ident)
        _cache = dict(count=len(bpy.data.objects), materials=materials, surfaces=surfaces, controls=controls,
                      states=states, data_users=data_users,
                      material_counts={pointer(mat): mat.users for mat in bpy.data.materials})
    return _cache


@persistent
def update(_scene, depsgraph):
    # Check updated objects only; transforms and expressions do not change ownership.
    if _cache is None:
        return
    if _cache['count'] != len(bpy.data.objects):
        invalidate()
        return
    try:
        for entry in depsgraph.updates:
            datablock = entry.id.original
            if isinstance(datablock, bpy.types.Object):
                objects = (datablock,)
            else:
                objects = _cache['data_users'].get(pointer(datablock), ())
            for obj in objects:
                saved = _cache['states'].get(pointer(obj))
                if saved is None or saved[1] != state(obj):
                    invalidate()
                    return
    except ReferenceError:
        invalidate()


def register():
    invalidate()
    for handlers, callback in ((bpy.app.handlers.load_post, invalidate),
                               (bpy.app.handlers.undo_post, invalidate),
                               (bpy.app.handlers.redo_post, invalidate),
                               (bpy.app.handlers.depsgraph_update_post, update)):
        handlers.append(callback)


def unregister():
    for handlers, callback in ((bpy.app.handlers.load_post, invalidate),
                               (bpy.app.handlers.undo_post, invalidate),
                               (bpy.app.handlers.redo_post, invalidate),
                               (bpy.app.handlers.depsgraph_update_post, update)):
        if callback in handlers:
            handlers.remove(callback)
    invalidate()
