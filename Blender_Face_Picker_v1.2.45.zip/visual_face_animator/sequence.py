import os
import re
import struct
import bpy
from bpy.app.handlers import persistent


def natural_key(path):
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r'(\d+)', os.path.basename(path))]


def parts(path):
    filename = path.replace('\\', '/').rsplit('/', 1)[-1]
    match = re.fullmatch(r'(.*?)(\d+)(\.[pP][nN][gG])', filename)
    if not match:
        raise ValueError("Use numbered PNG names such as Face_001.png.")
    return match.group(1), match.group(2), match.group(3)


def png_dimensions(path):
    try:
        with open(path, 'rb') as stream:
            header = stream.read(24)
    except OSError as exc:
        raise ValueError(f"Cannot read {os.path.basename(path)}: {exc}") from exc
    if len(header) != 24 or header[:8] != b'\x89PNG\r\n\x1a\n' or header[12:16] != b'IHDR':
        raise ValueError(f"Not a valid PNG: {os.path.basename(path)}")
    dimensions = struct.unpack('>II', header[16:24])
    if not all(dimensions):
        raise ValueError("Every expression must have the same nonzero image dimensions.")
    return dimensions


def validate(paths):
    paths = sorted((os.path.abspath(p) for p in paths), key=natural_key)
    if not paths:
        raise ValueError("Select one or more numbered PNG files.")
    if len(set(map(os.path.normcase, paths))) != len(paths):
        raise ValueError("The selection contains duplicate files.")
    if len({os.path.normcase(os.path.dirname(p)) for p in paths}) != 1:
        raise ValueError("All expressions must be in the same directory.")
    prefix, digits, suffix = parts(paths[0])
    first = int(digits)
    size = None
    for index, path in enumerate(paths):
        head, number, tail = parts(path)
        expected = first + index
        if (head != prefix or tail != suffix or int(number) != expected
                or number != str(expected).zfill(number_width(digits))):
            raise ValueError("Select a contiguous sequence with the same prefix and numbering format; no gaps.")
        if expected > 1048573:
            raise ValueError("Sequence file numbers must be between 0 and 1048573.")
        dimensions = png_dimensions(path)
        if size and dimensions != size:
            raise ValueError("Every expression must have the same nonzero image dimensions.")
        size = dimensions
    return paths


def stored_path(path):
    if bpy.data.filepath:
        try:
            return bpy.path.relpath(path)
        except ValueError:
            pass
    return path


def matches_library(ch, image):
    """Verify the image's source against saved paths without reading PNGs."""
    if not image or image.source != 'SEQUENCE':
        return False
    normalize = lambda path: os.path.normcase(os.path.abspath(path))
    source = normalize(bpy.path.abspath(image.filepath, library=image.library))
    return any(normalize(bpy.path.abspath(item.filepath)) == source for item in ch.expressions)


def load_native_sequence(context, paths, transaction):
    """Use Blender's image opener without assigning images to the active editor."""
    before = {image.as_pointer(): image.filepath_raw for image in bpy.data.images}
    staged = None
    normalize = lambda path: os.path.normcase(os.path.realpath(path))
    sources = {normalize(path) for path in paths}
    try:
        # Native Open reuses matching images and adds a user even without an
        # editor assignment. Hide matching raw paths for this synchronous call
        # so sequence detection creates private data instead. Raw assignment
        # leaves existing pixel buffers intact; finally restores every path.
        for image in bpy.data.images:
            if image.library is None and normalize(bpy.path.abspath(image.filepath)) in sources:
                image.filepath_raw = ''
        with context.temp_override(area=None, region=None, image_user=None,
                                   edit_image=None, edit_image_user=None, texture=None, camera=None):
            result = bpy.ops.image.open(
                'EXEC_DEFAULT', False, filepath=paths[0], directory=os.path.dirname(paths[0]),
                files=[{'name': os.path.basename(path)} for path in paths],
                use_sequence_detection=True, use_udim_detecting=False, relative_path=False)
        if 'FINISHED' not in result:
            raise ValueError('Blender could not open this image sequence.')
        loaded = next((image for image in bpy.data.images
                       if image.as_pointer() not in before and image.library is None
                       and normalize(bpy.path.abspath(image.filepath)) == normalize(paths[0])), None)
        if loaded is None:
            raise ValueError('Blender did not return the selected sequence.')
        # Keep the native opener's initial user count off the bound image.
        staged = transaction.track(bpy.data.images, loaded.copy())
        staged.source = 'SEQUENCE'
        staged.filepath = stored_path(paths[0])
        return staged
    finally:
        for image in list(bpy.data.images):
            ident = image.as_pointer()
            if ident in before:
                if image.filepath_raw != before[ident]:
                    image.filepath_raw = before[ident]
            elif image != staged:
                bpy.data.images.remove(image)


def number_width(digits):
    return len(digits) if len(digits) > 1 and digits.startswith('0') else 1


def sequence_files(image):
    """Index the existing files once; preserve Blender's actual filename numbers."""
    path = bpy.path.abspath(image.filepath, library=image.library)
    head, digits, tail = parts(path)
    matches = []
    with os.scandir(os.path.dirname(path)) as contents:
        for entry in contents:
            if not entry.is_file():
                continue
            try:
                prefix, number, suffix = parts(entry.name)
            except ValueError:
                continue
            value = int(number)
            if prefix == head and suffix == tail:
                matches.append((value, number, entry.path))
    anchor = int(digits)
    # At 100, both unpadded and three-digit names look identical. Infer padding
    # from the contiguous neighboring files instead of discarding 001..099.
    widths = {number_width(digits)}
    if not digits.startswith('0'):
        widths.update(number_width(number) for _value, number, _path in matches
                      if number_width(number) <= len(digits))
    choices = {}
    for width in widths:
        found = {value: filename for value, number, filename in matches
                 if number == str(value).zfill(width)}
        first = anchor
        while first - 1 in found and anchor - first < 9999:
            first -= 1
        last = anchor
        while last + 1 in found and last - first < 9999:
            last += 1
        # Schemes with the same reachable files are equivalent at this anchor.
        signature = tuple(found.get(value) for value in range(first, last + 1))
        choices[signature] = found
    file_sets = {signature: frozenset(found.values()) for signature, found in choices.items()}
    connected = [signature for signature in choices if len(signature) > 1
                 and not any(set(signature) < set(other) or file_sets[signature] < file_sets[other]
                             for other in choices)]
    if len(connected) > 1:
        raise ValueError('Ambiguous sequence numbering. Choose a source PNG with a leading zero or remove duplicate numbering schemes.')
    chosen = connected[0] if connected else next(iter(choices))
    return choices[chosen], anchor


def discovered_range(image):
    files, anchor = sequence_files(image)
    if anchor not in files:
        raise ValueError('Source PNG is missing. Use Relink Source Folder.')
    first = anchor
    while first - 1 in files and anchor - first < 9999:
        first -= 1
    count = 0
    while first + count in files and count < 10000:
        count += 1
    return first, count


def sequence_start(image):
    return discovered_range(image)[0]


def available_count(image, first=None):
    if first is None:
        return discovered_range(image)[1]
    files, _anchor = sequence_files(image)
    count = 0
    while first + count in files and count < 10000:
        count += 1
    return count


def existing_paths(image, count, first=None):
    files, anchor = sequence_files(image)
    first = anchor if first is None else first
    try:
        paths = [files[first + i] for i in range(count)]
    except KeyError as exc:
        raise ValueError(f'Image number {exc.args[0]} is missing. Check First Image Number and Sequence Total.') from exc
    return validate(paths)


def relink_paths(ch, image, directory, selected_file=''):
    """Recover a saved frame mapping using actual filenames in the new folder."""
    entries = list(ch.expressions)
    if not entries:
        raise ValueError("Connect an expression library before relinking.")
    numbers = [item.file_number for item in entries]
    if len(set(numbers)) != len(numbers):
        raise ValueError("The saved library has duplicate sequence frame numbers. Reconnect the sequence to repair it.")
    folder = os.path.abspath(bpy.path.abspath(directory))
    explicit = None
    if selected_file and os.path.splitext(selected_file)[1].casefold() == '.png':
        selected_file = os.path.abspath(bpy.path.abspath(selected_file))
        explicit = parts(selected_file)
        folder = os.path.dirname(selected_file)
    if not os.path.isdir(folder):
        raise ValueError("Choose the folder containing the sequence PNGs.")
    files, patterns = {}, set()
    with os.scandir(folder) as contents:
        for entry in contents:
            if not entry.is_file() or not entry.name.lower().endswith('.png'):
                continue
            try:
                prefix, digits, suffix = parts(entry.name)
            except ValueError:
                continue
            files[entry.name] = entry.path
            patterns.add((prefix, number_width(digits), suffix))
    known = []
    for source in [item.filepath for item in entries] + [image.filepath]:
        try:
            prefix, digits, suffix = parts(source)
        except ValueError:
            continue
        pattern = (prefix, number_width(digits), suffix)
        if pattern not in known:
            known.append(pattern)

    def matches(patterns_to_try):
        found = {}
        for prefix, width, suffix in patterns_to_try:
            if explicit and (prefix != explicit[0] or suffix != explicit[2]):
                continue
            names = [f'{prefix}{str(number).zfill(width)}{suffix}' for number in numbers]
            if not all(name in files for name in names):
                continue
            paths = [files[name] for name in names]
            if explicit and int(explicit[1]) in numbers:
                index = numbers.index(int(explicit[1]))
                if os.path.normcase(paths[index]) != os.path.normcase(selected_file):
                    continue
            found[tuple(paths)] = paths
        return list(found.values())

    # Prefer the saved naming scheme when it is usable. A selected PNG is an
    # explicit override; otherwise discover only sequences matching saved frames.
    candidates = matches(patterns if explicit else known)
    if not candidates:
        candidates = matches(patterns)
    if not candidates:
        raise ValueError(f'No numbered PNG sequence matches the {len(numbers)} saved expressions in this folder. '
                         'Choose the source folder or select its first numbered PNG.')
    if len(candidates) > 1:
        raise ValueError("More than one sequence matches this library. Select the first PNG of the intended sequence.")
    paths = candidates[0]
    validated = validate(paths)
    # Do not include extra neighboring files or change stored frame numbers.
    return paths, validated[0]


def set_library_source(ch, path, transaction=None, native_image=None):
    """A lightweight path carrier; never displayed or used by a shader.

    Custom PropertyGroup strings are not included in Blender's native path
    remapping. An Image ID is, and follows Save As/Save Copy, relative-remap
    choices and linked-library paths without rewriting the live file on save.
    """
    old = ch.source_image
    if native_image is None:
        from .materials import resolve
        node = resolve(ch)
        native_image = node.image if node else None
    image = bpy.data.images.new('Blender Face Picker Library Source', width=1, height=1)
    if transaction:
        transaction.track(bpy.data.images, image)
    image.source = 'FILE'
    # Match the connected image's absolute/relative policy, including when the
    # user disables Remap Relative in Blender's save dialog.
    image.filepath = (bpy.path.abspath(path) if native_image and
                      not native_image.filepath.startswith('//') else stored_path(path))
    image['vfa_library_source'] = True
    ch.source_image = image
    if old and old.get('vfa_library_source'):
        if transaction:
            # Cleanup removes it only after commit; rollback restores its user.
            transaction.created.append((bpy.data.images, old))
        elif old.users == 0:
            bpy.data.images.remove(old)


@persistent
def migrate_library_sources(*_args):
    from .data import all_channels
    for obj in bpy.data.objects:
        if not obj.is_editable or not obj.is_property_set('vfa_character'):
            continue
        for _key, ch in all_channels(obj):
            if ch.source_image or not ch.expressions:
                continue
            paths = [bpy.path.abspath(item.get('filepath', '')) for item in ch.expressions]
            if (all(item.get('filepath', '') for item in ch.expressions)
                    and len({os.path.normcase(os.path.dirname(path)) for path in paths}) == 1):
                set_library_source(ch, paths[0])


def fill_library(ch, paths, transaction=None, native_image=None):
    names = [item.name for item in ch.expressions]
    if names:
        normalize = lambda path: os.path.normcase(os.path.realpath(bpy.path.abspath(path)))
        saved = {normalize(item.filepath): item.name for item in ch.expressions}
        sources = [normalize(path) for path in paths]
        # When resizing the same library, keep names attached to their images.
        # For a different sequence, carry names over in expression order.
        if any(path in saved for path in sources):
            names = [saved.get(path) for path in sources]
    ch.expressions.clear()
    for index, path in enumerate(paths, 1):
        item = ch.expressions.add()
        name = names[index - 1] if index <= len(names) else None
        item.name = name if name is not None else os.path.splitext(os.path.basename(path))[0]
        item.filepath = stored_path(path)
        item.sequence_frame = index
        item.file_number = int(parts(path)[1])
    set_library_source(ch, paths[0], transaction, native_image)


def migrate_after_register():
    # Blender enables add-ons with RestrictedData; defer scene access until
    # registration has returned to the normal application context.
    if not hasattr(bpy.data, 'objects'):
        return 0.1
    migrate_library_sources()
    return None


def register():
    bpy.app.handlers.load_post.append(migrate_library_sources)
    bpy.app.handlers.save_pre.append(migrate_library_sources)
    bpy.app.timers.register(migrate_after_register, first_interval=0.0)


def unregister():
    if bpy.app.timers.is_registered(migrate_after_register):
        bpy.app.timers.unregister(migrate_after_register)
    for handlers in (bpy.app.handlers.load_post, bpy.app.handlers.save_pre):
        if migrate_library_sources in handlers:
            handlers.remove(migrate_library_sources)
