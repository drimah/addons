import bpy
from . import animation, materials, previews
from .data import channel, channel_key, active_key, linked, LABELS, target_object, validate_linked_eyes, control_owners


def control_status(obj, key, statuses):
    ready, message = statuses[key]
    if not ready or not linked(obj, key):
        return ready, message
    other = 'right_eye' if key == 'left_eye' else 'left_eye'
    other_ready, other_message = statuses[other]
    if not other_ready:
        return False, f'{LABELS[other]}: {other_message}'
    try:
        validate_linked_eyes(obj)
    except ValueError as exc:
        return False, str(exc)
    return True, message


def draw_repair(layout, obj, key, statuses, scene):
    parts = [key]
    if linked(obj, key):
        parts.append('right_eye' if key == 'left_eye' else 'left_eye')
    for part in parts:
        ch = channel(obj, part)
        if statuses[part][0]:
            continue
        node = materials.resolve(ch)
        if not materials.surface_available(obj, ch, scene):
            op = layout.operator('vfa.disconnect_sequence', text='Disconnect Missing Surface', icon='UNLINKED')
        elif node and node.image and (materials.shared_surface(materials.surface(obj, ch), obj)
                or materials.shared_material(materials.surface(obj, ch), ch.material, obj)
                or materials.shared_image(node.image) or node.image.library):
            op = layout.operator('vfa.make_independent', icon='DUPLICATE')
        else:
            op = layout.operator('vfa.connect_sequence', text='Reconnect Sequence', icon='NODE_TEXTURE')
        op.channel_key = part
        return


def section_header(layout, owner, prop, label):
    layout.separator(type='LINE')
    header = layout.row()
    header.alignment = 'LEFT'
    header.prop(owner, prop, emboss=False, text=label,
                icon='TRIA_DOWN' if getattr(owner, prop) else 'TRIA_RIGHT')
    return getattr(owner, prop)


def setup_buttons(layout, obj):
    key = active_key(obj)
    op = layout.operator('vfa.import_sequence', text='Create New Image', icon='FILE_FOLDER')
    op.channel_key = key
    op = layout.operator('vfa.connect_sequence', icon='NODE_TEXTURE')
    op.channel_key = key


def picker_pages(layout, ch):
    pages = previews.page_count(ch)
    if pages > 1:
        row = layout.row(align=True)
        row.prop(ch, 'picker_page', text='Page')
        row.label(text=f'/ {pages}')


def part_preview(tile, obj, key, statuses):
    ch = channel(obj, key)
    preview = tile.row()
    preview.alignment = 'CENTER'
    if ch.expressions and materials.surface_available(obj, ch, bpy.context.scene):
        preview.enabled = control_status(obj, key, statuses)[0]
        preview.template_icon_view(ch, 'picker', show_labels=True, scale=3.0, scale_popup=5.0)
        picker_pages(tile, ch)
    else:
        preview.scale_y = 3.0
        op = preview.operator('vfa.edit_part', text='Set Up', icon='ADD')
        op.part = key
        op.show_setup = True


def part_details(tile, obj, key, statuses):
    ch = channel(obj, key)
    selected = active_key(obj)
    is_active = selected == key
    op = tile.operator('vfa.edit_part', text=LABELS[key], depress=is_active)
    op.part = key
    ready, message = control_status(obj, key, statuses)
    status = tile.row()
    status.alignment = 'CENTER'
    status.label(text=message if ready or not ch.expressions else 'Needs attention',
                 icon='CHECKMARK' if ready else 'ERROR' if ch.expressions else 'UNLINKED')


def part_tile(row, obj, key, statuses):
    tile = row.column(align=True)
    part_preview(tile, obj, key, statuses)
    part_details(tile, obj, key, statuses)


def face_selector(layout, obj, statuses):
    cfg = obj.vfa_character
    face = layout.box()
    eyes = face.split(factor=0.5, align=True)
    part_preview(eyes.column(align=True), obj, 'right_eye', statuses)
    part_preview(eyes.column(align=True), obj, 'left_eye', statuses)
    face.operator('vfa.toggle_link_eyes', text='Unlink Eyes' if cfg.link_eyes else 'Link Eyes',
                  icon='LINKED' if cfg.link_eyes else 'UNLINKED', depress=cfg.link_eyes)
    labels = face.split(factor=0.5, align=True)
    part_details(labels.column(align=True), obj, 'right_eye', statuses)
    part_details(labels.column(align=True), obj, 'left_eye', statuses)
    mouth = face.row()
    mouth.alignment = 'CENTER'
    part_tile(mouth, obj, 'mouth', statuses)


class VFA_UL_expressions(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index=0, flt_flag=0):
        # Operator icons ignore scaling. Scale the preview separately so the scrollbar stays narrow.
        row = layout.row(align=True)
        icon_id = previews.icon(item.filepath)
        thumbnail = row.row(align=True)
        thumbnail.alignment = 'LEFT'
        thumbnail.scale_x = float(context.scene.vfa_settings.thumbnail_size)
        # Extra box padding would make the thumbnail taller than its list row.
        if icon_id:
            thumbnail.template_icon(icon_value=icon_id, scale=1.0)
        else:
            thumbnail.label(text='', icon='ERROR')
        row.enabled = previews.expression_available(data, index)
        button = row.operator('vfa.select_expression', text=item.name,
                              emboss=True, depress=index == previews.selected_get(data))
        button.index = index
        button.channel_key = channel_key(data)


class VFA_PT_main(bpy.types.Panel):
    bl_label = 'Blender Face Picker · 1.2.45'
    bl_idname = 'VFA_PT_main'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Blender Face Picker'

    def draw(self, context):
        layout = self.layout
        obj = target_object(context)
        settings = context.scene.vfa_settings
        details = layout.box()
        header = details.row(align=True)
        header.label(text='Active Object')
        header.operator('vfa.pin_object', text='',
                        icon='PINNED' if settings.pinned else 'UNPINNED',
                        depress=settings.pinned)
        owners = control_owners(context, context.object)
        if owners:
            details.operator('vfa.go_face_controls', icon='OUTLINER_OB_ARMATURE')
        if not obj or not hasattr(obj.data, 'materials'):
            details.label(text="Pinned object unavailable" if settings.pinned else
                          "No face object active.", icon='INFO')
            if not settings.pinned:
                create = layout.row()
                create.operator_context = 'INVOKE_DEFAULT'
                create.operator('vfa.import_sequence', text='Create New Image', icon='ADD')
            return
        details.label(text=obj.name, icon='OBJECT_DATA')
        ch = channel(obj)
        cfg = obj.vfa_character
        key = active_key(obj)
        layout.prop(cfg, 'mode', expand=True)
        status_keys = ('left_eye', 'right_eye', 'mouth') if cfg.mode == 'PARTS' else ('full_face',)
        statuses = {part: materials.connection_status(obj, channel(obj, part)) for part in status_keys}
        if cfg.mode == 'PARTS':
            face_selector(layout, obj, statuses)
        library_visible = bool(ch.expressions and materials.surface_available(obj, ch, context.scene))
        node = materials.resolve(ch)
        ready, status_message = control_status(obj, key, statuses)
        current = None
        if ready:
            number = animation.current_number(node)
            current = next((item for item in ch.expressions if item.file_number == number), None)
        if cfg.mode == 'PARTS':
            layout.label(text=f'Editing: {LABELS[key]}')
        if cfg.mode == 'FULL' and library_visible:
            preview_row = layout.row()
            preview_row.alignment = 'CENTER'
            preview_row.enabled = ready
            preview_row.template_icon_view(ch, 'picker', show_labels=True, scale=5.0, scale_popup=5.0)
            picker_pages(layout, ch)
        if not library_visible:
            message = ('No active Simple sequence.' if cfg.mode == 'FULL'
                       else f'No active sequence for {LABELS[key]}.')
            layout.label(text=message, icon='INFO')
            layout.label(text='Create or connect one in Material Setup.')
        elif not ready:
            warning = layout.box()
            warning.label(text=status_message, icon='ERROR')
            if linked(obj, key):
                warning.operator('vfa.toggle_link_eyes', text='Unlink Eyes to Edit Separately', icon='UNLINKED')
            draw_repair(warning, obj, key, statuses, context.scene)
        if library_visible:
            missing = previews.library_info(ch)['blocked']
            if missing:
                repair = layout.row()
                repair.label(text='Some linked eye images are missing.' if linked(obj, key) else
                             'Some expression images are missing.', icon='ERROR')
                op = repair.operator('vfa.relink_sources', text='Relink', icon='FILE_FOLDER')
                repair_key = key
                if linked(obj, key) and not previews.library_info(ch)['missing']:
                    repair_key = 'right_eye' if key == 'left_eye' else 'left_eye'
                op.channel_key = repair_key
        if section_header(layout, ch, 'show_thumbnails', 'Expressions') and library_visible:
            layout.label(text='Thumbnail Size')
            layout.prop(settings, 'thumbnail_size', text='')
            if library_visible:
                expression_list = layout.column()
                expression_list.enabled = ready
                expression_list.scale_x = 1.0
                expression_list.scale_y = float(settings.thumbnail_size)
                expression_list.template_list('VFA_UL_expressions', f'large_previews_{key}', ch, 'expressions',
                                              ch, 'list_index', rows=5, maxrows=5, sort_lock=True)
            names = layout.row(align=True)
            names.operator('vfa.copy_expression_names', icon='COPYDOWN')
            names.operator('vfa.paste_expression_names', icon='PASTEDOWN')
            if current:
                layout.label(text='Expression Name')
                layout.prop(current, 'name', text='')
        if section_header(layout, cfg, 'show_animation', 'Animation') and library_visible:
            keying = layout.column()
            keying.enabled = ready
            keying.prop(cfg if cfg.mode == 'PARTS' else ch,
                        'auto_key_parts' if cfg.mode == 'PARTS' else 'auto_key', toggle=True)
            keying.label(text='Keyframe Type')
            keying.prop(cfg, 'keyframe_type', text='')
            keying.prop(cfg, 'add_markers')
            key_button = keying.row()
            key_button.enabled = current is not None and previews.selected_get(ch) >= 0
            key_button.operator('vfa.key_expression', text='Insert Keyframe', icon='KEY_HLT')
            keying.label(text=f'Sequence Total: {len(ch.expressions) if library_visible else 0}')
            keying.label(text=f'Sequence Frame: {current.sequence_frame if current else chr(8212)}')

        if section_header(layout, cfg, 'show_material_setup', 'Material Setup'):
            if ch.surface_object and library_visible:
                layout.label(text=f'Surface: {ch.surface_object.name}', icon='OBJECT_DATA')
            setup_buttons(layout, obj)
            if library_visible:
                layout.operator('vfa.make_independent', icon='DUPLICATE')
                layout.operator('vfa.relink_sources', icon='FILE_FOLDER')
                layout.operator('vfa.refresh_previews', icon='FILE_REFRESH')
            if ch.expressions or ch.material or ch.node_name or ch.node_id or ch.surface_object:
                op = layout.operator('vfa.disconnect_sequence', text=f'Disconnect {LABELS[active_key(obj)]}', icon='UNLINKED')
                op.channel_key = active_key(obj)


CLASSES = (VFA_UL_expressions, VFA_PT_main)
