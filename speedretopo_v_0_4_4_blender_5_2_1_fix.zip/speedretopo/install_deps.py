# -*- coding:utf-8 -*-
"""One-click install of the extensions SpeedRetopo relies on.

SpeedRetopo used to show a popup explaining how to install LoopTools and
Bsurfaces by hand (Preferences > System > Online Access > Get Extensions >
search > Install). These operators do those steps themselves:

1. if the extension is already on disk but switched off, it is switched on;
2. otherwise Online Access is turned on, the blender.org repository is
   refreshed and the extension is downloaded, installed and enabled;
3. the preferences are saved so it stays on after a restart.

Everything goes through Blender's own extension operators, the same ones the
Get Extensions tab uses - nothing is fetched by hand.
"""

import json
import os

import addon_utils
import bpy
from bpy.types import Operator


# What each dependency is called. Extension ids are looked up by name in the
# repository index; the ids listed here are only a fallback for when the index
# cannot be read.
DEPENDENCIES = {
    "LOOPTOOLS": {
        "label": "LoopTools",
        "names": ("looptools",),
        "ids": ("looptools",),
        "legacy": "mesh_looptools",
    },
    "BSURFACES": {
        "label": "Bsurfaces",
        "names": ("bsurfaces gpl edition", "bsurfaces"),
        "ids": ("bsurfaces", "bsurfaces_gpl_edition", "mesh_bsurfaces"),
        "legacy": "mesh_bsurfaces",
    },
}


def is_ready(key):
    if key == "LOOPTOOLS":
        return (hasattr(bpy.types.WindowManager, "looptools")
                and "looptools_relax" in dir(bpy.ops.mesh))
    if key == "BSURFACES":
        return (hasattr(bpy.types.Scene, "bsurfaces")
                and "surfsk_add_surface" in dir(bpy.ops.mesh))
    return False


def _blender_org_repo():
    repos = bpy.context.preferences.extensions.repos
    for i, repo in enumerate(repos):
        if repo.module == "blender_org" or "extensions.blender.org" in (repo.remote_url or ""):
            return i, repo
    return None, None


def _installed_modules(dep):
    """Module names on disk that are this dependency, enabled or not."""
    wanted = set(dep["ids"]) | {dep["legacy"]}
    found = []
    for mod in addon_utils.modules(refresh=True):
        name = mod.__name__
        short = name.rsplit(".", 1)[-1]
        title = ""
        try:
            title = addon_utils.module_bl_info(mod).get("name", "").lower()
        except Exception:
            pass
        if short in wanted or any(n == title for n in dep["names"]):
            found.append(name)
    return found


def _index_ids(repo, dep):
    """Ids in the downloaded repository index whose name matches."""
    path = os.path.join(repo.directory, ".blender_ext", "index.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return []
    items = data.get("data", data) if isinstance(data, dict) else data
    ids = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).lower()
        if any(n == name for n in dep["names"]):
            ids.append(item.get("id"))
    return [i for i in ids if i]


def _enable(module):
    try:
        bpy.ops.preferences.addon_enable(module=module)
    except Exception as exc:
        print("SpeedRetopo: could not enable", module, exc)


def install(key):
    """Make one dependency available. Returns (ok, message)."""
    dep = DEPENDENCIES[key]
    label = dep["label"]
    if is_ready(key):
        return True, f"{label} is already active"

    # 1. On disk already - just switch it on.
    for module in _installed_modules(dep):
        _enable(module)
        if is_ready(key):
            return True, f"{label} enabled"

    # 2. Download it from extensions.blender.org.
    if not bpy.app.online_access:
        if bpy.app.online_access_override:
            return False, ("Blender was started in offline mode - start it "
                           f"normally to download {label}")
        bpy.context.preferences.system.use_online_access = True

    index, repo = _blender_org_repo()
    if repo is None:
        return False, "The extensions.blender.org repository is missing from Preferences"
    if not repo.enabled:
        repo.enabled = True

    try:
        bpy.ops.extensions.repo_sync(repo_index=index)
    except Exception as exc:
        print("SpeedRetopo: repository refresh failed:", exc)

    candidates = _index_ids(repo, dep) + [i for i in dep["ids"] if i]
    tried = []
    for pkg_id in candidates:
        if pkg_id in tried:
            continue
        tried.append(pkg_id)
        try:
            bpy.ops.extensions.package_install(
                repo_index=index, pkg_id=pkg_id, enable_on_install=True)
        except Exception as exc:
            print("SpeedRetopo: install of", pkg_id, "failed:", exc)
            continue
        if not is_ready(key):
            for module in _installed_modules(dep):
                _enable(module)
        if is_ready(key):
            return True, f"{label} installed and enabled"

    return False, (f"Could not download {label}. Check the internet "
                   "connection and try again")


def _save_prefs():
    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        pass


def _redraw(context):
    try:
        for area in context.screen.areas:
            area.tag_redraw()
    except Exception:
        pass


class _InstallBase:
    bl_options = {'REGISTER', 'INTERNAL'}
    keys = ()

    def invoke(self, context, event):
        missing = [DEPENDENCIES[k]["label"] for k in self.keys if not is_ready(k)]
        if not missing:
            return self.execute(context)
        names = " and ".join(missing)
        extra = "" if bpy.app.online_access else " Online Access will be turned on."
        return context.window_manager.invoke_confirm(
            self, event, title=f"Install {names}?",
            message=f"{names} will be downloaded from extensions.blender.org "
                    f"and enabled.{extra}",
            confirm_text="Install", icon='IMPORT')

    def execute(self, context):
        context.window.cursor_set('WAIT')
        results = []
        ok_all = True
        try:
            for key in self.keys:
                ok, msg = install(key)
                ok_all = ok_all and ok
                results.append(msg)
        finally:
            context.window.cursor_set('DEFAULT')
        _save_prefs()
        _redraw(context)
        self.report({'INFO'} if ok_all else {'ERROR'}, " | ".join(results))
        return {'FINISHED'} if ok_all else {'CANCELLED'}


class SPEEDRETOPO_OT_install_looptools(_InstallBase, Operator):
    bl_idname = "speedretopo.help_install_looptools"
    bl_label = "Install LoopTools"
    bl_description = ("LoopTools is missing.\n\n"
                      "Click to download it from extensions.blender.org and "
                      "enable it - or just enable it, if it is installed but off")
    keys = ("LOOPTOOLS",)


class SPEEDRETOPO_OT_install_bsurfaces(_InstallBase, Operator):
    bl_idname = "object.speedretopo_help_install_bsurfaces"
    bl_label = "Install Bsurfaces"
    bl_description = ("Bsurfaces is missing.\n\n"
                      "Click to download it from extensions.blender.org and "
                      "enable it - or just enable it, if it is installed but off")
    keys = ("BSURFACES",)


class SPEEDRETOPO_OT_install_missing(_InstallBase, Operator):
    bl_idname = "speedretopo.install_missing"
    bl_label = "Install Missing Add-ons"
    bl_description = ("Download and enable everything SpeedRetopo needs "
                      "that is not there yet (LoopTools, Bsurfaces)")
    keys = ("LOOPTOOLS", "BSURFACES")


def _package():
    return __package__ or "speedretopo"


def _uninstall_later():
    pkg = _package()
    parts = pkg.split(".")
    try:
        if len(parts) == 3 and parts[0] == "bl_ext":
            for i, repo in enumerate(bpy.context.preferences.extensions.repos):
                if repo.module == parts[1]:
                    bpy.ops.extensions.package_uninstall(
                        repo_directory=repo.directory, repo_index=i,
                        pkg_id=parts[2])
                    break
        else:
            try:
                bpy.ops.preferences.addon_disable(module=pkg)
            except Exception:
                pass
            bpy.ops.preferences.addon_remove(module=pkg)
    except Exception as exc:
        # Blender's remove operator can complain about redrawing after it has
        # already deleted the files; what counts is whether they are gone.
        still = any(m.__name__ == pkg for m in addon_utils.modules(refresh=True))
        if still:
            print("SpeedRetopo: uninstall failed:", exc)
            return None
    _save_prefs()
    print("SpeedRetopo: uninstalled")
    return None


class SPEEDRETOPO_OT_uninstall(Operator):
    bl_idname = "speedretopo.uninstall"
    bl_label = "Uninstall SpeedRetopo"
    bl_description = "Disable SpeedRetopo and delete it from this Blender"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self, event, title="Uninstall SpeedRetopo?",
            message="The add-on is disabled and its files deleted.",
            confirm_text="Uninstall", icon='WARNING')

    def execute(self, context):
        bpy.app.timers.register(_uninstall_later, first_interval=0.2)
        self.report({'INFO'}, "Uninstalling SpeedRetopo...")
        return {'FINISHED'}


def missing_any():
    return not (is_ready("LOOPTOOLS") and is_ready("BSURFACES"))


classes = (SPEEDRETOPO_OT_install_looptools,
           SPEEDRETOPO_OT_install_bsurfaces,
           SPEEDRETOPO_OT_install_missing,
           SPEEDRETOPO_OT_uninstall)
