DRIMAH MESHTOOLS 2.4

NEW IN 2.4 - MIRROR CENTER (no need to place the model at zero)
- Redraw > Symmetry has a new row: Auto Center | Origin | 3D Cursor  (default: Auto Center).
  Auto Center: the mirror plane is the center of the model itself (middle of its size on the axis),
    wherever the model is and wherever its origin is. A half model (flat open border on one side
    only) uses that border as the plane. If the object already has the Drimah Mirror modifier,
    its plane (the origin) is kept.
  Origin: the object origin (behavior before 2.4).
  3D Cursor: the plane goes through the 3D cursor.
- Works with Weld (Selected / Whole Model) and Mirror Modifier. With Mirror Modifier and a center
  that is not the origin, the object origin is moved onto the mirror plane (the model does not move
  in the scene), so the live modifier mirrors around the right place.
- A whole part that is selected (closed / with handles) is never redrawn after the cut at the plane,
  only mirrored. If a result would ever be empty, the operation is cancelled and nothing changes.
- Tested in Blender 5.2.3 with the chassis moved off zero and the object rotated/moved: all modes,
  Side + and Side -, symmetric about the chassis' own center, scene position unchanged, 0 non-manifold
  edges; shifted sphere patch, shifted half kart (half detected), Origin and 3D Cursor modes; all
  previous tests pass.

FIX 2.3.3 - MODELS THAT ARE NOT EXACTLY SYMMETRIC (tested on FastRemesher_LivePreview_CHASSI)
- Weld + Selected with whole parts selected: the selected faces on the other side are always replaced,
  even when the two sides are slightly different (before: overlapping faces / non-manifold edges).
- Weld + Selected with a patch: the patch is mirrored only when the other side matches it.
  If the other side is different there, only the chosen side is redrawn and the report says
  "patch NOT mirrored ... use Whole Model" (before: a loose copy floated over the other side).
- A single isolated face is no longer "redrawn" (nothing to improve).
- Tested on a copy of FastRemesher_LivePreview_CHASSI (953 faces, not symmetric, no center loop):
  all selected: Weld Selected / Weld Whole Model / Mirror Modifier, Side + and Side -,
  nothing selected + Mirror Modifier, 6 patches with and without symmetry and with Whole Model:
  all symmetric where expected, 0 non-manifold edges. All previous tests (kart, spheres, openings) pass.

DRIMAH MESHTOOLS 2.3.2

FIX 2.3.2 - WHOLE PARTS ARE MIRRORED, NEVER FLATTENED
- Before: selecting a whole part (e.g. the whole seat + kart) gave "Nothing was redrawn" and no mirror,
  and in some cases the whole part could be rebuilt as one flat grid (shape destroyed).
- Now Redraw only rebuilds real patches: one border (disk) or a ring around an opening, without
  handles/tunnels and not wrapped around itself. Everything else (closed parts, a steering wheel,
  a hollow backrest, a whole half model) is kept exactly as it is - and still mirrored:
  Weld + Selected: the selected parts are mirrored with Blender's Symmetrize (limited to them).
  Weld + Whole Model: the whole model is mirrored.
  Mirror Modifier: the model is cut in half and the Drimah Mirror modifier is added/reused.
- Weld on an object that already has the Drimah Mirror modifier: the modifier is removed
  (the mirror becomes real geometry; before, the result was doubled).
- Tested on the real "banco+kart" mesh (5,263 faces, half + modifier and full) in Blender 5.2.3:
  every mode symmetric, no non-manifold edges, shape untouched; seat patches still redrawn.

DRIMAH MESHTOOLS 2.3.1

FIX 2.3.1 - SYMMETRY WITHOUT A CENTER EDGE LOOP
- Before: "Symmetry needs a center edge loop: a selected face crosses the mirror plane" and nothing happened.
- Now: Redraw cuts the mesh at the mirror plane automatically (only faces that cross the plane are split,
  their shape does not change), takes the chosen half and mirrors it. The report says
  "center loop cut at the mirror plane".
- Tested in Blender 5.2.3 on a grid, a 31-segment UV sphere and a 15-sided cylinder (no center loop),
  Side + and Side -: redrawn area exactly symmetric, no non-manifold edges.

NEW IN 2.3 - WELD OR LIVE MIRROR MODIFIER
- Redraw > Symmetry has a new row: Weld | Mirror Modifier.
  Weld: the mirrored side is real geometry, welded at the center (2.2 behavior).
  Mirror Modifier: the model keeps only the chosen side (Side + or Side -), cut cleanly at the plane,
  and a live Mirror modifier named "Drimah Mirror" is added (Generate > Mirror: merge + clipping on).
  Keep modeling one side; the other side follows. The Selected | Whole Model row is greyed out in this
  mode because the modifier always mirrors the whole object.
- When the object has the Drimah Mirror modifier, the Symmetry box shows:
  [Mirror On] toggle (turn the modifier on/off), [Apply] (becomes real welded geometry), [X] (remove).
- Running Redraw again reuses the same modifier (no duplicates). Nothing selected + Mirror Modifier
  just cuts the model and adds the modifier.
- The option is saved in presets.
- Tested in Blender 5.2.3: Side + and Side -, evaluated result symmetric, toggle off shows one half,
  Apply gives symmetric welded mesh, Remove, presets, and all previous tests.

NEW IN 2.2.2 - MIRROR SELECTED OR WHOLE MODEL
- Redraw > Symmetry has a new row: Selected | Whole Model.
  Selected: only the redrawn faces are mirrored (2.2.1 behavior).
  Whole Model: the selection is redrawn on the chosen side, then the ENTIRE model is made symmetric
  from that side (Side + copies + onto -, Side - copies - onto +). Works on non-symmetric models.
  With nothing selected, Whole Model just mirrors the whole model.
  A selection made on the other side is used through its mirror twin when the model allows it.
- On a model without a center edge loop, Whole Model cuts the faces at the mirror plane
  (Blender's Symmetrize), which can leave a few n-gons on the center line.
- The option is saved in presets.

DRIMAH MESHTOOLS 2.2.1

NEW IN 2.2.1 - SYMMETRY PANEL (standard Drimah pattern)
- Redraw > Symmetry now uses the standard Drimah layout:
  row 1: None | X | Y | Z  (one axis at a time)
  row 2: Side + | Side -   (side that is kept and mirrored; greyed out when None)
- Mirror Tolerance is no longer shown (fixed internal value 0.001, still read from presets).
- Old presets with X/Y/Z checkboxes are converted automatically on load/import.

DRIMAH MESHTOOLS 2.2

NEW IN 2.2 - REDRAW OPENINGS (fluid oval holes)
- Select the ring of faces around an opening (hole, port, intake...) and press Redraw.
  The contour of the opening is smoothed WITHOUT turning it into a circle: an oval stays oval,
  only the steps / kinks / crowded edges disappear. Then evenly spaced loops are built around it.
- New "Openings" box in the Redraw panel:
  Opening Smoothness (0-1, default 0.6): how much the contour is smoothed (shape-preserving smoothing).
  Opening Loops (0 = automatic): number of loops between the outer border and the opening.
  Even Opening: spaces the contour vertices evenly.
- Open hole (contour is a free edge): the contour is rebuilt with the same vertex count as the outer
  border -> 100% quads.
- Contour attached to an inner wall (faces going down into the hole): the wall's top vertices are
  moved onto the smoothed contour (the wall follows). When the vertex counts differ, quad-only
  4-to-2 transitions are used (at most 1 triangle when the difference is odd).
- Symmetry works with openings: an opening across the center is made exactly symmetric; two mirrored
  openings -> only the source side is redrawn and mirrored.
- Safety: a large area that merely has two borders (not a ring around a hole) is skipped and reported.
- Presets store the new opening options.
- Runtime-tested in Blender 5.2.3: jagged oval hole on a curved surface (open and with inner wall),
  symmetry across the center and with two mirrored openings, plus all 2.1 tests again.

NEW IN 2.1 - REDRAW MODULE
- New panel: Redraw (Drimah MeshTools tab, after X-Ray).
- Select faces in Edit Mode and press Redraw: the selected area is rebuilt as a clean quad patch.
  The border of the selection is kept, so the patch stays connected to the rest of the mesh.
- Options:
  Border Loops (0-4): quad rings grown inward from the border before the fill (give a clean edge flow).
  Border Width: width of each ring, relative to the border edge length.
  Corner Offset: rotates the grid corners along the border (0 = automatic corner choice).
  Smooth Iterations / Smooth Strength: relax of the new vertices.
  Project to Surface: new vertices stay on the original surface (round shapes stay round).
  Keep Original: ON = original object is kept untouched (hidden) and the result goes to "<name>_Redraw";
                 OFF = the mesh is changed directly (Ctrl+Z to undo).
- Symmetry: X / Y / Z toggles, Source Side (+ to - or - to +) and Mirror Tolerance.
  The mirrored faces are included automatically, only the source side is redrawn, and the result is
  mirrored and welded to the existing border on the other side. Needs a center edge loop.
- Presets: Clean, Tight, Soft, Hard Surface + Save / Delete / Export / Import (redraw_presets.json).
  Presets store all Redraw options, including symmetry and Keep Original.
- Odd borders are closed with a single triangle in the most convex corner; everything else is quads.
- (2.1) Regions with holes inside were skipped; since 2.2 a ring around an opening is redrawn.
- Limitation: very concave selections (L or U shapes) are filled with one 4-sided patch, so cells near
  the inner corner get compressed. Split the selection or use Corner Offset. UVs of the new faces are not kept.
- Runtime-tested in Blender 5.2.3 (Python module, Linux): UV sphere, ico sphere (odd borders), grids with
  0-3 border loops, symmetry X, X+Y, + to - and - to +, Suzanne, Keep Original, presets save/export/import/delete.
  Pure Python, no binaries: works the same on Windows and Linux.

NEW IN 2.0 - ROUND AND CIRCULAR AREAS
- Relax > Keep Shape (on by default): relaxes along the surface and projects back onto it.
  Spheres, cylinders and circular areas no longer shrink (UV sphere test: radius 0.974 -> 0.9995).
  With Protect Open Boundaries off, open rims slide along the original boundary and stay round.
- X-Ray > Follow Curvature (on by default): new loop vertices are placed on the curved surface
  (cubic curve from the smooth normals, ignoring faces across hard edges) instead of a straight
  chord. 12-sided cylinder test: radius 0.966 -> 0.9994; flat/straight areas stay straight.
  Curves are recorded on the untouched mesh before any ring is split.
- X-Ray > Soften Selected Tips now smooths along the surface (tips do not flatten).
- Inflate > Falloff: Smooth (default, fades to zero at the selection edge), Round (circular
  dome profile), Constant (1.9 behavior). Circular selection test: step at the edge 0.296 -> 0.030.
- Fix: the Inflate button now uses the Intensity / Smoothness / Falloff values shown in the panel
  (1.9 always used 0.10 and 3).
- New options are saved in presets; old preset files still load.
- Runtime-tested in Blender 5.2.3 (Python module, Linux).
- Fix 2.0.1: installing over an older version without restarting Blender no longer fails
  with "has no attribute 'FALLOFF_ITEMS'" (stale submodules are reloaded).


CONTENTS
- Integrated add-on: Drimah MeshTools 2.2.
- Modules: Inflate, Relax, X-Ray, and Redraw.
- X-Ray includes adaptive quad edge-loop detection, progress status text, and a diagnostic report.
- User-facing interface language is English.

INSTALLATION
1. Close Blender completely before replacing an earlier package.
2. Install Drimah_MeshTools_2.4.0.zip from Blender Preferences / Extensions area.
3. Enable Drimah MeshTools.
4. In the 3D Viewport, press N and open the Drimah MeshTools tab.

X-RAY ADAPTIVE LOOPS
X-Ray compares quad edges against local transverse spacing, includes boundary edges as valid
ring seeds/members for open panel strips, traces opposite-edge rings through quad faces, and
estimates cut count from the ring-wide median ratio. Boundary-edge scoring is intended to
recover long strips near spoiler bases and panel rims that the prior version could skip. It avoids stopping solely because a ring touches
a marked-sharp vertex, since that over-protected many hard-surface meshes.

X-RAY DIAGNOSTIC TEST IN 1.6
The X-Ray Fix temporarily bypasses the _repair_quad_flow post-processing pass to isolate whether
that pass is responsible for unwanted topology changes. Loop detection and insertion remain enabled.
This is a diagnostic build, not a confirmed final fix.

LIMITATIONS / TESTING
The algorithm is heuristic and targets continuous quad regions. It does not solve arbitrary
retopology, and it may skip regions with triangles, poles, open/non-manifold topology, or
strongly uneven ring lengths. The package and Python syntax were checked, but the add-on
has not been run inside Blender 5.2 in this environment. Test on a duplicate mesh first.


X-RAY DIAGNOSTIC TEST IN 1.7
This build keeps the 1.6 diagnostic bypass of _repair_quad_flow and changes only subdivide_edges(use_grid_fill=False), to test whether grid-fill behavior causes unwanted topology changes. Loop detection, candidate selection, and cut counts remain unchanged. This is a diagnostic build, not a confirmed final fix.


X-RAY DIAGNOSTIC TEST IN 1.8
This build replaces connected face-region edge aggregation with opposite-edge ring tracing. It rejects rings with low candidate coverage or highly inconsistent edge lengths, and uses median candidate-face aspect ratio to estimate cuts. This is experimental; test on a duplicate mesh. Blender runtime testing was not available during packaging.


X-RAY DIAGNOSTIC TEST IN 1.9
This build keeps the 1.8 opposite-edge ring tracing but reduces collateral subdivision: a ring must have at least 85% overlap with edges independently identified as candidates, ring edge-length variation is limited to 3:1, the trace limit is 512 edges, and inserted cuts are capped at 3 per ring. The intent is to preserve the improvement around the spoiler while rejecting rings that extend through healthy regions. This is an experimental hypothesis, not a Blender-runtime-verified fix. Test on a duplicate mesh.


X-RAY TEST VARIANT (SAME VERSION 1.9)
This same-version experiment makes candidate selection more conservative: the face aspect-ratio threshold is raised from 1.9 to 2.4 and faces with strongly unequal short-side lengths are skipped. The purpose is to test whether the upper strip was selected merely for being elongated. This may also skip needed loops, so compare spoiler-base results carefully. It is not a confirmed fix and has not been runtime-tested in Blender.


X-RAY ADDITIONAL LOOPS CONTROL (1.9 same-version test)
- Added one field: Additional Loops.
- Default is 2, adding two extra cuts to each accepted ring, while retaining the conservative candidate selection.
- The value is included in custom preset save/import/export.
- Maximum cuts per accepted ring is capped at 8 to limit accidental extreme density.
- Not runtime-tested inside Blender in this environment. Test on a duplicate of the kart mesh.
