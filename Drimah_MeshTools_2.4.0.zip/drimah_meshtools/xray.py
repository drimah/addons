import bpy
import bmesh
import math
import json
import os
import re
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from . import geom


def _mesh_object(context):
    obj = context.active_object
    return obj if obj and obj.type == 'MESH' else None


def _get_bmesh(context, obj):
    if obj.mode == 'EDIT':
        return bmesh.from_edit_mesh(obj.data), True
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    return bm, False


def _update_mesh(obj, bm, edit_mode, destructive=False):
    if edit_mode:
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=destructive)
    else:
        bm.to_mesh(obj.data)
        obj.data.update()
        bm.free()


def _selected_or_all(bm, edit_mode):
    if edit_mode:
        selected = [v for v in bm.verts if v.select]
        if selected:
            return set(selected)
    return set(bm.verts)



def _hard_edge_vertices(bm, angle_threshold=math.radians(35.0)):
    """Return vertices on marked-sharp edges or strong two-face angle transitions."""
    protected = set()
    for edge in bm.edges:
        marked_sharp = False
        try:
            marked_sharp = not edge.smooth
        except (AttributeError, ReferenceError):
            pass
        angled_sharp = False
        if len(edge.link_faces) == 2:
            n1, n2 = edge.link_faces[0].normal, edge.link_faces[1].normal
            try:
                angle = n1.angle(n2)
                angled_sharp = angle >= angle_threshold
            except (ValueError, RuntimeError):
                angled_sharp = False
        if marked_sharp or angled_sharp:
            protected.update(edge.verts)
    return protected

def _soften_selected_tips(bm, protected_vertices, intensity=0.18, iterations=2):
    """Conservative local smoothing for selected, non-hard vertices only.

    Moves coordinates slightly toward the one-ring average. It does not add
    edge loops or change connectivity; boundaries and sharp-edge vertices are
    excluded to prevent unintended silhouette/corner damage.
    """
    selected = {v for v in bm.verts if v.select}
    if not selected:
        return 0
    boundary = {
        v for e in bm.edges if len(e.link_faces) == 1 for v in e.verts
    }
    movable = {
        v for v in selected
        if v.is_valid and v not in protected_vertices and v not in boundary
        and len(v.link_faces) >= 3
    }
    if not movable:
        return 0
    intensity = max(0.0, min(0.25, float(intensity)))
    iterations = max(1, min(3, int(iterations)))
    # 2.0: smooth along the surface (no flattening of rounded tips)
    return geom.relax_keep_shape(bm, movable, intensity, iterations)
    moved = set()
    for _ in range(iterations):
        old = {v: v.co.copy() for v in bm.verts if v.is_valid}
        updates = {}
        for v in movable:
            neighbors = [e.other_vert(v) for e in v.link_edges if e.is_valid]
            if len(neighbors) < 3:
                continue
            avg = sum((old[n] for n in neighbors if n in old), start=old[v].copy() * 0.0)
            count = sum(1 for n in neighbors if n in old)
            if count:
                updates[v] = old[v].lerp(avg / count, intensity)
        for v, co in updates.items():
            v.co = co
            moved.add(v)
    return len(moved)


def _quad_flow_score(verts):
    """Local quad valence score; lower is more regular for interior quad flow."""
    score = 0.0
    for vert in verts:
        if not vert.is_valid or not vert.link_faces:
            continue
        # Only score interior all-quad vertices. Boundaries and mixed topology
        # are intentionally excluded because their expected valence differs.
        if any(len(face.verts) != 4 for face in vert.link_faces):
            continue
        if any(len(edge.link_faces) != 2 for edge in vert.link_edges):
            continue
        score += abs(len(vert.link_edges) - 4)
    return score


def _repair_quad_flow(bm, protected_vertices):
    """Conservatively rotate local quad edges only when interior valence improves.

    This is a first-pass topology heuristic, not a universal retopology solver:
    it never moves vertices and skips boundaries, non-quads and protected hard
    edges. A rotation is kept only if the local quad-valence score improves.
    """
    fixed = 0
    # Small number of passes prevents oscillation and keeps large meshes quick.
    for _pass in range(2):
        candidates = list(bm.edges)
        pass_fixed = 0
        for edge in candidates:
            if not edge.is_valid or len(edge.link_faces) != 2:
                continue
            faces = list(edge.link_faces)
            if len(faces[0].verts) != 4 or len(faces[1].verts) != 4:
                continue
            if any(v in protected_vertices for v in edge.verts):
                continue
            if any(not e.is_valid or len(e.link_faces) != 2 for v in edge.verts for e in v.link_edges):
                continue
            try:
                if not edge.smooth:
                    continue
            except (AttributeError, ReferenceError):
                pass
            local_verts = set(edge.verts)
            for face in faces:
                local_verts.update(face.verts)
            for vert in list(local_verts):
                for linked_edge in vert.link_edges:
                    local_verts.update(linked_edge.verts)
            before_score = _quad_flow_score(local_verts)
            if before_score <= 0:
                continue
            try:
                result = bmesh.ops.rotate_edges(bm, edges=[edge], use_ccw=False)
                new_edges = [e for e in result.get("edges", []) if e and e.is_valid]
                if not new_edges:
                    continue
                bm.normal_update()
                after_verts = set(local_verts)
                for new_edge in new_edges:
                    if new_edge.is_valid:
                        after_verts.update(new_edge.verts)
                        for face in new_edge.link_faces:
                            after_verts.update(face.verts)
                after_score = _quad_flow_score(after_verts)
                # Reject rotations that create degenerate faces or non-quad local faces.
                local_faces = {f for v in after_verts if v.is_valid for f in v.link_faces}
                valid_quads = all(len(f.verts) == 4 and f.calc_area() > 1e-12 for f in local_faces)
                if after_score < before_score and valid_quads:
                    fixed += 1
                    pass_fixed += 1
                else:
                    # Reverse the topology change immediately if it did not help.
                    reverse_edges = [e for e in new_edges if e.is_valid]
                    if reverse_edges:
                        bmesh.ops.rotate_edges(bm, edges=reverse_edges, use_ccw=True)
                        bm.normal_update()
            except (RuntimeError, ValueError, ReferenceError, TypeError):
                # A candidate that Blender cannot rotate is simply skipped.
                continue
        if pass_fixed == 0:
            break
    return fixed


def _edge_opposite_in_quad(edge, face):
    """Find the edge joining the two vertices opposite an edge in a quad."""
    if len(face.verts) != 4 or edge not in face.edges:
        return None
    a, b = edge.verts
    other = [v for v in face.verts if v is not a and v is not b]
    if len(other) != 2:
        return None
    for candidate in face.edges:
        if candidate is edge:
            continue
        if set(candidate.verts) == set(other):
            return candidate
    return None


def _trace_quad_edge_ring(seed, max_edges=512):
    """Trace opposite edges through quad faces; hard-edge vertices do not block topology."""
    ring = set()
    stack = [seed]
    seen = set()
    while stack and len(ring) < max_edges:
        edge = stack.pop()
        if edge in seen or not edge.is_valid:
            continue
        seen.add(edge)
        faces = list(edge.link_faces)
        if len(faces) not in (1, 2) or not faces:
            return None
        if any(len(face.verts) != 4 for face in faces):
            return None
        ring.add(edge)
        for face in faces:
            opposite = _edge_opposite_in_quad(edge, face)
            if opposite is None:
                return None
            if opposite not in seen:
                stack.append(opposite)
    if stack or not ring:
        return None
    return ring


def _insert_missing_quad_loops(bm, ratio=2.4, max_edges=512, additional_loops=2, follow_curvature=True):
    """Insert loops only along traceable opposite-edge rings.

    Unlike the previous face-region approach, this version does not combine
    every long edge from a connected patch. Each candidate edge must belong to
    a coherent opposite-edge ring through quad faces. Ring cut count is based
    on the median aspect ratio of candidate faces touched by that ring.
    """
    stats = {
        "candidate_edges": 0, "long_edges": 0, "rings_found": 0,
        "rings_rejected": 0, "rings_subdivided": 0, "new_vertices": 0,
        "non_quad_edges": 0, "boundary_edges": 0, "inconsistent_rings": 0,
        "candidate_faces": 0, "regions_found": 0, "regions_subdivided": 0,
    }
    valid_edges = [e for e in bm.edges if e.is_valid and e.calc_length() > 1e-9]
    stats["candidate_edges"] = len(valid_edges)
    stats["boundary_edges"] = sum(1 for e in valid_edges if len(e.link_faces) == 1)
    stats["non_quad_edges"] = sum(1 for e in valid_edges if len(e.link_faces) not in (1, 2) or any(len(f.verts) != 4 for f in e.link_faces))

    face_scores = {}
    candidate_edges = set()
    for face in bm.faces:
        if not face.is_valid or len(face.verts) != 4:
            continue
        lengths = [e.calc_length() for e in face.edges]
        if len(lengths) != 4 or min(lengths) <= 1e-9:
            continue
        pair_a = (lengths[0] + lengths[2]) * 0.5
        pair_b = (lengths[1] + lengths[3]) * 0.5
        long_pair = (0, 2) if pair_a >= pair_b else (1, 3)
        score = max(pair_a, pair_b) / max(min(pair_a, pair_b), 1e-9)
        if score < ratio:
            continue
        # Conservative test variant: a high aspect ratio alone is not enough
        # to justify inserting loops. Require both short-side edges to be
        # meaningfully longer than the shortest edge in the face, while using
        # a higher ratio threshold (2.4) to avoid subdividing already-regular
        # elongated strips. This changes only candidate selection; tracing,
        # cut count, Inflate, Relax, and weld behavior remain untouched.
        short_pair = (1, 3) if long_pair == (0, 2) else (0, 2)
        short_lengths = (lengths[short_pair[0]], lengths[short_pair[1]])
        if min(short_lengths) <= 1e-9 or max(short_lengths) / min(short_lengths) > 1.6:
            continue
        long_edges = {face.edges[i] for i in long_pair}
        if any(len(e.link_faces) not in (1, 2) or any(len(f.verts) != 4 for f in e.link_faces) for e in long_edges):
            continue
        face_scores[face] = score
        candidate_edges.update(long_edges)

    stats["candidate_faces"] = len(face_scores)
    stats["long_edges"] = len(candidate_edges)
    if not candidate_edges:
        return 0, stats

    # Trace each candidate independently; overlapping rings are processed once.
    processed = set()
    operations = []
    for seed in sorted(candidate_edges, key=lambda e: e.index):
        if seed in processed or not seed.is_valid:
            continue
        ring = _trace_quad_edge_ring(seed, max_edges=max_edges)
        if not ring or any(not e.is_valid for e in ring):
            stats["rings_rejected"] += 1
            continue
        # A traced ring can extend beyond the region that actually needs repair.
        # Reject it unless nearly all of its edges independently passed the
        # elongated-face detector. Otherwise one bad face can subdivide an
        # entire otherwise-healthy strip (the collateral-density failure).
        coverage = len(ring & candidate_edges) / max(len(ring), 1)
        if coverage < 0.85:
            stats["inconsistent_rings"] += 1
            stats["rings_rejected"] += 1
            continue
        # Avoid propagating cuts through rings whose edge lengths vary sharply.
        lengths = [e.calc_length() for e in ring]
        if not lengths or min(lengths) <= 1e-9 or max(lengths) / min(lengths) > 3.0:
            stats["inconsistent_rings"] += 1
            stats["rings_rejected"] += 1
            continue
        scores = []
        for edge in ring:
            for face in edge.link_faces:
                if face in face_scores:
                    scores.append(face_scores[face])
        if not scores:
            stats["rings_rejected"] += 1
            continue
        scores.sort()
        median_score = scores[len(scores) // 2]
        # Conservative cap: the old formula could create up to 32 cuts from
        # one elongated strip. A repair pass should add only a few loops; it
        # must not radically increase density in one operation.
        base_cuts = max(1, min(3, int(math.ceil(median_score - 1.0))))
        # User-controlled extra cuts; default +2 adds at least two cuts to each accepted ring.
        cuts = max(1, min(8, base_cuts + max(0, min(5, int(additional_loops)))))
        operations.append((ring, cuts))
        processed.update(ring)
        stats["rings_found"] += 1

    # 2.0: curves are recorded on the untouched mesh, before any ring is split, so
    # normals are not tilted by neighbouring rings that were already curved.
    curves = [_record_edge_curves(ring) if follow_curvature else [] for ring, _c in operations]
    for (ring, cuts), curve_info in zip(operations, curves):
        ring = [e for e in ring if e.is_valid]
        if not ring:
            stats["rings_rejected"] += 1
            continue
        before_verts = len(bm.verts)
        # This diagnostic build isolates ring selection. A full rollback-safe
        # trial mesh will be added only after Blender API compatibility is tested.
        try:
            bmesh.ops.subdivide_edges(
                bm, edges=ring, cuts=cuts, use_grid_fill=False,
                smooth=0.0, use_single_edge=True,
            )
            bm.normal_update()
            added = len(bm.verts) - before_verts
            if added <= 0 or any(f.is_valid and f.calc_area() <= 1e-12 for f in bm.faces):
                stats["rings_rejected"] += 1
                continue
            if follow_curvature:
                stats["curved_vertices"] = stats.get("curved_vertices", 0) + _curve_new_vertices(curve_info, bm)
                bm.normal_update()
            stats["rings_subdivided"] += 1
            stats["regions_subdivided"] += 1
            stats["new_vertices"] += added
        except (RuntimeError, ValueError, TypeError, ReferenceError):
            stats["rings_rejected"] += 1
    return stats["new_vertices"], stats

def _record_edge_curves(ring):
    """Before splitting: remember each edge's ends and the smooth curve through them.
    On a hard edge the two sides give different curves; the more curved one is the
    real rim (e.g. a cylinder cap edge follows the circle, not the flat cap)."""
    info = []
    for e in ring:
        if not e.is_valid:
            continue
        a, b = e.verts
        faces = list(e.link_faces)
        groups = [faces]
        if len(faces) == 2 and geom.is_hard_edge(e):
            groups = [[faces[0]], [faces[1]]]
        best = None
        for g in groups:
            na = geom.smooth_normal(a, g)
            nb = geom.smooth_normal(b, g)
            mid = geom.curve_point(a.co, b.co, na, nb, 0.5)
            bulge = (mid - (a.co + b.co) * 0.5).length
            if best is None or bulge > best[0]:
                best = (bulge, na, nb)
        info.append((a.co.copy(), b.co.copy(), best[1].copy(), best[2].copy()))
    return info


def _curve_new_vertices(info, bm):
    """After splitting: move the new vertices of each edge from the straight chord
    onto the smooth curve, so loops on round areas follow the round shape.
    Vertices are found by position (Blender can reallocate BMesh elements during
    subdivision, so element references taken before the split are not reused)."""
    from mathutils.kdtree import KDTree
    verts = list(bm.verts)
    kd = KDTree(len(verts))
    for i, v in enumerate(verts):
        kd.insert(v.co, i)
    kd.balance()
    moved = 0
    for pa, pb, na, nb in info:
        seg = pb - pa
        L2 = seg.length_squared
        if L2 < 1e-24:
            continue
        L = seg.length
        tol = max(1e-9, L * 1e-4)
        for _co, i, _d in kd.find_range((pa + pb) * 0.5, L * 0.5 + tol):
            v = verts[i]
            t = (v.co - pa).dot(seg) / L2
            if t <= 1e-6 or t >= 1.0 - 1e-6:
                continue
            if (v.co - (pa + seg * t)).length > tol:
                continue
            v.co = geom.curve_point(pa, pb, na, nb, t)
            moved += 1
    return moved


def _diagnose(bm, settings):
    issues = {
        "loose_vertices": 0,
        "loose_edges": 0,
        "non_manifold_edges": 0,
        "degenerate_faces": 0,
        "duplicate_vertices": 0,
        "faces": len(bm.faces),
        "vertices": len(bm.verts),
    }
    for v in bm.verts:
        if not v.link_edges:
            issues["loose_vertices"] += 1
    for e in bm.edges:
        if not e.link_faces:
            issues["loose_edges"] += 1
        if len(e.link_faces) > 2:
            issues["non_manifold_edges"] += 1
    for f in bm.faces:
        if f.calc_area() <= settings.area_threshold:
            issues["degenerate_faces"] += 1
    # A spatial hash keeps the duplicate check bounded for typical meshes.
    # This reports near-coincident pairs without changing the mesh.
    verts = list(bm.verts)
    cell = max(settings.merge_distance, 1e-8)
    buckets = {}
    duplicate_pairs = set()
    for v in verts:
        key = tuple(int(round(c / cell)) for c in v.co)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    near = (key[0] + dx, key[1] + dy, key[2] + dz)
                    for other in buckets.get(near, ()):
                        if (v.co - other.co).length <= settings.merge_distance:
                            duplicate_pairs.add(tuple(sorted((v.index, other.index))))
        buckets.setdefault(key, []).append(v)
    issues["duplicate_vertices"] = len(duplicate_pairs)
    return issues


XRAY_BUILTINS = {
    "SAFE": {"label": "Safe Repair", "fix_loose": True, "fix_doubles": True, "fix_degenerate": True, "recalc_normals": False, "maintain_hard_edges": True, "soften_tips": False, "insert_missing_loops": True, "additional_loops": 2, "merge_distance": 0.0001, "area_threshold": 0.0000001},
    "BALANCED": {"label": "Balanced", "fix_loose": True, "fix_doubles": True, "fix_degenerate": True, "recalc_normals": True, "maintain_hard_edges": True, "soften_tips": False, "insert_missing_loops": True, "additional_loops": 2, "merge_distance": 0.0001, "area_threshold": 0.0000001},
    "ORGANIC": {"label": "Organic", "fix_loose": True, "fix_doubles": True, "fix_degenerate": True, "recalc_normals": True, "maintain_hard_edges": True, "soften_tips": False, "insert_missing_loops": True, "additional_loops": 2, "merge_distance": 0.0001, "area_threshold": 0.0000001},
    "HARD": {"label": "Hard Surface", "fix_loose": True, "fix_doubles": True, "fix_degenerate": True, "recalc_normals": True, "maintain_hard_edges": True, "soften_tips": False, "insert_missing_loops": True, "additional_loops": 2, "merge_distance": 0.0001, "area_threshold": 0.0000001},
    "GAME": {"label": "Game Ready", "fix_loose": True, "fix_doubles": True, "fix_degenerate": True, "recalc_normals": True, "maintain_hard_edges": True, "soften_tips": False, "insert_missing_loops": True, "additional_loops": 2, "merge_distance": 0.0001, "area_threshold": 0.0000001},
}


def _xray_preset_path():
    base = bpy.utils.user_resource('CONFIG', path="drimah_meshtools", create=True)
    return os.path.join(base, "xray_presets.json")


def _load_xray_custom():
    try:
        with open(_xray_preset_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write_xray_custom(data):
    path = _xray_preset_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


_XRAY_ENUM_ITEMS_CACHE = []

def _xray_preset_items(self, context):
    global _XRAY_ENUM_ITEMS_CACHE
    items = [(k, v["label"], "Built-in X-Ray preset") for k, v in XRAY_BUILTINS.items()]
    custom = _load_xray_custom()
    for key, value in sorted(custom.items(), key=lambda item: str(item[1].get("label", "")).lower()):
        if isinstance(value, dict) and isinstance(value.get("label"), str):
            items.append((key, value["label"], "Custom X-Ray preset"))
    if not items:
        items = [('BALANCED', 'Balanced', 'Built-in X-Ray preset')]
    # Keep dynamic enum strings alive; Blender can retain pointers between redraws.
    _XRAY_ENUM_ITEMS_CACHE = items
    return _XRAY_ENUM_ITEMS_CACHE


def _xray_preset_update(self, context):
    data = XRAY_BUILTINS.get(self.preset) or _load_xray_custom().get(self.preset)
    if not isinstance(data, dict):
        return
    for prop in ("fix_loose", "fix_doubles", "fix_degenerate", "recalc_normals", "maintain_hard_edges", "soften_tips", "insert_missing_loops", "follow_curvature"):
        if prop in data:
            setattr(self, prop, bool(data[prop]))
    self.merge_distance = max(0.000001, min(0.1, float(data.get("merge_distance", self.merge_distance))))
    self.area_threshold = max(0.0, min(0.01, float(data.get("area_threshold", self.area_threshold))))
    self.additional_loops = max(0, min(5, int(data.get("additional_loops", self.additional_loops))))


class DMT_XRAY_Settings(PropertyGroup):
    preset: EnumProperty(name="Preset", items=_xray_preset_items, update=_xray_preset_update)
    fix_loose: BoolProperty(name="Loose Geometry", default=True)
    fix_doubles: BoolProperty(
        name="Weld Nearby Vertices",
        description="Weld vertices that are almost overlapping, within a conservative distance",
        default=True,
    )
    fix_degenerate: BoolProperty(name="Remove Degenerate Geometry", default=True)
    recalc_normals: BoolProperty(name="Recalculate Normals", default=True)
    maintain_hard_edges: BoolProperty(
        name="Maintain Hard Edges",
        description="Protect marked sharp edges and strong face-angle transitions during vertex merging",
        default=True,
    )
    soften_tips: BoolProperty(
        name="Soften Selected Tips",
        description="Slightly smooth selected non-hard interior vertices; select only the tip area first",
        default=False,
    )
    insert_missing_loops: BoolProperty(
        name="Insert Missing Edge Loops",
        description="Subdivide unusually long edges in continuous interior quad regions",
        default=True,
    )
    follow_curvature: BoolProperty(
        name="Follow Curvature",
        description="Place new loop vertices on the curved surface instead of a straight line (keeps round areas round)",
        default=True,
    )
    additional_loops: IntProperty(
        name="Additional Loops",
        description="Extra cuts added to each accepted X-Ray loop ring",
        default=2, min=0, max=5,
    )
    merge_distance: FloatProperty(name="Merge Distance", default=0.0001, min=0.000001, max=0.1, precision=6)
    area_threshold: FloatProperty(name="Minimum Face Area", default=0.0000001, min=0.0, max=0.01, precision=8)


class DMT_XRAY_OT_fix(Operator):
    bl_idname = "dmt_xray.fix"
    bl_label = "Fix"
    bl_description = "Inspect the active mesh and apply the selected safe repairs"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _mesh_object(context)
        return obj is not None and context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        obj = _mesh_object(context)
        if obj is None:
            self.report({'ERROR'}, "Select a mesh object.")
            return {'CANCELLED'}

        settings = context.scene.dmt_xray_settings

        edit_mode = obj.mode == 'EDIT'
        switched = False
        if not edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')
            switched = True
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        before = _diagnose(bm, settings)
        changed = []

        try:
            if settings.fix_doubles:
                # When requested, avoid welding vertices that define sharp
                # edges or strong angle transitions. This is deliberately
                # conservative: it may leave some duplicates near hard edges.
                # Always protect vertices defining marked-sharp edges or strong
                # face-angle transitions from welding. The UI toggle controls
                # whether flow rotations may cross those regions; it must never
                # authorize destructive welding of corners.
                protected = _hard_edge_vertices(bm)
                merge_candidates = [v for v in bm.verts if v not in protected]
                if len(merge_candidates) > 1:
                    vertex_count_before_merge = len(bm.verts)
                    # Blender may return None from this BMesh operation in some builds.
                    # Detect an actual weld from the mesh itself, without relying on the operator return value.
                    bmesh.ops.remove_doubles(
                        bm, verts=merge_candidates, dist=settings.merge_distance
                    )
                    if len(bm.verts) < vertex_count_before_merge:
                        changed.append("merged near-duplicate vertices")
                if protected and len(merge_candidates) != len(bm.verts):
                    changed.append("preserved hard-edge vertices")

            if settings.fix_loose:
                loose_verts = [v for v in bm.verts if not v.link_edges]
                loose_edges = [e for e in bm.edges if not e.link_faces]
                if loose_verts:
                    bmesh.ops.delete(bm, geom=loose_verts, context='VERTS')
                if loose_edges:
                    bmesh.ops.delete(bm, geom=loose_edges, context='EDGES')
                if loose_verts or loose_edges:
                    changed.append("removed loose geometry")

            if settings.fix_degenerate:
                # Delete only faces below a deliberately small area threshold.
                tiny_faces = [f for f in bm.faces if f.is_valid and f.calc_area() <= settings.area_threshold]
                if tiny_faces:
                    bmesh.ops.delete(bm, geom=tiny_faces, context='FACES_ONLY')
                    changed.append("removed degenerate faces")
                hard_vertices_for_cleanup = _hard_edge_vertices(bm)
                tiny_edges = [
                    e for e in bm.edges
                    if e.is_valid
                    and e.calc_length() <= settings.merge_distance * 0.1
                    and not any(v in hard_vertices_for_cleanup for v in e.verts)
                ]
                if tiny_edges:
                    bmesh.ops.dissolve_degenerate(bm, edges=tiny_edges, dist=max(settings.merge_distance * 0.1, 1e-9))
                    changed.append("dissolved degenerate edges")

            if settings.insert_missing_loops:
                context.window_manager.progress_begin(0, 100)
                context.workspace.status_text_set("Processing... X-Ray adaptive edge-loop analysis")
                try:
                    added_vertices, loop_stats = _insert_missing_quad_loops(bm, additional_loops=settings.additional_loops, follow_curvature=settings.follow_curvature)
                finally:
                    context.window_manager.progress_end()
                    context.workspace.status_text_set(None)
                if added_vertices:
                    changed.append(
                        f"inserted adaptive edge loops ({loop_stats['rings_subdivided']} rings, "
                        f"{added_vertices} vertices; {loop_stats['rings_rejected']} rings rejected, {loop_stats['inconsistent_rings']} inconsistent rings)"
                    )
                else:
                    changed.append(
                        f"edge-loop analysis: {loop_stats['candidate_edges']} quad edges, "
                        f"{loop_stats['long_edges']} long-edge candidates, "
                        f"{loop_stats['rings_rejected']} rings rejected, {loop_stats['inconsistent_rings']} inconsistent rings, {loop_stats['non_quad_edges']} non-quad/non-manifold edges, {loop_stats['boundary_edges']} boundary edges; no loops inserted"
                    )

            # Repair local breaks in quad edge flow conservatively. This changes
            # connectivity only where a safe edge rotation improves interior
            # quad valence; it does not smooth or move the surface.
            # Edge rotation is only a conservative local heuristic; do not run
            # it when hard-edge protection is disabled, because this module does
            # not yet have enough semantic information to safely infer intended
            # flow across sharp transitions.
            # DIAGNOSTIC TEST ONLY (Drimah MeshTools 1.6):
            # Temporarily bypass _repair_quad_flow to isolate whether this
            # post-processing pass causes collateral topology changes.
            # No other X-Ray logic is changed in this test package.
            flow_rotations = 0

            if settings.soften_tips:
                protected_for_smoothing = _hard_edge_vertices(bm)
                softened = _soften_selected_tips(bm, protected_for_smoothing)
                if softened:
                    changed.append(f"softened selected tip area ({softened} vertices)")

            if settings.recalc_normals and bm.faces:
                bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
                changed.append("recalculated face normals")

            bm.normal_update()
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
            after = _diagnose(bm, settings)
            report = (
                f"Before: {before['vertices']} verts, {before['faces']} faces; "
                f"loose verts {before['loose_vertices']}, loose edges {before['loose_edges']}, "
                f"non-manifold edges (>2 faces) {before['non_manifold_edges']}, "
                f"degenerate faces {before['degenerate_faces']}, near-duplicate pairs {before['duplicate_vertices']}. "
                f"After: {len(bm.verts)} verts, {len(bm.faces)} faces. "
                + ("Fixed: " + ", ".join(changed) + "." if changed else "No selected repairs were necessary.")
            )
            self.report({'INFO'}, "X-Ray finished. " + (", ".join(changed) if changed else "No repairs needed."))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, f"X-Ray repair failed: {exc}")
            return {'CANCELLED'}
        finally:
            if switched and context.mode == 'EDIT_MESH':
                bpy.ops.object.mode_set(mode='OBJECT')


class DMT_XRAY_OT_save_preset(Operator):
    bl_idname = "dmt_xray.save_preset"
    bl_label = "Save Preset"
    name: StringProperty(name="Preset Name", default="My Preset", maxlen=64)
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)
    def draw(self, context):
        self.layout.prop(self, "name", text="")
    def execute(self, context):
        label = self.name.strip()
        if not label:
            self.report({'WARNING'}, "Enter a preset name.")
            return {'CANCELLED'}
        key = "CUSTOM_" + re.sub(r'[^A-Z0-9]+', '_', label.upper()).strip('_')[:40]
        s = context.scene.dmt_xray_settings
        data = _load_xray_custom()
        data[key] = {"label": label, **{p: getattr(s, p) for p in ("fix_loose", "fix_doubles", "fix_degenerate", "recalc_normals", "maintain_hard_edges", "soften_tips", "insert_missing_loops", "follow_curvature", "merge_distance", "area_threshold", "additional_loops")}}
        try:
            _write_xray_custom(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not save: {exc}")
            return {'CANCELLED'}
        s.preset = key
        return {'FINISHED'}


class DMT_XRAY_OT_delete_preset(Operator):
    bl_idname = "dmt_xray.delete_preset"
    bl_label = "Delete Preset"
    @classmethod
    def poll(cls, context):
        return context.scene.dmt_xray_settings.preset in _load_xray_custom()
    def execute(self, context):
        s = context.scene.dmt_xray_settings
        data = _load_xray_custom()
        if s.preset not in data:
            return {'CANCELLED'}
        del data[s.preset]
        try:
            _write_xray_custom(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not delete: {exc}")
            return {'CANCELLED'}
        s.preset = 'BALANCED'
        return {'FINISHED'}


class DMT_XRAY_OT_export_presets(Operator):
    bl_idname = "dmt_xray.export_presets"
    bl_label = "Export Presets"
    filepath: StringProperty(subtype='FILE_PATH')
    def invoke(self, context, event):
        self.filepath = os.path.join(os.path.expanduser("~"), "drimah_xray_presets.json")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self, context):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(_load_xray_custom(), f, ensure_ascii=False, indent=2)
            return {'FINISHED'}
        except OSError as exc:
            self.report({'ERROR'}, f"Export failed: {exc}")
            return {'CANCELLED'}


class DMT_XRAY_OT_import_presets(Operator):
    bl_idname = "dmt_xray.import_presets"
    bl_label = "Import Presets"
    filepath: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self, context):
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                incoming = json.load(f)
            if not isinstance(incoming, dict):
                raise ValueError("Invalid preset file")
            existing = _load_xray_custom()
            props = ("fix_loose", "fix_doubles", "fix_degenerate", "recalc_normals", "maintain_hard_edges", "soften_tips", "insert_missing_loops", "follow_curvature")
            for key, value in incoming.items():
                if not isinstance(value, dict) or not isinstance(value.get("label"), str):
                    continue
                safe_key = re.sub(r'[^A-Z0-9_]+', '_', str(key).upper())[:48] or "IMPORTED"
                item = {"label": value["label"][:64]}
                item.update({p: bool(value.get(p, True)) for p in props})
                item["merge_distance"] = max(0.000001, min(0.1, float(value.get("merge_distance", 0.0001))))
                item["area_threshold"] = max(0.0, min(0.01, float(value.get("area_threshold", 0.0000001))))
                item["additional_loops"] = max(0, min(5, int(value.get("additional_loops", 2))))
                existing[safe_key] = item
            _write_xray_custom(existing)
            _xray_preset_items(None, None)
            return {'FINISHED'}
        except (OSError, ValueError, TypeError) as exc:
            self.report({'ERROR'}, f"Import failed: {exc}")
            return {'CANCELLED'}


class DMT_XRAY_PT_panel(Panel):
    bl_label = "X-Ray"
    bl_idname = "DMT_XRAY_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drimah MeshTools"
    bl_parent_id = "DMT_PT_meshtools_root"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.dmt_xray_settings

        # Match Inflate's layout: preset selector, module settings,
        # Save/Delete, Export/Import, then the main action last.
        layout.prop(s, "preset", text="Preset")
        layout.prop(s, "fix_loose")
        layout.prop(s, "fix_doubles")
        layout.prop(s, "fix_degenerate")
        layout.prop(s, "recalc_normals")
        layout.prop(s, "maintain_hard_edges")
        layout.prop(s, "soften_tips")
        layout.prop(s, "insert_missing_loops")
        layout.prop(s, "additional_loops")
        layout.prop(s, "follow_curvature")
        layout.prop(s, "merge_distance")
        layout.prop(s, "area_threshold")

        row = layout.row(align=True)
        row.operator("dmt_xray.save_preset", text="Save", icon='FILE_TICK')
        row.operator("dmt_xray.delete_preset", text="Delete", icon='TRASH')

        row = layout.row(align=True)
        row.operator("dmt_xray.export_presets", text="Export", icon='EXPORT')
        row.operator("dmt_xray.import_presets", text="Import", icon='IMPORT')

        layout.separator()
        row = layout.row()
        row.scale_y = 1.35
        row.operator("dmt_xray.fix", text="Fix", icon='CHECKMARK')


def register():
    bpy.utils.register_class(DMT_XRAY_Settings)
    bpy.utils.register_class(DMT_XRAY_OT_fix)
    bpy.utils.register_class(DMT_XRAY_OT_save_preset)
    bpy.utils.register_class(DMT_XRAY_OT_delete_preset)
    bpy.utils.register_class(DMT_XRAY_OT_export_presets)
    bpy.utils.register_class(DMT_XRAY_OT_import_presets)
    bpy.utils.register_class(DMT_XRAY_PT_panel)
    bpy.types.Scene.dmt_xray_settings = bpy.props.PointerProperty(type=DMT_XRAY_Settings)


def unregister():
    if hasattr(bpy.types.Scene, "dmt_xray_settings"):
        del bpy.types.Scene.dmt_xray_settings
    for cls in (DMT_XRAY_PT_panel, DMT_XRAY_OT_import_presets, DMT_XRAY_OT_export_presets, DMT_XRAY_OT_delete_preset, DMT_XRAY_OT_save_preset, DMT_XRAY_OT_fix, DMT_XRAY_Settings):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
