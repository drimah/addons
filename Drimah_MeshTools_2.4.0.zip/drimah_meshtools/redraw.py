"""Drimah MeshTools - Redraw module.

Redraw rebuilds the selected faces as a clean quad patch:
  1. the selected region's border loop is kept (the rest of the mesh is untouched),
  2. optional border rings are grown inward along the surface,
  3. the remaining hole is filled with a quad grid (Coons patch, automatic corners),
  4. the new vertices are relaxed and projected back onto the original surface.

Symmetry: when a mirror axis is enabled, the matching faces on the other side
are included automatically, only the source side is redrawn, and the result is
mirrored and welded to the existing border on the other side.
"""

import bpy
import bmesh
import math
import json
import os
import re
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup


# ---------------------------------------------------------------------------
# Presets
# ---------------------------------------------------------------------------

REDRAW_BUILTINS = {
    "CLEAN": {"label": "Clean", "border_loops": 1, "border_width": 0.6, "corner_offset": 0,
              "smooth_iterations": 12, "smooth_strength": 0.5, "project_surface": True,
              "opening_smooth": 0.6, "opening_loops": 0, "even_opening": True},
    "TIGHT": {"label": "Tight", "border_loops": 0, "border_width": 0.6, "corner_offset": 0,
              "smooth_iterations": 6, "smooth_strength": 0.4, "project_surface": True,
              "opening_smooth": 0.3, "opening_loops": 0, "even_opening": True},
    "SOFT": {"label": "Soft", "border_loops": 2, "border_width": 0.7, "corner_offset": 0,
             "smooth_iterations": 25, "smooth_strength": 0.6, "project_surface": True,
             "opening_smooth": 0.75, "opening_loops": 0, "even_opening": True},
    "HARD_SURFACE": {"label": "Hard Surface", "border_loops": 1, "border_width": 0.35, "corner_offset": 0,
                     "smooth_iterations": 4, "smooth_strength": 0.3, "project_surface": True,
                     "opening_smooth": 0.2, "opening_loops": 0, "even_opening": True},
}

# Values stored in presets (symmetry and Keep Original included).
PRESET_PROPS = {
    "border_loops": (int, 0, 4),
    "border_width": (float, 0.1, 2.0),
    "corner_offset": (int, -64, 64),
    "smooth_iterations": (int, 0, 100),
    "smooth_strength": (float, 0.0, 1.0),
    "project_surface": (bool, None, None),
    "keep_original": (bool, None, None),
    "symmetry_axis": (str, None, None),
    "symmetry_scope": (str, None, None),
    "mirror_result": (str, None, None),
    "mirror_center": (str, None, None),
    "mirror_side": (str, None, None),
    "mirror_tolerance": (float, 0.000001, 0.1),
    "opening_smooth": (float, 0.0, 1.0),
    "opening_loops": (int, 0, 30),
    "even_opening": (bool, None, None),
}


STR_CHOICES = {
    "symmetry_axis": {'NONE', 'X', 'Y', 'Z'},
    "symmetry_scope": {'SELECTED', 'WHOLE'},
    "mirror_result": {'WELD', 'MODIFIER'},
    "mirror_center": {'AUTO', 'ORIGIN', 'CURSOR'},
    "mirror_side": {'POSITIVE', 'NEGATIVE'},
}


def _legacy_symmetry(data):
    """Presets from 2.1/2.2 used X/Y/Z checkboxes; map them to the single axis."""
    if isinstance(data, dict) and "symmetry_axis" not in data:
        for ax in ("x", "y", "z"):
            if data.get("use_mirror_" + ax):
                data = dict(data)
                data["symmetry_axis"] = ax.upper()
                return data
        if any(("use_mirror_" + ax) in data for ax in ("x", "y", "z")):
            data = dict(data)
            data["symmetry_axis"] = 'NONE'
    return data


def _clean_value(prop, value, fallback):
    kind, lo, hi = PRESET_PROPS[prop]
    try:
        if kind is bool:
            return bool(value)
        if kind is str:
            return value if value in STR_CHOICES[prop] else fallback
        value = kind(value)
        return max(lo, min(hi, value))
    except (TypeError, ValueError):
        return fallback


def _redraw_preset_path():
    base = bpy.utils.user_resource('CONFIG', path="drimah_meshtools", create=True)
    return os.path.join(base, "redraw_presets.json")


def _load_redraw_custom():
    try:
        with open(_redraw_preset_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write_redraw_custom(data):
    path = _redraw_preset_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


_REDRAW_ENUM_ITEMS_CACHE = []


def _redraw_preset_items(self, context):
    global _REDRAW_ENUM_ITEMS_CACHE
    items = [(k, v["label"], "Built-in Redraw preset") for k, v in REDRAW_BUILTINS.items()]
    custom = _load_redraw_custom()
    for key, value in sorted(custom.items(), key=lambda item: str(item[1].get("label", "")).lower()):
        if isinstance(value, dict) and isinstance(value.get("label"), str):
            items.append((key, value["label"], "Custom Redraw preset"))
    # Keep dynamic enum strings alive; Blender can retain pointers between redraws.
    _REDRAW_ENUM_ITEMS_CACHE = items
    return _REDRAW_ENUM_ITEMS_CACHE


def _redraw_preset_update(self, context):
    data = REDRAW_BUILTINS.get(self.preset) or _load_redraw_custom().get(self.preset)
    if not isinstance(data, dict):
        return
    data = _legacy_symmetry(data)
    for prop in PRESET_PROPS:
        if prop in data:
            setattr(self, prop, _clean_value(prop, data[prop], getattr(self, prop)))


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

AXES = {'X': 0, 'Y': 1, 'Z': 2}


class RedrawError(Exception):
    pass


def _mirror_co(co, axis):
    m = co.copy()
    m[axis] = -m[axis]
    return m


def _components(faces):
    """Split a face set into edge-connected components."""
    faces = set(faces)
    seen = set()
    comps = []
    for start in faces:
        if start in seen:
            continue
        stack = [start]
        seen.add(start)
        comp = []
        while stack:
            f = stack.pop()
            comp.append(f)
            for e in f.edges:
                for g in e.link_faces:
                    if g in faces and g not in seen:
                        seen.add(g)
                        stack.append(g)
        comps.append(comp)
    return comps


def _border_loops(comp):
    """Directed border loops of a face component, following the faces' winding."""
    comp_set = set(comp)
    nxt = {}
    for f in comp:
        for loop in f.loops:
            e = loop.edge
            inside = sum(1 for g in e.link_faces if g in comp_set)
            if inside == 1:
                a = loop.vert
                b = loop.link_loop_next.vert
                if a in nxt:
                    raise RedrawError("The selection touches itself at a single vertex; adjust the selection.")
                nxt[a] = b
    loops = []
    used = set()
    for start in list(nxt.keys()):
        if start in used:
            continue
        ring = [start]
        used.add(start)
        cur = nxt[start]
        guard = 0
        while cur is not start:
            if cur in used or cur not in nxt:
                raise RedrawError("Could not trace a clean border around the selection.")
            ring.append(cur)
            used.add(cur)
            cur = nxt[cur]
            guard += 1
            if guard > 1000000:
                raise RedrawError("Border tracing did not finish.")
        loops.append(ring)
    return loops


def _turn_angle(prev_co, co, next_co):
    d1 = co - prev_co
    d2 = next_co - co
    if d1.length < 1e-12 or d2.length < 1e-12:
        return 0.0
    try:
        return d1.angle(d2)
    except ValueError:
        return 0.0


def _choose_corners(cos, user_offset):
    """Pick 4 corners on an even loop: (start index k, side a, side b)."""
    n = len(cos)
    h = n // 2
    # Loop normal (Newell). Faces lie to the left of the loop, so a left turn is
    # a convex corner (good grid corner) and a right turn is concave (avoid).
    normal = Vector()
    for i in range(n):
        p, q = cos[i], cos[(i + 1) % n]
        normal.x += (p.y - q.y) * (p.z + q.z)
        normal.y += (p.z - q.z) * (p.x + q.x)
        normal.z += (p.x - q.x) * (p.y + q.y)
    turn = []
    for i in range(n):
        ang = _turn_angle(cos[i - 1], cos[i], cos[(i + 1) % n])
        side = (cos[i] - cos[i - 1]).cross(cos[(i + 1) % n] - cos[i]).dot(normal)
        turn.append(ang if side >= 0 else -1.5 * ang)
    seg = [(cos[(i + 1) % n] - cos[i]).length for i in range(n)]
    prefix = [0.0]
    for s in seg:
        prefix.append(prefix[-1] + s)
    total = prefix[-1]

    def span_len(start, count):
        end = start + count
        if end <= n:
            return prefix[end] - prefix[start]
        return (total - prefix[start]) + prefix[end - n]

    best = None
    for a in range(1, h):
        b = h - a
        balance = abs(a - b) / float(h) * 0.15
        for k in range(n):
            score = turn[k] + turn[(k + a) % n] + turn[(k + h) % n] + turn[(k + h + a) % n]
            la = span_len(k, a) + span_len((k + h) % n, a)
            lb = span_len((k + a) % n, b) + span_len((k + h + a) % n, b)
            if la > 1e-12 and lb > 1e-12:
                # Prefer side counts proportional to side lengths (square-ish cells).
                score -= 0.5 * abs(math.log((la / a) / (lb / b)))
            score -= balance
            if best is None or score > best[0] + 1e-9:
                best = (score, k, a, b)
    _, k, a, b = best
    return (k + user_offset) % n, a, b


def _grid_fill(bm, loop, user_offset, mat, smooth):
    """Fill one closed, even, directed loop of verts with a quad grid (Coons patch)."""
    n = len(loop)
    cos = [v.co.copy() for v in loop]
    k, a, b = _choose_corners(cos, user_offset)

    def L(i):
        return loop[(k + i) % n]

    P = [[None] * (b + 1) for _ in range(a + 1)]
    for i in range(a + 1):
        P[i][0] = L(i)
        P[i][b] = L(2 * a + b - i)
    for j in range(b + 1):
        P[a][j] = L(a + j)
        P[0][j] = L(n - j) if j else L(0)

    c00, c10, c11, c01 = P[0][0].co, P[a][0].co, P[a][b].co, P[0][b].co
    new_verts = []
    for i in range(1, a):
        u = i / a
        for j in range(1, b):
            v = j / b
            co = ((1 - v) * P[i][0].co + v * P[i][b].co
                  + (1 - u) * P[0][j].co + u * P[a][j].co
                  - ((1 - u) * (1 - v) * c00 + u * (1 - v) * c10
                     + (1 - u) * v * c01 + u * v * c11))
            vert = bm.verts.new(co)
            P[i][j] = vert
            new_verts.append(vert)

    new_faces = []
    for i in range(a):
        for j in range(b):
            quad = (P[i][j], P[i + 1][j], P[i + 1][j + 1], P[i][j + 1])
            try:
                f = bm.faces.new(quad)
            except ValueError:
                continue
            f.material_index = mat
            f.smooth = smooth
            new_faces.append(f)
    return new_verts, new_faces


def _cap_odd(bm, loop, mat, smooth):
    """Close one convex corner with a triangle so the remaining loop is even."""
    n = len(loop)
    best_i, best_angle = 0, None
    centroid = sum((v.co for v in loop), Vector()) / n
    for i in range(n):
        p, c, q = loop[i - 1].co, loop[i].co, loop[(i + 1) % n].co
        d1, d2 = p - c, q - c
        if d1.length < 1e-12 or d2.length < 1e-12:
            continue
        ang = d1.angle(d2)
        # Prefer corners pointing away from the centre (convex).
        convex = (c - centroid).dot((d1.normalized() + d2.normalized())) < 0
        key = ang if convex else ang + math.pi
        if best_angle is None or key < best_angle:
            best_angle, best_i = key, i
    a, b, c = loop[best_i - 1], loop[best_i], loop[(best_i + 1) % n]
    faces = []
    try:
        f = bm.faces.new((a, b, c))
        f.material_index = mat
        f.smooth = smooth
        faces.append(f)
    except ValueError:
        pass
    rest = loop[:best_i] + loop[best_i + 1:] if best_i else loop[1:]
    return rest, faces


class _Surface:
    """Original surface used for projection (built before anything changes)."""

    def __init__(self, faces):
        verts = {}
        coords = []
        polys = []
        for f in faces:
            poly = []
            for v in f.verts:
                idx = verts.get(v)
                if idx is None:
                    idx = len(coords)
                    verts[v] = idx
                    coords.append(v.co.copy())
                poly.append(idx)
            polys.append(poly)
        self.tree = BVHTree.FromPolygons(coords, polys, all_triangles=False) if polys else None

    def nearest(self, co):
        if self.tree is None:
            return co, None
        hit = self.tree.find_nearest(co)
        if hit[0] is None:
            return co, None
        return hit[0], hit[1]


def _grow_ring(bm, loop, surface, width, mat, smooth):
    """Grow one quad ring inward from a directed border loop."""
    n = len(loop)
    new_loop = []
    for i in range(n):
        prev_co, co, next_co = loop[i - 1].co, loop[i].co, loop[(i + 1) % n].co
        tangent = next_co - prev_co
        if tangent.length < 1e-12:
            tangent = next_co - co
        tangent.normalize()
        _, normal = surface.nearest(co)
        if normal is None:
            normal = loop[i].normal.copy()
        # Faces lie to the left of the loop direction when seen from the normal.
        inward = normal.cross(tangent)
        if inward.length < 1e-12:
            inward = (sum((v.co for v in loop), Vector()) / n) - co
        inward.normalize()
        edge_len = 0.5 * ((co - prev_co).length + (next_co - co).length)
        target = co + inward * (edge_len * width)
        target, _ = surface.nearest(target)
        new_loop.append(bm.verts.new(target))
    faces = []
    for i in range(n):
        j = (i + 1) % n
        try:
            f = bm.faces.new((loop[i], loop[j], new_loop[j], new_loop[i]))
            f.material_index = mat
            f.smooth = smooth
            faces.append(f)
        except ValueError:
            pass
    return new_loop, faces


def _relax(movable, surface, iterations, strength, project):
    movable = [v for v in movable if v.is_valid]
    if not movable:
        return
    for _ in range(iterations):
        old = {v: v.co.copy() for v in movable}
        for v in movable:
            neighbors = [e.other_vert(v) for e in v.link_edges]
            if not neighbors:
                continue
            avg = Vector()
            for nb in neighbors:
                avg += old.get(nb, nb.co)
            avg /= len(neighbors)
            v.co = old[v].lerp(avg, strength)
        if project:
            for v in movable:
                v.co, _ = surface.nearest(v.co)
    if project and iterations == 0:
        for v in movable:
            v.co, _ = surface.nearest(v.co)


# ---------------------------------------------------------------------------
# Openings (selected ring of faces around a hole)
# ---------------------------------------------------------------------------

def _closed_params(cos):
    n = len(cos)
    acc = [0.0]
    for i in range(n):
        acc.append(acc[-1] + (cos[(i + 1) % n] - cos[i]).length)
    total = acc[-1] or 1.0
    return [a / total for a in acc], total


def _sample_closed(cos, t):
    """Point at normalized arc length t (0..1, wraps) on a closed polyline."""
    params, _ = _closed_params(cos)
    t = t % 1.0
    n = len(cos)
    lo, hi = 0, n
    while lo < hi:
        mid = (lo + hi) // 2
        if params[mid + 1] < t:
            lo = mid + 1
        else:
            hi = mid
    i = min(lo, n - 1)
    span = params[i + 1] - params[i]
    f = 0.0 if span <= 1e-12 else (t - params[i]) / span
    return cos[i].lerp(cos[(i + 1) % n], max(0.0, min(1.0, f)))


def _taubin_closed(cos, iterations, lam=0.5, mu=-0.53):
    """Smooth a closed curve without shrinking it (an oval stays an oval)."""
    pts = [c.copy() for c in cos]
    n = len(pts)
    for _ in range(iterations):
        for factor in (lam, mu):
            old = [p.copy() for p in pts]
            for i in range(n):
                avg = (old[i - 1] + old[(i + 1) % n]) * 0.5
                pts[i] = old[i] + (avg - old[i]) * factor
    return pts


def _dense_closed(cos, steps=6):
    """Catmull-Rom densification of a closed curve (keeps it fluid when resampling)."""
    n = len(cos)
    out = []
    for i in range(n):
        p0, p1, p2, p3 = cos[i - 1], cos[i], cos[(i + 1) % n], cos[(i + 2) % n]
        for k in range(steps):
            t = k / steps
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
                              + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    return out


def _nearest_param(cos, point):
    params, _ = _closed_params(cos)
    best, best_t = None, 0.0
    n = len(cos)
    for i in range(n):
        a, b = cos[i], cos[(i + 1) % n]
        ab = b - a
        L = ab.length_squared
        f = 0.0 if L <= 1e-18 else max(0.0, min(1.0, (point - a).dot(ab) / L))
        d = (a + ab * f - point).length
        if best is None or d < best:
            best = d
            best_t = params[i] + (params[i + 1] - params[i]) * f
    return best_t


def _loop_edges(bm, loop):
    n = len(loop)
    return [bm.edges.get((loop[i], loop[(i + 1) % n])) for i in range(n)]


def _zipper(bm, A, B, mat, smooth):
    """Join loop A (outer side) to loop B (reversed inner) with quads, plus triangles
    only where the vertex counts differ."""
    n, m = len(A), len(B)
    faces = []
    tris = 0
    i = j = 0
    tol = 0.5 / max(n, m)
    while i < n or j < m:
        a_next = (i + 1) / n if i < n else 2.0
        b_next = (j + 1) / m if j < m else 2.0
        if i < n and j < m and abs(a_next - b_next) < tol:
            verts = (A[i % n], A[(i + 1) % n], B[(j + 1) % m], B[j % m])
            i += 1
            j += 1
        elif a_next < b_next:
            verts = (A[i % n], A[(i + 1) % n], B[j % m])
            i += 1
        else:
            verts = (A[i % n], B[(j + 1) % m], B[j % m])
            j += 1
        if len(set(verts)) < len(verts):
            continue
        try:
            f = bm.faces.new(verts)
        except ValueError:
            continue
        f.material_index = mat
        f.smooth = smooth
        faces.append(f)
        if len(verts) == 3:
            tris += 1
    return faces, tris


def _quad_zipper(bm, A, B, surface, mat, smooth):
    """Join loop A to reversed loop B using quads only where possible.

    Every 2 extra vertices are absorbed by one 4-to-2 transition (one new pole
    vertex, 4 quads). An odd difference leaves a single triangle.
    Returns (faces, triangle_count, new_pole_verts).
    """
    n, m = len(A), len(B)
    if n == m:
        faces, tris = _zipper(bm, A, B, mat, smooth)
        return faces, tris, []
    flipped = m > n
    if flipped:
        # Same orientation rules with the roles swapped, index 0 kept aligned.
        A, B = [B[0]] + B[:0:-1], [A[0]] + A[:0:-1]
        n, m = m, n
    d = n - m
    units = d // 2
    odd = d % 2
    # Steps: units (4 A-edges, 2 B-edges), plain quads (1, 1), one triangle (1, 0).
    plain = m - 2 * units
    if plain < 0:
        faces, tris = _zipper(bm, A, B, mat, smooth)
        return faces, tris, []
    steps = ['U'] * units + ['T'] * odd
    total = len(steps) + plain
    seq = []
    # Spread the transitions evenly between the plain quads.
    acc = 0.0
    special = len(steps)
    for k in range(total):
        acc += special / total
        if acc >= 1.0 - 1e-9 and steps:
            seq.append(steps.pop())
            acc -= 1.0
        else:
            seq.append('Q')
    seq += steps  # safety: anything left over

    faces, poles = [], []
    tris = 0
    i = j = 0

    def a(k):
        return A[k % n]

    def b(k):
        return B[k % m]

    def add(verts):
        try:
            f = bm.faces.new(verts)
        except ValueError:
            return
        f.material_index = mat
        f.smooth = smooth
        faces.append(f)

    for step in seq:
        if step == 'Q':
            add((a(i), a(i + 1), b(j + 1), b(j)))
            i += 1
            j += 1
        elif step == 'T':
            add((a(i), a(i + 1), b(j)))
            tris += 1
            i += 1
        else:
            co = (a(i + 2).co + b(j + 1).co) * 0.5
            P = bm.verts.new(surface.nearest(co)[0])
            poles.append(P)
            add((a(i), a(i + 1), P, b(j)))
            add((a(i + 1), a(i + 2), a(i + 3), P))
            add((a(i + 3), a(i + 4), b(j + 2), P))
            add((b(j), P, b(j + 2), b(j + 1)))
            i += 4
            j += 2
    return faces, tris, poles


def _euler(comp):
    verts = {v for f in comp for v in f.verts}
    edges = {e for f in comp for e in f.edges}
    return len(verts) - len(edges) + len(comp)


def _normal_coherence(comp):
    n = Vector()
    area = 0.0
    for f in comp:
        a = f.calc_area()
        n += f.normal * a
        area += a
    if area <= 0 or n.length < 1e-12:
        return 0.0
    n.normalize()
    return sum(f.normal.dot(n) * f.calc_area() for f in comp) / area


def _is_patch(comp, loops):
    """A redrawable patch: a disk (one border) or a ring (two borders), without
    handles/tunnels, and (for a disk) not folding back over itself."""
    if _euler(comp) != 2 - len(loops):
        return False
    if len(loops) == 1 and _normal_coherence(comp) < 0.2:
        return False
    return True


def _is_band(comp, loops):
    """True when the faces form a band between the two borders (a ring around an
    opening), not a large area that merely has two borders."""
    l0, l1 = loops

    def perim(loop):
        return sum((loop[(i + 1) % len(loop)].co - loop[i].co).length for i in range(len(loop)))

    inner_cos = [v.co for v in l1]
    gaps = []
    for v in l0:
        gaps.append(min((v.co - c).length for c in inner_cos))
    gap = sum(gaps) / len(gaps)
    band_area = 0.5 * (perim(l0) + perim(l1)) * gap
    area = sum(f.calc_area() for f in comp)
    return band_area > 0 and area <= band_area * 2.5


def _redraw_opening(bm, comp, loops, surface, settings, axes, mat, smooth):
    """Rebuild a ring of faces around an opening: smooth contour + concentric loops."""
    l0, l1 = loops

    def is_free(loop):
        return all(e is not None and len(e.link_faces) == 1 for e in _loop_edges(bm, loop))

    def perimeter(loop):
        return sum((loop[(i + 1) % len(loop)].co - loop[i].co).length for i in range(len(loop)))

    free0, free1 = is_free(l0), is_free(l1)
    if free0 != free1:
        inner, outer = (l0, l1) if free0 else (l1, l0)
    else:
        outer, inner = (l0, l1) if perimeter(l0) >= perimeter(l1) else (l1, l0)
    inner_free = is_free(inner)

    # Start the outer loop on the mirror plane when symmetry is on (symmetric sampling).
    if axes:
        ax = axes[0]
        k0 = min(range(len(outer)), key=lambda i: abs(outer[i].co[ax]))
        outer = outer[k0:] + outer[:k0]
    n = len(outer)
    O = outer
    o_cos = [v.co.copy() for v in O]
    edge_len = sum((o_cos[(i + 1) % n] - o_cos[i]).length for i in range(n)) / n

    # 1) Smooth the opening contour (Taubin: no shrinking, oval stays oval).
    in_cos = [v.co.copy() for v in inner]
    iters = int(round((settings.opening_smooth ** 1.3) * 160))
    smooth_cos = _taubin_closed(in_cos, iters) if iters else in_cos
    m = n if inner_free else len(inner)
    if inner_free or settings.even_opening:
        dense = _dense_closed(smooth_cos)
        if inner_free:
            # Inner order runs opposite to the outer one; start next to O[0].
            t0 = _nearest_param(dense, o_cos[0])
        else:
            t0 = _nearest_param(dense, smooth_cos[0])
        new_in = [_sample_closed(dense, t0 + i / m) for i in range(m)]
    else:
        new_in = smooth_cos
    new_in = [surface.nearest(c)[0] for c in new_in]

    # 2) Remove the old faces, keep the outer border (and an attached inner border).
    keep = set(O) | (set() if inner_free else set(inner))
    keep_edges = set(e for e in _loop_edges(bm, O) if e is not None)
    if not inner_free:
        keep_edges |= set(e for e in _loop_edges(bm, inner) if e is not None)
    comp_edges = {e for f in comp for e in f.edges}
    comp_verts = {v for f in comp for v in f.verts}
    bmesh.ops.delete(bm, geom=list(comp), context='FACES_ONLY')
    dead_e = [e for e in comp_edges if e.is_valid and not e.link_faces and e not in keep_edges]
    if dead_e:
        bmesh.ops.delete(bm, geom=dead_e, context='EDGES')
    dead_v = [v for v in comp_verts if v.is_valid and v not in keep and not v.link_edges]
    if dead_v:
        bmesh.ops.delete(bm, geom=dead_v, context='VERTS')

    if inner_free:
        I = [bm.verts.new(c) for c in new_in]
    else:
        I = list(inner)
        for v, c in zip(I, new_in):
            v.co = c
    moved_inner = list(I)

    # 3) Align the reversed inner loop with the outer loop.
    Ir = list(reversed(I))
    if len(Ir) == n:
        best = min(range(n), key=lambda off: sum((o_cos[i] - Ir[(i + off) % n].co).length_squared
                                                  for i in range(n)))
    else:
        best = min(range(len(Ir)), key=lambda j: (Ir[j].co - o_cos[0]).length)
    Ir = Ir[best:] + Ir[:best]

    ir_cos = [v.co.copy() for v in Ir]
    if len(Ir) == n:
        targets = ir_cos
    else:
        o_params, _ = _closed_params(o_cos)
        targets = [_sample_closed(ir_cos, o_params[i]) for i in range(n)]

    gap = sum((o_cos[i] - targets[i]).length for i in range(n)) / n
    rings = settings.opening_loops - 1 if settings.opening_loops > 0 else \
        max(0, min(29, int(round(gap / max(edge_len, 1e-9))) - 1))

    # 4) Concentric loops, then the last join.
    faces = []
    movable = []
    prev = O
    for r in range(1, rings + 1):
        t = r / (rings + 1)
        cur = [bm.verts.new(surface.nearest(o_cos[i].lerp(targets[i], t))[0]) for i in range(n)]
        for i in range(n):
            j = (i + 1) % n
            try:
                f = bm.faces.new((prev[i], prev[j], cur[j], cur[i]))
                f.material_index = mat
                f.smooth = smooth
                faces.append(f)
            except ValueError:
                pass
        movable += cur
        prev = cur
    last, tris, poles = _quad_zipper(bm, prev, Ir, surface, mat, smooth)
    movable += poles
    faces += last

    _relax(movable, surface, settings.smooth_iterations, settings.smooth_strength,
           settings.project_surface)
    return faces, movable + moved_inner, tris


MIRROR_MOD_NAME = "Drimah Mirror"


def _cut_half(bm, axes, sign, tol):
    """Keep only the chosen side (cut at the plane) for a live Mirror modifier."""
    for ax in axes:
        no = Vector((0.0, 0.0, 0.0))
        no[ax] = 1.0
        geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
        bmesh.ops.bisect_plane(bm, geom=geom, dist=max(tol, 1e-6), plane_co=Vector((0.0, 0.0, 0.0)),
                               plane_no=no, clear_inner=sign > 0, clear_outer=sign < 0)
        for v in bm.verts:
            if abs(v.co[ax]) <= max(tol, 1e-6):
                v.co[ax] = 0.0
    bm.normal_update()


def _setup_mirror_modifier(obj, axes, tol):
    mod = obj.modifiers.get(MIRROR_MOD_NAME)
    if mod is None or mod.type != 'MIRROR':
        mod = obj.modifiers.new(MIRROR_MOD_NAME, 'MIRROR')
        try:
            obj.modifiers.move(len(obj.modifiers) - 1, 0)  # first in the stack
        except (AttributeError, RuntimeError, TypeError):
            pass
    mod.use_axis = [i in axes for i in range(3)]
    mod.use_bisect_axis = [False, False, False]
    mod.use_mirror_merge = True
    mod.merge_threshold = max(tol, 1e-6)
    mod.use_clip = True
    mod.show_viewport = True
    mod.show_render = True
    mod.show_in_editmode = True
    mod.show_on_cage = False
    return mod


def _symmetrize_whole(bm, axes, sign, tol, reselect=False):
    """Make the entire mesh symmetric: the chosen side replaces the other one."""
    names = {0: 'X', 1: 'Y', 2: 'Z'}
    keep = [f.calc_center_median() for f in bm.faces if f.select] if reselect else []
    for ax in axes:
        direction = names[ax] if sign > 0 else '-' + names[ax]
        bmesh.ops.symmetrize(bm, input=bm.verts[:] + bm.edges[:] + bm.faces[:],
                             direction=direction, dist=max(tol, 1e-6))
    bm.normal_update()
    for f in bm.faces:
        f.select_set(False)
    if keep:
        # Select the redrawn faces on both sides.
        kd = KDTree(len(keep))
        for i, c in enumerate(keep):
            kd.insert(c, i)
        kd.balance()
        reach = max(tol * 10, 1e-4)
        for f in bm.faces:
            c = f.calc_center_median()
            m = c.copy()
            for ax in axes:
                m[ax] = -m[ax]
            if kd.find(c)[2] <= reach or kd.find(m)[2] <= reach:
                f.select_set(True)


def _symmetrize_verts(verts, axes, sign, edge_len):
    """Make the new vertices of a whole (not split) region exactly symmetric."""
    verts = [v for v in verts if v.is_valid]
    if not verts:
        return
    reach = edge_len * 0.5
    for ax in axes:
        kd = KDTree(len(verts))
        for i, v in enumerate(verts):
            kd.insert(v.co, i)
        kd.balance()
        for v in verts:
            if abs(v.co[ax]) < reach * 0.25:
                v.co[ax] = 0.0
        for v in verts:
            if v.co[ax] * sign <= 0:
                continue
            target = _mirror_co(v.co, ax)
            co, idx, dist = kd.find(target)
            if idx is not None and dist < reach and verts[idx] is not v and verts[idx].co[ax] * sign < 0:
                verts[idx].co = target


# ---------------------------------------------------------------------------
# Symmetry
# ---------------------------------------------------------------------------

def _mirror_axes(settings):
    axis = settings.symmetry_axis
    return [AXES[axis]] if axis in AXES else []


def _axis_combos(axes):
    combos = []
    for mask in range(1, 1 << len(axes)):
        combos.append([axes[i] for i in range(len(axes)) if mask & (1 << i)])
    return combos


def _expand_symmetric(bm, faces, axes, tol):
    """Add the mirrored counterpart of every selected face (when it exists)."""
    if not axes:
        return set(faces), 0
    kd = KDTree(len(bm.faces))
    flist = list(bm.faces)
    for i, f in enumerate(flist):
        kd.insert(f.calc_center_median(), i)
    kd.balance()
    result = set(faces)
    missing = 0
    for f in faces:
        c = f.calc_center_median()
        for combo in _axis_combos(axes):
            m = c.copy()
            for ax in combo:
                m[ax] = -m[ax]
            co, idx, dist = kd.find(m)
            if idx is not None and dist <= tol:
                result.add(flist[idx])
            else:
                missing += 1
    return result, missing


def _on_source_side(co, axes, sign, eps):
    return all(co[ax] * sign >= -eps for ax in axes)


def _straddles(f, axes, eps):
    for ax in axes:
        lo = min(v.co[ax] for v in f.verts)
        hi = max(v.co[ax] for v in f.verts)
        if lo < -eps and hi > eps:
            return True
    return False


def _cut_at_plane(bm, selected, axes, eps):
    """Bisect the faces that cross the mirror plane; returns the new selection."""
    bm.faces.index_update()
    sel_idx = {f.index for f in selected}
    # Adding a layer invalidates Python face references: go through indices.
    layer = bm.faces.layers.int.get("dmt_redraw_sel") or bm.faces.layers.int.new("dmt_redraw_sel")
    bm.faces.ensure_lookup_table()
    for i, f in enumerate(bm.faces):
        f[layer] = 1 if i in sel_idx else 0
    for ax in axes:
        crossing = [f for f in bm.faces if _straddles(f, [ax], eps)]
        if not crossing:
            continue
        geom = list({e for f in crossing for e in f.edges}) + crossing + \
            list({v for f in crossing for v in f.verts})
        no = Vector((0.0, 0.0, 0.0))
        no[ax] = 1.0
        bmesh.ops.bisect_plane(bm, geom=geom, dist=eps, plane_co=Vector((0.0, 0.0, 0.0)), plane_no=no)
        for v in bm.verts:
            if abs(v.co[ax]) <= eps:
                v.co[ax] = 0.0
    bm.faces.ensure_lookup_table()
    new_idx = [i for i, f in enumerate(bm.faces) if f[layer] == 1]
    bm.faces.ensure_lookup_table()  # the layer is removed at the end (redraw_bmesh)
    for f in bm.faces:
        f.select_set(False)
    new_sel = [bm.faces[i] for i in new_idx]
    for f in new_sel:
        f.select_set(True)
    return new_sel


def _check_no_straddle(faces, axes, eps):
    for f in faces:
        for ax in axes:
            lo = min(v.co[ax] for v in f.verts)
            hi = max(v.co[ax] for v in f.verts)
            if lo < -eps and hi > eps:
                raise RedrawError(
                    "Symmetry needs a center edge loop: a selected face crosses the mirror plane "
                    "({}).".format("XYZ"[ax]))


def _mirror_result(bm, result_faces, axis, tol, eps):
    """Mirror result faces across one axis, welding to existing border verts."""
    result_set = set(result_faces)
    result_verts = {v for f in result_faces for v in f.verts}
    others = [v for v in bm.verts if v not in result_verts]
    kd = KDTree(max(1, len(others)))
    for i, v in enumerate(others):
        kd.insert(v.co, i)
    kd.balance()

    vmap = {}
    unmatched = 0
    for v in result_verts:
        if abs(v.co[axis]) <= eps:
            vmap[v] = v
            continue
        target = _mirror_co(v.co, axis)
        hit = None
        if others and v.link_faces and any(f not in result_set for f in v.link_faces):
            # Border vertex: weld to the existing vertex on the other side.
            co, idx, dist = kd.find(target)
            if idx is not None and dist <= tol:
                hit = others[idx]
            else:
                unmatched += 1
        vmap[v] = hit if hit is not None else bm.verts.new(target)

    created = []
    for f in result_faces:
        verts = [vmap[v] for v in reversed(list(f.verts))]
        if len(set(verts)) < 3:
            continue
        try:
            g = bm.faces.new(verts)
        except ValueError:
            continue
        g.material_index = f.material_index
        g.smooth = f.smooth
        created.append(g)
    return created, unmatched


# ---------------------------------------------------------------------------
# Main operation
# ---------------------------------------------------------------------------

def mirror_center_value(obj, bm, settings, cursor_world=None):
    """Local coordinate of the mirror plane along the symmetry axis."""
    axes = _mirror_axes(settings)
    if not axes or settings.mirror_center == 'ORIGIN' or not bm.verts:
        return 0.0
    ax = axes[0]
    if settings.mirror_center == 'CURSOR':
        if cursor_world is None:
            return 0.0
        return (obj.matrix_world.inverted() @ cursor_world)[ax]
    # AUTO. An existing Drimah Mirror modifier already defines the plane (origin).
    mod = obj.modifiers.get(MIRROR_MOD_NAME) if obj is not None else None
    if mod is not None and mod.type == 'MIRROR' and mod.use_axis[ax]:
        return 0.0
    vals = [v.co[ax] for v in bm.verts]
    lo, hi = min(vals), max(vals)
    size = hi - lo
    if size <= 1e-9:
        return lo
    eps = max(size * 1e-4, 1e-6)
    boundary = {v for e in bm.edges if len(e.link_faces) == 1 for v in e.verts}
    at_lo = sum(1 for v in boundary if v.co[ax] - lo <= eps)
    at_hi = sum(1 for v in boundary if hi - v.co[ax] <= eps)
    # A half model: flat open border on one side only -> that side is the plane.
    if at_lo >= 3 and at_hi == 0:
        return 0.0 if abs(lo) <= size * 1e-5 else lo
    if at_hi >= 3 and at_lo == 0:
        return 0.0 if abs(hi) <= size * 1e-5 else hi
    c = (lo + hi) * 0.5
    # Already centered (within float noise): keep the plane exactly at the origin.
    return 0.0 if abs(c) <= size * 1e-5 else c


def redraw_bmesh(bm, settings, center=0.0):
    """Redraw with the mirror plane at `center` (local coordinate on the axis)."""
    axes = _mirror_axes(settings)
    shift = bool(axes) and abs(center) >= 1e-12
    ax = axes[0] if axes else 0
    faces_before = len(bm.faces)
    if shift:
        for v in bm.verts:
            v.co[ax] -= center
    try:
        stats = _redraw_core(bm, settings)
    finally:
        if shift:
            for v in bm.verts:
                if v.is_valid:
                    v.co[ax] += center
        for name in (WHOLE_LAYER, "dmt_redraw_sel"):
            layer = bm.faces.layers.int.get(name)
            if layer is not None:
                bm.faces.layers.int.remove(layer)
    if faces_before and not bm.faces:
        raise RedrawError("Cancelled: the result would be empty. Nothing was changed.")
    stats["center"] = center
    return stats


WHOLE_LAYER = "dmt_redraw_whole"


def _mark_whole_parts(bm):
    """Tag the faces of selected parts that are not patches (closed parts, parts
    with handles...). They are never redrawn, only mirrored, even after a cut.
    The tag is a face layer, so it survives face splits."""
    layer = bm.faces.layers.int.get(WHOLE_LAYER) or bm.faces.layers.int.new(WHOLE_LAYER)
    bm.faces.ensure_lookup_table()
    selected = [f for f in bm.faces if f.select]
    for f in bm.faces:
        f[layer] = 0
    for comp in _components(selected):
        try:
            loops = _border_loops(comp)
        except RedrawError:
            loops = None
        whole = loops is None or len(loops) == 0 or len(loops) > 2 or not _is_patch(comp, loops)
        if whole:
            for f in comp:
                f[layer] = 1
    return layer


def _redraw_core(bm, settings):
    """Redraw the selected faces of bm. Returns a stats dict; raises RedrawError."""
    whole_layer = _mark_whole_parts(bm)
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    selected = [f for f in bm.faces if f.select]
    axes = _mirror_axes(settings)
    sign = 1.0 if settings.mirror_side == 'POSITIVE' else -1.0
    tol = settings.mirror_tolerance
    eps = max(tol * 0.5, 1e-7)
    use_modifier = bool(axes) and settings.mirror_result == 'MODIFIER'
    whole = bool(axes) and (settings.symmetry_scope == 'WHOLE' or use_modifier)

    if not selected:
        if whole:
            before = len(bm.faces)
            if use_modifier:
                _cut_half(bm, axes, sign, tol)
            else:
                _symmetrize_whole(bm, axes, sign, tol)
            for f in bm.faces:
                f.select_set(False)
            return {"regions": 0, "faces_removed": 0, "faces_created": 0, "triangles": 0,
                    "skipped": 0, "mirrored": 0, "unwelded": 0, "missing_mirror": 0,
                    "openings": 0, "whole": True, "modifier": use_modifier,
                    "faces_before": before, "faces_after": len(bm.faces)}
        raise RedrawError("Select the faces to redraw (Edit Mode, face selection).")

    whole_axes = list(axes)
    if whole:
        # The other side is replaced by the whole-model symmetrize at the end, so
        # only the source side (and faces across the plane) needs to be redrawn.
        # A selection made on the other side counts too (its mirror twin is used).
        selected = list(_expand_symmetric(bm, selected, axes, tol)[0])
        selected = [f for f in selected
                    if any(v.co[ax] * sign > eps for v in f.verts for ax in axes)
                    or all(abs(v.co[ax]) <= eps for v in f.verts for ax in axes)]
        axes = []
        if not selected:
            raise RedrawError("The selection is only on the other side and the model is not symmetric there: "
                              "select the faces on the chosen side, or switch Side + / Side -.")

    # Selection across the mirror plane without a center edge loop: cut the mesh
    # at the plane first (only faces that cross it are split), then use the half.
    cut_center = False
    if axes and any(_straddles(f, axes, eps) for f in selected):
        selected = _cut_at_plane(bm, selected, axes, eps)
        whole_layer = bm.faces.layers.int.get(WHOLE_LAYER)
        cut_center = True

    region, missing_mirror = _expand_symmetric(bm, selected, axes, tol)

    # Rings of faces around an opening (two borders) are handled whole.
    openings = []
    skipped_big = 0
    rest = set(region)
    for comp in _components(region):
        try:
            loops = _border_loops(comp)
        except RedrawError:
            continue
        if len(loops) == 2 and min(len(l) for l in loops) >= 3:
            if _is_patch(comp, loops) and _is_band(comp, loops) \
                    and not any(f[whole_layer] for f in comp):
                openings.append((comp, loops))
                rest -= set(comp)

    # With symmetry: an opening fully on the mirror side is dropped (rebuilt by
    # mirroring its source-side twin); openings across the plane are done whole.
    mirrored_openings = []
    dest_openings = []
    if axes and openings:
        def side(comp):
            cs = [f.calc_center_median() for f in comp]
            if all(_on_source_side(c, axes, sign, eps) for c in cs):
                return 1
            if all(not _on_source_side(c, axes, sign, -eps) for c in cs):
                return -1
            return 0
        src_kd_items = [(comp, loops) for comp, loops in openings if side(comp) == 1]
        centers = KDTree(max(1, len(src_kd_items)))
        for i, (comp, _) in enumerate(src_kd_items):
            centers.insert(sum((f.calc_center_median() for f in comp), Vector()) / len(comp), i)
        centers.balance()
        kept = []
        for comp, loops in openings:
            sd = side(comp)
            if sd == -1 and src_kd_items:
                c = sum((f.calc_center_median() for f in comp), Vector()) / len(comp)
                for ax in axes:
                    if c[ax] * sign < 0:
                        c[ax] = -c[ax]
                _, idx, dist = centers.find(c)
                if idx is not None and dist <= max(tol * 10, 1e-4):
                    dest_openings.append(comp)
                    continue
            if sd == 1:
                mirrored_openings.append((comp, loops))
            else:
                kept.append((comp, loops))
        openings = kept

    if axes and rest:
        _check_no_straddle(rest, axes, eps)
        source = [f for f in rest if _on_source_side(f.calc_center_median(), axes, sign, eps)]
        src_set = set(source)
        dest = [f for f in rest if f not in src_set]
    else:
        source = list(rest)
        dest = []
    if not source and not openings and not mirrored_openings:
        raise RedrawError("No selected faces on the symmetry source side.")
    if len(region) == len(bm.faces) and not dest:
        # Whole closed mesh selected: there is no border to keep.
        if not any(len(e.link_faces) == 1 for e in bm.edges):
            raise RedrawError("The whole closed mesh is selected; select a region with a border.")

    stats = {"regions": 0, "faces_removed": 0, "faces_created": 0, "triangles": 0,
             "skipped": 0, "mirrored": 0, "unwelded": 0, "missing_mirror": missing_mirror}

    # Validate every source region BEFORE changing anything, so a skipped region
    # never leaves a hole on the mirror side.
    jobs = []
    keep_as_is = []  # cannot be redrawn, but still mirrored when symmetry is on
    keep_dest = []
    twin_count = None
    for comp in _components(source):
        try:
            loops = _border_loops(comp)
        except RedrawError:
            loops = []
        if len(comp) < 2:
            # A single face cannot be improved by a redraw: keep it as it is.
            if axes:
                keep_as_is.append(comp)
            continue
        if len(loops) != 1 or len(loops[0]) < 3 or not _is_patch(comp, loops) \
                or any(f[whole_layer] for f in comp):
            # Closed parts, areas with several borders, parts with handles/tunnels
            # (a steering wheel, a hollow backrest) or wrapped-around areas are not redrawn.
            stats["skipped"] += 1
            if axes:
                keep_as_is.append(comp)
            continue
        jobs.append((comp, loops[0]))
    stats["kept"] = sum(len(c) for c in keep_as_is)
    nothing = not jobs and not openings and not mirrored_openings and not keep_as_is
    if nothing and whole:
        # Nothing redrawable: still make the model symmetric / add the modifier.
        stats["mirror_only"] = True
        stats["modifier"] = use_modifier
        stats["whole"] = True
        if use_modifier:
            _cut_half(bm, whole_axes, sign, tol)
        else:
            _symmetrize_whole(bm, whole_axes, sign, tol)
        for f in bm.faces:
            f.select_set(False)
        return stats
    if nothing:
        raise RedrawError("Nothing to redraw: the selection is a whole part (closed, with handles, or several borders). "
                          "Select a patch of faces (one border, or a ring around an opening).")

    twin_count = [0] * len(jobs)
    if dest and not jobs and not keep_as_is:
        dest = []
    if dest:
        # Keep only mirror faces whose source counterpart is being redrawn (or kept).
        valid_src = [f for comp, _ in jobs for f in comp] + [f for comp in keep_as_is for f in comp]
        job_of = [j for j, (comp, _) in enumerate(jobs) for _f in comp]
        n_jobs = len(job_of)
        kd = KDTree(len(valid_src))
        for i, f in enumerate(valid_src):
            kd.insert(f.calc_center_median(), i)
        kd.balance()
        kept = []
        for f in dest:
            c = f.calc_center_median()
            for ax in axes:
                if c[ax] * sign < -eps:
                    c[ax] = -c[ax]
            _, idx, dist = kd.find(c)
            if idx is not None and dist <= tol and idx < n_jobs:
                kept.append(f)
                twin_count[job_of[idx]] += 1
            elif keep_as_is:
                # Selected faces on the other side that are not twins of a redrawn
                # patch: replaced by the symmetrize of the kept parts (works even when
                # the model is not exactly symmetric).
                keep_dest.append(f)
        dest = kept

    # Projection surface: the region plus one ring of neighbours, before changes.
    ring = set(region)
    for f in region:
        for v in f.verts:
            ring.update(v.link_faces)
    surface = _Surface(ring)

    # Remove the mirror side first (its border verts stay, used later for welding).
    for comp in dest_openings:
        dest += comp
    if dest:
        dest_edges = {e for f in dest for e in f.edges}
        dest_verts = {v for f in dest for v in f.verts}
        bmesh.ops.delete(bm, geom=list(dest), context='FACES_ONLY')
        stats["faces_removed"] += len(dest)
        loose_e = [e for e in dest_edges if e.is_valid and not e.link_faces]
        if loose_e:
            bmesh.ops.delete(bm, geom=loose_e, context='EDGES')
        loose_v = [v for v in dest_verts if v.is_valid and not v.link_edges]
        if loose_v:
            bmesh.ops.delete(bm, geom=loose_v, context='VERTS')

    result_faces = []
    opening_faces = []
    stats["openings"] = 0

    for comp, loops in mirrored_openings:
        mat = comp[0].material_index
        smooth = comp[0].smooth
        faces, moved, tris = _redraw_opening(bm, comp, loops, surface, settings, [], mat, smooth)
        stats["faces_removed"] += len(comp)
        stats["triangles"] += tris
        stats["openings"] += 1
        stats["regions"] += 1
        result_faces += faces  # mirrored below like the other source-side faces

    for comp, loops in openings:
        mat = comp[0].material_index
        smooth = comp[0].smooth
        faces, moved, tris = _redraw_opening(bm, comp, loops, surface, settings, axes, mat, smooth)
        stats["faces_removed"] += len(comp)
        stats["triangles"] += tris
        stats["openings"] += 1
        stats["regions"] += 1
        if axes:
            el = sum(e.calc_length() for f in faces for e in f.edges) / max(1, sum(len(f.edges) for f in faces))
            _symmetrize_verts(moved, axes, sign, el)
        # Opening faces are already complete on both sides: never mirrored again.
        opening_faces += faces

    # A patch is mirrored only when the other side matches it (its twin faces were
    # found). Otherwise the mirrored copy would float over different geometry.
    mirror_job = []
    for j, (comp, loop) in enumerate(jobs):
        mirror_job.append(bool(axes) and twin_count[j] >= 0.9 * len(comp))
    unmirrored_faces = []
    stats["not_mirrored"] = sum(1 for m in mirror_job if axes and not m)

    for j, (comp, loop) in enumerate(jobs):
        mat = comp[0].material_index
        smooth = comp[0].smooth
        border = set(loop)

        comp_edges = {e for f in comp for e in f.edges}
        comp_verts = {v for f in comp for v in f.verts}
        bmesh.ops.delete(bm, geom=list(comp), context='FACES_ONLY')
        inner_e = [e for e in comp_edges if e.is_valid and not e.link_faces
                   and not (e.verts[0] in border and e.verts[1] in border and _is_loop_edge(e, loop))]
        if inner_e:
            bmesh.ops.delete(bm, geom=inner_e, context='EDGES')
        inner_v = [v for v in comp_verts if v.is_valid and v not in border and not v.link_edges]
        if inner_v:
            bmesh.ops.delete(bm, geom=inner_v, context='VERTS')
        stats["faces_removed"] += len(comp)

        new_faces = []
        movable = []
        cur = loop
        # Rings need room; small loops go straight to the grid.
        rings = settings.border_loops if len(loop) >= 8 else 0
        for _ in range(rings):
            cur, faces = _grow_ring(bm, cur, surface, settings.border_width, mat, smooth)
            new_faces += faces
            movable += cur
        if len(cur) % 2 == 1:
            cur, faces = _cap_odd(bm, cur, mat, smooth)
            new_faces += faces
            stats["triangles"] += len(faces)
        if len(cur) == 3:
            try:
                f = bm.faces.new(cur)
                f.material_index = mat
                f.smooth = smooth
                new_faces.append(f)
                stats["triangles"] += 1
            except ValueError:
                pass
        elif len(cur) >= 4:
            verts, faces = _grid_fill(bm, cur, settings.corner_offset, mat, smooth)
            new_faces += faces
            movable += verts

        _relax(movable, surface, settings.smooth_iterations, settings.smooth_strength,
               settings.project_surface)
        if axes and not mirror_job[j]:
            unmirrored_faces += new_faces
        else:
            result_faces += new_faces
        stats["regions"] += 1

    if stats["regions"] == 0 and not keep_as_is:
        raise RedrawError("Nothing to redraw: the selection is a whole part (closed, with handles, or several borders). "
                          "Select a patch of faces (one border, or a ring around an opening).")

    # Parts that could not be redrawn are mirrored unchanged (Blender's symmetrize,
    # limited to those parts and their twins on the other side).
    kept_faces = [f for comp in keep_as_is for f in comp if f.is_valid]

    # Symmetry: mirror the redrawn source side across each enabled axis.
    for ax in axes:
        created, unmatched = _mirror_result(bm, result_faces, ax, tol, eps)
        stats["mirrored"] += len(created)
        stats["unwelded"] += unmatched
        result_faces += created

    if kept_faces:
        part = kept_faces + [f for f in keep_dest if f.is_valid]
        geom = list({v for f in part for v in f.verts}) + list({e for f in part for e in f.edges}) + part
        before = len(bm.faces)
        names = {0: 'X', 1: 'Y', 2: 'Z'}
        for ax in axes:
            bmesh.ops.symmetrize(bm, input=geom, direction=(names[ax] if sign > 0 else '-' + names[ax]),
                                 dist=max(tol, 1e-6))
        stats["mirrored"] += max(0, len(bm.faces) - before + len(keep_dest))
    result_faces = [f for f in result_faces if f.is_valid]
    result_faces += [f for f in unmirrored_faces if f.is_valid]
    result_faces += opening_faces
    stats["faces_created"] = len(result_faces)
    stats["whole"] = whole
    stats["cut_center"] = cut_center
    if result_faces:
        bm.normal_update()
    for f in bm.faces:
        f.select_set(False)
    for e in bm.edges:
        e.select_set(False)
    for v in bm.verts:
        v.select_set(False)
    for f in result_faces:
        if f.is_valid:
            f.select_set(True)
    stats["modifier"] = use_modifier
    if use_modifier:
        _cut_half(bm, whole_axes, sign, tol)
    elif whole:
        _symmetrize_whole(bm, whole_axes, sign, tol, reselect=True)
    return stats


def _is_loop_edge(edge, loop):
    a, b = edge.verts
    try:
        i = loop.index(a)
    except ValueError:
        return False
    n = len(loop)
    return loop[(i + 1) % n] is b or loop[i - 1] is b


# ---------------------------------------------------------------------------
# Blender types
# ---------------------------------------------------------------------------

class DMT_REDRAW_Settings(PropertyGroup):
    preset: EnumProperty(name="Preset", items=_redraw_preset_items, update=_redraw_preset_update)
    border_loops: IntProperty(
        name="Border Loops",
        description="Quad rings grown inward from the selection border before the grid fill",
        default=1, min=0, max=4,
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of each border ring, relative to the border edge length",
        default=0.6, min=0.1, max=2.0, subtype='FACTOR',
    )
    corner_offset: IntProperty(
        name="Corner Offset",
        description="Rotate the grid corners along the border (0 = automatic)",
        default=0, min=-64, max=64,
    )
    smooth_iterations: IntProperty(
        name="Smooth Iterations",
        description="Relax passes applied to the new vertices",
        default=12, min=0, max=100,
    )
    smooth_strength: FloatProperty(
        name="Smooth Strength", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
    )
    project_surface: BoolProperty(
        name="Project to Surface",
        description="Keep the new vertices on the original surface",
        default=True,
    )
    keep_original: BoolProperty(
        name="Keep Original",
        description="Leave the original object untouched (hidden) and put the result in a new object",
        default=False,
    )
    symmetry_axis: EnumProperty(
        name="Symmetry",
        description="Mirror axis (object local space)",
        items=[('NONE', "None", "No symmetry"),
               ('X', "X", "Mirror across the local X axis"),
               ('Y', "Y", "Mirror across the local Y axis"),
               ('Z', "Z", "Mirror across the local Z axis")],
        default='NONE',
    )
    mirror_center: EnumProperty(
        name="Center",
        description="Where the mirror plane is",
        items=[('AUTO', "Auto Center", "Center of the model itself: no need to place it at zero "
                                       "(a half model uses its flat open side)"),
               ('ORIGIN', "Origin", "Object origin"),
               ('CURSOR', "3D Cursor", "3D cursor position")],
        default='AUTO',
    )
    mirror_result: EnumProperty(
        name="Result",
        description="How the mirrored side is created",
        items=[('WELD', "Weld", "Create the mirrored geometry and weld it at the center"),
               ('MODIFIER', "Mirror Modifier",
                "Keep only the chosen side and add a live Mirror modifier (can be turned off or applied later)")],
        default='WELD',
    )
    symmetry_scope: EnumProperty(
        name="Mirror",
        description="What is mirrored",
        items=[('SELECTED', "Selected", "Mirror only the redrawn selected faces"),
               ('WHOLE', "Whole Model", "Make the whole model symmetric from the chosen side")],
        default='SELECTED',
    )
    mirror_side: EnumProperty(
        name="Side",
        description="Which side is redrawn and copied to the other side",
        items=[('POSITIVE', "Side +", "Use the positive side and mirror it to the negative side"),
               ('NEGATIVE', "Side -", "Use the negative side and mirror it to the positive side")],
        default='POSITIVE',
    )
    opening_smooth: FloatProperty(
        name="Opening Smoothness",
        description="How much the contour of an opening is smoothed. Keeps its overall shape (an oval stays oval)",
        default=0.6, min=0.0, max=1.0, subtype='FACTOR',
    )
    opening_loops: IntProperty(
        name="Opening Loops",
        description="Loops between the outer border and the opening (0 = automatic, from the edge size)",
        default=0, min=0, max=30,
    )
    even_opening: BoolProperty(
        name="Even Opening",
        description="Space the vertices of the opening contour evenly along it",
        default=True,
    )
    mirror_tolerance: FloatProperty(
        name="Mirror Tolerance",
        description="Maximum distance to match mirrored faces and weld vertices on the mirror side",
        default=0.001, min=0.000001, max=0.1, precision=6, unit='LENGTH',
    )


class DMT_REDRAW_OT_redraw(Operator):
    bl_idname = "dmt_redraw.redraw"
    bl_label = "Redraw"
    bl_description = "Rebuild the selected faces as a clean quad patch connected to the rest of the mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        obj = context.active_object
        s = context.scene.dmt_redraw_settings
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')

        target = obj
        if s.keep_original:
            target = obj.copy()
            target.data = obj.data.copy()
            target.name = obj.name + "_Redraw"
            target.data.name = obj.data.name + "_Redraw"
            for coll in obj.users_collection:
                coll.objects.link(target)

        bm = bmesh.new()
        bm.from_mesh(target.data)
        center = mirror_center_value(target, bm, s, context.scene.cursor.location.copy())
        context.window_manager.progress_begin(0, 1)
        context.workspace.status_text_set("Processing... Redraw")
        try:
            stats = redraw_bmesh(bm, s, center)
            bm.to_mesh(target.data)
            target.data.update()
        except RedrawError as exc:
            bm.free()
            if target is not obj:
                bpy.data.meshes.remove(target.data)
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:
            bm.free()
            if target is not obj:
                bpy.data.meshes.remove(target.data)
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'ERROR'}, f"Redraw failed: {exc}")
            return {'CANCELLED'}
        finally:
            context.window_manager.progress_end()
            context.workspace.status_text_set(None)
        bm.free()
        removed_mod = False
        if stats.get("modifier"):
            if abs(center) > 1e-12:
                off = Vector((0.0, 0.0, 0.0))
                off[_mirror_axes(s)[0]] = center
                target.data.transform(Matrix.Translation(-off))
                target.data.update()
                target.matrix_world = target.matrix_world @ Matrix.Translation(off)
                stats["origin_moved"] = True
            _setup_mirror_modifier(target, _mirror_axes(s), s.mirror_tolerance)
        elif _mirror_axes(s):
            # Weld made the mirrored side real: a Drimah Mirror on the same axis would double it.
            mod = target.modifiers.get(MIRROR_MOD_NAME)
            if mod is not None and mod.type == 'MIRROR' and \
                    any(mod.use_axis[a] for a in _mirror_axes(s)):
                target.modifiers.remove(mod)
                removed_mod = True

        if target is not obj:
            for o in context.selected_objects:
                o.select_set(False)
            target.select_set(True)
            context.view_layer.objects.active = target
            obj.hide_set(True)
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')

        if stats.get("whole") and stats["regions"] == 0:
            msg = "Mirror modifier added (live)" if stats.get("modifier") else "Whole model mirrored"
            if stats.get("mirror_only"):
                msg += " (selection had nothing to redraw: whole parts are not redrawn)"
            if removed_mod:
                msg += "; Drimah Mirror modifier removed (the mirror is now real geometry)"
            if stats.get("origin_moved"):
                msg += "; object origin moved to the mirror center"
            self.report({'INFO'}, msg + (f". Result: {target.name} (original hidden)." if target is not obj else "."))
            return {'FINISHED'}
        if removed_mod:
            stats["removed_mod"] = True
        msg = f"Redraw: {stats['regions']} region(s), {stats['faces_removed']} faces replaced by {stats['faces_created']}"
        if stats.get("cut_center"):
            msg += ", center loop cut at the mirror plane"
        if stats.get("modifier"):
            msg += ", live Mirror modifier added"
        elif stats.get("whole"):
            msg += ", whole model mirrored"
        if stats.get("openings"):
            msg += f", {stats['openings']} opening(s) smoothed"
        if stats["mirrored"]:
            msg += f" ({stats['mirrored']} mirrored)"
        if stats["triangles"]:
            msg += f", {stats['triangles']} triangle(s) for an odd border"
        if stats["skipped"]:
            if stats.get("kept"):
                msg += f", {stats['kept']} faces kept as they were and mirrored (whole parts are not redrawn)"
            else:
                msg += f", {stats['skipped']} region(s) skipped (whole part, not a patch)"
        if stats["unwelded"]:
            msg += f", {stats['unwelded']} mirror vertices not welded (mesh not symmetric?)"
        if stats["missing_mirror"] and not stats.get("kept"):
            msg += f", {stats['missing_mirror']} faces without a mirror match"
        if target is not obj:
            msg += f". Result: {target.name} (original hidden)"
        if stats.get("origin_moved"):
            msg += "; object origin moved to the mirror center"
        if stats.get("not_mirrored"):
            msg += (f"; {stats['not_mirrored']} patch(es) NOT mirrored: the other side of the model is different "
                    "there (use Whole Model to make the model symmetric)")
        if stats.get("removed_mod"):
            msg += "; Drimah Mirror modifier removed (the mirror is now real geometry)"
        warn = stats["unwelded"] or stats.get("not_mirrored") or (stats["skipped"] and not stats.get("kept"))
        self.report({'WARNING'} if warn else {'INFO'}, msg + ".")
        return {'FINISHED'}


class DMT_REDRAW_OT_apply_mirror(Operator):
    bl_idname = "dmt_redraw.apply_mirror"
    bl_label = "Apply Mirror"
    bl_description = "Apply the Drimah Mirror modifier (the mirrored side becomes real, welded geometry)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.modifiers.get(MIRROR_MOD_NAME) is not None

    def execute(self, context):
        obj = context.active_object
        was_edit = context.mode == 'EDIT_MESH'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            with context.temp_override(object=obj, active_object=obj):
                bpy.ops.object.modifier_apply(modifier=MIRROR_MOD_NAME)
        except RuntimeError as exc:
            self.report({'ERROR'}, f"Could not apply: {exc}")
            return {'CANCELLED'}
        finally:
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "Mirror applied.")
        return {'FINISHED'}


class DMT_REDRAW_OT_remove_mirror(Operator):
    bl_idname = "dmt_redraw.remove_mirror"
    bl_label = "Remove Mirror"
    bl_description = "Remove the Drimah Mirror modifier (only the modeled side stays)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.modifiers.get(MIRROR_MOD_NAME) is not None

    def execute(self, context):
        obj = context.active_object
        obj.modifiers.remove(obj.modifiers[MIRROR_MOD_NAME])
        return {'FINISHED'}


class DMT_REDRAW_OT_save_preset(Operator):
    bl_idname = "dmt_redraw.save_preset"
    bl_label = "Save Preset"
    name: StringProperty(name="Preset Name", default="My Preset", maxlen=64)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        self.layout.prop(self, "name", text="")

    def execute(self, context):
        label = self.name.strip()
        if not label:
            self.report({'WARNING'}, "Enter a preset name.")
            return {'CANCELLED'}
        key = "CUSTOM_" + re.sub(r'[^A-Z0-9]+', '_', label.upper()).strip('_')[:40]
        s = context.scene.dmt_redraw_settings
        data = _load_redraw_custom()
        data[key] = {"label": label, **{p: getattr(s, p) for p in PRESET_PROPS}}
        try:
            _write_redraw_custom(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not save: {exc}")
            return {'CANCELLED'}
        s.preset = key
        self.report({'INFO'}, "Preset saved.")
        return {'FINISHED'}


class DMT_REDRAW_OT_delete_preset(Operator):
    bl_idname = "dmt_redraw.delete_preset"
    bl_label = "Delete Preset"

    @classmethod
    def poll(cls, context):
        return context.scene.dmt_redraw_settings.preset in _load_redraw_custom()

    def execute(self, context):
        s = context.scene.dmt_redraw_settings
        data = _load_redraw_custom()
        if s.preset not in data:
            return {'CANCELLED'}
        del data[s.preset]
        try:
            _write_redraw_custom(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not delete: {exc}")
            return {'CANCELLED'}
        s.preset = 'CLEAN'
        return {'FINISHED'}


class DMT_REDRAW_OT_export_presets(Operator):
    bl_idname = "dmt_redraw.export_presets"
    bl_label = "Export Presets"
    filepath: StringProperty(subtype='FILE_PATH')

    def invoke(self, context, event):
        self.filepath = os.path.join(os.path.expanduser("~"), "drimah_redraw_presets.json")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(_load_redraw_custom(), f, ensure_ascii=False, indent=2)
            return {'FINISHED'}
        except OSError as exc:
            self.report({'ERROR'}, f"Export failed: {exc}")
            return {'CANCELLED'}


class DMT_REDRAW_OT_import_presets(Operator):
    bl_idname = "dmt_redraw.import_presets"
    bl_label = "Import Presets"
    filepath: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                incoming = json.load(f)
            if not isinstance(incoming, dict):
                raise ValueError("Invalid preset file")
            existing = _load_redraw_custom()
            defaults = REDRAW_BUILTINS["CLEAN"]
            for key, value in incoming.items():
                if not isinstance(value, dict) or not isinstance(value.get("label"), str):
                    continue
                safe_key = re.sub(r'[^A-Z0-9_]+', '_', str(key).upper())[:48] or "IMPORTED"
                item = {"label": value["label"][:64]}
                value = _legacy_symmetry(value)
                for prop in PRESET_PROPS:
                    fallback = defaults.get(prop, {"keep_original": False, "mirror_side": 'POSITIVE', "symmetry_axis": 'NONE',
                                                   "symmetry_scope": 'SELECTED', "mirror_result": 'WELD',
                                                   "mirror_center": 'AUTO',
                                                   "mirror_tolerance": 0.001, "opening_smooth": 0.5,
                                                   "opening_loops": 0, "even_opening": True}.get(prop, False))
                    item[prop] = _clean_value(prop, value.get(prop, fallback), fallback)
                existing[safe_key] = item
            _write_redraw_custom(existing)
            _redraw_preset_items(None, None)
            return {'FINISHED'}
        except (OSError, ValueError, TypeError) as exc:
            self.report({'ERROR'}, f"Import failed: {exc}")
            return {'CANCELLED'}


class DMT_REDRAW_PT_panel(Panel):
    bl_label = "Redraw"
    bl_idname = "DMT_REDRAW_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drimah MeshTools"
    bl_parent_id = "DMT_PT_meshtools_root"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.dmt_redraw_settings

        layout.prop(s, "preset", text="Preset")
        layout.prop(s, "border_loops")
        layout.prop(s, "border_width", slider=True)
        layout.prop(s, "corner_offset")
        layout.prop(s, "smooth_iterations")
        layout.prop(s, "smooth_strength", slider=True)
        layout.prop(s, "project_surface")
        layout.prop(s, "keep_original")

        box = layout.box()
        box.label(text="Openings", icon='MESH_CIRCLE')
        box.prop(s, "opening_smooth", slider=True)
        box.prop(s, "opening_loops")
        box.prop(s, "even_opening")

        box = layout.box()
        box.label(text="Symmetry", icon='MOD_MIRROR')
        row = box.row(align=True)
        row.prop(s, "symmetry_axis", expand=True)
        row = box.row(align=True)
        row.enabled = s.symmetry_axis != 'NONE'
        row.prop(s, "mirror_result", expand=True)
        row = box.row(align=True)
        # The modifier always mirrors the whole object.
        row.enabled = s.symmetry_axis != 'NONE' and s.mirror_result == 'WELD'
        row.prop(s, "symmetry_scope", expand=True)
        row = box.row(align=True)
        row.enabled = s.symmetry_axis != 'NONE'
        row.prop(s, "mirror_side", expand=True)
        row = box.row(align=True)
        row.enabled = s.symmetry_axis != 'NONE'
        row.prop(s, "mirror_center", expand=True)
        obj = context.active_object
        mod = obj.modifiers.get(MIRROR_MOD_NAME) if obj is not None and obj.type == 'MESH' else None
        if mod is not None:
            row = box.row(align=True)
            row.prop(mod, "show_viewport", text="Mirror On", toggle=True)
            row.operator("dmt_redraw.apply_mirror", text="Apply", icon='CHECKMARK')
            row.operator("dmt_redraw.remove_mirror", text="", icon='X')

        row = layout.row(align=True)
        row.operator("dmt_redraw.save_preset", text="Save", icon='FILE_TICK')
        row.operator("dmt_redraw.delete_preset", text="Delete", icon='TRASH')
        row = layout.row(align=True)
        row.operator("dmt_redraw.export_presets", text="Export", icon='EXPORT')
        row.operator("dmt_redraw.import_presets", text="Import", icon='IMPORT')

        layout.separator()
        row = layout.row()
        row.scale_y = 1.35
        row.operator("dmt_redraw.redraw", text="Redraw", icon='MESH_GRID')


CLASSES = (
    DMT_REDRAW_Settings,
    DMT_REDRAW_OT_redraw,
    DMT_REDRAW_OT_apply_mirror,
    DMT_REDRAW_OT_remove_mirror,
    DMT_REDRAW_OT_save_preset,
    DMT_REDRAW_OT_delete_preset,
    DMT_REDRAW_OT_export_presets,
    DMT_REDRAW_OT_import_presets,
    DMT_REDRAW_PT_panel,
)
