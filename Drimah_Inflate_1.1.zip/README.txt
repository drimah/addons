Drimah Inflate - 1.0

English UI build for international distribution.

Features:
- Presets: Subtle, Soft, Plush, Cushion, Custom.
- Intensity and Smoothness controls.
- Inflate button.
- Save and Delete custom presets.
- Export and Import custom presets as JSON.
- Processing status: Please wait... Processing...
- Preset Name field without a redundant label.
- Blender file-save icon on Save.

Installation:
1. Disable the previous Drimah Inflate add-on.
2. Install this file, drimah_inflate.py, and enable it.
3. In the 3D Viewport, press N and open the Inflate tab.

Notes:
This is an experimental prototype. Test it in your Blender version before relying on it for production work.
