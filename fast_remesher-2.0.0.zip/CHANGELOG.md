# Changelog

## 2.0.0

- New single-panel workflow: Mode (Auto, Hard Surface, Organic), Result preset, Density, and one Remesh Selected button. Advanced options are collapsed.
- New engine: every separate part is remeshed on its own with the bundled Instant Meshes solver, sized by surface area.
- Hard Surface: sharp edges and corners are snapped back onto the original creases after remeshing, then each crease is walked and rebuilt as one continuous edge loop and marked Sharp. Narrow fillet and bevel strips smaller than a quad stay smooth.
- Every rebuilt part is validated against the original surface; failures retry with more faces, then fall back to tidying the part in place.
- Thin, small and already-clean parts are kept with their original data and tidied into quads.
- Organic mode no longer runs QuadriFlow inside Blender, which could freeze Blender on hard meshes.
- Solver runs in a separate process with progress, Cancel (button or Esc), and a stall watchdog.
- Preflight: detects curves, NURBS, text, empty meshes, shape keys, CAD-style tessellation, non-manifold edges, loose geometry and flipped faces. CAD data is pointed to CADPrep.
- Automatic mesh repair on a working copy before remeshing.
- Errors are shown in the panel with cause, next step, and Copy Diagnostics.
- Before and after statistics and a quality grade after every run. Revert to Original and Keep Result buttons.
- Convert to Mesh Copy for curves, text and metaballs.
- After a few successful remeshes, a small box under the result invites you to leave a review (Leave a Review, Not Now, Don't Ask Again). It never interrupts your work and is always available in the add-on preferences.
- Blender 4.2 to 5.2 supported.
- macOS and Linux solver builds bundled (Experimental).
- Removed: Live Preview, Garment mode (open shells are now handled automatically by both modes), manual preserved-edge marking.
- Known tradeoff: Hard Surface output vertices lie on the original surface but are no longer guaranteed to be original vertices.

## 1.0.0

- Initial release.
