import json
import os

import bpy

REVIEW_URL = "https://superhivemarket.com/products/fast-remesher"
FIRST_ASK = 3
SNOOZE = 10

_cache = {}


def _path():
    folder = None
    try:
        folder = bpy.utils.extension_path_user(__package__, create=True)
    except Exception:
        folder = None
    if not folder:
        folder = bpy.utils.user_resource("CONFIG", path="fast_remesher", create=True)
    return os.path.join(folder, "review.json")


def _load():
    if _cache:
        return _cache
    data = {"successes": 0, "next_ask": FIRST_ASK, "done": False}
    try:
        with open(_path(), encoding="utf-8") as handle:
            stored = json.load(handle)
        if isinstance(stored, dict):
            data.update({k: stored[k] for k in data if k in stored})
    except (OSError, ValueError):
        pass
    _cache.update(data)
    return _cache


def _save():
    try:
        path = _path()
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(_load(), handle)
        os.replace(tmp, path)
    except OSError:
        pass


def record_success():
    data = _load()
    data["successes"] = int(data["successes"]) + 1
    _save()


def should_ask():
    data = _load()
    return not data["done"] and int(data["successes"]) >= int(data["next_ask"])


def snooze():
    data = _load()
    data["next_ask"] = int(data["successes"]) + SNOOZE
    _save()


def finish():
    _load()["done"] = True
    _save()


def open_page(url):
    bpy.ops.wm.url_open(url=url)


def draw_nudge(layout):
    box = layout.box()
    box.label(text="Enjoying Fast Remesher?", icon="FUND")
    box.label(text="A quick review helps a lot.", icon="BLANK1")
    row = box.row()
    row.scale_y = 1.2
    row.operator("fastremesher.leave_review", icon="URL")
    row = box.row(align=True)
    row.operator("fastremesher.review_later", text="Not Now")
    row.operator("fastremesher.review_never", text="Don't Ask Again")


class FASTREMESHER_OT_leave_review(bpy.types.Operator):
    bl_idname = "fastremesher.leave_review"
    bl_label = "Leave a Review"
    bl_description = "Open the Fast Remesher page on Superhive in your browser to leave a review"

    def execute(self, context):
        open_page(REVIEW_URL)
        finish()
        self.report({"INFO"}, "Thank you! The review page is open in your browser")
        return {"FINISHED"}


class FASTREMESHER_OT_review_later(bpy.types.Operator):
    bl_idname = "fastremesher.review_later"
    bl_label = "Not Now"
    bl_description = "Hide this for now. It may come back after more remeshes"

    def execute(self, context):
        snooze()
        return {"FINISHED"}


class FASTREMESHER_OT_review_never(bpy.types.Operator):
    bl_idname = "fastremesher.review_never"
    bl_label = "Don't Ask Again"
    bl_description = "Never show this again. You can still leave a review from the add-on preferences"

    def execute(self, context):
        finish()
        return {"FINISHED"}


classes = (
    FASTREMESHER_OT_leave_review,
    FASTREMESHER_OT_review_later,
    FASTREMESHER_OT_review_never,
)
