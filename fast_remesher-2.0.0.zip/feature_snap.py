import math

import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import intersect_point_line
from mathutils.kdtree import KDTree


def _is_feature(edge, feature_angle):
    if len(edge.link_faces) == 1:
        return True
    if len(edge.link_faces) == 2:
        return edge.calc_face_angle(0.0) >= feature_angle
    return False


def extract_features(source_obj, feature_angle, include_sharp=True):
    mw = source_obj.matrix_world
    bm = bmesh.new()
    bm.from_mesh(source_obj.data)
    bm.verts.ensure_lookup_table()
    segments = []
    kinds = []
    degree = {}
    for e in bm.edges:
        boundary = len(e.link_faces) == 1
        if boundary or (include_sharp and _is_feature(e, feature_angle)):
            a, b = e.verts
            segments.append((mw @ a.co, mw @ b.co))
            kinds.append(boundary)
            degree[a.index] = degree.get(a.index, 0) + 1
            degree[b.index] = degree.get(b.index, 0) + 1
    corners = []
    for idx in sorted(degree):
        deg = degree[idx]
        v = bm.verts[idx]
        if deg != 2:
            corners.append(mw @ v.co)
            continue
        dirs = []
        for e in v.link_edges:
            if len(e.link_faces) == 1 or (include_sharp and _is_feature(e, feature_angle)):
                dirs.append((e.other_vert(v).co - v.co).normalized())
        if len(dirs) == 2 and dirs[0].dot(dirs[1]) > -0.5:
            corners.append(mw @ v.co)
    bm.free()
    return segments, kinds, corners


def build_bvh(obj):
    mw = obj.matrix_world
    verts = [mw @ v.co for v in obj.data.vertices]
    polys = [tuple(p.vertices) for p in obj.data.polygons]
    return BVHTree.FromPolygons(verts, polys, all_triangles=False)


def _segment_kdtree(segments, spacing):
    pts = []
    owners = []
    for i, (a, b) in enumerate(segments):
        n = max(1, int(math.ceil((b - a).length / spacing)))
        for k in range(n + 1):
            pts.append(a.lerp(b, k / n))
            owners.append(i)
    kd = KDTree(len(pts))
    for i, p in enumerate(pts):
        kd.insert(p, i)
    kd.balance()
    return kd, owners


def _closest_on_segment(p, a, b):
    q, t = intersect_point_line(p, a, b)
    if t <= 0.0:
        return a.copy()
    if t >= 1.0:
        return b.copy()
    return q


class _Grid:
    def __init__(self, cell):
        self.cell = max(cell, 1e-12)
        self.cells = {}

    def _key(self, p):
        c = self.cell
        return (int(math.floor(p.x / c)), int(math.floor(p.y / c)), int(math.floor(p.z / c)))

    def near(self, p, radius):
        kx, ky, kz = self._key(p)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for q in self.cells.get((kx + dx, ky + dy, kz + dz), ()):
                        if (q - p).length < radius:
                            return True
        return False

    def add(self, p):
        self.cells.setdefault(self._key(p), []).append(p.copy())


def _poly_normal(points):
    n = Vector((0.0, 0.0, 0.0))
    count = len(points)
    for k in range(count):
        a = points[k]
        b = points[(k + 1) % count]
        n.x += (a.y - b.y) * (a.z + b.z)
        n.y += (a.z - b.z) * (a.x + b.x)
        n.z += (a.x - b.x) * (a.y + b.y)
    return n


def fit_to_source(result_obj, source_obj, feature_angle=math.radians(35.0), snap_features=True, iterations=4, relax=0.5):
    segments, kinds, corners = extract_features(source_obj, feature_angle, include_sharp=snap_features)
    bvh = build_bvh(source_obj)
    mw = result_obj.matrix_world
    mwi = mw.inverted()
    bm = bmesh.new()
    bm.from_mesh(result_obj.data)
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    count = len(bm.verts)
    if count == 0:
        bm.free()
        return {"segments": 0, "corners": 0, "snapped": 0, "edge_length": 0.0}
    pos = [mw @ v.co for v in bm.verts]
    nbrs = [sorted(e.other_vert(v).index for e in v.link_edges) for v in bm.verts]
    on_boundary = [v.is_boundary for v in bm.verts]
    faces = [[v.index for v in f.verts] for f in bm.faces]
    vert_faces = [sorted(f.index for f in v.link_faces) for v in bm.verts]
    lengths = [(pos[e.verts[0].index] - pos[e.verts[1].index]).length for e in bm.edges]
    h = sum(lengths) / len(lengths) if lengths else 1.0
    locked = [False] * count

    def safe_move(i, target):
        old = pos[i]
        before = [_poly_normal([pos[j] for j in faces[fi]]) for fi in vert_faces[i]]
        pos[i] = target
        for fi, nb in zip(vert_faces[i], before):
            na = _poly_normal([pos[j] for j in faces[fi]])
            if nb.length < 1e-24 or na.length < 1e-24 or nb.dot(na) <= 0.0:
                pos[i] = old
                return False
        return True

    if corners:
        vkd = KDTree(count)
        for i, p in enumerate(pos):
            vkd.insert(p, i)
        vkd.balance()
        taken = set()
        for c in corners:
            for co, idx, dist in vkd.find_n(c, 4):
                if idx in taken or dist >= h * 0.75:
                    continue
                if safe_move(idx, c.copy()):
                    taken.add(idx)
                    locked[idx] = True
                    break

    kd = None
    owners = []
    if segments:
        kd, owners = _segment_kdtree(segments, h * 0.25)

    snapped = 0
    for it in range(iterations):
        for i in range(count):
            if locked[i]:
                continue
            hit = bvh.find_nearest(pos[i])
            if hit[0] is not None:
                safe_move(i, hit[0])
        if kd is not None:
            cands = []
            for i in range(count):
                if locked[i]:
                    continue
                co, idx, dist = kd.find(pos[i])
                seg_index = owners[idx]
                if kinds[seg_index] and not on_boundary[i]:
                    continue
                limit = h * (0.75 if on_boundary[i] else 0.5)
                if dist < limit:
                    a, b = segments[seg_index]
                    target = _closest_on_segment(pos[i], a, b)
                    cands.append(((target - pos[i]).length, i, target))
            cands.sort(key=lambda c: (c[0], c[1]))
            grid = _Grid(h * 0.5)
            for i in range(count):
                if locked[i]:
                    grid.add(pos[i])
            for d, i, target in cands:
                if not on_boundary[i] and grid.near(target, h * 0.45):
                    continue
                if safe_move(i, target):
                    locked[i] = True
                    grid.add(target)
                    snapped += 1
        if relax > 0.0 and it < iterations - 1:
            proposals = []
            for i in range(count):
                if locked[i] or on_boundary[i] or not nbrs[i]:
                    continue
                avg = Vector((0.0, 0.0, 0.0))
                for j in nbrs[i]:
                    avg += pos[j]
                avg /= len(nbrs[i])
                proposals.append((i, pos[i].lerp(avg, relax)))
            for i, target in proposals:
                safe_move(i, target)
    bridged = 0
    if kd is not None:
        chain_of = _segment_chains(segments)
        bridged = _bridge_chains(pos, nbrs, locked, on_boundary, segments, kinds, chain_of, kd, owners, h, safe_move)
        for _ in range(2):
            proposals = []
            for i in range(count):
                if locked[i] or on_boundary[i] or not nbrs[i]:
                    continue
                avg = Vector((0.0, 0.0, 0.0))
                for j in nbrs[i]:
                    avg += pos[j]
                avg /= len(nbrs[i])
                proposals.append((i, pos[i].lerp(avg, relax * 0.5)))
            for i, target in proposals:
                safe_move(i, target)
            for i in range(count):
                if locked[i]:
                    continue
                hit = bvh.find_nearest(pos[i])
                if hit[0] is not None:
                    safe_move(i, hit[0])
    for i in range(count):
        if locked[i] or on_boundary[i]:
            continue
        hit = bvh.find_nearest(pos[i])
        if hit[0] is not None:
            safe_move(i, hit[0])
    coverage = 0.0
    total_feature = sum((b - a).length for a, b in segments)
    on_line = [False] * count
    if kd is not None:
        for i in range(count):
            best_d = float("inf")
            for co, idx, dist in kd.find_n(pos[i], 6):
                a, b = segments[owners[idx]]
                best_d = min(best_d, (_closest_on_segment(pos[i], a, b) - pos[i]).length)
            on_line[i] = best_d <= h * 0.02
        for e in bm.edges:
            a, b = e.verts[0].index, e.verts[1].index
            if on_line[a] and on_line[b]:
                mid = (pos[a] + pos[b]) * 0.5
                co, idx, dist = kd.find(mid)
                sa, sb = segments[owners[idx]]
                if (_closest_on_segment(mid, sa, sb) - mid).length <= h * 0.05:
                    coverage += (pos[a] - pos[b]).length
    stats_locked = sum(1 for x in locked if x)
    stats_on_line = sum(1 for x in on_line if x)
    for v in bm.verts:
        v.co = mwi @ pos[v.index]
    bm.to_mesh(result_obj.data)
    bm.free()
    result_obj.data.update()
    return {
        "segments": len(segments),
        "corners": len(corners),
        "snapped": snapped,
        "bridged": bridged,
        "locked": stats_locked,
        "on_line": stats_on_line,
        "feature_coverage": coverage / total_feature if total_feature > 0 else 1.0,
        "edge_length": h,
    }


def _point_key(p, scale):
    return (round(p.x / scale), round(p.y / scale), round(p.z / scale))


def _segment_chains(segments):
    if not segments:
        return []
    span = max(max(abs(c) for c in a[:] + b[:]) for a, b in segments) or 1.0
    scale = span * 1e-9
    node_segs = {}
    ends = []
    for i, (a, b) in enumerate(segments):
        ka = _point_key(a, scale)
        kb = _point_key(b, scale)
        ends.append((ka, kb))
        node_segs.setdefault(ka, []).append(i)
        node_segs.setdefault(kb, []).append(i)
    chain_of = [-1] * len(segments)
    chain = 0
    for start in range(len(segments)):
        if chain_of[start] != -1:
            continue
        stack = [start]
        chain_of[start] = chain
        while stack:
            s = stack.pop()
            for key in ends[s]:
                linked = node_segs[key]
                if len(linked) != 2:
                    continue
                for other in linked:
                    if chain_of[other] == -1:
                        chain_of[other] = chain
                        stack.append(other)
        chain += 1
    return chain_of


def _nearest_on_chain(p, chain, kd, owners, segments, chain_of):
    best = None
    best_d = float("inf")
    for co, idx, dist in kd.find_n(p, 12):
        seg = owners[idx]
        if chain_of[seg] != chain:
            continue
        a, b = segments[seg]
        q = _closest_on_segment(p, a, b)
        d = (q - p).length
        if d < best_d:
            best_d = d
            best = (q, seg)
    return best, best_d


def _bridge_chains(pos, nbrs, locked, on_boundary, segments, kinds, chain_of, kd, owners, h, safe_move):
    import heapq
    members = {}
    for i in range(len(pos)):
        if not locked[i]:
            continue
        best_seg = None
        best_d = float("inf")
        for co, idx, dist in kd.find_n(pos[i], 6):
            seg = owners[idx]
            a, b = segments[seg]
            d = (_closest_on_segment(pos[i], a, b) - pos[i]).length
            if d < best_d:
                best_d = d
                best_seg = seg
        if best_seg is None or best_d > h * 0.02:
            continue
        members.setdefault(chain_of[best_seg], []).append(i)
    bridged = 0
    for chain in sorted(members):
        verts = members[chain]
        if len(verts) < 2:
            continue
        member_set = set(verts)
        mkd = KDTree(len(verts))
        for k, v in enumerate(verts):
            mkd.insert(pos[v], v)
        mkd.balance()
        for i in verts:
            near = sorted(idx for co, idx, d in mkd.find_range(pos[i], h * 2.6) if idx > i and idx not in nbrs[i])
            for j in near:
                dist = {i: 0.0}
                prev = {}
                heap = [(0.0, i)]
                found = False
                while heap:
                    d, u = heapq.heappop(heap)
                    if d > dist.get(u, float("inf")):
                        continue
                    if u == j:
                        found = True
                        break
                    if d > h * 4.0:
                        break
                    for w in nbrs[u]:
                        if w != j and (locked[w] or w in member_set):
                            continue
                        if kinds and on_boundary[w] != on_boundary[i]:
                            continue
                        hit, off = _nearest_on_chain(pos[w], chain, kd, owners, segments, chain_of)
                        if hit is None or off > h * 0.9:
                            continue
                        nd = d + (pos[w] - pos[u]).length + off * 3.0
                        if nd < dist.get(w, float("inf")):
                            dist[w] = nd
                            prev[w] = u
                            heapq.heappush(heap, (nd, w))
                if not found:
                    continue
                path = []
                u = prev.get(j)
                while u is not None and u != i:
                    path.append(u)
                    u = prev.get(u)
                if len(path) > 3:
                    continue
                for w in path:
                    hit, off = _nearest_on_chain(pos[w], chain, kd, owners, segments, chain_of)
                    if hit is not None and safe_move(w, hit[0]):
                        locked[w] = True
                        member_set.add(w)
                        bridged += 1
    return bridged
