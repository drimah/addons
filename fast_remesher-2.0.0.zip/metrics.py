import math

import bmesh


def topology(mesh):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    try:
        faces = len(bm.faces)
        quads = 0
        tris = 0
        for f in bm.faces:
            n = len(f.verts)
            if n == 4:
                quads += 1
            elif n == 3:
                tris += 1
        interior = [v for v in bm.verts if v.link_faces and not v.is_boundary and v.is_manifold]
        regular = sum(1 for v in interior if len(v.link_edges) == 4)
        angle_error = 0.0
        corners = 0
        lengths = []
        for f in bm.faces:
            if len(f.verts) != 4:
                continue
            for loop in f.loops:
                angle_error += abs(math.degrees(loop.calc_angle()) - 90.0)
                corners += 1
                lengths.append(loop.edge.calc_length())
        mean = sum(lengths) / len(lengths) if lengths else 0.0
        cv = 0.0
        if mean > 0.0:
            cv = math.sqrt(sum((x - mean) ** 2 for x in lengths) / len(lengths)) / mean
        return {
            "faces": faces,
            "quads": quads,
            "tris": tris,
            "ngons": faces - quads - tris,
            "quad_ratio": quads / faces if faces else 0.0,
            "regular_vertex_ratio": regular / len(interior) if interior else 0.0,
            "corner_angle_error": angle_error / corners if corners else 0.0,
            "edge_length_variation": cv,
        }
    finally:
        bm.free()


def score(stats):
    if not stats or not stats.get("faces"):
        return 0.0
    value = 40.0 * stats.get("quad_ratio", 0.0)
    value += 30.0 * stats.get("regular_vertex_ratio", 0.0)
    value += 15.0 * max(0.0, 1.0 - stats.get("corner_angle_error", 90.0) / 30.0)
    value += 15.0 * max(0.0, 1.0 - stats.get("edge_length_variation", 1.0))
    return value


def grade(stats):
    if not stats or not stats.get("faces"):
        return "N/A"
    score = 0.0
    score += 40.0 * stats.get("quad_ratio", 0.0)
    score += 30.0 * stats.get("regular_vertex_ratio", 0.0)
    score += 15.0 * max(0.0, 1.0 - stats.get("corner_angle_error", 90.0) / 30.0)
    score += 15.0 * max(0.0, 1.0 - stats.get("edge_length_variation", 1.0))
    if score >= 85.0:
        return "Excellent"
    if score >= 70.0:
        return "Good"
    if score >= 55.0:
        return "Fair"
    return "Poor"
