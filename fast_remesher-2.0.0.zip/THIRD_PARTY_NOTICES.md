# Third-Party Notices

Fast Remesher bundles **Instant Meshes** by Wenzel Jakob, Daniele Panozzo, Marco Tarini and Olga Sorkine-Hornung.

Project: https://github.com/wjakob/instant-meshes

Instant Meshes is distributed under its BSD-style license. The complete license notice is in `INSTANT_MESHES_LICENSE.txt`.

Fast Remesher itself is distributed under GPL-3.0-or-later; see `LICENSE`.

Bundled solver binaries (SHA-256):

| Platform | File | SHA-256 |
|---|---|---|
| Windows x64 | `bin/Windows/Instant Meshes.exe` | `f1fe5b5f56d1002ae61dbd76a3fd646229fc1fe15322e7a3744f8ce442c76b2d` |
| macOS (Intel, runs on Apple Silicon through Rosetta 2) | `bin/Darwin/Instant Meshes.app/Contents/MacOS/Instant Meshes` | `53be5ab05f8baeb3ddb97388313aad74f98b812a5d58860f41e730f253e5b23d` |
| Linux x64 | `bin/Linux/Instant Meshes` | `a1946606e15d452b3d16ff3ec0161ff12053b6e0c8568d3eab6cd7e97486448d` |
