# Fast Remesher 2.0

Fast Remesher rebuilds a mesh as clean, even quads in one click. It runs on Blender 4.2 to 5.2 and keeps your original so you can switch back at any time.

## Quick start

1. Select the mesh you want to clean up.
2. Open the sidebar (N) and the **Fast Remesher** tab.
3. Leave Mode on **Auto** and press **Remesh Selected**.
4. Not happy? Press **Revert to Original**, pick another **Result** preset, and run again.

## Modes

- **Auto** looks at the mesh and chooses Hard Surface or Organic.
- **Hard Surface** keeps sharp edges and corners crisp. Use it for props, weapons, vehicles, furniture and machinery.
- **Organic** builds smooth, evenly flowing quads. Use it for characters, creatures, sculpts and scans.

## Result presets

| Preset | Density | Typical use |
|---|---|---|
| Fast Preview | 25 | A quick look at the flow in seconds |
| Clean Game Mesh | 50 | Balanced real-time asset (default) |
| High Detail | 75 | Holds fine shapes; heavier result |

Each +25 Density gives about 5 times as many faces (quads about half as wide). Density is measured relative to the object's own size, so the same preset gives a similar result on a tiny prop and on a large vehicle.

## What happens when you press Remesh Selected

1. **Preflight** checks the selection: object type, empty or zero-size meshes, shape keys, CAD-style tessellation, non-manifold edges, loose geometry, flipped faces and missing solver files.
2. Mesh problems are fixed on a working copy (loose points removed, duplicate vertices merged, face directions made consistent). Your original is never changed.
3. Each separate part of the mesh is handled on its own:
   - Parts large enough to rebuild are remeshed with the bundled Instant Meshes solver.
   - Very small parts, parts that are already clean quads, and thin parts that a rebuild would damage are kept and tidied (triangle pairs joined into quads, never across a UV seam or material border).
4. Every rebuilt part is checked against the original surface. If it drifts too far, Fast Remesher retries with more faces, then falls back to tidying that part in place. It never hands back a damaged shape.
5. In Hard Surface mode, sharp edges and corners are snapped back onto the original creases.
6. Materials, UV maps, colour attributes, vertex groups and skin weights are carried over to the rebuilt parts. Kept parts keep their original data exactly.

## Never hangs, never fails silently

- The solver runs as a separate process. The panel shows a progress bar and the current step, and **Cancel** (or Esc) stops it immediately with your mesh unchanged.
- A watchdog stops the solver if it stops making progress, then tries the next strategy automatically.
- Every error is shown in the panel with the cause, what to do next, and a **Copy Diagnostics** button for support.

## Unsuitable input

- **Curves, text and metaballs**: press **Convert to Mesh Copy**, then remesh the copy.
- **NURBS surfaces and CAD data**: if you have the original STEP or IGES file, CADPrep (by Anvil) builds cleaner meshes from the real CAD surfaces. Fast Remesher points you there when it detects CAD-style tessellation.

## Known tradeoff: Hard Surface output vertices

Fast Remesher 1.x tried to keep every output vertex on an original vertex. That often meant the tool could not improve the mesh at all and returned it unchanged. From 2.0, Hard Surface mode builds new, even quads and then fits them back onto the original surface and creases. Output vertices therefore lie **on** the original surface but are generally **not** original vertices. Parts that are kept (small, thin or already clean) still use only original vertices.

## Determinism

The same mesh with the same settings gives a byte-identical result on every run, on the same machine and solver build. The solver runs single-threaded in its deterministic mode, and all parts are processed in a fixed order. If the watchdog has to stop a stalled solve, the fallback result is still the same for the same input, but it differs from what the stalled solve would have produced.

## Platforms

- Windows x64: fully tested.
- macOS (Intel, and Apple Silicon through Rosetta 2) and Linux x64: solver bundled, **Experimental** (not yet verified on real hardware). Missing execute permission and macOS quarantine flags are fixed automatically when possible, otherwise the panel shows the exact command to run.

## Preserved data

Materials and per-face material assignment, UV maps (including UDIM tiles), colour attributes, vertex groups and skin weights, armature relationship, object transform and modifier stack. Shape keys cannot survive a new topology; you are warned before running, and Revert to Original brings them back.

## Enjoying it?

A review on [Superhive](https://superhivemarket.com/products/fast-remesher) helps other artists find Fast Remesher. After a few good results the panel shows a small Leave a Review box; Not Now hides it for a while and Don't Ask Again hides it for good. The link is also in Edit > Preferences > Add-ons > Fast Remesher.

## Third-party software

Fast Remesher bundles Instant Meshes. See `THIRD_PARTY_NOTICES.md` and `INSTANT_MESHES_LICENSE.txt`.

## License

GPL-3.0-or-later. See `LICENSE`.
