import bisect
import math

import bmesh
from mathutils import Vector
from mathutils.geometry import intersect_point_line
from mathutils.kdtree import KDTree


def _key(p, scale):
    return (round(p.x / scale), round(p.y / scale), round(p.z / scale))


def build_polylines(segments):
    if not segments:
        return []
    span = max(max(abs(c) for c in tuple(a) + tuple(b)) for a, b in segments) or 1.0
    scale = span * 1e-9
    points = {}
    adjacency = {}
    for a, b in segments:
        ka = _key(a, scale)
        kb = _key(b, scale)
        if ka == kb:
            continue
        points[ka] = a
        points[kb] = b
        adjacency.setdefault(ka, set()).add(kb)
        adjacency.setdefault(kb, set()).add(ka)
    used = set()
    lines = []

    def edge_id(u, v):
        return (u, v) if u < v else (v, u)

    def walk(start, nxt):
        line = [start, nxt]
        used.add(edge_id(start, nxt))
        prev, cur = start, nxt
        while len(adjacency[cur]) == 2:
            options = [n for n in adjacency[cur] if n != prev]
            if not options:
                break
            n = options[0]
            if edge_id(cur, n) in used:
                break
            used.add(edge_id(cur, n))
            line.append(n)
            prev, cur = cur, n
        return line

    for node in sorted(adjacency):
        if len(adjacency[node]) != 2:
            for n in sorted(adjacency[node]):
                if edge_id(node, n) not in used:
                    lines.append(walk(node, n))
    for node in sorted(adjacency):
        for n in sorted(adjacency[node]):
            if edge_id(node, n) not in used:
                lines.append(walk(node, n))
    result = []
    for line in lines:
        pts = [points[k].copy() for k in line]
        if len(pts) >= 2:
            result.append(pts)
    return result


class Polyline:
    def __init__(self, pts):
        self.pts = pts
        self.cum = [0.0]
        for i in range(1, len(pts)):
            self.cum.append(self.cum[-1] + (pts[i] - pts[i - 1]).length)
        self.length = self.cum[-1]
        self.closed = len(pts) > 2 and (pts[0] - pts[-1]).length < 1e-9 * max(1.0, self.length)

    def point_at(self, s):
        s = max(0.0, min(self.length, s))
        lo, hi = 0, len(self.cum) - 1
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if self.cum[mid] <= s:
                lo = mid
            else:
                hi = mid
        seg = self.cum[hi] - self.cum[lo]
        t = 0.0 if seg <= 0.0 else (s - self.cum[lo]) / seg
        return self.pts[lo].lerp(self.pts[hi], t)

    def project(self, p, s_min=0.0, s_max=None):
        if s_max is None:
            s_max = self.length
        best = (float("inf"), 0.0, None)
        first = max(0, bisect.bisect_right(self.cum, s_min) - 1)
        for i in range(first, len(self.pts) - 1):
            if self.cum[i] > s_max:
                break
            a = self.pts[i]
            b = self.pts[i + 1]
            q, t = intersect_point_line(p, a, b)
            t = max(0.0, min(1.0, t))
            q = a.lerp(b, t)
            d = (q - p).length
            if d < best[0]:
                best = (d, self.cum[i] + t * (self.cum[i + 1] - self.cum[i]), q)
        return best


def _face_normals_ok(vert, new_co):
    old = vert.co.copy()
    before = [f.normal.copy() for f in vert.link_faces]
    vert.co = new_co
    ok = True
    for f, nb in zip(vert.link_faces, before):
        f.normal_update()
        if nb.length < 1e-20 or f.normal.length < 1e-20 or nb.dot(f.normal) <= 0.0:
            ok = False
            break
    if not ok:
        vert.co = old
        for f in vert.link_faces:
            f.normal_update()
    return ok


def _diagonal_partners(v):
    result = []
    neighbours = {e.other_vert(v) for e in v.link_edges}
    for f in v.link_faces:
        for w in f.verts:
            if w is not v and w not in neighbours and w not in result:
                result.append(w)
    return result


def _edge_between(a, b):
    for e in a.link_edges:
        if e.other_vert(a) is b:
            return e
    return None


def resolvable_polylines(lines, h, spacing_factor=0.8, paired_share=0.5):
    from mathutils.kdtree import KDTree
    samples = []
    owners = []
    dirs = []
    per_line = []
    step = max(h * 0.25, 1e-12)
    for li, pts in enumerate(lines):
        mine = []
        for i in range(len(pts) - 1):
            a, b = pts[i], pts[i + 1]
            seg = b - a
            if seg.length <= 0.0:
                continue
            d = seg.normalized()
            n = max(1, int(seg.length / step))
            for k in range(n):
                samples.append(a + seg * ((k + 0.5) / n))
                owners.append(li)
                dirs.append(d)
                mine.append(len(samples) - 1)
        per_line.append(mine)
    if not samples:
        return []
    kd = KDTree(len(samples))
    for i, p in enumerate(samples):
        kd.insert(p, i)
    kd.balance()
    keep = []
    for li, mine in enumerate(per_line):
        if not mine:
            continue
        paired = 0
        for i in mine:
            p = samples[i]
            d = dirs[i]
            for co, j, dist in kd.find_range(p, h * spacing_factor):
                if owners[j] == li or abs(d.dot(dirs[j])) < 0.8:
                    continue
                off = co - p
                perp = (off - d * off.dot(d)).length
                if h * 0.05 < perp < h * spacing_factor:
                    paired += 1
                    break
        if paired < len(mine) * paired_share:
            keep.append(lines[li])
    return keep


def weld_creases(bm, segments, h, feature_layer_name="fast_remesher_crease"):
    lines = [Polyline(p) for p in resolvable_polylines(build_polylines(segments), h)]
    lines = [ln for ln in lines if ln.length > h * 0.5]
    bm.verts.ensure_lookup_table()
    kd = KDTree(len(bm.verts))
    for v in bm.verts:
        kd.insert(v.co, v.index)
    kd.balance()
    verts = list(bm.verts)
    crease_edges = set()
    owner = {}
    stats = {"lines": len(lines), "walked": 0, "cuts": 0, "steps": 0, "gaps": 0}
    reach = h * 1.1

    def free(v, line_id, p=None):
        o = owner.get(v)
        if o is None or o == line_id:
            return True
        return p is not None and (v.co - p).length < h * 0.05

    def nearest_vertex(p, radius, line_id):
        best = None
        best_d = radius
        for co, idx, d in kd.find_range(p, radius * 1.6):
            v = verts[idx]
            if not v.is_valid or not free(v, line_id, p):
                continue
            dd = (v.co - p).length
            if dd < best_d:
                best_d = dd
                best = v
        return best

    for line_id, line in enumerate(sorted(lines, key=lambda ln: (-ln.length, tuple(ln.pts[0])))):
        start = nearest_vertex(line.pts[0], reach, line_id)
        if start is None:
            stats["gaps"] += 1
            continue
        _face_normals_ok(start, line.pts[0].copy())
        owner.setdefault(start, line_id)
        current = start
        s_cur = 0.0
        stats["walked"] += 1
        guard = int(line.length / max(h * 0.2, 1e-12)) + 8
        while s_cur < line.length - h * 0.35 and guard > 0:
            guard -= 1
            best = None
            for w, diagonal in [(e.other_vert(current), False) for e in current.link_edges] + [(w, True) for w in _diagonal_partners(current)]:
                d, s_w, q = line.project(w.co, s_cur, s_cur + h * 2.5)
                if q is None or s_w <= s_cur + h * 0.2 or d > reach:
                    continue
                if not free(w, line_id, q):
                    continue
                score = (s_w - s_cur) - 2.0 * d - (h * 0.35 if diagonal else 0.0)
                if best is None or score > best[0]:
                    best = (score, w, diagonal, s_w, q)
            if best is None:
                s_next = min(line.length, s_cur + h)
                jump = nearest_vertex(line.point_at(s_next), reach, line_id)
                stats["gaps"] += 1
                if jump is None or jump is current:
                    s_cur = s_next
                    continue
                current = jump
                d, s_cur, q = line.project(current.co, s_cur, s_cur + h * 2.5)
                if q is not None:
                    _face_normals_ok(current, q)
                continue
            score, w, diagonal, s_w, q = best
            if diagonal:
                try:
                    res = bmesh.ops.connect_vert_pair(bm, verts=[current, w])
                except Exception:
                    res = {"edges": []}
                if not res.get("edges"):
                    s_cur = s_w
                    current = w
                    continue
                stats["cuts"] += 1
            target = line.point_at(line.length) if line.length - s_w < h * 0.35 else q
            if owner.get(w) in (None, line_id):
                _face_normals_ok(w, target.copy())
            owner.setdefault(w, line_id)
            e = _edge_between(current, w)
            if e is not None:
                crease_edges.add(e)
            current = w
            s_cur = s_w
            stats["steps"] += 1
    for e in list(crease_edges):
        if e.is_valid:
            e.smooth = False
            e.seam = True
    tris = [f for f in bm.faces if len(f.verts) == 3]
    if tris:
        bmesh.ops.join_triangles(
            bm, faces=tris, cmp_seam=True, cmp_sharp=False, cmp_uvs=False,
            cmp_vcols=False, cmp_materials=True,
            angle_face_threshold=math.radians(30.0),
            angle_shape_threshold=math.radians(40.0),
        )
    for e in bm.edges:
        if e.seam:
            e.seam = False
    stats["crease_edges"] = sum(1 for e in crease_edges if e.is_valid)
    return stats
