import math

import bmesh

from . import solver


CADPREP_HINT = "CADPrep (by Anvil) imports STEP and IGES files directly and builds clean meshes from the original CAD surfaces."
CAD_NAME_HINTS = (".step", ".stp", ".iges", ".igs", "_step", "brep", "solid", "body", "shell", "assembly", "asm", "part")

NON_MESH_TYPES = {
    "CURVE": "a curve",
    "SURFACE": "a NURBS surface",
    "FONT": "a text object",
    "META": "a metaball",
    "CURVES": "a hair curves object",
    "POINTCLOUD": "a point cloud",
    "VOLUME": "a volume",
}


def _issue(level, code, message, next_step="", action=""):
    return {"level": level, "code": code, "message": message, "next_step": next_step, "action": action}


def _sampled_faces(bm, limit):
    faces = bm.faces
    count = len(faces)
    if count <= limit:
        return list(faces)
    faces.ensure_lookup_table()
    step = count / float(limit)
    return [faces[int(i * step)] for i in range(limit)]


def cad_signals(bm, obj, tri_ratio):
    faces = _sampled_faces(bm, 20000)
    if not faces:
        return 0.0, {}
    sliver = 0
    planar_tri = 0
    for f in faces:
        if len(f.verts) != 3:
            continue
        lengths = sorted(e.calc_length() for e in f.edges)
        if lengths[0] > 0 and lengths[2] / lengths[0] > 8.0:
            sliver += 1
        flat = True
        for e in f.edges:
            if len(e.link_faces) == 2 and e.calc_face_angle(0.0) > math.radians(0.5):
                flat = False
                break
        if flat:
            planar_tri += 1
    n = float(len(faces))
    verts = bm.verts
    fan = 0
    sample_verts = list(verts)[:: max(1, len(verts) // 20000)]
    for v in sample_verts:
        if len(v.link_edges) >= 12:
            fan += 1
    fan_ratio = fan / float(max(1, len(sample_verts)))
    name = (obj.name + " " + (obj.data.name if obj.data else "")).lower()
    name_hit = any(h in name for h in CAD_NAME_HINTS)
    imported_by = str(obj.get("cad_source", "")) or (str(obj.data.get("cad_source", "")) if obj.data else "")
    signals = {
        "triangle_ratio": tri_ratio,
        "sliver_ratio": sliver / n,
        "flat_triangle_ratio": planar_tri / n,
        "fan_vertex_ratio": fan_ratio,
        "name_hint": name_hit,
    }
    score = 0.0
    if tri_ratio > 0.95:
        score += 0.3
    score += min(0.35, signals["sliver_ratio"] * 1.2)
    score += min(0.2, signals["flat_triangle_ratio"] * 0.3)
    score += min(0.2, fan_ratio * 6.0)
    if name_hit:
        score += 0.1
    if imported_by:
        score += 0.5
    return min(1.0, score), signals


def suggest_mode(bm):
    edges = [e for e in bm.edges if len(e.link_faces) == 2]
    if not edges:
        return "HARDSURFACE"
    step = max(1, len(edges) // 30000)
    flat = 0
    sharp = 0
    total = 0
    for e in edges[::step]:
        a = e.calc_face_angle(0.0)
        total += 1
        if a < math.radians(1.0):
            flat += 1
        elif a > math.radians(30.0):
            sharp += 1
    flat_ratio = flat / float(total)
    sharp_ratio = sharp / float(total)
    if flat_ratio > 0.35 or sharp_ratio > 0.04:
        return "HARDSURFACE"
    return "ORGANIC"


def analyze(obj, max_solve_faces=200000):
    result = {
        "ok": False,
        "issues": [],
        "stats": {},
        "suggested_mode": "HARDSURFACE",
        "cad_score": 0.0,
        "summary": "",
    }
    if obj is None:
        result["issues"].append(_issue("ERROR", "NO_SELECTION", "Nothing is selected.", "Click a mesh object in the viewport, then press Remesh Selected."))
        result["summary"] = "Select a mesh to begin"
        return result
    if obj.type != "MESH":
        kind = NON_MESH_TYPES.get(obj.type, "a %s object" % obj.type.lower())
        if obj.type == "SURFACE":
            result["issues"].append(_issue(
                "ERROR", "NURBS",
                "%s is %s. Fast Remesher rebuilds meshes, not NURBS surfaces." % (obj.name, kind),
                "If this came from a CAD program, re-import the original STEP or IGES file with CADPrep for clean, accurate geometry. Otherwise click Convert to Mesh Copy and remesh the copy.",
                "CONVERT",
            ))
        elif obj.type in {"CURVE", "FONT", "META"}:
            result["issues"].append(_issue(
                "ERROR", "NOT_MESH",
                "%s is %s, not a mesh." % (obj.name, kind),
                "Click Convert to Mesh Copy to make a mesh version you can remesh. Your original is kept.",
                "CONVERT",
            ))
        else:
            result["issues"].append(_issue("ERROR", "NOT_MESH", "%s is %s, not a mesh." % (obj.name, kind), "Select a mesh object instead."))
        result["summary"] = "%s is not a mesh" % obj.name
        return result

    mesh = obj.data
    faces = len(mesh.polygons)
    stats = {"faces": faces, "vertices": len(mesh.vertices)}
    result["stats"] = stats
    if faces == 0:
        result["issues"].append(_issue("ERROR", "NO_FACES", "%s has no faces (only points or edges)." % obj.name, "Fast Remesher needs surfaces. Fill the shape first (Edit Mode > F), or pick another object."))
        result["summary"] = "Mesh has no faces"
        return result

    status = solver.binary_status()
    if not status["ok"]:
        result["issues"].append(_issue("ERROR", "SOLVER", status["cause"], status["next_step"]))

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        tris = sum(1 for f in bm.faces if len(f.verts) == 3)
        tri_ratio = tris / float(faces)
        non_manifold = sum(1 for e in bm.edges if len(e.link_faces) > 2)
        loose = sum(1 for e in bm.edges if not e.link_faces) + sum(1 for v in bm.verts if not v.link_edges)
        flipped = 0
        for e in bm.edges:
            if len(e.link_faces) != 2:
                continue
            f0, f1 = e.link_faces
            l0 = next(l for l in e.link_loops if l.face is f0)
            l1 = next(l for l in e.link_loops if l.face is f1)
            if l0.vert is l1.vert:
                flipped += 1
        dims = obj.dimensions
        diag = math.sqrt(dims.x ** 2 + dims.y ** 2 + dims.z ** 2)
        scale_ok = all(abs(abs(s) - 1.0) < 1e-4 for s in obj.scale)
        stats.update({
            "triangle_ratio": tri_ratio,
            "non_manifold_edges": non_manifold,
            "loose_elements": loose,
            "flipped_edges": flipped,
            "size": diag,
        })
        cad_score, signals = cad_signals(bm, obj, tri_ratio)
        stats["cad"] = signals
        result["cad_score"] = cad_score
        result["suggested_mode"] = suggest_mode(bm)
    finally:
        bm.free()

    if diag <= 0.0:
        result["issues"].append(_issue("ERROR", "ZERO_SIZE", "%s has zero size." % obj.name, "Check the object's scale and geometry."))
    if mesh.shape_keys is not None and len(mesh.shape_keys.key_blocks) > 1:
        result["issues"].append(_issue("WARNING", "SHAPE_KEYS", "Shape keys will be removed: a new topology cannot carry them over.", "Keep a copy of the original if you need its shape keys.", ""))
    if cad_score >= 0.6:
        result["issues"].append(_issue(
            "INFO", "CAD",
            "This looks like CAD tessellation (long thin triangles and fan patterns).",
            "Fast Remesher will clean it up, but if you have the original STEP or IGES file, " + CADPREP_HINT,
            "CADPREP",
        ))
        result["suggested_mode"] = "HARDSURFACE"
    quads = sum(1 for poly in mesh.polygons if len(poly.vertices) == 4)
    if faces >= 50 and quads / float(faces) >= 0.9 and not non_manifold:
        result["issues"].append(_issue("INFO", "CLEAN", "Already %d%% quads. A remesh rebuilds it at your Density and may soften small details." % round(100.0 * quads / faces), "", ""))
    if non_manifold or loose or flipped:
        parts = []
        if non_manifold:
            parts.append("%d non-manifold edges" % non_manifold)
        if loose:
            parts.append("%d loose points or edges" % loose)
        if flipped:
            parts.append("%d edges with flipped faces" % flipped)
        result["issues"].append(_issue("INFO", "MESSY", "Mesh problems found: " + ", ".join(parts) + ".", "These are fixed automatically on a working copy before remeshing.", ""))
    if faces > max_solve_faces:
        result["issues"].append(_issue("INFO", "DENSE", "Dense mesh (%s faces). It will be simplified to %s faces first to keep the solve fast." % (format(faces, ","), format(max_solve_faces, ",")), "Raise Max Solve Faces under Advanced for more fidelity on very detailed scans.", ""))
    if not scale_ok:
        result["issues"].append(_issue("INFO", "SCALE", "Object scale is not applied. Density is measured in world size, so this is handled automatically.", "", ""))

    errors = [i for i in result["issues"] if i["level"] == "ERROR"]
    result["ok"] = not errors
    if errors:
        result["summary"] = errors[0]["message"]
    else:
        result["summary"] = "%s: %s faces, ready" % (obj.name, format(faces, ","))
    return result
