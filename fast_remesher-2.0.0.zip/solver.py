import atexit
import os
import platform
import stat
import subprocess
import time


_LIVE = set()


def kill_all():
    for job in list(_LIVE):
        job.kill()


atexit.register(kill_all)


BINARY_NAMES = {
    "Windows": ("Windows", "Instant Meshes.exe"),
    "Darwin": ("Darwin", os.path.join("Instant Meshes.app", "Contents", "MacOS", "Instant Meshes")),
    "Linux": ("Linux", "Instant Meshes"),
}

STAGES = (
    ("Processing input mesh", "Reading mesh"),
    ("Computing orientation field", "Aligning flow"),
    ("Computing position field", "Placing vertices"),
    ("Extracting", "Building quads"),
    ("Writing", "Writing result"),
)


class SolverUnavailable(Exception):
    def __init__(self, cause, next_step):
        super().__init__(cause)
        self.cause = cause
        self.next_step = next_step


def addon_dir():
    return os.path.dirname(os.path.abspath(__file__))


_STATUS_CACHE = {}


def binary_status(refresh=False):
    cached = _STATUS_CACHE.get("status")
    if cached is not None and cached["ok"] and not refresh:
        return cached
    status = _probe_binary()
    _STATUS_CACHE["status"] = status
    return status


def _probe_binary():
    system = platform.system()
    entry = BINARY_NAMES.get(system)
    if entry is None:
        return {
            "ok": False,
            "path": "",
            "cause": "Fast Remesher has no solver build for %s." % system,
            "next_step": "Use Windows, macOS or Linux (x64 or Apple Silicon).",
        }
    folder, name = entry
    path = os.path.join(addon_dir(), "bin", folder, name)
    if not os.path.isfile(path):
        return {
            "ok": False,
            "path": path,
            "cause": "The remesh solver is missing from this install (%s)." % os.path.join("bin", folder),
            "next_step": "Reinstall Fast Remesher from the original download. Antivirus tools sometimes quarantine the solver; restore it or add an exception.",
        }
    if system != "Windows" and not os.access(path, os.X_OK):
        try:
            mode = os.stat(path).st_mode
            os.chmod(path, mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except OSError:
            pass
        if not os.access(path, os.X_OK):
            return {
                "ok": False,
                "path": path,
                "cause": "The remesh solver is not allowed to run (missing execute permission).",
                "next_step": 'Run in a terminal: chmod +x "%s"' % path,
            }
    if system == "Darwin":
        _clear_quarantine(path)
        if platform.machine() == "arm64" and not _rosetta_available():
            return {
                "ok": False,
                "path": path,
                "cause": "The remesh solver needs Rosetta 2 on Apple Silicon Macs.",
                "next_step": "Open Terminal and run: softwareupdate --install-rosetta --agree-to-license  then restart Blender.",
            }
    return {"ok": True, "path": path, "cause": "", "next_step": "", "experimental": system != "Windows"}


def _rosetta_available():
    try:
        proc = subprocess.run(["/usr/bin/arch", "-x86_64", "/usr/bin/true"], capture_output=True, timeout=10)
        return proc.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _clear_quarantine(path):
    bundle = path
    marker = ".app" + os.sep
    if marker in path:
        bundle = path[: path.index(marker) + 4]
    try:
        subprocess.run(["xattr", "-dr", "com.apple.quarantine", bundle], capture_output=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        pass


def require_binary():
    status = binary_status()
    if not status["ok"]:
        raise SolverUnavailable(status["cause"], status["next_step"])
    return status["path"]


def build_command(binary, in_path, out_path, target_faces, crease_degrees=None, align_boundaries=False, smooth_iterations=2):
    cmd = [
        binary,
        "-o", out_path,
        "-f", str(max(8, int(target_faces))),
        "-r", "4",
        "-p", "4",
        "-S", str(int(smooth_iterations)),
        "-t", "1",
        "-d",
    ]
    if crease_degrees is not None:
        cmd += ["-c", "%.3f" % float(crease_degrees)]
    if align_boundaries:
        cmd += ["-b"]
    cmd.append(in_path)
    return cmd


class SolverJob:
    def __init__(self, cmd, out_path, timeout, label="", stall=45.0):
        self.cmd = cmd
        self.out_path = out_path
        self.timeout = timeout
        self.stall = stall
        self.last_size = -1
        self.last_change = None
        self.label = label
        self.proc = None
        self.started = None
        self.log_path = out_path + ".log"
        self.log_handle = None
        self.state = "pending"
        self.error = ""

    def start(self):
        flags = 0
        if platform.system() == "Windows":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.log_handle = open(self.log_path, "w", encoding="utf-8", errors="replace")
        try:
            self.proc = subprocess.Popen(
                self.cmd,
                stdout=self.log_handle,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                cwd=os.path.dirname(self.cmd[0]),
                creationflags=flags,
            )
        except OSError as exc:
            self.log_handle.close()
            self.state = "failed"
            self.error = "Could not start the solver: %s" % exc
            return
        self.started = time.monotonic()
        self.last_change = self.started
        self.state = "running"
        _LIVE.add(self)

    def poll(self):
        if self.state != "running":
            return self.state
        code = self.proc.poll()
        if code is None:
            now = time.monotonic()
            try:
                size = os.path.getsize(self.log_path)
            except OSError:
                size = self.last_size
            if size != self.last_size:
                self.last_size = size
                self.last_change = now
            if now - self.last_change > self.stall:
                self.kill()
                self.state = "timeout"
                self.error = "Solver stopped making progress for %d s" % int(self.stall)
            elif now - self.started > self.timeout:
                self.kill()
                self.state = "timeout"
                self.error = "Solver exceeded its %d s time limit" % int(self.timeout)
            return self.state
        _LIVE.discard(self)
        self.log_handle.close()
        if code == 0 and os.path.isfile(self.out_path) and os.path.getsize(self.out_path) > 0:
            self.state = "done"
        else:
            self.state = "failed"
            self.error = "Solver exited with code %s. %s" % (code, self.tail(400))
        return self.state

    def kill(self):
        _LIVE.discard(self)
        if self.proc is not None and self.proc.poll() is None:
            try:
                self.proc.kill()
                self.proc.wait(timeout=5)
            except (OSError, subprocess.SubprocessError):
                pass
        if self.log_handle is not None and not self.log_handle.closed:
            self.log_handle.close()
        if self.state in {"pending", "running"}:
            self.state = "cancelled"

    def stage(self):
        text = self.tail(4000)
        label = "Starting solver"
        for needle, name in STAGES:
            if needle in text:
                label = name
        return label

    def tail(self, size):
        try:
            with open(self.log_path, "r", encoding="utf-8", errors="replace") as fh:
                data = fh.read()
            return data[-size:].strip()
        except OSError:
            return ""

    def elapsed(self):
        if self.started is None:
            return 0.0
        return time.monotonic() - self.started


def stall_for(faces):
    return float(45 + faces / 4000.0)


def timeout_for(faces):
    return float(min(600, 6 + faces / 400.0))
