import json
import platform
import time

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup

from . import engine
from . import metrics
from . import preflight
from . import review
from . import solver


ORIGINAL_PROP = "fast_remesher_original"
REPORT_PROP = "fast_remesher_report"
STORE_URL = "https://theanvilstore.com"

_STATE = {
    "previous": None,
    "task": None,
    "object": "",
    "error": None,
    "preflight_key": None,
    "preflight": None,
}


def addon_version():
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __package__:
                return ".".join(str(x) for x in mod.bl_info.get("version", ()))
    except Exception:
        pass
    return "2.0.0"


def cadprep_installed():
    for key in bpy.context.preferences.addons.keys():
        if "cadprep" in key.lower():
            return True
    return False


def _prefs(context):
    addon = context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def _apply_preset(self, context):
    preset = engine.PRESETS.get(self.preset)
    if preset is not None:
        self["density"] = preset["density"]


def _density_changed(self, context):
    for key, preset in engine.PRESETS.items():
        if preset["density"] == self.density:
            if self.preset != key:
                self["preset"] = list(PRESET_KEYS).index(key)
            return
    if self.preset != "CUSTOM":
        self["preset"] = list(PRESET_KEYS).index("CUSTOM")


PRESET_KEYS = ("FAST_PREVIEW", "GAME", "HIGH", "CUSTOM")


class FASTREMESHER_Settings(PropertyGroup):
    mode: EnumProperty(
        name="Mode",
        items=[
            ("AUTO", "Auto", "Look at the mesh and pick Hard Surface or Organic for you. Best first choice"),
            ("HARDSURFACE", "Hard Surface", "Keeps sharp edges and corners crisp. For props, weapons, vehicles, furniture, machinery"),
            ("ORGANIC", "Organic", "Smooth, even quads that follow the form. For characters, creatures, sculpts and scans"),
        ],
        default="AUTO",
    )
    preset: EnumProperty(
        name="Result",
        items=[
            ("FAST_PREVIEW", "Fast Preview", "Few, large quads. Quick look at the flow in a few seconds"),
            ("GAME", "Clean Game Mesh", "Balanced density for real-time use. A good default"),
            ("HIGH", "High Detail", "Many small quads that hold fine shapes. Slower, heavier result"),
            ("CUSTOM", "Custom", "Your own Density value"),
        ],
        default="GAME",
        update=_apply_preset,
    )
    density: IntProperty(
        name="Density",
        description="How many quads to build. 25 = light preview, 50 = game mesh, 75 = high detail. Each +25 gives about 5 times as many faces",
        default=50,
        min=1,
        max=100,
        subtype="PERCENTAGE",
        update=_density_changed,
    )
    max_solve_faces: IntProperty(
        name="Max Solve Faces",
        description="Meshes denser than this are simplified first so the solve stays fast. 200,000 suits most scans; raise it for very fine detail",
        default=200000,
        min=10000,
        max=2000000,
    )
    feature_angle: FloatProperty(
        name="Sharp Edge Angle",
        description="Hard Surface only. Edges folded more than this are kept as crisp lines. 35 degrees suits most props; lower it to keep gentler bevels",
        default=0.610865,
        min=0.087266,
        max=1.396263,
        subtype="ANGLE",
    )
    auto_cleanup: BoolProperty(
        name="Fix Mesh Problems First",
        description="Remove loose points, merge duplicate vertices and fix flipped faces on a working copy before remeshing. Your original is never changed",
        default=True,
    )
    show_advanced: BoolProperty(name="Advanced", default=False)


class FASTREMESHER_Preferences(AddonPreferences):
    bl_idname = __package__

    show_intro: BoolProperty(name="Show Getting Started", default=True)

    def draw(self, context):
        self.layout.prop(self, "show_intro")
        status = solver.binary_status()
        if status["ok"]:
            self.layout.label(text="Remesh solver: ready", icon="CHECKMARK")
        else:
            self.layout.label(text=status["cause"], icon="ERROR")
            self.layout.label(text=status["next_step"])
        self.layout.operator("fastremesher.leave_review", icon="URL")


def _store_error(obj_name, cause, next_step, action="", details=""):
    _STATE["error"] = {
        "object": obj_name,
        "cause": cause,
        "next_step": next_step,
        "action": action,
        "details": details,
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def _effective_mode(settings, analysis):
    if settings.mode != "AUTO":
        return settings.mode
    return analysis.get("suggested_mode", "HARDSURFACE")


def _tag_redraw(context):
    wm = context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type in {"VIEW_3D", "PROPERTIES"}:
                area.tag_redraw()


def _settle_previous(restore):
    entry = _STATE.get("previous")
    _STATE["previous"] = None
    if not entry:
        return
    obj = bpy.data.objects.get(entry[0])
    mesh = bpy.data.meshes.get(entry[1])
    if mesh is None:
        return
    mesh.use_fake_user = False
    if restore and obj is not None:
        obj.data = mesh
    elif mesh.users == 0:
        bpy.data.meshes.remove(mesh)


def _finish_success(obj, task, original_mesh, mode):
    _settle_previous(False)
    if obj.get(ORIGINAL_PROP) is None:
        obj[ORIGINAL_PROP] = original_mesh
    elif original_mesh.users == 0:
        bpy.data.meshes.remove(original_mesh)
    report = task.report
    summary = {
        "mode": mode,
        "density": task.density,
        "faces_before": report.get("faces_before", 0),
        "faces_after": report.get("faces_after", 0),
        "before": report.get("before", {}),
        "after": report.get("after", {}),
        "seconds": round(report.get("seconds", 0.0), 2),
        "islands": report.get("islands", 0),
        "islands_kept": report.get("islands_kept", 0),
        "warnings": report.get("warnings", []),
        "predecimated": report.get("predecimated", False),
        "grade": metrics.grade(report.get("after", {})),
        "improved": metrics.score(report.get("after", {})) > metrics.score(report.get("before", {})) + 2.0,
    }
    obj[REPORT_PROP] = json.dumps(summary)
    if summary["improved"]:
        review.record_success()
    prefs = _prefs(bpy.context)
    if prefs is not None and prefs.show_intro:
        prefs.show_intro = False


class FASTREMESHER_OT_remesh(Operator):
    bl_idname = "fastremesher.remesh"
    bl_label = "Remesh Selected"
    bl_description = "Rebuild the selected mesh as clean quads. Your original is kept and can be restored with one click"
    bl_options = {"REGISTER"}

    mode: EnumProperty(
        name="Mode",
        items=[("SETTINGS", "From Panel", ""), ("HARDSURFACE", "Hard Surface", ""), ("ORGANIC", "Organic", "")],
        default="SETTINGS",
        options={"SKIP_SAVE"},
    )
    density: IntProperty(name="Density", default=-1, min=-1, max=100, options={"SKIP_SAVE"})

    _timer = None

    @classmethod
    def poll(cls, context):
        if _STATE["task"] is not None:
            cls.poll_message_set("A remesh is already running")
            return False
        obj = context.active_object
        if obj is None:
            cls.poll_message_set("Select a mesh to begin")
            return False
        if obj.mode != "OBJECT" and obj.type == "MESH" and obj.mode != "EDIT":
            cls.poll_message_set("Switch to Object Mode first")
            return False
        return True

    def _start(self, context):
        settings = context.scene.fast_remesher_settings
        obj = context.active_object
        if obj is not None and obj.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
        if obj is not None and obj.type == "MESH" and obj.get(ORIGINAL_PROP) is not None:
            previous = obj.data
            if previous is not obj[ORIGINAL_PROP]:
                previous.use_fake_user = True
                _STATE["previous"] = (obj.name, previous.name)
                obj.data = obj[ORIGINAL_PROP]
        _STATE["error"] = None
        analysis = preflight.analyze(obj, settings.max_solve_faces)
        _STATE["preflight"] = analysis
        _STATE["preflight_key"] = _preflight_key(obj)
        if not analysis["ok"]:
            issue = next(i for i in analysis["issues"] if i["level"] == "ERROR")
            _store_error(obj.name if obj else "", issue["message"], issue["next_step"], issue.get("action", ""), json.dumps(analysis.get("stats", {}), default=str))
            _settle_previous(True)
            self.report({"ERROR"}, issue["message"])
            return None
        mode = self.mode if self.mode != "SETTINGS" else _effective_mode(settings, analysis)
        density = self.density if self.density >= 0 else settings.density
        task = engine.RemeshTask(obj, mode, density, settings.max_solve_faces, settings.feature_angle * 57.29577951308232, settings.auto_cleanup)
        task.analysis = analysis
        try:
            task.prepare()
        except (engine.RemeshError, solver.SolverUnavailable) as exc:
            task.cleanup()
            _settle_previous(True)
            _store_error(obj.name, exc.cause, exc.next_step)
            self.report({"ERROR"}, exc.cause)
            return None
        except Exception as exc:
            task.cleanup()
            _settle_previous(True)
            _store_error(obj.name, "Fast Remesher could not prepare this mesh: %s" % exc, "Click Copy Diagnostics and send it to support@theanvilstore.com.", details=repr(exc))
            self.report({"ERROR"}, str(exc))
            return None
        return task

    def execute(self, context):
        task = self._start(context)
        if task is None:
            return {"CANCELLED"}
        obj = task.obj
        try:
            while task.tick() == "solving":
                time.sleep(0.05)
            original = task.finish()
        except Exception as exc:
            task.cancel()
            engine.release_source_proxy(obj)
            _settle_previous(True)
            _store_error(obj.name, "Remesh failed: %s" % exc, "Your original mesh is unchanged. Try a lower Density, or Copy Diagnostics and send it to support.", details=repr(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _finish_success(obj, task, original, task.mode)
        self.report({"INFO"}, _result_line(obj))
        bpy.ops.ed.undo_push(message="Remesh Selected")
        return {"FINISHED"}

    def invoke(self, context, event):
        if context.window is None:
            return self.execute(context)
        task = self._start(context)
        if task is None:
            return {"CANCELLED"}
        _STATE["task"] = task
        _STATE["object"] = task.obj.name
        wm = context.window_manager
        wm.fast_remesher_progress = 0.02
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        context.workspace.status_text_set("Fast Remesher: working. Press Esc to cancel")
        return {"RUNNING_MODAL"}

    def _end(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        _STATE["task"] = None
        wm.fast_remesher_progress = 0.0
        context.workspace.status_text_set(None)
        _tag_redraw(context)

    def modal(self, context, event):
        task = _STATE["task"]
        if task is None:
            self._end(context)
            return {"CANCELLED"}
        if event.type == "ESC" or task.cancelled:
            if not task.cancelled:
                task.cancel()
            _settle_previous(True)
            self._end(context)
            self.report({"WARNING"}, "Remesh cancelled. Your mesh is unchanged")
            return {"CANCELLED"}
        if event.type != "TIMER":
            return {"PASS_THROUGH"}
        obj = task.obj
        try:
            state = task.tick()
            context.window_manager.fast_remesher_progress = max(0.02, task.progress)
            if state == "assembling":
                context.window_manager.fast_remesher_progress = 0.88
                original = task.finish()
                _finish_success(obj, task, original, task.mode)
                self._end(context)
                bpy.ops.ed.undo_push(message="Remesh Selected")
                self.report({"INFO"}, _result_line(obj))
                return {"FINISHED"}
        except Exception as exc:
            task.cancel()
            engine.release_source_proxy(obj)
            _settle_previous(True)
            _store_error(obj.name, "Remesh failed: %s" % exc, "Your original mesh is unchanged. Try a lower Density, or Copy Diagnostics and send it to support.", details=repr(exc))
            self._end(context)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _tag_redraw(context)
        return {"RUNNING_MODAL"}


class FASTREMESHER_OT_cancel(Operator):
    bl_idname = "fastremesher.cancel"
    bl_label = "Cancel"
    bl_description = "Stop the remesh. Your mesh stays exactly as it was"

    def execute(self, context):
        task = _STATE["task"]
        if task is not None:
            task.cancel()
        return {"FINISHED"}


class FASTREMESHER_OT_revert(Operator):
    bl_idname = "fastremesher.revert"
    bl_label = "Revert to Original"
    bl_description = "Put back the mesh exactly as it was before Fast Remesher touched it"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH" or obj.get(ORIGINAL_PROP) is None:
            cls.poll_message_set("Nothing to revert on this object")
            return False
        return True

    def execute(self, context):
        obj = context.active_object
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        original = obj[ORIGINAL_PROP]
        current = obj.data
        obj.data = original
        del obj[ORIGINAL_PROP]
        if REPORT_PROP in obj:
            del obj[REPORT_PROP]
        if current.users == 0:
            bpy.data.meshes.remove(current)
        self.report({"INFO"}, "Original mesh restored")
        return {"FINISHED"}


class FASTREMESHER_OT_keep(Operator):
    bl_idname = "fastremesher.keep"
    bl_label = "Keep Result"
    bl_description = "Accept the new mesh and discard the stored original to save memory and file size"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.get(ORIGINAL_PROP) is not None

    def execute(self, context):
        obj = context.active_object
        original = obj[ORIGINAL_PROP]
        del obj[ORIGINAL_PROP]
        if original.users == 0:
            bpy.data.meshes.remove(original)
        self.report({"INFO"}, "Result kept")
        return {"FINISHED"}


class FASTREMESHER_OT_convert(Operator):
    bl_idname = "fastremesher.convert_copy"
    bl_label = "Convert to Mesh Copy"
    bl_description = "Make a mesh copy of this curve, surface or text object and select it, ready to remesh. The original stays untouched"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type in {"CURVE", "SURFACE", "FONT", "META"}

    def execute(self, context):
        obj = context.active_object
        depsgraph = context.evaluated_depsgraph_get()
        mesh = bpy.data.meshes.new_from_object(obj.evaluated_get(depsgraph))
        if not mesh.polygons:
            bpy.data.meshes.remove(mesh)
            _store_error(obj.name, "%s has no surface to convert (for example an open curve with no bevel or extrude)." % obj.name, "Give the curve some Bevel Depth or Extrude in its Data properties, then convert again.")
            self.report({"ERROR"}, "Nothing to convert")
            return {"CANCELLED"}
        copy = bpy.data.objects.new(obj.name + "_mesh", mesh)
        copy.matrix_world = obj.matrix_world.copy()
        for collection in obj.users_collection:
            collection.objects.link(copy)
        for o in context.selected_objects:
            o.select_set(False)
        copy.select_set(True)
        context.view_layer.objects.active = copy
        _STATE["error"] = None
        self.report({"INFO"}, "Created %s. Press Remesh Selected" % copy.name)
        return {"FINISHED"}


class FASTREMESHER_OT_cadprep(Operator):
    bl_idname = "fastremesher.cadprep_help"
    bl_label = "Open CADPrep"
    bl_description = "CADPrep imports STEP and IGES files directly and builds clean meshes from the real CAD surfaces"

    def execute(self, context):
        if cadprep_installed():
            self.report({"INFO"}, "CADPrep is installed: use its panel in the sidebar or File > Import to bring in the original STEP or IGES file")
            return {"FINISHED"}
        bpy.ops.wm.url_open(url=STORE_URL)
        return {"FINISHED"}


def diagnostics_text(context):
    obj = context.active_object
    lines = [
        "Fast Remesher %s" % addon_version(),
        "Blender %s" % bpy.app.version_string,
        "OS %s %s (%s)" % (platform.system(), platform.release(), platform.machine()),
    ]
    status = solver.binary_status()
    lines.append("Solver: %s" % ("ready" if status["ok"] else status["cause"]))
    if obj is not None:
        lines.append("Object: %s (%s)" % (obj.name, obj.type))
        if obj.type == "MESH":
            lines.append("Faces: %d  Vertices: %d" % (len(obj.data.polygons), len(obj.data.vertices)))
        if obj.get(REPORT_PROP):
            lines.append("Last result: %s" % obj[REPORT_PROP])
    if _STATE["error"]:
        lines.append("Last error: %s" % json.dumps(_STATE["error"], default=str))
    if _STATE["preflight"]:
        p = _STATE["preflight"]
        lines.append("Preflight: %s" % json.dumps({"summary": p.get("summary"), "issues": p.get("issues"), "stats": p.get("stats"), "suggested_mode": p.get("suggested_mode"), "cad_score": p.get("cad_score")}, default=str))
    return "\n".join(lines)


class FASTREMESHER_OT_copy_diagnostics(Operator):
    bl_idname = "fastremesher.copy_diagnostics"
    bl_label = "Copy Diagnostics"
    bl_description = "Copy a plain-text report of the last run (no mesh data) to the clipboard, ready to paste into a support email"

    def execute(self, context):
        context.window_manager.clipboard = diagnostics_text(context)
        self.report({"INFO"}, "Diagnostics copied to the clipboard")
        return {"FINISHED"}


class FASTREMESHER_OT_dismiss_intro(Operator):
    bl_idname = "fastremesher.dismiss_intro"
    bl_label = "Got It"
    bl_description = "Hide the Getting Started box. Turn it back on in the add-on preferences"

    def execute(self, context):
        prefs = _prefs(context)
        if prefs is not None:
            prefs.show_intro = False
        return {"FINISHED"}


class FASTREMESHER_OT_clear_error(Operator):
    bl_idname = "fastremesher.clear_error"
    bl_label = "Dismiss"
    bl_description = "Hide this message"

    def execute(self, context):
        _STATE["error"] = None
        return {"FINISHED"}


def _preflight_key(obj):
    if obj is None:
        return None
    if obj.type != "MESH":
        return (obj.name, obj.type)
    return (obj.name, obj.type, len(obj.data.polygons), len(obj.data.vertices))


def _cached_preflight(obj, settings):
    key = _preflight_key(obj)
    if key == _STATE["preflight_key"] and _STATE["preflight"] is not None:
        return _STATE["preflight"]
    if obj is not None and obj.type == "MESH" and len(obj.data.polygons) > 60000:
        return None
    analysis = preflight.analyze(obj, settings.max_solve_faces)
    _STATE["preflight_key"] = key
    _STATE["preflight"] = analysis
    return analysis


def _result_line(obj):
    try:
        data = json.loads(obj.get(REPORT_PROP, "{}"))
    except ValueError:
        return "Remesh finished"
    after = data.get("after", {})
    return "%s faces -> %s faces, %d%% quads, quality %s, %.1f s" % (
        format(data.get("faces_before", 0), ","),
        format(data.get("faces_after", 0), ","),
        round(after.get("quad_ratio", 0.0) * 100),
        data.get("grade", "N/A"),
        data.get("seconds", 0.0),
    )


class FASTREMESHER_PT_main(Panel):
    bl_idname = "FASTREMESHER_PT_main"
    bl_label = "Fast Remesher"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Fast Remesher"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.fast_remesher_settings
        prefs = _prefs(context)
        obj = context.active_object
        task = _STATE["task"]

        if task is not None:
            box = layout.box()
            box.label(text="Remeshing...", icon="MOD_REMESH")
            box.progress(factor=context.window_manager.fast_remesher_progress, type="BAR", text=task.step)
            row = box.row()
            row.scale_y = 1.5
            row.operator("fastremesher.cancel", icon="CANCEL")
            box.label(text="Esc also cancels")
            return

        if prefs is not None and prefs.show_intro:
            box = layout.box()
            box.label(text="Getting Started", icon="INFO")
            col = box.column(align=True)
            col.label(text="1. Click the mesh to clean up")
            col.label(text="2. Press Remesh Selected")
            col.label(text="3. Revert to Original to undo")
            box.operator("fastremesher.dismiss_intro", icon="CHECKMARK")

        analysis = _cached_preflight(obj, settings)
        if obj is None:
            layout.label(text="Select a mesh to begin", icon="RESTRICT_SELECT_OFF")
        elif analysis is not None and not analysis["ok"]:
            layout.label(text="Cannot remesh this object", icon="ERROR")
        else:
            mode = settings.mode
            if mode == "AUTO":
                mode = analysis["suggested_mode"] if analysis is not None else ""
            mode_name = {"HARDSURFACE": "Hard Surface", "ORGANIC": "Organic"}.get(mode, "Auto")
            faces = len(obj.data.polygons) if obj.type == "MESH" else 0
            layout.label(text="Ready: %s, %s faces" % (mode_name, format(faces, ",")), icon="CHECKMARK")

        error = _STATE["error"]
        if error is not None and (obj is None or error["object"] == obj.name or not error["object"]):
            box = layout.box()
            box.alert = True
            col = box.column(align=True)
            for i, line in enumerate(_wrap(error["cause"], 30)):
                col.label(text=line, icon="ERROR" if i == 0 else "BLANK1")
            col.separator()
            for i, line in enumerate(_wrap(error["next_step"], 30)):
                col.label(text=line, icon="RIGHTARROW" if i == 0 else "BLANK1")
            if error.get("action") == "CONVERT":
                box.operator("fastremesher.convert_copy", icon="MESH_DATA")
            if error.get("action") == "CADPREP" or "CADPrep" in error.get("next_step", ""):
                box.operator("fastremesher.cadprep_help", icon="IMPORT", text="Use CADPrep" if cadprep_installed() else "About CADPrep")
            row = box.row(align=True)
            row.operator("fastremesher.copy_diagnostics", icon="COPYDOWN")
            row.operator("fastremesher.clear_error", icon="X", text="")

        if solver.binary_status().get("experimental"):
            layout.label(text="%s: Experimental" % ("macOS" if platform.system() == "Darwin" else "Linux"), icon="EXPERIMENTAL")

        col = layout.column()
        col.row().prop(settings, "mode", expand=True)
        col.prop(settings, "preset")
        col.prop(settings, "density", slider=True)
        row = col.row()
        row.scale_y = 1.8
        row.operator("fastremesher.remesh", text="Remesh Selected", icon="MOD_REMESH")

        if obj is not None and obj.get(REPORT_PROP):
            try:
                data = json.loads(obj[REPORT_PROP])
            except ValueError:
                data = None
            if data:
                before = data.get("before", {})
                after = data.get("after", {})
                box = layout.box()
                if data.get("improved", True):
                    box.label(text="Result: %s" % data.get("grade", "N/A"), icon="CHECKMARK")
                else:
                    box.label(text="Little to gain on this mesh", icon="INFO")
                    for line in _wrap("The original was already clean quads. Revert keeps it.", 34):
                        box.label(text=line, icon="BLANK1")
                col = box.column(align=True)
                col.label(text="Faces  %s > %s" % (format(data.get("faces_before", 0), ","), format(data.get("faces_after", 0), ",")))
                col.label(text="Quads  %d%% > %d%%" % (round(before.get("quad_ratio", 0) * 100), round(after.get("quad_ratio", 0) * 100)))
                col.label(text="Clean vertices  %d%% > %d%%" % (round(before.get("regular_vertex_ratio", 0) * 100), round(after.get("regular_vertex_ratio", 0) * 100)))
                col.label(text="%s, %.1f s" % ("Hard Surface" if data.get("mode") == "HARDSURFACE" else "Organic", data.get("seconds", 0.0)))
                for warning in data.get("warnings", [])[:2]:
                    for i, line in enumerate(_wrap(warning, 30)):
                        box.label(text=line, icon="ERROR" if i == 0 else "BLANK1")
                row = box.row(align=True)
                row.operator("fastremesher.revert", icon="LOOP_BACK", text="Revert")
                row.operator("fastremesher.keep", icon="CHECKMARK", text="Keep")
                if data.get("improved", True) and review.should_ask():
                    review.draw_nudge(layout)

        if analysis is not None:
            for issue in analysis["issues"]:
                if issue["level"] == "ERROR" or issue["code"] not in {"CAD", "SHAPE_KEYS", "CLEAN"} or (issue["code"] == "CLEAN" and obj is not None and obj.get(REPORT_PROP)):
                    continue
                hint = layout.box()
                for i, line in enumerate(_wrap(issue["message"], 30)):
                    hint.label(text=line, icon="INFO" if i == 0 else "BLANK1")
                if issue["code"] == "CAD":
                    hint.operator("fastremesher.cadprep_help", icon="IMPORT", text="Use CADPrep" if cadprep_installed() else "About CADPrep")

        adv = layout.box()
        adv.prop(settings, "show_advanced", icon="TRIA_DOWN" if settings.show_advanced else "TRIA_RIGHT", emboss=False)
        if settings.show_advanced:
            adv.prop(settings, "max_solve_faces")
            sub = adv.row()
            sub.enabled = settings.mode != "ORGANIC"
            sub.prop(settings, "feature_angle")
            adv.prop(settings, "auto_cleanup")
            adv.operator("fastremesher.copy_diagnostics", icon="COPYDOWN")


def _wrap(text, width):
    words = str(text).split()
    lines = []
    current = ""
    for word in words:
        if current and len(current) + 1 + len(word) > width:
            lines.append(current)
            current = word
        else:
            current = (current + " " + word).strip()
    if current:
        lines.append(current)
    return lines or [""]


classes = (
    FASTREMESHER_Settings,
    FASTREMESHER_Preferences,
    FASTREMESHER_OT_remesh,
    FASTREMESHER_OT_cancel,
    FASTREMESHER_OT_revert,
    FASTREMESHER_OT_keep,
    FASTREMESHER_OT_convert,
    FASTREMESHER_OT_cadprep,
    FASTREMESHER_OT_copy_diagnostics,
    FASTREMESHER_OT_dismiss_intro,
    FASTREMESHER_OT_clear_error,
    *review.classes,
    FASTREMESHER_PT_main,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fast_remesher_settings = bpy.props.PointerProperty(type=FASTREMESHER_Settings)
    bpy.types.WindowManager.fast_remesher_progress = FloatProperty(default=0.0, min=0.0, max=1.0, subtype="FACTOR")


def unregister():
    task = _STATE.get("task")
    if task is not None:
        task.cancel()
        _STATE["task"] = None
    solver.kill_all()
    del bpy.types.WindowManager.fast_remesher_progress
    del bpy.types.Scene.fast_remesher_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
