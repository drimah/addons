import math
import os
import shutil
import tempfile
import time

import bmesh
import bpy
from mathutils import Matrix, Vector

from . import crease
from . import feature_snap
from . import metrics
from . import solver
from . import surface_transfer


MIN_ISLAND_FACES = 24
MAX_PARALLEL = 4
TIME_BUDGET = 240.0

PRESETS = {
    "FAST_PREVIEW": {"density": 25, "label": "Fast Preview"},
    "GAME": {"density": 50, "label": "Clean Game Mesh"},
    "HIGH": {"density": 75, "label": "High Detail"},
}


class RemeshError(Exception):
    def __init__(self, cause, next_step, action=""):
        super().__init__(cause)
        self.cause = cause
        self.next_step = next_step
        self.action = action


def edge_fraction(density):
    d = max(1.0, min(100.0, float(density))) / 100.0
    return 0.12 * math.pow(0.04, d)


def target_faces_for(area, diag, density):
    h = max(diag * edge_fraction(density), 1e-9)
    return max(MIN_ISLAND_FACES, int(round(area / (h * h))))


def world_bmesh(obj, matrix):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(matrix)
    return bm


def cleanup_bmesh(bm, diag):
    stats = {"loose_removed": 0, "degenerate_removed": 0, "normals_fixed": False, "merged": 0}
    loose_edges = [e for e in bm.edges if not e.link_faces]
    if loose_edges:
        stats["loose_removed"] += len(loose_edges)
        bmesh.ops.delete(bm, geom=loose_edges, context="EDGES")
    loose_verts = [v for v in bm.verts if not v.link_faces]
    if loose_verts:
        stats["loose_removed"] += len(loose_verts)
        bmesh.ops.delete(bm, geom=loose_verts, context="VERTS")
    before = len(bm.verts)
    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=diag * 1e-6)
    stats["merged"] = before - len(bm.verts)
    faces_before = len(bm.faces)
    bmesh.ops.dissolve_degenerate(bm, edges=list(bm.edges), dist=diag * 1e-7)
    stats["degenerate_removed"] = max(0, faces_before - len(bm.faces))
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        stats["normals_fixed"] = True
    return stats


def islands(bm):
    bm.faces.index_update()
    bm.faces.ensure_lookup_table()
    seen = set()
    result = []
    for f in bm.faces:
        if f.index in seen:
            continue
        stack = [f]
        seen.add(f.index)
        comp = []
        while stack:
            cur = stack.pop()
            comp.append(cur.index)
            for e in cur.edges:
                for other in e.link_faces:
                    if other.index not in seen:
                        seen.add(other.index)
                        stack.append(other)
        comp.sort()
        result.append(comp)
    result.sort(key=lambda c: c[0])
    return result


def island_bmesh(bm, face_indices):
    bm.faces.ensure_lookup_table()
    out = bmesh.new()
    vmap = {}
    for fi in face_indices:
        f = bm.faces[fi]
        verts = []
        for v in f.verts:
            nv = vmap.get(v.index)
            if nv is None:
                nv = out.verts.new(v.co)
                vmap[v.index] = nv
            verts.append(nv)
        try:
            nf = out.faces.new(verts)
            nf.material_index = f.material_index
        except ValueError:
            pass
    out.verts.index_update()
    out.faces.index_update()
    out.normal_update()
    return out


def write_obj(bm, path):
    tri = bm.copy()
    bmesh.ops.triangulate(tri, faces=list(tri.faces), quad_method="BEAUTY", ngon_method="BEAUTY")
    tri.verts.index_update()
    with open(path, "w", encoding="ascii", newline="\n") as fh:
        for v in tri.verts:
            fh.write("v %.9g %.9g %.9g\n" % (v.co.x, v.co.y, v.co.z))
        for f in tri.faces:
            fh.write("f %d %d %d\n" % tuple(v.index + 1 for v in f.verts))
    tri.free()


def read_obj(path):
    verts = []
    faces = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("v "):
                parts = line.split()
                try:
                    co = (float(parts[1]), float(parts[2]), float(parts[3]))
                except ValueError:
                    return [], []
                if not all(math.isfinite(c) for c in co):
                    return [], []
                verts.append(co)
            elif line.startswith("f "):
                idx = []
                for token in line.split()[1:]:
                    value = int(token.split("/")[0])
                    idx.append(value - 1 if value > 0 else len(verts) + value)
                if len(idx) >= 3:
                    faces.append(idx)
    return verts, faces


def append_to_bmesh(target, verts, faces, material_index=0):
    new_verts = [target.verts.new(co) for co in verts]
    for f in faces:
        try:
            nf = target.faces.new([new_verts[i] for i in f])
            nf.material_index = material_index
        except (ValueError, IndexError):
            pass


def densify(bm, max_edge, max_faces):
    out = bm.copy()
    bmesh.ops.triangulate(out, faces=list(out.faces), quad_method="BEAUTY", ngon_method="BEAUTY")
    for _ in range(12):
        long_edges = [e for e in out.edges if e.calc_length() > max_edge]
        if not long_edges or len(out.faces) + 2 * len(long_edges) > max_faces:
            break
        bmesh.ops.subdivide_edges(out, edges=long_edges, cuts=1, use_grid_fill=False)
        bmesh.ops.triangulate(out, faces=[f for f in out.faces if len(f.verts) > 3], quad_method="BEAUTY", ngon_method="BEAUTY")
    bmesh.ops.beautify_fill(out, faces=list(out.faces), edges=[e for e in out.edges if not e.is_boundary and e.calc_face_angle(0.0) < 0.05])
    return out


def quad_cleanup(bm, angle_deg=40.0):
    tris = [f for f in bm.faces if len(f.verts) == 3]
    if tris:
        bmesh.ops.join_triangles(
            bm, faces=tris, cmp_seam=False, cmp_sharp=False, cmp_uvs=False,
            cmp_vcols=False, cmp_materials=True,
            angle_face_threshold=math.radians(angle_deg),
            angle_shape_threshold=math.radians(angle_deg),
        )
    faces = len(bm.faces)
    if not faces:
        return 0.0
    return sum(1 for f in bm.faces if len(f.verts) == 4) / float(faces)


def already_clean(bm):
    trial = bm.copy()
    try:
        quad_cleanup(trial)
        faces = len(trial.faces)
        if not faces:
            return False
        quads = sum(1 for f in trial.faces if len(f.verts) == 4)
        if quads / float(faces) < 0.95:
            return False
        interior = [v for v in trial.verts if not v.is_boundary and v.link_faces]
        if interior and sum(1 for v in interior if len(v.link_edges) == 4) / float(len(interior)) < 0.88:
            return False
        error = 0.0
        corners = 0
        for f in trial.faces:
            if len(f.verts) == 4:
                for loop in f.loops:
                    error += abs(math.degrees(loop.calc_angle()) - 90.0)
                    corners += 1
        if corners and error / corners > 12.0:
            return False
    finally:
        trial.free()
    quad_cleanup(bm)
    return True


def island_thickness(bm, samples=96):
    from mathutils.bvhtree import BVHTree
    if len(bm.faces) < 4:
        return None
    bm.faces.ensure_lookup_table()
    bvh = BVHTree.FromBMesh(bm)
    faces = sorted(bm.faces, key=lambda f: (-f.calc_area(), f.index))
    step = max(1, len(faces) // samples)
    values = []
    sampled_area = 0.0
    for f in faces[::step][:samples]:
        n = f.normal
        area = f.calc_area()
        if n.length < 1e-12 or area <= 0.0:
            continue
        sampled_area += area
        center = f.calc_center_median()
        offset = 1e-6 * max(1.0, f.calc_perimeter())
        best = None
        for direction in (-n, n):
            hit = bvh.ray_cast(center + direction * offset, direction)
            if hit[0] is None or hit[2] is None or hit[2] == f.index:
                continue
            other = bm.faces[hit[2]].normal
            if abs(other.dot(n)) < 0.7:
                continue
            if best is None or hit[3] < best:
                best = hit[3]
        if best is not None:
            values.append((best, area))
    hit_area = sum(w for _, w in values)
    if not values or hit_area < sampled_area * 0.4:
        return None
    values.sort()
    half = hit_area * 0.5
    acc = 0.0
    for value, weight in values:
        acc += weight
        if acc >= half:
            return value
    return values[-1][0]


def coverage_gap(source_bm, verts, faces, samples=1500):
    import bisect
    import random
    from mathutils.bvhtree import BVHTree
    source_bvh = BVHTree.FromBMesh(source_bm)
    projected = []
    for co in verts:
        hit = source_bvh.find_nearest(Vector(co))
        projected.append(hit[0] if hit[0] is not None else Vector(co))
    result_bvh = BVHTree.FromPolygons(projected, faces, all_triangles=False)
    tris = []
    for f in sorted(source_bm.faces, key=lambda f: f.index):
        vs = [v.co for v in f.verts]
        for k in range(1, len(vs) - 1):
            area = (vs[k] - vs[0]).cross(vs[k + 1] - vs[0]).length * 0.5
            if area > 0.0:
                tris.append((vs[0], vs[k], vs[k + 1], area))
    if not tris:
        return float("inf")
    cumulative = []
    total = 0.0
    for t in tris:
        total += t[3]
        cumulative.append(total)
    rng = random.Random(1729)
    gaps = []
    for _ in range(samples):
        a, b, c, _area = tris[min(len(tris) - 1, bisect.bisect_left(cumulative, rng.random() * total))]
        u = rng.random()
        v = rng.random()
        if u + v > 1.0:
            u, v = 1.0 - u, 1.0 - v
        hit = result_bvh.find_nearest(a + (b - a) * u + (c - a) * v)
        gaps.append(hit[3] if hit[0] is not None else float("inf"))
    gaps.sort()
    return gaps[int(len(gaps) * 0.98)]


def surface_area(bm):
    return sum(f.calc_area() for f in bm.faces)


def bbox_diag_of(bm):
    if not bm.verts:
        return 1.0
    xs = [v.co.x for v in bm.verts]
    ys = [v.co.y for v in bm.verts]
    zs = [v.co.z for v in bm.verts]
    return math.sqrt((max(xs) - min(xs)) ** 2 + (max(ys) - min(ys)) ** 2 + (max(zs) - min(zs)) ** 2) or 1.0


def dominant_material(bm):
    counts = {}
    for f in bm.faces:
        counts[f.material_index] = counts.get(f.material_index, 0) + 1
    if not counts:
        return 0
    return max(sorted(counts), key=lambda k: counts[k])


def predecimate(bm, max_faces):
    if len(bm.faces) <= max_faces:
        return bm, False
    mesh = bpy.data.meshes.new("FastRemesher_PreDecimate")
    bm.to_mesh(mesh)
    obj = bpy.data.objects.new("FastRemesher_PreDecimate", mesh)
    bpy.context.scene.collection.objects.link(obj)
    try:
        mod = obj.modifiers.new("decimate", "DECIMATE")
        mod.ratio = max(0.001, max_faces / float(len(bm.faces)))
        mod.use_collapse_triangulate = True
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        out = bmesh.new()
        out.from_object(evaluated, depsgraph)
    finally:
        bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.meshes.remove(mesh)
    bm.free()
    return out, True


def voxel_proxy(bm, edge):
    mesh = bpy.data.meshes.new("FastRemesher_Voxel")
    bm.to_mesh(mesh)
    obj = bpy.data.objects.new("FastRemesher_Voxel", mesh)
    bpy.context.scene.collection.objects.link(obj)
    try:
        diag = bbox_diag_of(bm)
        mod = obj.modifiers.new("voxel", "REMESH")
        mod.mode = "VOXEL"
        mod.voxel_size = max(edge * 0.5, diag / 600.0)
        mod.adaptivity = 0.0
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        out = bmesh.new()
        out.from_object(evaluated, depsgraph)
    finally:
        bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.meshes.remove(mesh)
    return out


class Island:
    def __init__(self, index, bm, target, open_boundary, material_index):
        self.index = index
        self.bm = bm
        self.target = target
        self.open_boundary = open_boundary
        self.material_index = material_index
        self.faces = []
        self.attempt = 0
        self.level = 0
        self.transient_retries = 0
        self.job = None
        self.result = None
        self.kept = False
        self.local_edge = None
        self.notes = []


class RemeshTask:
    def __init__(self, obj, mode, density, max_solve_faces, feature_angle_deg=35.0, auto_cleanup=True):
        self.obj = obj
        self.mode = mode
        self.density = density
        self.max_solve_faces = max_solve_faces
        self.feature_angle = math.radians(feature_angle_deg)
        self.auto_cleanup = auto_cleanup
        self.state = "new"
        self.step = "Preparing"
        self.progress = 0.0
        self.islands = []
        self.queue = []
        self.running = []
        self.tmpdir = None
        self.binary = None
        self.started = time.monotonic()
        self.report = {"warnings": [], "notes": []}
        self.source_bm = None
        self.base_bm = None
        self.cancelled = False
        self.error = None

    def prepare(self):
        self.binary = solver.require_binary()
        obj = self.obj
        self.report["faces_before"] = len(obj.data.polygons)
        self.report["before"] = metrics.topology(obj.data)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        self.matrix = obj.matrix_world.copy()
        bm = world_bmesh(obj, self.matrix)
        diag = bbox_diag_of(bm)
        self.diag = diag
        if self.auto_cleanup:
            self.report["cleanup"] = cleanup_bmesh(bm, diag)
        self.source_bm = bm.copy()
        if not bm.faces:
            raise RemeshError("The mesh has no faces left after cleanup.", "Check that the object contains real surfaces, not only loose edges or points.")
        bm, decimated = predecimate(bm, self.max_solve_faces)
        self.report["predecimated"] = decimated
        total_area = surface_area(bm)
        if total_area <= 0.0:
            raise RemeshError("The mesh has zero surface area.", "Apply the object's scale and make sure the mesh is not flattened to a point or line.")
        total_target = target_faces_for(total_area, diag, self.density)
        self.report["target_faces"] = total_target
        self.tmpdir = tempfile.mkdtemp(prefix="fast_remesher_")
        comps = islands(bm)
        self.report["islands"] = len(comps)
        edge = diag * edge_fraction(self.density)
        self.edge = edge
        for i, comp in enumerate(comps):
            ibm = island_bmesh(bm, comp)
            area = surface_area(ibm)
            target = int(round(total_target * area / total_area))
            open_boundary = any(e.is_boundary for e in ibm.edges)
            isl = Island(i, ibm, target, open_boundary, dominant_material(ibm))
            isl.faces = comp
            isl.base_target = target
            self.islands.append(isl)
            if target < MIN_ISLAND_FACES:
                isl.kept = True
                continue
            if self.mode == "HARDSURFACE" and len(ibm.faces) <= target and already_clean(ibm):
                isl.kept = True
                isl.notes.append("already clean, tidied in place")
                continue
            thickness = island_thickness(ibm)
            if thickness is not None and thickness < edge * 1.5:
                local = max(thickness / 1.5, edge * 0.25)
                scaled = int(round(target * (edge / local) ** 2))
                if self.mode == "ORGANIC" and scaled > target * 4:
                    scaled = min(target * 4, self.max_solve_faces)
                    local = edge * math.sqrt(target / float(max(1, scaled)))
                elif scaled > target * 4 or scaled > self.max_solve_faces:
                    isl.kept = True
                    isl.notes.append("thin part, tidied in place")
                    continue
                isl.target = scaled
                isl.local_edge = local
            self.queue.append(isl)
        self.report["islands_kept"] = sum(1 for i in self.islands if i.kept)
        if not self.queue:
            self.report["warnings"].append("Nothing needed rebuilding at this Density, so the mesh was only tidied (triangles joined into quads). Raise Density or pick High Detail for a full rebuild.")
        self.report["islands_solved"] = len(self.queue)
        self.base_bm = bm
        self.state = "solving"
        self.total_jobs = max(1, len(self.queue))

    def _launch(self, isl):
        isl.attempt += 1
        if isl.level == 0:
            isl.level = 1
        base = os.path.join(self.tmpdir, "island_%05d_try%d" % (isl.index, isl.attempt))
        in_path = base + "_in.obj"
        out_path = base + "_out.obj"
        source = isl.bm
        crease = math.degrees(self.feature_angle) if self.mode == "HARDSURFACE" else None
        align = isl.open_boundary
        smooth = 2
        target = isl.target
        if isl.level == 2:
            crease = None
            target = max(MIN_ISLAND_FACES * 4, int(target * 2.5))
        if isl.level == 3 and isl.open_boundary:
            crease = None
            target = min(self.max_solve_faces, max(MIN_ISLAND_FACES * 4, int(target * 6)))
        elif isl.level == 3:
            edge = self.diag * edge_fraction(self.density)
            source = voxel_proxy(isl.bm, edge)
            align = False
            crease = None
            isl.notes.append("voxel rebuild")
        target = max(MIN_ISLAND_FACES, min(target, isl.base_target * 6))
        if source is isl.bm and len(isl.bm.faces) < target * 2:
            source = densify(isl.bm, (isl.local_edge or self.edge) * 0.5, max(200000, target * 16))
        write_obj(source, in_path)
        solve_faces = len(source.faces)
        if source is not isl.bm:
            source.free()
        request = max(8, int(round(target / 4.0)))
        cmd = solver.build_command(self.binary, in_path, out_path, request, crease, align, smooth)
        isl.job = solver.SolverJob(cmd, out_path, solver.timeout_for(solve_faces + target), "island %d" % isl.index, solver.stall_for(solve_faces + target))
        isl.job.start()
        self.running.append(isl)

    def tick(self):
        if self.state != "solving":
            return self.state
        while self.queue and len(self.running) < MAX_PARALLEL:
            self._launch(self.queue.pop(0))
        for isl in list(self.running):
            st = isl.job.poll()
            if st == "running":
                continue
            self.running.remove(isl)
            if st == "done":
                verts, faces = read_obj(isl.job.out_path)
                if faces:
                    gap = coverage_gap(isl.bm, verts, faces)
                    factor = 0.6 if self.mode == "HARDSURFACE" else 1.25
                    limit = max((isl.local_edge or self.edge) * factor, self.diag * 0.002)
                    if gap <= limit:
                        isl.result = (verts, faces)
                        continue
                    isl.job.error = "Rebuilt surface drifted from the original (%.3g > %.3g)" % (gap, limit)
                else:
                    isl.job.error = "Solver returned an empty mesh"
            isl.notes.append(isl.job.error.splitlines()[0][:160] if isl.job.error else "solver failed")
            if st != "done" and isl.transient_retries < 2:
                isl.transient_retries += 1
                retry = True
            elif isl.level < 3:
                isl.level += 1
                retry = True
            else:
                retry = False
            if retry and time.monotonic() - self.started < TIME_BUDGET:
                self.queue.insert(0, isl)
            else:
                isl.kept = True
                self.report["warnings"].append("Part %d could not be rebuilt, so it was tidied in place instead." % (isl.index + 1))
        done = sum(1 for i in self.islands if not i.kept and i.result is not None) + sum(1 for i in self.islands if i.kept and i.attempt > 0)
        partial = 0.0
        for isl in self.running:
            partial += min(0.95, isl.job.elapsed() / max(1.0, isl.job.timeout * 0.25))
        self.progress = min(0.97, (done + partial * 0.5) / float(self.total_jobs)) * 0.85
        if self.running:
            self.step = "%s (%d of %d parts)" % (self.running[0].job.stage(), min(self.total_jobs, done + 1), self.total_jobs)
        if not self.queue and not self.running:
            self.state = "assembling"
        return self.state

    def cancel(self):
        self.cancelled = True
        for isl in self.running:
            isl.job.kill()
        self.running = []
        self.queue = []
        self.state = "cancelled"
        self.cleanup()

    def _kept_geometry(self):
        kept_faces = set()
        for isl in self.islands:
            if isl.result is None:
                kept_faces.update(isl.faces)
        bm = self.base_bm
        self.base_bm = None
        bm.faces.ensure_lookup_table()
        drop = [f for f in bm.faces if f.index not in kept_faces]
        if drop:
            bmesh.ops.delete(bm, geom=drop, context="FACES")
        loose = [v for v in bm.verts if not v.link_faces]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context="VERTS")
        tris = [f for f in bm.faces if len(f.verts) == 3]
        if tris:
            bmesh.ops.join_triangles(
                bm, faces=tris, cmp_seam=True, cmp_sharp=True, cmp_uvs=True,
                cmp_vcols=True, cmp_materials=True,
                angle_face_threshold=math.radians(40.0),
                angle_shape_threshold=math.radians(40.0),
            )
        return bm

    def _solved_geometry(self, solved):
        bm = bmesh.new()
        for isl in solved:
            append_to_bmesh(bm, isl.result[0], isl.result[1], isl.material_index)
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=self.diag * 1e-7)
        bm.normal_update()
        mesh = bpy.data.meshes.new(self.obj.data.name + "_rebuilt")
        bm.to_mesh(mesh)
        bm.free()
        tmp_obj = bpy.data.objects.new("FastRemesher_Result", mesh)
        src_mesh = bpy.data.meshes.new("FastRemesher_Source")
        self.source_bm.to_mesh(src_mesh)
        src_obj = bpy.data.objects.new("FastRemesher_Source", src_mesh)
        try:
            self.report["snap"] = feature_snap.fit_to_source(
                tmp_obj, src_obj,
                feature_angle=self.feature_angle,
                snap_features=self.mode == "HARDSURFACE",
            )
            if self.mode == "HARDSURFACE":
                segments, _kinds, _corners = feature_snap.extract_features(src_obj, self.feature_angle, include_sharp=True)
                cbm = bmesh.new()
                cbm.from_mesh(mesh)
                cbm.normal_update()
                self.report["crease"] = crease.weld_creases(cbm, segments, self.report["snap"].get("edge_length", self.edge))
                cbm.to_mesh(mesh)
                cbm.free()
        finally:
            bpy.data.objects.remove(tmp_obj, do_unlink=True)
            bpy.data.objects.remove(src_obj, do_unlink=True)
            bpy.data.meshes.remove(src_mesh)
        mesh.transform(self.matrix.inverted())
        return mesh

    def finish(self):
        obj = self.obj
        original = obj.data
        solved = [isl for isl in self.islands if isl.result is not None]
        self.step = "Keeping unchanged parts"
        kept = self._kept_geometry()
        kept.transform(self.matrix.inverted())
        transfer = {}
        if solved:
            self.step = "Fitting to original surface"
            solved_mesh = self._solved_geometry(solved)
            self.step = "Transferring materials and UVs"
            self.progress = 0.92
            holder = obj.copy()
            holder.data = solved_mesh
            holder.modifiers.clear()
            bpy.context.scene.collection.objects.link(holder)
            try:
                transfer = surface_transfer.transfer_surface_data(holder, _source_proxy(obj, original))
            except Exception as exc:
                transfer = {"success": False, "error": str(exc)}
            finally:
                release_source_proxy(obj)
                bpy.data.objects.remove(holder, do_unlink=True)
            kept.from_mesh(solved_mesh)
            bpy.data.meshes.remove(solved_mesh)
        final = bpy.data.meshes.new(original.name + "_remeshed")
        kept.to_mesh(final)
        kept.free()
        for material in original.materials:
            final.materials.append(material)
        obj.data = final
        if self.source_bm is not None:
            self.source_bm.free()
            self.source_bm = None
        self.report["transfer"] = {k: v for k, v in transfer.items() if isinstance(v, (int, float, str, bool))} if isinstance(transfer, dict) else {}
        self.report["after"] = metrics.topology(obj.data)
        self.report["faces_after"] = len(obj.data.polygons)
        self.report["seconds"] = time.monotonic() - self.started
        self.report["notes"] = [n for isl in self.islands for n in isl.notes]
        self.cleanup()
        self.state = "done"
        self.progress = 1.0
        return original

    def cleanup(self):
        if self.tmpdir and os.path.isdir(self.tmpdir):
            shutil.rmtree(self.tmpdir, ignore_errors=True)
        self.tmpdir = None
        for isl in self.islands:
            if isl.bm is not None:
                isl.bm.free()
                isl.bm = None
        for name in ("base_bm", "source_bm"):
            bm = getattr(self, name, None)
            if bm is not None:
                bm.free()
                setattr(self, name, None)


def _source_proxy(obj, original_mesh):
    proxy = _SOURCE_PROXIES.get(obj.name)
    if proxy is not None and proxy.name in bpy.data.objects:
        bpy.data.objects.remove(proxy, do_unlink=True)
    proxy = obj.copy()
    proxy.data = original_mesh
    proxy.name = "FastRemesher_SourceProxy"
    proxy.modifiers.clear()
    bpy.context.scene.collection.objects.link(proxy)
    _SOURCE_PROXIES[obj.name] = proxy
    return proxy


_SOURCE_PROXIES = {}


def release_source_proxy(obj):
    proxy = _SOURCE_PROXIES.pop(obj.name, None)
    if proxy is not None:
        try:
            bpy.data.objects.remove(proxy, do_unlink=True)
        except ReferenceError:
            pass


def run_blocking(obj, mode, density, max_solve_faces, feature_angle_deg=35.0, auto_cleanup=True, poll_interval=0.05):
    task = RemeshTask(obj, mode, density, max_solve_faces, feature_angle_deg, auto_cleanup)
    try:
        task.prepare()
        while task.tick() == "solving":
            time.sleep(poll_interval)
        original = task.finish()
    except Exception:
        task.cancel()
        release_source_proxy(obj)
        raise
    release_source_proxy(obj)
    return task, original
