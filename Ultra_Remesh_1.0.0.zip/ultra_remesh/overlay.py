"""Ultra Remesh - the card of controls drawn into the viewport itself.

The look comes from Monster Remesh: a titled dark card with capsule buttons,
switches and sliders, drawn with `gpu` and `blf` over the 3D view, and a short
text tip that opens beside any control the pointer rests on. Here
it keeps the Remesh Ultimate look (dark card, blue cast) with orange
buttons, and carries the Ultra Remesh settings.

Monster Remesh's tutorial thumbnails and drawn tip animations are not used:
the tips here are text only, and the add-on carries no image files at all.

Three things are easy to get wrong:

* **Screen scale.** Everything is authored at 1x and multiplied by `ui_scale`
  at draw time; hit rects are tested in the same unscaled pixels.
* **Which corner a rectangle is given by.** Blender takes the bottom left while
  the card is laid out downwards from its top, so a row goes in at ``y - h``.
* **Letting go of events.** Only a pointer over the card swallows a click;
  anywhere else the event passes straight through to Blender.
"""

from __future__ import annotations

import math
import time

import blf
import bpy
import colorsys
import gpu
from gpu_extras.batch import batch_for_shader


# -- the look ---------------------------------------------------------------

CARD = (0.082, 0.094, 0.118, 0.97)       # dark with a cold, blue cast
EDGE = (0.55, 0.75, 1.0, 0.14)
CONTROL = (0.70, 0.82, 1.0, 0.065)
CONTROL_HOVER = (0.70, 0.82, 1.0, 0.13)
PICKED = (0.03, 0.09, 0.16, 1.0)
TRACK = (0.75, 0.85, 1.0, 0.16)
RULE = (0.75, 0.85, 1.0, 0.08)
TEXT = (0.910, 0.930, 0.960, 1.0)
TEXT_DIM = (0.470, 0.510, 0.570, 1.0)
ACCENT = (0.94, 0.53, 0.19, 1.0)
ACCENT_HOVER = (0.94, 0.65, 0.40, 1.0)
ON_ACCENT = (0.02, 0.06, 0.11, 1.0)
KNOB = (0.980, 0.985, 0.995, 1.0)

ACCENT_HUE = 0.075           # Ultra Remesh orange (the buttons)
ACCENT_SAT = 0.80
ACCENT_VAL = 0.94


def _ac(alpha=1.0):
    """The accent colour at a given strength."""
    return (ACCENT[0], ACCENT[1], ACCENT[2], alpha)


def accent_rgb(hue, sat):
    return colorsys.hsv_to_rgb(hue % 1.0, max(0.0, min(1.0, sat)), ACCENT_VAL)


def retint():
    """Build every accent-derived colour from the accent hue."""
    global ACCENT, ACCENT_HOVER, ON_ACCENT, PICKED
    r, g, b = accent_rgb(ACCENT_HUE, ACCENT_SAT)
    ACCENT = (r, g, b, 1.0)
    ACCENT_HOVER = accent_rgb(ACCENT_HUE, ACCENT_SAT * 0.70) + (1.0,)
    ON_ACCENT = (r * 0.10, g * 0.10, b * 0.12, 1.0)
    PICKED = (r * 0.20, g * 0.20, b * 0.24, 1.0)


def _prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return None


def _card_wanted():
    """False when the user picked the classic sidebar panel in Preferences."""
    p = _prefs()
    return bool(getattr(p, "use_card", True)) if p is not None else True


# Every button and value box is a capsule: the radius is far bigger than any
# control and _round_rect clamps it to half the height.
PILL = 1000.0
R_CARD = 14.0
R_CTL = PILL
R_BOX = PILL
R_LOGO = 7.0

CARD_W = 257.0
TAB_STRIP = 26.0          # the sidebar collapsed to its tabs alone
PAD = 14.0
GAP = 8.0
ROW = 30.0
TAB = "Ultra Remesh"

_state = {
    "open": set(),
    "tip": None,          # (widget index, key, when the pointer settled)
    "ticking": False,
    "handle": None,
    "modal": False,
    "quit": False,
    "widgets": [],
    "hover": None,
    "drag": None,
    "note": None,         # a line the card says back, and when
    "painted": 0.0,
    "beat": 0.0,
    "drawn": 0.0,
    "asked": 0.0,
    "cost": 0.02,
    "dirty": False,
    "was_up": False,
    "typing": None,
    "scroll": 0.0,
    "over": 0.0,
}


def _visible(context, area=None):
    """The card is up exactly when our own tab in the sidebar is."""
    if not _card_wanted():
        return False
    if area is None:
        area = getattr(context, "area", None)
    if area is None or area.type != "VIEW_3D":
        return False
    space = area.spaces.active
    if not getattr(space, "show_region_ui", False):
        return False
    for region in area.regions:
        if region.type == "UI":
            if region.width < 60:
                return False
            return getattr(region, "active_panel_category", "") == TAB
    return False


# -- drawing ----------------------------------------------------------------

def _round_rect(x, y, w, h, r, steps=5):
    """Triangles for a rounded rectangle, as one fan around its middle."""
    r = max(0.0, min(r, w * 0.5, h * 0.5))
    pts = []
    corners = ((x + w - r, y + h - r, 0.0),
               (x + r, y + h - r, math.pi * 0.5),
               (x + r, y + r, math.pi),
               (x + w - r, y + r, math.pi * 1.5))
    for cx, cy, a0 in corners:
        for i in range(steps + 1):
            a = a0 + (math.pi * 0.5) * (i / steps)
            pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    mid = (x + w * 0.5, y + h * 0.5)
    tris = []
    for i in range(len(pts)):
        tris.extend((mid, pts[i], pts[(i + 1) % len(pts)]))
    return tris


def _fill(shader, x, y, w, h, r, color):
    if w <= 0.0 or h <= 0.0:
        return
    batch = batch_for_shader(shader, "TRIS",
                             {"pos": _round_rect(x, y, w, h, r)})
    shader.uniform_float("color", color)
    batch.draw(shader)


# 1.13.2: smaller, lighter type everywhere on the card (layout sizes unchanged)
FONT_SCALE = 0.86


def _text(s, x, y, size, color, scale, right=None, mid=None, bold=False):
    # `bold` is accepted for old callers but ignored: no faux-bold double draw
    fs = size * FONT_SCALE
    blf.size(0, fs * scale)
    blf.color(0, *color)
    if right is not None or mid is not None:
        tw, _ = blf.dimensions(0, s)
        x = (right - tw) if right is not None else (mid - tw * 0.5)
    # keep the smaller text optically centred where the bigger one sat
    y = y + (size - fs) * 0.35 * scale
    blf.position(0, x, y, 0)
    blf.draw(0, s)


# -- what a control means --------------------------------------------------
#
# Rest on a control for a moment and a small text card opens beside the panel
# saying what it does. Text only: no pictures, no drawings.

TIP_DELAY = 0.55
TIP_W = 244.0

TIPS = {
    "remesh": ("Remesh",
               "Builds a clean quad mesh from the active object with the "
               "QRemesh engine. The original is kept, hidden.", ""),
    "compare": ("Compare",
                "Switches between the original and the remeshed result.", ""),
    "revert": ("Revert",
               "Deletes the remeshed result and shows the original again.", ""),
    "faces": ("Target quads",
              "About how many quads the result will have.", ""),
    "half": ("Half", "Halves the target quad count.", ""),
    "same": ("Same",
             "Target quads = the face count of the selected object, so the "
             "result keeps the same density.", ""),
    "double": ("Double", "Doubles the target quad count.", ""),
    "adaptive": ("Size variation",
                 "0 = every quad the same size. 1 = small quads on curves "
                 "and big ones on flat areas.", ""),
    "smooth": ("Smooth",
               "Relax passes that even out the quads on the surface.", ""),
    "m_v2": ("QRemesh 2",
             "Edge loops follow the curvature; poles only where the form "
             "needs them. The default.", ""),
    "m_legacy": ("Legacy",
                 "The older field-aligned method (Instant Meshes style).", ""),
    "symmetry": ("Symmetry",
                 "Remeshes one half and mirrors it, welded on the seam. A model "
                 "that is not symmetric is remeshed whole.", ""),
    "symauto": ("Auto plane",
                "Finds the mirror plane from the model itself.", ""),
    "symcenter": ("Mirror center",
                  "Where the mirror plane sits on the axis, in object space.", ""),
    "sharp": ("Keep hard edges",
              "Faces meeting at a strong angle get an edge loop along the crease.", ""),
    "groups": ("Follow materials",
               "Edge loops run along the borders between materials and the "
               "result keeps the materials.", ""),
    "paint": ("Density from paint",
              "Active color attribute: red asks for up to 4x the quads, blue "
              "for down to a quarter.", ""),
    "mods": ("Apply modifiers",
             "Remesh the object as it looks with its modifiers. The original "
             "is not changed.", ""),
    "hideorig": ("Hide original",
                 "Hides the original once the result is made.", ""),
    "quality": ("Quality report",
                "Counts poles and corner angles and measures the distance to "
                "the original.", ""),
    "seed": ("Seed",
             "Legacy method only: a different seed gives a slightly different "
             "layout.", ""),
}


def _wrap(text, width, size, scale):
    blf.size(0, size * FONT_SCALE * scale)
    out = []
    line = ""
    for word in text.split():
        probe = (line + " " + word).strip()
        if blf.dimensions(0, probe)[0] > width * scale and line:
            out.append(line)
            line = word
        else:
            line = probe
    if line:
        out.append(line)
    return out[:4]




def _draw_tip(shader, card, scale):
    tip = _state["tip"]
    if tip is None:
        return
    index, key, since = tip
    waited = time.time() - since
    if waited < TIP_DELAY:
        return
    found = TIPS.get(key)
    widgets = _state["widgets"]
    if not found or index >= len(widgets):
        return
    title, body = found[0], found[1]
    wx, wy, ww, wh = widgets[index]["rect"]
    # blf leaves its own blend state behind, and the tip is drawn after the
    # text - without setting it back, every translucent fill here lands opaque
    # and the whole drawing came out as one white square.
    gpu.state.blend_set("ALPHA")
    shader.bind()

    lines = _wrap(body, TIP_W - 24.0, 11, scale)
    h = 16.0 + 16.0 + 6.0 + len(lines) * 15.0 + 4.0
    x = card[0] - TIP_W - 10.0
    y = min(max(wy + wh - h, 20.0), card[1] + card[3] - h)

    _fill(shader, (x - 1.0) * scale, (y - 1.0) * scale, (TIP_W + 2.0) * scale,
          (h + 2.0) * scale, 13.0 * scale, EDGE)
    _fill(shader, x * scale, y * scale, TIP_W * scale, h * scale,
          12.0 * scale, CARD)

    ty = y + h - 24.0
    _text(title, (x + 12.0) * scale, ty * scale, 12, TEXT, scale, bold=True)
    ty -= 17.0
    for line in lines:
        _text(line, (x + 12.0) * scale, ty * scale, 11, TEXT_DIM, scale)
        ty -= 15.0


def _settle():
    """Pay back a repaint the throttle skipped.

    Blender stops sending mouse moves the moment the pointer stops, so the
    last move of a sweep is often the one the throttle drops - and the
    highlight would then sit on the row before the one under the pointer until
    something else happened to force a paint.
    """
    if not _state["dirty"] or _state["quit"]:
        _state["dirty"] = False
        return None
    _state["dirty"] = False
    _state["painted"] = time.time()
    _state["asked"] = _state["painted"]
    for win in bpy.context.window_manager.windows:
        for a in win.screen.areas:
            if a.type == "VIEW_3D":
                a.tag_redraw()
    return None


def _tick():
    """Paint once when the pointer has rested long enough for the tip."""
    _state["ticking"] = False
    if _state["quit"] or _state["tip"] is None:
        return None
    for win in bpy.context.window_manager.windows:
        for a in win.screen.areas:
            if a.type == "VIEW_3D":
                a.tag_redraw()
    return None


# What to say when an action will not run.
WHY = {
    "ultra_remesh.remesh": "Select a mesh object in Object Mode to remesh.",
    "ultra_remesh.compare":
        "Compare needs a remeshed result - select the result or its original.",
    "ultra_remesh.revert":
        "Nothing to revert - there is no result behind this object.",
    "ultra_remesh.scale_target": "Select a mesh object.",
    "ultra_remesh.same_target": "Select a mesh object to copy its face count.",
}

# -- what the card holds ----------------------------------------------------

def _settings(context):
    return getattr(context.scene, "ultra_remesh", None)


def _pkg():
    import sys
    return sys.modules.get(__package__)


def _build(context, region):
    """Lay the card out and return its widgets, in unscaled pixels."""
    st = _settings(context)
    if st is None:
        return [], (0.0, 0.0, 0.0, 0.0)
    pkg = _pkg()

    scale = context.preferences.system.ui_scale or 1.0
    heads = 0.0
    area = getattr(context, "area", None)
    if area is not None:
        for r in area.regions:
            if r.type in {"HEADER", "TOOL_HEADER"}:
                heads += r.height
    x = region.width / scale - TAB_STRIP - CARD_W
    top = (region.height - heads) / scale - 6.0

    w = []
    inner = CARD_W - PAD * 2.0
    left = x + PAD
    y = [top - PAD + _state["scroll"]]

    def put(kind, h, gap=GAP, **kw):
        kw["kind"] = kind
        kw["rect"] = (left, y[0] - h, inner, h)
        w.append(kw)
        y[0] -= h + gap
        return kw

    def section(text):
        put("section", 16.0, gap=4.0, text=text)

    def chips(owner, prop, items, h=30.0, shares=None):
        """One capsule per enum choice: (label, code, tip)."""
        n = len(items)
        shares = shares or [1.0] * n
        room = inner - 6.0 * (n - 1)
        cur = getattr(owner, prop)
        cx = left
        for (name, code, tip), share in zip(items, shares):
            cw = room * share / sum(shares)
            w.append({"kind": "chip", "rect": (cx, y[0] - h, cw, h),
                      "text": name, "on": cur == code, "tip": tip,
                      "act": ("enum", (owner, prop, code))})
            cx += cw + 6.0
        y[0] -= h + GAP

    def toggles(owner, items, h=30.0):
        """One capsule per on/off property: (label, prop, tip)."""
        n = len(items)
        cw = (inner - 6.0 * (n - 1)) / n
        for k, (name, prop, tip) in enumerate(items):
            w.append({"kind": "chip", "rect": (left + k * (cw + 6.0), y[0] - h, cw, h),
                      "text": name, "on": bool(getattr(owner, prop)), "tip": tip,
                      "act": ("prop", (owner, prop))})
        y[0] -= h + GAP

    def switch(text, owner, prop, tip=None):
        if hasattr(owner, prop):
            put("switch", 34.0, gap=0.0, text=text, tip=tip,
                on=bool(getattr(owner, prop)), act=("prop", (owner, prop)))

    def field(text, owner, prop, lo, hi, decimals=0, suffix="", tip=None,
              mul=1.0):
        """A value box over a slider. `mul` converts what is stored into
        what is shown (radians into degrees)."""
        if not hasattr(owner, prop):
            return
        val = getattr(owner, prop) * mul
        shown = (f"{int(round(val)):,}" if not decimals
                 else f"{val:.{decimals}f}")
        put("field", 26.0, gap=6.0, text=text, shown=shown + suffix, tip=tip,
            act=("type", (owner, prop, lo, hi, decimals, mul)))
        put("bar", 14.0, value=val, lo=lo, hi=hi, decimals=decimals, tip=tip,
            act=("slide", (owner, prop, mul)))

    def button(text, idname, kind="btn", h=ROW, tip=None):
        put(kind, h, text=text, tip=tip, act=("op", idname))

    def row(items, kind="tool"):
        n = len(items)
        cw = (inner - 6.0 * (n - 1)) / n
        for k, item in enumerate(items):
            name, act = item[0], item[1]
            tip = item[2] if len(item) > 2 else None
            if isinstance(act, str):
                act = ("op", act)
            w.append({"kind": kind,
                      "rect": (left + k * (cw + 6.0), y[0] - ROW, cw, ROW),
                      "text": name, "tip": tip, "act": act})
        y[0] -= ROW + GAP

    def note_line(text, color=None, size=11):
        for line in _wrap(text, inner, size, scale):
            w.append({"kind": "label", "rect": (left, y[0] - 12.0, 0, 0),
                      "text": line, "size": size,
                      "color": TEXT_DIM if color is None else color})
            y[0] -= 15.0

    def fold(key, text):
        open_ = key in _state["open"]
        put("fold", ROW, text=text, on=open_, act=("fold", key))
        return open_

    def rule():
        put("rule", 1.0, gap=GAP + 2.0)

    # header ---------------------------------------------------------------
    w.append({"kind": "logo", "rect": (left, y[0] - 26.0, 26.0, 26.0)})
    w.append({"kind": "title", "rect": (left + 36.0, y[0] - 19.0, 0, 0),
              "text": "ULTRA REMESH"})
    ver = getattr(pkg, "VERSION_STR", "")
    if ver:
        w.append({"kind": "version", "rect": (left + inner, y[0] - 18.0, 0, 0),
                  "text": ver})
    y[0] -= 26.0 + GAP + 2.0

    running = bool(getattr(pkg, "_running", {}).get("on")) if pkg else False
    if running:
        put("running", 38.0, text=getattr(pkg, "WAIT_TEXT", "Aguarde... Processando..."),
            frac=0.0)
    else:
        button("Remesh", "ultra_remesh.remesh", "run", 38.0, tip="remesh")
    row((("Compare", "ultra_remesh.compare", "compare"),
         ("Revert", "ultra_remesh.revert", "revert")))

    ob = context.active_object
    if ob is not None and "ur_report" in ob:
        for part in str(ob["ur_report"]).split(" | "):
            if part.strip():
                note_line(part.strip())
        y[0] -= 4.0

    section("TARGET")
    field("Target quads", st, "target_faces", 100, 50000, tip="faces")
    row((("Half", ("opargs", ("ultra_remesh.scale_target",
                              {"factor": 0.5})), "half"),
         ("Same", "ultra_remesh.same_target", "same"),
         ("Double", ("opargs", ("ultra_remesh.scale_target",
                                {"factor": 2.0})), "double")))
    field("Size variation", st, "adaptive", 0.0, 1.0, 2, tip="adaptive")
    field("Smooth", st, "smooth", 0, 30, tip="smooth")
    y[0] -= GAP

    section("METHOD")
    chips(st, "method", (("QRemesh 2", "V2", "m_v2"),
                         ("Legacy", "LEGACY", "m_legacy")))

    section("SYMMETRY")
    chips(st, "symmetry", (("Off", "NONE", "symmetry"),
                           ("X", "X", "symmetry"),
                           ("Y", "Y", "symmetry"),
                           ("Z", "Z", "symmetry")),
          shares=(1.2, 1.0, 1.0, 1.0))
    if st.symmetry != "NONE":
        switch("Auto plane", st, "symmetry_auto", tip="symauto")
        if not st.symmetry_auto:
            y[0] -= GAP
            field("Mirror center", st, "symmetry_center", -10.0, 10.0, 3,
                  tip="symcenter")
        y[0] -= GAP

    section("EDGE FLOW")
    switch("Keep hard edges", st, "detect_edges", tip="sharp")
    switch("Follow materials", st, "keep_groups", tip="groups")
    switch("Density from paint", st, "use_vertex_paint", tip="paint")
    y[0] -= GAP

    section("RESULT")
    switch("Apply modifiers", st, "use_modifiers", tip="mods")
    switch("Hide original", st, "hide_original", tip="hideorig")
    switch("Quality report", st, "measure_quality", tip="quality")
    y[0] -= GAP

    if st.method == "LEGACY":
        rule()
        field("Seed", st, "seed", 0, 9999, tip="seed")

    note = _state.get("note")
    if note is not None and time.time() - note[1] < 6.0:
        note_line(note[0], ACCENT)
        y[0] -= 3.0
    bottom = y[0] - PAD
    full = (top + PAD - bottom) + _state["scroll"]
    room = top + PAD - 6.0
    _state["over"] = max(0.0, full - room)
    shown = min(full, room)
    card = (x, top + PAD - shown, CARD_W, shown)
    return w, card

def _typing_here(it):
    """Is this the number box that is open for typing?"""
    t = _state["typing"]
    if t is None or it.get("kind") != "field":
        return False
    act = it.get("act")
    if not act or act[0] != "type":
        return False
    if act[1][1] != t["prop"]:
        return False
    # Blender hands back a fresh Python wrapper for the same settings block on
    # every access, so `is` says no even when it is the same block. Comparing
    # what they point at is the only test that holds - without it the box drew
    # as if nothing was happening and typing looked dead.
    try:
        return act[1][0].as_pointer() == t["owner"].as_pointer()
    except Exception:
        return False


def _stop_typing(context, apply):
    """Close the box, keeping what was typed or throwing it away."""
    t = _state["typing"]
    _state["typing"] = None
    if t is None:
        return
    if apply and t["text"].strip() not in ("", "-", ".", "-."):
        try:
            val = float(t["text"])
        except ValueError:
            val = None
        if val is not None:
            val = val / (t.get("mul") or 1.0)
            # A typed number is held to what the setting really permits,
            # not to the narrower range that is comfortable to drag.
            mul = t.get("mul") or 1.0
            lo, hi = t["lo"] / mul, t["hi"] / mul
            try:
                rna = t["owner"].bl_rna.properties[t["prop"]]
                lo, hi = rna.hard_min, rna.hard_max
            except Exception:
                pass
            val = min(max(val, lo), hi)
            try:
                cur = getattr(t["owner"], t["prop"])
                is_int = isinstance(cur, int) and not isinstance(cur, bool)
                setattr(t["owner"], t["prop"],
                        int(round(val)) if is_int else float(val))
            except Exception:
                pass
    _redraw(context, getattr(context, "area", None))


def _hit(widgets, mx, my):
    for i, it in enumerate(widgets):
        # "field" is the words and the number above a slider. It is not a
        # control - it has nothing to press - but it is the part of the row
        # the pointer actually lands on, so it has to be reachable or the
        # explanation on it can never be seen.
        if it["kind"] in {"label", "logo", "title", "section", "rule", "version"}:
            continue
        x, y, w, h = it["rect"]
        if x <= mx <= x + w and y <= my <= y + h:
            return i
    return None


def _draw():
    context = bpy.context
    region = context.region
    if region is None or not _visible(context):
        return
    widgets, card = _build(context, region)
    if not widgets:
        return
    if _state["typing"] is not None and not any(_typing_here(w) for w in widgets):
        _state["typing"] = None
    # Every 3D view draws its own card, laid out for its own width. With the
    # viewport split in two, the second one drawn used to overwrite the first
    # one's buttons, and clicks were tested against the wrong card. So each
    # keeps its own, and the shared copy is the one the pointer is over.
    key = region.as_pointer()
    _state.setdefault("regions", {})[key] = (widgets, card)
    if _state.get("hot") in (None, key) or _state.get("hot") not in _state["regions"]:
        _state["hot"] = key
        _state["widgets"] = widgets
        _state["card"] = card
    now = time.time()
    # How long the machine took to answer the last repaint we asked for. On a
    # light scene this is a millisecond or two; on a 200k face garment it is
    # fifteen, and asking twenty times a second for that is what made the
    # pointer feel heavy. Measured rather than guessed, because it is the
    # scene that decides, not us.
    if _state["asked"]:
        _state["cost"] = _state["cost"] * 0.7 + (now - _state["asked"]) * 0.3
        _state["asked"] = 0.0
    _state["drawn"] = now

    scale = context.preferences.system.ui_scale or 1.0
    hover = _state["hover"] if _state.get("hot") == key else None
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    shader.bind()

    def box(rect, r, color):
        x, y, w, h = rect
        _fill(shader, x * scale, y * scale, w * scale, h * scale, r * scale,
              color)

    def ring(rect, r, color, t=1.0, inside=None):
        """A border, drawn as the card colour punched out of a filled rect."""
        x, y, w, h = rect
        _fill(shader, x * scale, y * scale, w * scale, h * scale, r * scale,
              color)
        _fill(shader, (x + t) * scale, (y + t) * scale, (w - t * 2) * scale,
              (h - t * 2) * scale, max(0.0, r - t) * scale,
              inside if inside is not None else CARD)

    cx, cy, cw, ch = card
    _fill(shader, (cx - 1.0) * scale, (cy - 1.0) * scale, (cw + 2.0) * scale,
          (ch + 2.0) * scale, (R_CARD + 1.0) * scale, EDGE)
    _fill(shader, cx * scale, cy * scale, cw * scale, ch * scale,
          R_CARD * scale, CARD)

    # Rows scrolled past the top or the bottom must not paint over the
    # viewport. The scissor is set to the frame for the whole of the contents
    # and put back afterwards, so the tip drawn later is not clipped by it.
    clipped = _state["over"] > 0.0
    if clipped:
        gpu.state.scissor_test_set(True)
        gpu.state.scissor_set(int(cx * scale) - 2, int(cy * scale) - 2,
                              int(cw * scale) + 4, int(ch * scale) + 4)

    for i, it in enumerate(widgets):
        k = it["kind"]
        x, y, w, h = it["rect"]
        lit = (i == hover)
        if k == "logo":
            box(it["rect"], R_LOGO, ACCENT)
            # A grid, not four blocks. The mark has to say what the add-on
            # makes, and four filled squares said "app icon" while the thing
            # under them is a quad mesh - so it is drawn as the wires.
            span = 16.0
            t = 1.6
            ox = x + (w - span) * 0.5
            oy = y + (h - span) * 0.5
            for k2 in range(4):
                at = k2 * (span - t) / 3.0
                _fill(shader, ox * scale, (oy + at) * scale, span * scale,
                      t * scale, 0.0, ON_ACCENT)
                _fill(shader, (ox + at) * scale, oy * scale, t * scale,
                      span * scale, 0.0, ON_ACCENT)
        elif k == "chip":
            if it["on"]:
                ring(it["rect"], R_CTL, ACCENT, 1.0, inside=PICKED)
            else:
                box(it["rect"], R_CTL, CONTROL_HOVER if lit else CONTROL)
        elif k == "playbtn":
            # Quiet at rest. It is a link to a video, not something the card
            # wants pressed, so it only comes up under the pointer.
            if lit:
                box(it["rect"], R_CTL, CONTROL_HOVER)
            bx = (x + 9.5) * scale
            by = (y + 7.5) * scale
            side = 11.0 * scale
            batch = batch_for_shader(shader, "TRIS", {"pos": (
                (bx, by), (bx, by + side),
                (bx + side * 0.88, by + side * 0.5))})
            shader.uniform_float("color", ACCENT if lit else TEXT_DIM)
            batch.draw(shader)
        elif k == "play":
            # Same manners as the one in the header: a link, drawn quietly,
            # that only lights up when the pointer is on it.
            if lit:
                _fill(shader, (x - 4.0) * scale, y * scale,
                      (w + 8.0) * scale, h * scale, R_CTL * scale,
                      CONTROL_HOVER)
            bx = (x + 4.0) * scale
            by = (y + 8.0) * scale
            side = 10.0 * scale
            batch = batch_for_shader(shader, "TRIS", {"pos": (
                (bx, by), (bx, by + side),
                (bx + side * 0.88, by + side * 0.5))})
            shader.uniform_float("color", ACCENT if lit else TEXT_DIM)
            batch.draw(shader)
        elif k == "switch":
            _fill(shader, x * scale, y * scale, w * scale, 1.0 * scale, 0.0,
                  RULE)
            kx = (x + w - 30.0) * scale
            ky = (y + (h - 17.0) * 0.5) * scale
            _fill(shader, kx, ky, 30.0 * scale, 17.0 * scale, 8.5 * scale,
                  ACCENT if it["on"] else TRACK)
            knob = kx + (14.5 if it["on"] else 2.0) * scale
            _fill(shader, knob, ky + 2.0 * scale, 13.0 * scale, 13.0 * scale,
                  6.5 * scale, ON_ACCENT if it["on"] else KNOB)
        elif k == "field":
            if _typing_here(it):
                # a border, not a filled block: the inside has to be opaque or
                # the accent shows straight through it and the whole box reads
                # as one solid orange slab
                ring((x + w - 84.0, y, 84.0, h), R_BOX, ACCENT, 1.5,
                     inside=CARD)
            else:
                box((x + w - 84.0, y, 84.0, h), R_BOX, CONTROL)
        elif k == "bar":
            ty = y + (h - 5.0) * 0.5
            _fill(shader, x * scale, ty * scale, w * scale, 5.0 * scale,
                  2.5 * scale, TRACK)
            span = float(it["hi"] - it["lo"]) or 1.0
            frac = max(0.0, min(1.0, (it["value"] - it["lo"]) / span))
            _fill(shader, x * scale, ty * scale, w * frac * scale,
                  5.0 * scale, 2.5 * scale, ACCENT)
            _fill(shader, (x + w * frac - 7.0) * scale, (ty - 4.5) * scale,
                  14.0 * scale, 14.0 * scale, 7.0 * scale, ACCENT)
        elif k == "rule":
            _fill(shader, x * scale, y * scale, w * scale, 1.0 * scale, 0.0,
                  RULE)
        elif k == "run":
            box(it["rect"], R_CTL, ACCENT_HOVER if lit else ACCENT)
        elif k == "running":
            # the button itself becomes the bar: the track, then the part done
            box(it["rect"], R_CTL, CONTROL)
            done = max(0.0, min(1.0, it["frac"]))
            if done > 0.0:
                box((x, y, max(h, w * done), h), R_CTL, ACCENT)
        elif k == "ghost":
            ring(it["rect"], R_CTL, ACCENT, 1.0,
                 inside=CONTROL_HOVER if lit else CARD)
        elif k in {"btn", "tool", "fold"}:
            box(it["rect"], R_CTL, CONTROL_HOVER if lit else CONTROL)

    for it in widgets:
        k = it["kind"]
        x, y, w, h = it["rect"]
        if k == "title":
            _text(it["text"], x * scale, y * scale, 15, TEXT, scale, bold=True)
        elif k == "version":
            _text(it["text"], 0, y * scale, 10, TEXT_DIM, scale,
                  right=x * scale)
        elif k == "label":
            _text(it["text"], x * scale, y * scale, it["size"], it["color"],
                  scale)
        elif k == "section":
            _text(it["text"], x * scale, (y + 3.0) * scale, 10, TEXT_DIM,
                  scale)
        elif k == "chip":
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 12,
                  TEXT if it["on"] else TEXT_DIM, scale,
                  mid=(x + w * 0.5) * scale)
        elif k == "play":
            lit = (widgets.index(it) == hover)
            _text(it["text"], (x + 22.0) * scale, (y + 8.0) * scale, 12,
                  TEXT if lit else TEXT_DIM, scale)
        elif k == "switch":
            _text(it["text"], x * scale, (y + (h - 11.0) * 0.5) * scale, 12,
                  TEXT if it["on"] else TEXT_DIM, scale)
        elif k == "field":
            _text(it["text"], x * scale, (y + 8.0) * scale, 12, TEXT, scale)
            if _typing_here(it):
                caret = "|" if int(time.time() * 2) % 2 else " "
                _text(_state["typing"]["text"] + caret, 0, (y + 8.0) * scale,
                      12, ACCENT, scale, right=(x + w - 12.0) * scale)
            else:
                _text(it["shown"], 0, (y + 8.0) * scale, 12, TEXT, scale,
                      right=(x + w - 12.0) * scale)
        elif k == "fold":
            _text(">" if not it["on"] else "v", (x + 12.0) * scale,
                  (y + 9.0) * scale, 11, TEXT_DIM, scale)
            _text(it["text"], (x + 28.0) * scale, (y + 9.0) * scale, 12,
                  TEXT if it["on"] else TEXT_DIM, scale)
        elif k == "run":
            _text(it["text"], 0, (y + (h - 12.0) * 0.5) * scale, 13, ON_ACCENT,
                  scale, mid=(x + w * 0.5) * scale, bold=True)
        elif k == "running":
            _text(it["text"], 0, (y + (h - 12.0) * 0.5) * scale, 13, TEXT,
                  scale, mid=(x + w * 0.5) * scale, bold=True)
        elif k == "runline":
            _text(it["text"], 0, (y + 2.0) * scale, 10, TEXT_DIM, scale,
                  mid=(x + w * 0.5) * scale)
        elif k == "ghost":
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 12, ACCENT,
                  scale, mid=(x + w * 0.5) * scale)
        elif k in {"btn", "tool"}:
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 12, TEXT,
                  scale, mid=(x + w * 0.5) * scale)

    if clipped:
        gpu.state.scissor_test_set(False)
        # a hint that there is more, so the foot is not silently lost
        _fill(shader, (cx + cw * 0.5 - 14.0) * scale, (cy + 3.0) * scale,
              28.0 * scale, 3.0 * scale, 1.5 * scale, _ac(0.55))

    _draw_tip(shader, card, scale)
    gpu.state.blend_set("NONE")


# -- the operator that gives it a mouse -------------------------------------

def _redraw(context, area=None):
    """Ask for a repaint - of one area where we know which one.

    A repaint is not cheap: Blender redraws the whole 3D view, model and all,
    to move a highlight by one row. On a 197k face garment that is what the
    pointer felt like it was dragging. So only the area under the pointer is
    asked, and only when something actually changed.
    """
    hot = _state.get("hot_area")
    if hot is not None:
        for win in bpy.context.window_manager.windows:
            for a in win.screen.areas:
                if a.as_pointer() == hot:
                    a.tag_redraw()
                    return
    if area is not None:
        area.tag_redraw()
        return
    for a in context.screen.areas:
        if a.type == "VIEW_3D":
            a.tag_redraw()


def _run_op(context, idname, kwargs=None):
    mod, _, name = idname.partition(".")
    op = getattr(getattr(bpy.ops, mod, None), name, None)
    if op is None:
        return
    try:
        ready = op.poll()
    except Exception:
        ready = False
    obj = context.active_object
    # Polish is the one action that is meant to run from Edit Mode, so the
    # mode is only left when the action cannot run where it is.
    if not ready and obj is not None and obj.mode != "OBJECT":
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
            ready = op.poll()
        except Exception:
            ready = False
    if not ready:
        _state["note"] = (WHY.get(idname, "Select a mesh object first."),
                          time.time())
        return
    try:
        op("INVOKE_DEFAULT", **(kwargs or {}))
    except Exception as exc:
        _state["note"] = (str(exc)[:80], time.time())
        print("Ultra Remesh card:", exc)


def _fire(context, it, mx):
    kind, arg = it["act"]
    if kind == "enum":
        owner, name, code = arg
        setattr(owner, name, code)
    elif kind == "prop":
        owner, name = arg
        setattr(owner, name, not getattr(owner, name))
    elif kind == "fold":
        if arg in _state["open"]:
            _state["open"].discard(arg)
        else:
            _state["open"].add(arg)
    elif kind == "slide":
        owner, name, mul = arg
        x, y, w, h = it["rect"]
        frac = max(0.0, min(1.0, (mx - x) / max(1.0, w)))
        val = it["lo"] + frac * (it["hi"] - it["lo"])
        if not it.get("decimals"):
            val = round(val)
        val = val / (mul or 1.0)
        try:
            cur = getattr(owner, name)
            setattr(owner, name, int(round(val)) if isinstance(cur, int)
                    and not isinstance(cur, bool) else float(val))
        except Exception:
            pass
    elif kind == "opargs":
        idname, kwargs = arg
        _run_op(context, idname, kwargs)
    elif kind == "op":
        _run_op(context, arg)


class UR_OT_overlay(bpy.types.Operator):
    """Give the viewport card a mouse. Started on its own, never by hand."""

    bl_idname = "ultra_remesh.overlay"
    bl_label = "Viewport Card"
    bl_options = {"INTERNAL"}

    def modal(self, context, event):
        # One card, one modal. The keep-alive below starts a new one when it
        # has heard nothing for a few seconds - which is also what happens
        # when Blender simply sits in the background - and the old one was
        # still there. Found with 76 of them stacked up: every mouse move ran
        # the card's hit test 76 times, the sliders lagged behind the pointer
        # and felt dead. A copy that is not the newest now leaves quietly.
        if getattr(self, "_token", None) != _state.get("token"):
            return {"CANCELLED"}
        _state["beat"] = time.time()
        if _state["quit"]:
            _state["modal"] = False
            return {"CANCELLED"}
        # The pointer's own viewport. The modal belongs to whichever 3D view
        # it was started in, and Blender gives its coordinates relative to
        # that one - so in a split screen every click on the other card
        # landed hundreds of pixels away from where it was aimed. Held while
        # a slider is dragged or a number typed, so the pointer drifting over
        # the border does not swap cards half way.
        hot_area = None
        hot_region = None
        busy = _state["drag"] is not None or _state["typing"] is not None
        for a in context.window.screen.areas:
            if a.type != "VIEW_3D":
                continue
            for r in a.regions:
                if r.type != "WINDOW":
                    continue
                if busy:
                    if r.as_pointer() == _state.get("hot"):
                        hot_area, hot_region = a, r
                elif (r.x <= event.mouse_x < r.x + r.width
                        and r.y <= event.mouse_y < r.y + r.height):
                    hot_area, hot_region = a, r
        if hot_region is not None:
            key = hot_region.as_pointer()
            laid = _state.get("regions", {}).get(key)
            if laid is not None and key != _state.get("hot"):
                _state["hot"] = key
                _state["widgets"], _state["card"] = laid
                _state["hover"] = None
                _state["tip"] = None
            _state["hot_area"] = hot_area.as_pointer()
        if not _visible(context, hot_area):
            if _state["typing"] is not None:
                _stop_typing(context, False)
            if _state["hover"] is not None:
                _state["hover"] = None
                _state["drag"] = None
                _state["tip"] = None
            # Clicking another tab in the sidebar repaints the sidebar and
            # nothing else, so the card's own handler is never called again
            # and the last painting of it just stays on the screen. Blender's
            # panels vanish because they live in the region that was
            # repainted; the card does not, so it has to ask.
            if _state["was_up"]:
                _state["was_up"] = False
                _redraw(context, getattr(context, "area", None))
            return {"PASS_THROUGH"}
        if not _state["was_up"]:
            # Coming back to our tab repaints the sidebar and nothing else, so
            # without this the card waited for the next viewport redraw to
            # appear - a mouse move, or the timer below. That wait is what
            # read as the card opening late, or not at all until the sidebar
            # was closed and opened again.
            _state["was_up"] = True
            _redraw(context, getattr(context, "area", None))

        scale = context.preferences.system.ui_scale or 1.0
        if hot_region is not None:
            mx = (event.mouse_x - hot_region.x) / scale
            my = (event.mouse_y - hot_region.y) / scale
        else:
            mx = event.mouse_region_x / scale
            my = event.mouse_region_y / scale

        # A box open for typing owns the keyboard until it is closed, or a
        # digit would reach Blender as a shortcut and change the mode.
        if _state["typing"] is not None:
            if event.value != "PRESS":
                return {"RUNNING_MODAL"}
            if event.type in {"RET", "NUMPAD_ENTER"}:
                _stop_typing(context, True)
                return {"RUNNING_MODAL"}
            if event.type == "ESC":
                _stop_typing(context, False)
                return {"RUNNING_MODAL"}
            if event.type == "BACK_SPACE":
                t = _state["typing"]
                t["text"] = "" if t.get("fresh") else t["text"][:-1]
                t["fresh"] = False
                _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if event.type == "LEFTMOUSE":
                _stop_typing(context, True)   # clicking away keeps it
                return {"RUNNING_MODAL"}
            ch = event.ascii
            if ch and (ch.isdigit() or ch in "-."):
                # The box opens showing the current value, selected the way
                # Blender's own fields open. The first key replaces it: typing
                # 10000 into a box that read 7262 used to give 726210000,
                # which was then clamped to the maximum and looked like the
                # typing had been ignored.
                t = _state["typing"]
                if t.get("fresh"):
                    t["text"] = ""
                    t["fresh"] = False
                t["text"] += ch
                _redraw(context, context.area)
            return {"RUNNING_MODAL"}
        widgets = _state["widgets"]
        over = _hit(widgets, mx, my)

        if _state["drag"] is not None:
            if event.type == "MOUSEMOVE":
                it = (widgets[_state["drag"]]
                      if _state["drag"] < len(widgets) else None)
                if it is not None:
                    _fire(context, it, mx)
                    _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if event.type == "LEFTMOUSE" and event.value == "RELEASE":
                it = (widgets[_state["drag"]]
                      if _state["drag"] < len(widgets) else None)
                _state["drag"] = None
                return {"RUNNING_MODAL"}
            return {"RUNNING_MODAL"}

        if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            # Only when the pointer is on the card, and only when there is
            # something to reach. Anywhere else the wheel is the viewport's.
            card = _state.get("card")
            if (_state["over"] > 0.0 and card is not None
                    and card[0] <= mx <= card[0] + card[2]
                    and card[1] <= my <= card[1] + card[3]):
                step = 48.0 if event.type == "WHEELDOWNMOUSE" else -48.0
                was = _state["scroll"]
                _state["scroll"] = min(max(0.0, was + step), _state["over"])
                if _state["scroll"] != was:
                    _redraw(context, getattr(context, "area", None))
                return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}

        if event.type == "MOUSEMOVE":
            if over != _state["hover"]:
                _state["hover"] = over
                key = None
                if over is not None:
                    key = widgets[over].get("tip")
                _state["tip"] = ((over, key, time.time())
                                 if key is not None else None)
                if _state["tip"] is not None and not _state["ticking"]:
                    _state["ticking"] = True
                    if not bpy.app.timers.is_registered(_tick):
                        bpy.app.timers.register(_tick, first_interval=TIP_DELAY)
                # Sweeping across the card crosses a row every few pixels, and
                # a frame for each of those is a frame of the whole viewport.
                # Twenty-five a second is smooth and is a third of the cost.
                now = time.time()
                wait = max(0.04, _state["cost"] * 1.5)
                if now - _state["painted"] > wait:
                    _state["painted"] = now
                    _state["asked"] = now
                    _state["dirty"] = False
                    _redraw(context, context.area)
                else:
                    _state["dirty"] = True
                    if not bpy.app.timers.is_registered(_settle):
                        bpy.app.timers.register(_settle, first_interval=wait)
            return {"PASS_THROUGH"} if over is None else {"RUNNING_MODAL"}

        if over is None:
            return {"PASS_THROUGH"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            it = widgets[over]
            if "act" not in it:
                return {"RUNNING_MODAL"}      # a label, not a button
            kind, arg = it["act"]
            if kind == "type":
                fx, fy, fw, fh = it["rect"]
                if mx < fx + fw - 84.0:
                    return {"RUNNING_MODAL"}  # the words, not the number
                owner, prop, lo, hi, decimals, mul = arg
                val = getattr(owner, prop) * mul
                _state["typing"] = {
                    "owner": owner, "prop": prop, "lo": lo, "hi": hi,
                    "decimals": decimals, "mul": mul,
                    "fresh": True,
                    "text": (str(int(round(val))) if not decimals
                             else ("%.*f" % (decimals, val))),
                }
                _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if it["kind"] == "bar":
                _state["drag"] = over
            _fire(context, it, mx)
            _redraw(context, context.area)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE":
            return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}

    def cancel(self, context):
        # Blender ends a modal on its own for plenty of reasons - a file load,
        # a window closing, an error anywhere in the chain. Without this the
        # flag stayed set, the keep-alive saw a live modal that was not there,
        # and the card went on drawing while nothing on it could be clicked.
        if getattr(self, "_token", None) == _state.get("token"):
            _state["modal"] = False

    def invoke(self, context, event):
        if _state["modal"]:
            return {"CANCELLED"}
        _state["modal"] = True
        _state["token"] = _state.get("token", 0) + 1
        self._token = _state["token"]
        _state["beat"] = time.time()
        _state["hover"] = None
        _state["drag"] = None
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


def _showing():
    """Is the card up somewhere, without needing a draw to ask?"""
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                space = area.spaces.active
                if not getattr(space, "show_region_ui", False):
                    continue
                for r in area.regions:
                    if (r.type == "UI" and r.width >= 60
                            and getattr(r, "active_panel_category", "") == TAB):
                        return True
    except Exception:
        pass
    return False


def _keep_alive():
    """Start the card's modal, and start it again if it ever drops.

    A modal dies with a file load or a window closing, and the card would go
    quiet with the tab still open. One cheap check a second brings it back
    without anyone noticing it went.
    """
    if _state["quit"]:
        return None
    # A modal that died without saying so. The old test asked whether the card
    # had been painted in the last two seconds, on the reasoning that a fresh
    # paint means the pointer is over it - but a dead modal is exactly what
    # stops anything asking for a paint, so the card that most needed reviving
    # was the one this could never see. An add-on update leaves one behind
    # every time. Now the only question is whether the card is up and whether
    # anything has reached it lately.
    now = time.time()
    if (_state["modal"] and _state["handle"] is not None
            and now - _state["beat"] > 5.0 and _showing()):
        _state["modal"] = False
    # The same check once a second, for the case where the pointer left the
    # viewport before the tab changed and the modal sees no events at all.
    up = _showing()
    if up != _state["was_up"]:
        _state["was_up"] = up
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    if not _state["modal"]:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                region = next((r for r in area.regions if r.type == "WINDOW"),
                              None)
                if region is None:
                    continue
                try:
                    with bpy.context.temp_override(window=win, area=area,
                                                   region=region):
                        bpy.ops.ultra_remesh.overlay("INVOKE_DEFAULT")
                except Exception:
                    pass
                break
            if _state["modal"]:
                break
    # Five times a second, not once: this is the only thing watching for a
    # tab change when the pointer is not in the viewport at all, and a whole
    # second of the card being missing is a second of it looking broken. The
    # check itself is a few attribute reads.
    return 0.2


def clear():
    """Take the card down, whoever is asking."""
    if _state["handle"] is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_state["handle"],
                                                      "WINDOW")
        except Exception:
            pass
    _state["handle"] = None
    bpy.app.driver_namespace.pop(_CARD_HANDLE, None)
    _state["widgets"] = []
    _state["hover"] = None
    _state["drag"] = None
    _state["tip"] = None


def is_on():
    return bool(_state["handle"])



CLASSES = (UR_OT_overlay,)

_CARD_HANDLE = "ultra_remesh_card_draw_handle"


def _drop_stale_card():
    """Remove a card handler left behind by an earlier load of this module."""
    ns = bpy.app.driver_namespace
    old = ns.pop(_CARD_HANDLE, None)
    if old is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(old, "WINDOW")
        except Exception:
            pass


def redraw_all():
    """Repaint every 3D view - used when the card is switched on or off."""
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    except Exception:
        pass


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    retint()
    _state["quit"] = False
    _state["modal"] = False
    _drop_stale_card()
    _state["handle"] = bpy.types.SpaceView3D.draw_handler_add(
        _draw, (), "WINDOW", "POST_PIXEL")
    bpy.app.driver_namespace[_CARD_HANDLE] = _state["handle"]
    if not bpy.app.timers.is_registered(_keep_alive):
        bpy.app.timers.register(_keep_alive, first_interval=0.5,
                                persistent=True)


def unregister():
    _state["quit"] = True
    try:
        if bpy.app.timers.is_registered(_keep_alive):
            bpy.app.timers.unregister(_keep_alive)
    except Exception:
        pass
    try:
        clear()
    except Exception:
        pass
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
