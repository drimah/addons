import uuid
from mathutils import Vector
from . import utils
import bmesh

def curve_profiles_to_mesh(layout, context):
    col = layout.column()
    col.separator()
    col.label(text="Profile Subdivisions")

    box = col.box()
    col = box.column()
    col.prop(context.scene, "c2m_number_of_cuts_across", text="Curve Subdivisions")
    col.enabled = not context.scene.c2m_use_resolution
    col = box.column()
    col.prop(context.scene, "c2m_number_of_cuts_down", text="Bridging Subdivisions")

    col = box.column()
    col.prop(context.scene, "c2m_use_resolution", text="Use Curve Resolution")
    col = box.column()
    col.label(text="Bridge creation")
    col.prop(context.scene, "c2m_twist", text="Twist")
    col.label(text="Bridge Ordering")
    col.prop(context.scene, "c2m_bridge_order", text="")
    if context.scene.c2m_bridge_order == 'ORDER':
        col.prop(context.scene, "c2m_bridge_order_reversed", text='Reverse')

    if context.scene.c2m_bridge_order == 'PROXIMITY':
        box = col.box()
        box.label(text="Smoothing")
        col_row = box.row()
        col_row.label(text="Smooth Type")
        col_row.prop(context.scene, 'c2m_subdivide_interp_mode', text='')
        if context.scene.c2m_subdivide_interp_mode != 'LINEAR':
            box.prop(context.scene, 'c2m_subdivide_smooth')

    col.separator()
    
    box = col.box()
    box.label(text="Profile")
    box.prop(context.scene, "c2m_subdivide_profile_shape_factor", text="Profile Shape")
    col_row = box.row()
    col_row.label(text="Profile Type")
    col_row.prop(context.scene, "c2m_subdivide_profile_shape", text="")


def curve_sweep_to_mesh(layout, context):
    col = layout.column()

    box = col.box()
    box.label(text="Sweep Curve")
    box.prop(context.scene, "c2m_sweep_curve", text="")
    box.prop(context.scene, "c2m_number_of_cuts_down", text="Subdivisions")
    box.prop(context.scene, "c2m_sweep_curve_subd", text="Accuracy")

    col.separator()

    box = col.box()
    box.label(text="Cross Sections")
    col1 = box.column()
    col1.prop(context.scene, "c2m_number_of_cuts_across", text="Subdivisions")
    col1.enabled = not context.scene.c2m_use_resolution
    box.prop(context.scene, "c2m_use_resolution", text="Use Curve Resolution")
    
    # Commented out for now as this gives some unexpected results.
    # box = col.box()
    # box.label(text="Smoothing")
    # col_row = box.row()
    # col_row.label(text="Smooth Type")
    # col_row.prop(context.scene, 'c2m_subdivide_interp_mode', text='')
    # if context.scene.c2m_subdivide_interp_mode != 'LINEAR':
    #     box.prop(context.scene, 'c2m_subdivide_smooth')

    # col.separator()

    # box = col.box()
    # box.label(text="Profile")
    # box.prop(context.scene, "c2m_subdivide_profile_shape_factor", text="Profile Shape")
    # box_row = box.row()
    # box_row.label(text="Profile Type")
    # box_row.prop(context.scene, "c2m_subdivide_profile_shape", text="")

    col.separator()
    box = col.box()
    box.label(text="Bridge creation (degrees)")
    box.prop(context.scene, "c2m_twist", text="Twist")


def curve_surface_to_mesh(layout, context):
    col = layout.column()
    col.separator()
    col.label(text="Surface Subdivisions")

    box = col.box()
    col = box.column()
    col.prop(context.scene, "c2m_number_of_cuts_across", text="Across")
    col.prop(context.scene, "c2m_number_of_cuts_down", text="Down")
    col.enabled = not context.scene.c2m_use_resolution
    col = box.column()
    col.prop(context.scene, "c2m_use_resolution", text="Use Curve Resolution")
    col = box.column()
    col.separator()
    col.label(text="Surface Creation:")
    col.prop(context.scene, "c2m_direction_check", text="Check direction of curve")
