"""
    Contains UI reference function for the addon.
"""
import bpy
import blf
import math
from mathutils import Vector
from . import utils
from . import classes
from . import curve_uis
from . import props

import gpu
from gpu_extras.batch import batch_for_shader

_shader_map = {}
def get_shader(str_type, str_type_override=None):
    '''Get a cached shader'''
    global _shader_map
    
    # Check if the shader for str_type is already cached
    if str_type in _shader_map:
        return _shader_map[str_type]
    
    # If str_type_override is already cached, return it
    if str_type_override and str_type_override in _shader_map:
        return _shader_map[str_type_override]
    
    try:
        # Try to fetch and cache the shader for str_type
        _shader_map[str_type] = gpu.shader.from_builtin(str_type)
        return _shader_map[str_type]
    except ValueError:
        # If there's an exception and str_type_override is provided, try that
        if str_type_override:
            _shader_map[str_type_override] = gpu.shader.from_builtin(str_type_override)
            return _shader_map[str_type_override]
        
    # If everything fails, raise an error or return a default value
    raise ValueError("Unable to fetch shader")

def draw_callback_3d(self, context):
    """Draw in 3D a representation of the mesh with occlusion support"""

    try:
        if not (classes.CurvesToSurface.running_curves_to_meshes.get(self._region) is self): return
        if not hasattr(self, 'verts'): return

        user_preferences = context.preferences
        addon_prefs = user_preferences.addons[__package__].preferences

        coords = [self.verts[i] for i in self.verts.keys()]

        # === Calculate Edges ===
        gpu.state.line_width_set(2.0)
        indices = self.edges.values()
        edge_indices = indices
        
        # === Calculate Faces ===
        indices = []
        for face_data in self.faces.values():
            vert_indexes = face_data['vert_indexes']
            if len(vert_indexes) < 3:
                continue

            iv0 = vert_indexes[0]
            for iv1, iv2 in zip(vert_indexes[1:-1], vert_indexes[2:]):
                indices.append((iv0, iv1, iv2))
        face_indices = indices


        # Enable depth testing and writing
        gpu.state.blend_set("ALPHA")

        if bpy.app.version < (4, 0, 0):

            gpu.state.blend_set("ALPHA")

            # Draw Edges
            shader = get_shader('UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'LINES', {"pos": coords}, indices= edge_indices)
            shader.bind()
            shader.uniform_float("color", to_4(addon_prefs.edge_color, addon_prefs.transparent_value))
            batch.draw(shader)

            # Draw faces
            shader = get_shader('UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'TRIS', {"pos": coords}, indices= face_indices)
            shader.bind()
            shader.uniform_float("color", to_4(addon_prefs.face_color, addon_prefs.transparent_value))
            batch.draw(shader)

            # Draw vertices
            gpu.state.point_size_set(5)
            shader = get_shader('UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
            shader.bind()
            shader.uniform_float("color", to_4(addon_prefs.vertex_color, addon_prefs.transparent_value))
            batch.draw(shader)

            gpu.state.blend_set("NONE")

        else:

            if hasattr(gpu.state, 'depth_mask_set'):
                gpu.state.depth_mask_set(True)
            if hasattr(gpu.state, 'depth_test_set'):
                gpu.state.depth_test_set("LESS_EQUAL")
            if hasattr(gpu.state, 'face_culling_set'):
                if self.flip_normals:
                    gpu.state.face_culling_set('BACK')
                else:
                    gpu.state.face_culling_set('FRONT')
            if hasattr(gpu.state, 'front_facing_set'):
                gpu.state.front_facing_set(True)

            region = context.region

            # === Draw Faces ===
            shader = get_shader('UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            shader.bind()
            shader.uniform_float("color", to_4(addon_prefs.face_color, addon_prefs.transparent_value))
            gpu.state.blend_set("ALPHA")
            face_batch = batch_for_shader(shader, 'TRIS', {"pos": coords}, indices=face_indices)
            face_batch.draw(shader)

            # # === Draw Edges ===
            # shader = get_shader('POLYLINE_UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            # shader.bind()
            # shader.uniform_float("color", addon_prefs.edge_color) # Lighter color
            # shader.uniform_float("lineWidth", 5.0)
            # shader.uniform_float("viewportSize", (region.width, region.height))
            # gpu.state.blend_set("ALPHA")
            # edge_batch = batch_for_shader(shader, 'LINES', {"pos": coords}, indices=edge_indices)
            # edge_batch.draw(shader)

            # Draw Edges
            shader = get_shader('UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'LINES', {"pos": coords}, indices= edge_indices)
            shader.bind()
            shader.uniform_float("color", to_4(addon_prefs.edge_color, addon_prefs.transparent_value))
            batch.draw(shader)

            # === Draw Vertices ===
            gpu.state.point_size_set(5)
            shader = get_shader('UNIFORM_COLOR', '3D_UNIFORM_COLOR')
            vertex_batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
            shader.bind()
            shader.uniform_float("color", to_4(addon_prefs.vertex_color, addon_prefs.transparent_value))
            vertex_batch.draw(shader)

            # Reset state
            if hasattr(gpu.state, 'depth_test_set'):
                gpu.state.depth_test_set('ALWAYS')
            if hasattr(gpu.state, 'depth_mask_set'):
                gpu.state.depth_mask_set(False)
            if hasattr(gpu.state, 'face_culling_set'):
                gpu.state.face_culling_set('NONE')
            if hasattr(gpu.state, 'front_facing_set'):
                gpu.state.front_facing_set(False)

        gpu.state.blend_set("NONE")

    except ReferenceError:
        pass


def to_4(v,t):
    return [v[0], v[1], v[2], t]


class OBJECT_PT_curves_to_mesh(bpy.types.Panel):
    bl_idname = "OBJECT_PT_curves_to_mesh"
    bl_label = "Curves To Mesh"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curves To Mesh'

    def draw(self, context):
        draw_options(self, context)


class OBJECT_PT_curves_to_mesh_tools(bpy.types.Panel):
    bl_idname = "OBJECT_PT_curves_to_mesh_tools"
    bl_label = "Curve Editing"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curves To Mesh'
    bl_parent_id = 'OBJECT_PT_curves_to_mesh'



    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        box = col.box()
        box.label(text="Display")
        box = box.box()
        box.label(text="View Line Width")
        box.row().prop(context.preferences.view, "ui_line_width", expand=True)
        box.label(text="Display Handles")
        box.row().prop(context.space_data.overlay, "display_handle", expand=True)
        box.prop(context.space_data.overlay, "show_curve_normals", toggle=True, text="Show Curve Direction")

        col.separator()
        box = col.box()
        box.label(text="Curve Edit Mode Tools")
        box = box.box()
        col = box.column(align=True)
        col.operator('curve.select_linked', text="Select Linked")
        col.operator('curve.subdivide', text="Subdivide Points")
        col.operator('curve.split', text="Split Points")
        col.operator('curve.separate', text="Separate Points")
        col.operator('curve.make_segment', text="Fill Between Points")
        col.operator('curve.switch_direction', text="Switch Curve Direction")
        col.label(text="* Right-click viewport for more")
            

class OBJECT_PT_curves_to_mesh_preferences(bpy.types.Panel):
    bl_idname = "OBJECT_PT_curves_to_mesh_preferences"
    bl_label = "Preferences"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curves To Mesh'
    bl_parent_id = 'OBJECT_PT_curves_to_mesh'
    
    def draw(self, context):
        user_preferences = context.preferences
        addon_prefs = user_preferences.addons[__package__].preferences

        layout = self.layout


        box = layout.box()
        box.label(text="Preview Settings")
        col = box.column(align=True)
        col.label(text="Preview Transparency")
        col.prop(addon_prefs, "transparent_value", text="", slider=True)
        col.label(text="Vertex Color")
        col.prop(addon_prefs, "vertex_color", text="")
        col.label(text="Edge Color")
        col.prop(addon_prefs, "edge_color", text="")
        col.label(text="Face Color")
        col.prop(addon_prefs, "face_color", text="")


        box = layout.box()
        box.label(text="Theme Settings")
        col = box.column(align=True)
        col.row().prop(context.preferences.themes[0].view_3d, "wire")
        col.row().prop(context.preferences.themes[0].view_3d, "wire_edit")

class OBJECT_PT_curves_to_mesh_adv(bpy.types.Panel):
    bl_idname = "OBJECT_PT_curves_to_mesh_advanced"
    bl_label = "Advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curves To Mesh'
    bl_parent_id = 'OBJECT_PT_curves_to_mesh'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        draw_options_adv(self, context)



def draw_options(self, context):
    layout = self.layout
    col = layout.column()
    col.label(text="Preview")
    row = col.row()
    row.operator("curvestomesh.preview_operator", text="Enable", depress=context.scene.c2m_preview_mode)
    row.operator("curvestomesh.cancel_operator", text="Disable")

    col = layout.column()
    col.separator()
    col.label(text="Collection to operate on")
    col.prop_search(data = context.scene,
                            property = 'c2m_collection',
                            search_data = bpy.data,
                            search_property = 'collections',
                            text="")

    col = layout.column(align=True)
    col.separator()
    col.label(text="Conversion Method")
    c2m_method_text = ""
    for creation_method_item in props.creation_method_items:
        col.prop_enum(context.scene, "c2m_curve_method", creation_method_item[0])


    col = layout.column()
    custom_draw_func = getattr(curve_uis, context.scene.c2m_curve_method, None)
    if custom_draw_func is not None:
        custom_draw_func(col, context)


    col = layout.column()
    col.separator()
    col.label(text="Mesh Settings")
    col = col.box()
    col.prop(context.scene, "c2m_snap_verts", text="Snap to control point")
    col.prop(context.scene, "c2m_mirror_x")
    col.prop(context.scene, "c2m_mirror_y")
    col.prop(context.scene, "c2m_mirror_z")
    col.prop(context.scene, "c2m_flip_normals")
    col.prop(context.scene, "c2m_shade_smooth")
    col.prop(context.scene, "c2m_show_all_edges")
    col.prop(context.scene, "c2m_show_wire")

    col = layout.column()
    col.separator()
    col.operator("curvestomesh.commit_operator", text="Create Mesh")


def draw_options_adv(self, context):
    layout = self.layout
    col = layout.column()

    col.separator()
    col.label(text="Vertex Settings")
    col.prop(context.scene, "c2m_number_of_nudges", text="Nudges")
    col.prop(context.scene, "c2m_samples_between_points", text="Samples")
    col.prop(context.scene, "c2m_precision", text="Definition")
    col.separator()
    col.prop(context.scene, "c2m_remove_double_distance", text="Remove Double Precision")

    col = layout.column()
    col.separator()
    col.label(text="Curve Connections")
    col.prop(context.scene, "c2m_round_to_decimals")