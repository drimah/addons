"""
property: A set of containers that represent the model for storing and managing data for the add-on.
"""

import bpy
from bpy.types import PropertyGroup
from bpy.props import PointerProperty, IntProperty, FloatVectorProperty, BoolProperty, CollectionProperty, StringProperty, EnumProperty, BoolVectorProperty

from bpy.utils import register_class, unregister_class


class CurvesToMeshCollection(bpy.types.PropertyGroup):
    """Settings for the collection of Curves to Mesh"""   

    target_object: PointerProperty(
        name="Target Object",
        type=bpy.types.Object,
        description="The object to which the curves will be converted",
        poll=lambda self, obj: obj.type == 'MESH'
    )

class CurvesToMeshObject(bpy.types.PropertyGroup):
    """Settings for the object of Curves to Mesh"""

    old_show_in_front: BoolProperty(
        name="Old Show In Front",
        description="Store the old 'Show In Front' state of the object",
        default=False,
        options={'HIDDEN'}
    )

 
classes = [
    CurvesToMeshCollection,
    CurvesToMeshObject

]


def register():
    for cls in classes:
        register_class(cls)

    # bpy.types.WindowManager.quad_maker = PointerProperty(name='Quad Maker UI', type=quad_maker_ui)
    bpy.types.Object.c2m_object = PointerProperty(name='Curves to Mesh Object', type=CurvesToMeshObject)
    bpy.types.Collection.c2m_collection = PointerProperty(name='Curves to Mesh Collection', type=CurvesToMeshCollection)


def unregister():
    # bpy.types.WindowManager.quad_maker = None
    del bpy.types.Object.c2m_object
    del bpy.types.Collection.c2m_collection
    for cls in reversed(classes):
        unregister_class(cls)
    # del bpy.types.WindowManager.quad_maker
