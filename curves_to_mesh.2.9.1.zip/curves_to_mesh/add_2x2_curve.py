import bpy
from bpy.types import Operator
from bpy.props import FloatVectorProperty, BoolProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector

def create_bezier_spline(start, end, handle_offset):
    spline_data = bpy.data.curves.new(name="BezierSegment", type='CURVE')
    spline_data.dimensions = '3D'
    spline = spline_data.splines.new(type='BEZIER')
    spline.bezier_points.add(1)

    spline.bezier_points[0].co = start
    spline.bezier_points[0].handle_left = start - handle_offset
    spline.bezier_points[0].handle_right = start + handle_offset

    spline.bezier_points[1].co = end
    spline.bezier_points[1].handle_left = end - handle_offset
    spline.bezier_points[1].handle_right = end + handle_offset

    return spline_data

def add_2x2_curve(self, context, separate_objects=False):
    scale_x = self.scale.x
    scale_y = self.scale.y

    verts = [
        Vector((-scale_x, scale_y, 0)),   # 0 Top Left
        Vector((scale_x, scale_y, 0)),    # 1 Top Right
        Vector((scale_x, -scale_y, 0)),   # 2 Bottom Right
        Vector((-scale_x, -scale_y, 0)),  # 3 Bottom Left
    ]

    if separate_objects:
        segments = [
            ("Top", verts[0], verts[1], Vector((0.5, 0, 0))),
            ("Right", verts[1], verts[2], Vector((0, -0.5, 0))),
            ("Bottom", verts[2], verts[3], Vector((-0.5, 0, 0))),
            ("Left", verts[3], verts[0], Vector((0, 0.5, 0))),
        ]
        new_objects = []
        for name, start, end, offset in segments:
            curve = create_bezier_spline(start, end, offset)
            curve.name = f"Curve {name}"
            object_data_add(context, curve)
            new_objects.append(context.view_layer.objects.active)
        for o in new_objects:
            o.select_set(True)
    else:
        curve = bpy.data.curves.new(name="2x2 Bezier Curve", type='CURVE')
        curve.dimensions = '3D'

        for _ in range(4):
            curve.splines.new(type='BEZIER').bezier_points.add(1)

        top, right, bottom, left = curve.splines

        top.bezier_points[0].co = verts[0]
        top.bezier_points[0].handle_left = verts[0] + Vector((-0.5, 0, 0))
        top.bezier_points[0].handle_right = verts[0] + Vector((0.5, 0, 0))
        top.bezier_points[1].co = verts[1]
        top.bezier_points[1].handle_left = verts[1] + Vector((-0.5, 0, 0))
        top.bezier_points[1].handle_right = verts[1] + Vector((0.5, 0, 0))

        right.bezier_points[0].co = verts[1]
        right.bezier_points[0].handle_left = verts[1] + Vector((0, 0.5, 0))
        right.bezier_points[0].handle_right = verts[1] + Vector((0, -0.5, 0))
        right.bezier_points[1].co = verts[2]
        right.bezier_points[1].handle_left = verts[2] + Vector((0, 0.5, 0))
        right.bezier_points[1].handle_right = verts[2] + Vector((0, -0.5, 0))

        bottom.bezier_points[0].co = verts[2]
        bottom.bezier_points[0].handle_left = verts[2] + Vector((0.5, 0, 0))
        bottom.bezier_points[0].handle_right = verts[2] + Vector((-0.5, 0, 0))
        bottom.bezier_points[1].co = verts[3]
        bottom.bezier_points[1].handle_left = verts[3] + Vector((0.5, 0, 0))
        bottom.bezier_points[1].handle_right = verts[3] + Vector((-0.5, 0, 0))

        left.bezier_points[0].co = verts[3]
        left.bezier_points[0].handle_left = verts[3] + Vector((0, -0.5, 0))
        left.bezier_points[0].handle_right = verts[3] + Vector((0, 0.5, 0))
        left.bezier_points[1].co = verts[0]
        left.bezier_points[1].handle_left = verts[0] + Vector((0, -0.5, 0))
        left.bezier_points[1].handle_right = verts[0] + Vector((0, 0.5, 0))

        object_data_add(context, curve)


class OBJECT_OT_add_2x2_curve(Operator, AddObjectHelper):
    """Create a new 2x2 Bezier Curve or 4 separate curves"""
    bl_idname = "curve.add_2x2"
    bl_label = "Add 2x2 Curve Object"
    bl_options = {'REGISTER', 'UNDO'}

    scale: FloatVectorProperty(
        name="Scale",
        default=(1.0, 1.0, 1.0),
        subtype='TRANSLATION',
        description="Scaling",
    )

    separate_objects: BoolProperty(
        name="Separate Objects",
        default=False,
        description="Create 4 separate curve objects instead of one multi-spline object"
    )

    def execute(self, context):
        add_2x2_curve(self, context, self.separate_objects)
        return {'FINISHED'}


# Registration
def append_to_menu():
    bpy.types.VIEW3D_MT_curve_add.append(add_2x2_curve_button)


def remove_from_menu():
    bpy.types.VIEW3D_MT_curve_add.remove(add_2x2_curve_button)


def add_2x2_curve_button(self, context):
    self.layout.operator(
        OBJECT_OT_add_2x2_curve.bl_idname,
        text="2x2 Bezier Patch",
        icon='OUTLINER_OB_SURFACE')


# This allows you to right click on a button and link to the manual
def add_object_manual_map():
    url_manual_prefix = "https://docs.blender.org/manual/en/dev/"
    url_manual_mapping = (
        ("bpy.ops.mesh.add_object", "editors/3dview/object"),
    )
    return url_manual_prefix, url_manual_mapping
