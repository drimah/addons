import bpy
from bpy.types import AddonPreferences
from bpy.props import FloatVectorProperty, FloatProperty
import rna_keymap_ui
from . import keymaps
from . import operators
import os

def addon_name():
    return __package__

class CurvesToMeshAddonPreferences(AddonPreferences):
    """Custom preferences and associated UI for add on properties."""
    # this must match the addon name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = addon_name()

    vertex_color : FloatVectorProperty(name="Preview Vertex Color",
                                        subtype='COLOR',
                                        size=3,
                                        default=[.6, .6, .6])

    edge_color : FloatVectorProperty(name="Preview Edge Color",
                                        subtype='COLOR',
                                        size=3,
                                        default=[0.391, .555, .781])


    face_color : FloatVectorProperty(name="Preview Face Color",
                                        subtype='COLOR',
                                        size=3,
                                        default=[0.250, .309, 0.558])

    transparent_value : FloatProperty(name="Preview Transparency",
                                            min=0.0, max=1.0,
                                            default=0.5,
                                            description="Transparency value for preview meshes")

    def draw(self, context):
        layout = self.layout
        # layout.label(text="Colors:")
        col = layout.column()
        col.alignment = 'CENTER'
        row = col.row()
        row.prop(self, "transparent_value", slider=True)
        row = col.row()
        row.prop(self, "vertex_color")
        row = col.row()
        row.prop(self, "edge_color")
        row = col.row()
        row.prop(self, "face_color")
        col.separator()

        col = col.column()
        col.separator()
        col.label(text='Keyboard shortcuts:')
        col = col.column()

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.user

        km = kc.keymaps['3D View']
        kmis = keymaps.hotkey_entry_items(km, keymaps.keymap_operators)

        if len(kmis) != len(keymaps.keymap_operators):
            col.alert = True
            col = col.column()
            row = col.row()
            row.alignment = 'CENTER'
            row.label(text="Not all hotkey entries found")
            col = col.column()
            row = col.row()
            row.alignment = 'CENTER'
            row.label(text="restore hotkeys from Keymap tab")

        for kmi in kmis:
            col.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
