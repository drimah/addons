# Speedretopo Release Notes

---

## Version 0.4.4

### Fixed

- **FIX** - Bsurface failing with `mesh.select_all.poll() failed` when curves are hidden in the viewport

---

## Version 0.4.3

- Updated the addon for Blender 4.2 and 5.2
- Added a tool to set per-face color using **Vertex Paint** mode.
- Added new options in the **Shading** panel.
- Fixed `AttributeError: 'Scene' object has no attribute 'bsurfaces'` when starting a retopology.
  Bsurface and Looptools detection now checks that the extension is really registered instead of
  only looking for its name in the add-on list. A stale entry (add-on left in the preferences after
  a failed registration, or a userpref migrated from an older Blender) no longer makes Speedretopo
  believe the extension is available.
- Fixed a crash in the pie menu when Bsurface is not installed.

---

## Version 0.4.2 and earlier

With **Blender 4.2**, you need to **install** and **enable** the following extensions to use them with **Speedretopo**:
- **Bsurface**
- **Looptools**

If these extensions are not installed or enabled, the interface will display a warning:


### Installing the extensions

1. Go to **Preferences > Get Extension** in Blender.
2. Search for "**Bsurface**" and "**Looptools**".


3. Click **Install** for each found extension.  
   Once installed, they will be automatically enabled.


> **Note:**  
> If the **Install** button is not clickable, enable **Allow Online Access** in  
> **System > Network**.


Once the extensions are installed and enabled, their tools will be available in Speedretopo.


---

Additionally, to allow update checking in the Speedretopo module preferences,  
be sure to enable **Allow Online Access**.
