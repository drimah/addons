"""Moving the poles of a quad mesh off the edges and into the flat.

A pole is a vertex that does not have four edges - the place a loop dies.
They cannot be got rid of: on a closed surface with no holes the valences are
fixed by the shape itself, and at least eight three-way poles have to exist
however the mesh is built. What can be changed is how many there are beyond
that minimum, and where they sit.

Where they sit is the part that shows. Measured on Milad's `part_02`, 10065
faces straight out of the organic remesh: 333 poles, and the surface bends by
1.9 degrees at the middle vertex but by 39.3 degrees at the middle pole. 180
of the 333 were sitting on an edge sharper than 30 degrees - the worst place
for one, and exactly where the eye goes.

The move is an edge rotation. Rotating the edge between two quads takes one
edge off each of its own ends and gives one to each of the two corners
across, so a pole can be walked across the surface a step at a time. Nothing
moves in space: the vertices stay exactly where they were, only the
connections change.

Which way round Blender rotates cannot be predicted from the face winding, so
this does not try. It rotates, looks at what actually came out, and keeps it
only if the result is better; otherwise it rotates on round the hexagon until
the mesh is back where it started. Three rotations return an edge to itself.

The test is in three parts, in order: the number of poles must not go up,
then how far off four they are must not go up, and only then is the bend
weighed. So a rotation can never trade a pole away to make the placement look
better - which an earlier scoring version did, turning 333 poles into 397.
"""

import math
import time

import bmesh
import numpy as np


def bend_at(v):
    """The sharpest crease running through this vertex, in radians."""
    worst = 0.0
    for e in v.link_edges:
        if len(e.link_faces) != 2:
            continue
        a, b = e.link_faces
        if a.normal.length and b.normal.length:
            ang = a.normal.angle(b.normal)
            if ang > worst:
                worst = ang
    return worst


def _score(verts, bend, pull=None):
    """How bad this patch is, in the order the parts are allowed to matter.

    Poles first, then how far off four they are, then how far each one is
    from a pole of the opposite kind, and only then where it sits.

    The third part is what lets the count actually come down. A rotation can
    cancel poles only when a five-way and two three-way vertices happen to
    meet on one edge, and on a real mesh they almost never do. Walking them
    towards each other needs moves that change nothing at all by the first
    two measures, so without this the pass had no reason to make them and
    the poles stayed where they were: 333 became 326 and stopped.
    """
    poles = 0
    off = 0
    together = 0.0
    placed = 0.0
    for v in verts:
        n = len(v.link_edges)
        if n != 4:
            poles += 1
            d = abs(4 - n)
            off += d
            placed += d * bend.get(v.index, 0.0) / math.pi
            if pull is not None:
                together += pull.get(v.index, 0.0)
    return (poles, off, together, placed)


def _better(new, old):
    for i in range(3):
        if new[i] != old[i]:
            return new[i] < old[i]
    return new[3] < old[3] - 1e-9


def _pull_towards(bm, med):
    """How far a pole is from one of the opposite kind, in edge lengths.

    A three-way vertex and a five-way vertex cancel when they meet, so the
    pass is told to bring them together. Distance is measured to the nearest
    pole of the other kind, in units of the mesh's own edge length so the
    number means the same on any model.
    """
    from mathutils.kdtree import KDTree

    low = [v for v in bm.verts if len(v.link_edges) < 4]
    high = [v for v in bm.verts if len(v.link_edges) > 4]
    trees = {}
    for name, group in (("low", low), ("high", high)):
        if not group:
            trees[name] = None
            continue
        kd = KDTree(len(group))
        for i, v in enumerate(group):
            kd.insert(v.co, i)
        kd.balance()
        trees[name] = kd

    # Worked out once for every pole in the mesh, not inside each trial.
    # Asking the tree from the inner loop meant eight lookups per rotation
    # tried, and the pass managed 25 rotations in 45 seconds instead of 107.
    out = {}
    for v in bm.verts:
        n = len(v.link_edges)
        if n == 4:
            continue
        kd = trees["high" if n < 4 else "low"]
        if kd is None:
            continue
        hit = kd.find(v.co)
        if hit is not None and hit[2] is not None:
            out[v.index] = hit[2] / med
    return out


def relax_poles(bm, rounds=8, budget=0.0, keep_marked=True, reach=2.2):
    """Walk the poles onto flatter ground. Returns (rotations, seconds).

    `budget` in seconds caps the work; 0 means no cap. `reach` is how long
    the new edge may be against the mesh's own middle edge, which keeps a
    rotation from stretching a face across something.
    """
    lengths = [e.calc_length() for e in bm.edges]
    if not lengths:
        return 0, 0.0
    med = float(np.median(lengths))
    start = time.time()
    done = 0
    for _round in range(max(1, rounds)):
        bm.verts.index_update()
        bend = {v.index: bend_at(v) for v in bm.verts}
        # Alternate: one round bringing the poles together so they can
        # cancel, the next moving whatever is left onto flatter ground.
        # Doing both at once let the pulling outrank the placing, and the
        # bend at the poles came out worse than it started - 39 degrees to
        # 40 - while the count barely moved.
        merging = bool(_round % 2 == 0)
        pull = _pull_towards(bm, med) if merging else None
        # Only the edges round a pole can help, and there are far fewer of
        # those than edges: 1500 against 20000 on that part. Trying them all
        # took so long Blender stopped answering.
        seen = set()
        todo = []
        for v in bm.verts:
            if len(v.link_edges) == 4:
                continue
            # Every edge of every face touching the pole, not only the edges
            # running into it. A rotation takes one edge off its own two ends
            # and gives one to the two corners across, so the move that walks
            # a three-way pole along is a rotation of an edge it is *opposite*
            # to - rotating one it sits on would take it down to two edges and
            # that is a crack, not a pole. Scanning only its own edges left
            # 127 of the 290 round Milad's part rejected for exactly that,
            # and the pass had almost nothing left to do.
            for f in v.link_faces:
                for e in f.edges:
                    if e.index not in seen:
                        seen.add(e.index)
                        todo.append(e)
        did = 0
        for e in todo:
            if budget and time.time() - start > budget:
                break
            if not e.is_valid or len(e.link_faces) != 2:
                continue
            if keep_marked and (e.tag or e.seam or not e.smooth or e.select):
                continue
            f1, f2 = e.link_faces
            if len(f1.verts) != 4 or len(f2.verts) != 4:
                continue
            a, b = e.verts
            # taking one off a three-way vertex would make a two-way one,
            # which is not a pole any more, it is a crack
            if len(a.link_edges) <= 3 or len(b.link_edges) <= 3:
                continue
            ring = list({v for f in (f1, f2) for v in f.verts})
            base = _score(ring, bend, pull)
            if base[0] == 0:
                continue                    # nothing wrong here to move
            cur = e
            steps = 0
            kept = False
            for _try in range(2):
                out = bmesh.ops.rotate_edges(bm, edges=[cur], use_ccw=False)
                if not out["edges"]:
                    break
                cur = out["edges"][0]
                steps += 1
                if len(cur.link_faces) != 2:
                    break
                if (cur.verts[0].co - cur.verts[1].co).length > med * reach:
                    continue
                ring2 = list({v for f in cur.link_faces for v in f.verts})
                if _better(_score(ring2, bend, pull), base):
                    kept = True
                    break
            if not kept:
                for _ in range(3 - steps):
                    out = bmesh.ops.rotate_edges(bm, edges=[cur],
                                                 use_ccw=False)
                    if not out["edges"]:
                        break
                    cur = out["edges"][0]
            else:
                did += 1
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        done += did
        if not did:
            break
        if budget and time.time() - start > budget:
            break
    return done, time.time() - start


def survey(bm):
    """Where the poles are now: how many, and how sharp the surface is there."""
    poles = [v for v in bm.verts
             if len(v.link_edges) != 4
             and not any(len(e.link_faces) < 2 for e in v.link_edges)]
    if not poles:
        return {"poles": 0, "median_bend": 0.0, "on_edges": 0}
    b = np.degrees([bend_at(v) for v in poles])
    return {"poles": len(poles),
            "median_bend": float(np.median(b)),
            "on_edges": int((b > 30.0).sum())}
