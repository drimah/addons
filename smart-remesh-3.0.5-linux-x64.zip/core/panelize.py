"""Dissolve everything between lines the user marked, leaving flat panels.

The rest of Hardsurface decides for itself which edges carry shape. This is
the manual counterpart: the user says where the panel borders are, and every
edge that is not one of them goes. What is left is one n-gon per region.

Nothing here moves a vertex. Dissolving an edge only removes it, so the
silhouette and every kept line stay exactly where they were - the only thing
that changes is a region that was not flat, which becomes a single n-gon and
therefore reads as flat. `protect_angle` exists for that case.
"""

from __future__ import annotations

import math

import bmesh

# two edges within this of a straight line can be joined without moving
# the surface; anything less is a corner and the corner is the shape
STRAIGHT = math.radians(179.0)

# Whether the two edges on the far side of a T carry on as one line. Looser
# than STRAIGHT on purpose: STRAIGHT decides what to dissolve and has to be
# tight or a circle collapses into a polygon, while this only decides whether
# a loop is allowed to end here. On a 192-sided ring the crossbar of a real T
# measures 178.1 degrees, so 179 rejected every one of them.
CONTINUES = math.radians(160.0)


def planar_groups(bm, tol_deg, flat_dist):
    """Grow faces into groups that share one plane.

    Comparing each pair of neighbours separately is not enough: every step can
    be inside the tolerance while the region as a whole bends far out of plane.
    Measured on a real part, a 10 degree pairwise limit left 117 n-gons that
    were not flat, up to 48 sides, and Blender triangulates those into the mess
    that looks like the model exploded.

    So each face is tested against the plane of the seed it grew from, not
    against its neighbour, and the group stops where that plane no longer fits.
    """
    import math
    from mathutils import Vector

    cos_tol = math.cos(math.radians(tol_deg))
    group = {}
    for seed in bm.faces:
        if seed.index in group:
            continue
        gid = len(set(group.values())) if group else 0
        gid = seed.index
        n0 = seed.normal.copy()
        if n0.length < 1e-12:
            group[seed.index] = gid
            continue
        d0 = n0.dot(seed.calc_center_median())
        stack = [seed]
        group[seed.index] = gid
        while stack:
            f = stack.pop()
            for e in f.edges:
                for g in e.link_faces:
                    if g.index in group:
                        continue
                    ng = g.normal
                    if ng.length < 1e-12 or ng.dot(n0) < cos_tol:
                        continue
                    if max(abs(n0.dot(v.co) - d0) for v in g.verts) > flat_dist:
                        continue
                    group[g.index] = gid
                    stack.append(g)
    return group


def keepers(bm, *, use_sharp=True, use_selection=True, keep_boundary=True,
            keep_creased=True, protect_angle=0.0, keep_seams=False,
            flat_dist=None):
    """The edges that survive. Everything else is dissolved.

    `protect_angle` in degrees is how far a face may tilt from its panel's
    plane and still join it. An edge between two different panels is kept even
    if unmarked, so curvature is not flattened into a non-planar n-gon. Zero
    turns the guard off, which is the literal reading of "remove everything
    between the lines".
    """
    keep = set()

    crease = bm.edges.layers.float.get("crease_edge")

    groups = None
    if protect_angle > 0:
        if flat_dist is None:
            # a fraction of the model, so the same setting behaves the same on
            # a part 2 units across and one 0.04 across
            xs = [v.co for v in bm.verts]
            if xs:
                span = max(max(p[i] for p in xs) - min(p[i] for p in xs)
                           for i in range(3))
                # Measured on a real part: 0.002 let panels bulge 0.107% of
                # the model off plane, 0.0002 held them to 0.024% while still
                # merging 9888 faces down to 1516.
                flat_dist = span * 0.0002
            else:
                flat_dist = 1e-4
        groups = planar_groups(bm, protect_angle, flat_dist)

    for e in bm.edges:
        n = len(e.link_faces)

        # A border or a non-manifold edge is not a panel line, but dissolving
        # it destroys the outline or tears the mesh, so it is never offered up.
        if n != 2:
            if keep_boundary or n > 2:
                keep.add(e.index)
            continue

        if use_sharp and not e.smooth:
            keep.add(e.index); continue
        if use_selection and e.select:
            keep.add(e.index); continue
        if keep_seams and e.seam:
            keep.add(e.index); continue
        if keep_creased and crease is not None and e[crease] > 0.0:
            keep.add(e.index); continue

        if groups is not None:
            a, b = e.link_faces[0].index, e.link_faces[1].index
            if groups.get(a) != groups.get(b):
                keep.add(e.index)

    return keep


def panelize(bm, keep, *, dissolve_verts=True):
    """Remove every edge not in `keep`. Returns what happened.

    `dissolve_verts` also drops vertices left sitting in the middle of a
    straight run with nothing else attached; without it the panel keeps a
    fringe of vertices that do nothing and every later operation has to
    step over them.
    """
    doomed = [e for e in bm.edges if e.index not in keep]
    before_e, before_f, before_v = len(bm.edges), len(bm.faces), len(bm.verts)
    area_before = sum(f.calc_area() for f in bm.faces)
    if doomed:
        bmesh.ops.dissolve_edges(bm, edges=doomed,
                                 use_verts=dissolve_verts,
                                 use_face_split=False)
    bm.normal_update()
    return {
        "edges_removed": before_e - len(bm.edges),
        "faces_before": before_f,
        "faces_after": len(bm.faces),
        "verts_removed": before_v - len(bm.verts),
        "lines_kept": len(keep),
        "area_before": area_before,
        "area_after": sum(f.calc_area() for f in bm.faces),
    }


def count_marked(bm, *, use_sharp=True, use_selection=True):
    """How many lines the user has actually marked, for the UI to report."""
    sharp = sum(1 for e in bm.edges if not e.smooth and len(e.link_faces) == 2)
    sel = sum(1 for e in bm.edges if e.select and len(e.link_faces) == 2)
    return {"sharp": sharp, "selected": sel,
            "usable": (sharp if use_sharp else 0) + (sel if use_selection else 0)}


def bounds(bm):
    """Axis-aligned extent of the mesh, or None when it is empty."""
    if not bm.verts:
        return None
    lo = [min(v.co[i] for v in bm.verts) for i in range(3)]
    hi = [max(v.co[i] for v in bm.verts) for i in range(3)]
    return lo, hi


def check(bm, before, res, *, area_drop=0.35, span_shrink=0.10):
    """Describe a dissolve that looks like it destroyed geometry.

    This only reports now. It used to block, and blocking was wrong: on a real
    part it refused results Milad wanted, and the operator is undoable anyway.

    Merging faces conserves surface area, so a large drop means a region
    collapsed rather than becoming an n-gon. Area is not an exact invariant -
    a non-planar n-gon measures differently from the faces it replaced, which
    on a real part swung the figure by up to 30% in both directions - so the
    threshold is deliberately loose and paired with a silhouette test.

    Both are relative. An earlier absolute tolerance of 1e-5 refused a sound
    result whose bounds moved by 0.00015 on a part 0.038 across, which is
    corner-cutting from `dissolve_verts` doing its job, not damage.

    Measured on that part: collapse showed 90.7% and 77.3% area loss, sound
    runs stayed within 30%. Returns a warning string, or "" when sound.
    """
    if res["faces_after"] == 0:
        return ("Every face was removed. The regions between your lines had "
                "nothing holding them open - Ctrl+Z, then mark more lines or "
                "raise Protect Above.")

    a0 = res.get("area_before", 0.0)
    a1 = res.get("area_after", 0.0)
    if a0 > 0 and (a0 - a1) / a0 > area_drop:
        pct = 100 * (a0 - a1) / a0
        return (f"{pct:.0f}% of the surface is gone - a region collapsed "
                "instead of merging. Ctrl+Z if that was not what you wanted.")

    after = bounds(bm)
    if before is None or after is None:
        return "The mesh came out empty."
    for i, axis in enumerate("XYZ"):
        span_b = before[1][i] - before[0][i]
        span_a = after[1][i] - after[0][i]
        if span_b > 1e-12 and (span_b - span_a) / span_b > span_shrink:
            pct = 100 * (span_b - span_a) / span_b
            return (f"The model shrank {pct:.0f}% on {axis} - a region "
                    "collapsed instead of merging. Ctrl+Z if that was not "
                    "what you wanted.")
    return ""

def inside_marked_loops(bm, *, use_sharp=True, use_selection=True):
    """Edges lying strictly inside a region fully enclosed by marked lines.

    This is what marking a loop round a pocket is meant to do: that pocket
    becomes one face and the rest of the model is not touched at all. Deciding
    it by curvature instead was wrong - on a smooth part almost nothing is
    truly flat, so either nothing merged or, with the guard off, the whole
    model became one region and collapsed.

    A region qualifies only when every edge on its border is marked. A region
    that leaks into the rest of the mesh is left alone.
    """
    marked = set()
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        if use_sharp and not e.smooth:
            marked.add(e.index)
        elif use_selection and e.select:
            marked.add(e.index)
    if not marked:
        return set(), 0

    region = {}
    groups = []
    for seed in bm.faces:
        if seed.index in region:
            continue
        gid = len(groups)
        stack = [seed]
        region[seed.index] = gid
        faces = []
        while stack:
            f = stack.pop()
            faces.append(f)
            for e in f.edges:
                if e.index in marked:
                    continue
                for g in e.link_faces:
                    if g.index not in region:
                        region[g.index] = gid
                        stack.append(g)
        groups.append(faces)

    # On a closed mesh a single marked loop encloses BOTH sides, so the rest
    # of the model qualifies too and would be flattened along with the pocket.
    # Anything covering most of the mesh is the body, not a panel.
    body_limit = 0.4 * len(bm.faces)

    doomed = set()
    kept_regions = 0
    for gid, faces in enumerate(groups):
        if len(faces) > body_limit:
            continue
        idx = {f.index for f in faces}
        interior = set()
        enclosed = True
        for f in faces:
            for e in f.edges:
                if e.index in marked:
                    continue
                if len(e.link_faces) != 2:
                    enclosed = False       # region reaches the mesh border
                    break
                a, b = e.link_faces
                if a.index in idx and b.index in idx:
                    interior.add(e.index)
            if not enclosed:
                break
        if enclosed and interior:
            doomed |= interior
            kept_regions += 1
    return doomed, kept_regions



def enclosed_interior(bm, *, require_selected=False):
    """Edges strictly inside a region whose whole border is tagged.

    `e.tag` marks the lines to keep. A region that leaks past them - into the
    rest of the model or off the mesh border - is skipped entirely, and so is
    anything covering most of the mesh, which is the body rather than a panel.
    Without both tests a single loop takes the whole model with it.
    """
    region = {}
    groups = []
    for seed in bm.faces:
        if seed.index in region:
            continue
        gid = len(groups)
        stack = [seed]
        region[seed.index] = gid
        faces = []
        while stack:
            f = stack.pop()
            faces.append(f)
            for e in f.edges:
                if e.tag:
                    continue
                for g in e.link_faces:
                    if g.index not in region:
                        region[g.index] = gid
                        stack.append(g)
        groups.append(faces)

    # Spare only the single biggest region - the body the lines are drawn on.
    # A fixed 40% share was tried and blocked every band but the smallest, so
    # all but the last pair of lines looked like they did nothing.
    order = sorted(range(len(groups)), key=lambda i: len(groups[i]),
                   reverse=True)
    body = order[0] if len(order) > 1 else None

    doomed = set()
    for gi, faces in enumerate(groups):
        if gi == body:
            continue
        if require_selected:
            # Only clean a region the user pointed at. Other lines still split
            # regions - that is how they survive - but a pocket nobody selected
            # is left alone.
            touched = any(e.select for f in faces for e in f.edges)
            if not touched:
                continue
        idx = {f.index for f in faces}
        interior = set()
        ok = True
        for f in faces:
            for e in f.edges:
                if e.tag:
                    continue
                if len(e.link_faces) != 2:
                    # The mesh's own border closes a region just as well as a
                    # marked line. Refusing it meant a band across an open
                    # sheet never qualified, so nothing was ever removed.
                    continue
                a, b = e.link_faces
                if a.index in idx and b.index in idx:
                    interior.add(e)
            if not ok:
                break
        if ok:
            doomed |= interior
    return doomed


def _next_in_loop(e, v):
    """The edge continuing `e` straight through `v`, or None.

    On a quad grid that is the one edge at `v` sharing no face with `e`. A
    vertex that is not four-way has no unambiguous continuation, so the loop
    ends there.
    """
    # Written out rather than with sets and generators. It is called three
    # million times to survey a 127000-face mesh, and it was more than half
    # of the whole thinning run.
    le = v.link_edges
    if len(le) != 4:
        return None
    ef = e.link_faces
    if len(ef) == 2:
        f0, f1 = ef[0], ef[1]
    elif len(ef) == 1:
        f0 = f1 = ef[0]
    else:
        return None
    for o in le:
        if o is e:
            continue
        shared = False
        for f in o.link_faces:
            if f is f0 or f is f1:
                shared = True
                break
        if not shared:
            return o
    return None


def edge_loops(edges):
    """Split a set of edges into whole loops.

    Removing edges one at a time leaves a loop cut half way, which reads as a
    stray line going nowhere - Milad's words, it has to be there or not at all.
    Grouping first means a percentage takes whole loops instead.

    """
    # Walked in index order, not set order. A set of bmesh elements hashes on
    # the memory address, which is different every time the mesh is rebuilt -
    # so the seeds came out in a new order on every press and the same
    # settings gave 77, 65, 91 and 17 faces on four consecutive runs. Taking
    # a loop changes the topology for the next one, so the order decides the
    # whole result.
    pool = set(edges)
    order = sorted(edges, key=lambda e: e.index)
    loops = []
    for seed in order:
        if seed not in pool:
            continue
        pool.discard(seed)
        loop = [seed]
        for start_vert in (seed.verts[0], seed.verts[1]):
            cur, v = seed, start_vert
            while True:
                nxt = _next_in_loop(cur, v)
                if nxt is None:
                    # not a four-way vertex: the run genuinely stops here
                    break
                if nxt is seed or nxt not in pool:
                    break
                pool.discard(nxt)
                loop.append(nxt)
                v = nxt.other_vert(v)
                cur = nxt
        loops.append(loop)
    return loops


def _loop_error(loop):
    """How much shape is lost if this loop is removed, as an angle.

    Ranking a loop by its own bend was wrong: a loop running *around* a rounded
    end is straight along its length, so it scored as flat and went first,
    which is what turned a round slot into a polygon.

    Distance was wrong too. On a part 0.43 across, every loop came out between
    0 and 0.00005, so the ordering was effectively arbitrary and a curve was no
    safer than a flat run.

    The angle the surface turns across the loop is scale free: zero when the
    two crossing edges run straight through, growing as the surface bends.
    """
    worst = 0.0
    for e in loop:
        for v in e.verts:
            across = [o for o in v.link_edges if o not in loop]
            if len(across) != 2:
                continue
            a = across[0].other_vert(v).co - v.co
            b = across[1].other_vert(v).co - v.co
            if a.length < 1e-12 or b.length < 1e-12:
                continue
            worst = max(worst, math.pi - a.angle(b))
    return worst


def _adjacent(loops):
    """Which loops sit next to which, through a shared face."""
    owner = {}
    for i, loop in enumerate(loops):
        for e in loop:
            for f in e.link_faces:
                owner.setdefault(f.index, set()).add(i)
    near = {i: set() for i in range(len(loops))}
    for shared in owner.values():
        for i in shared:
            near[i] |= shared - {i}
    return near


def thin_out(edges, percent):
    """Keep a share of the interior, removing whole loops at a time.

    Two rules together, because either alone gives a bad result:

    - flattest first, so the loops holding a curve are the last to go
    - never two neighbours in the same pass, so the thinning spreads out

    Without the second, removal piles up wherever the surface happens to be
    flat and leaves the curved parts at full density - which reads as the tool
    ignoring half the area rather than protecting it.
    """
    if percent >= 100.0:
        return set(edges)
    if percent <= 0.0:
        return set()

    loops = edge_loops(edges)
    order = sorted(range(len(loops)),
                   key=lambda i: (_loop_error(set(loops[i])),
                                  min(e.index for e in loops[i])))
    near = _adjacent(loops)

    want = len(edges) * percent / 100.0
    taken = set()
    out = set()
    # Repeated passes: each pass skips anything touching a loop already taken,
    # so the gaps stay even. When a pass can place nothing more, the block is
    # lifted and the remainder is filled in error order.
    for blocking in (True, False):
        progress = True
        while progress and len(out) < want:
            progress = False
            for i in order:
                if len(out) >= want:
                    break
                if i in taken:
                    continue
                if blocking and (near[i] & taken):
                    continue
                taken.add(i)
                out.update(loops[i])
                progress = True
    return out


def merge_flat(bm, faces, angle_deg):
    """Merge neighbouring faces inside a region that lie close to one plane.

    Loop removal can only take whole rings, so it stops as soon as any ring
    carries shape. This works face by face instead and keeps going where the
    rings could not - inside a bore, the wall thins further without the mouth
    losing its circle.

    Returns how many faces went.
    """
    if angle_deg <= 0.0 or not faces:
        return 0
    keep = {f.index for f in faces}
    edges = [e for e in bm.edges
             if len(e.link_faces) == 2 and not e.tag
             and all(f.index in keep for f in e.link_faces)]
    if not edges:
        return 0
    verts = {v for e in edges for v in e.verts}
    before = len(bm.faces)
    bmesh.ops.dissolve_limit(bm, angle_limit=math.radians(angle_deg),
                             use_dissolve_boundaries=False,
                             verts=list(verts), edges=edges,
                             delimit={"NORMAL"})
    bm.normal_update()
    return before - len(bm.faces)


def region_faces(bm, require_selected=True):
    """The faces of every region the cleaning is allowed to touch."""
    region = {}
    groups = []
    for seed in bm.faces:
        if seed.index in region:
            continue
        gid = len(groups)
        stack = [seed]
        region[seed.index] = gid
        faces = []
        while stack:
            f = stack.pop()
            faces.append(f)
            for e in f.edges:
                if e.tag:
                    continue
                for g in e.link_faces:
                    if g.index not in region:
                        region[g.index] = gid
                        stack.append(g)
        groups.append(faces)
    if len(groups) < 2:
        return []
    body = max(range(len(groups)), key=lambda i: len(groups[i]))
    out = []
    for gi, faces in enumerate(groups):
        if gi == body:
            continue
        if require_selected and not any(e.select for f in faces for e in f.edges):
            continue
        out += faces
    return out


def _ring_of(faces):
    """The border loop of a face group, in order, or None if it is not one loop."""
    idx = {f.index for f in faces}
    border = []
    for f in faces:
        for e in f.edges:
            if len(e.link_faces) != 2:
                border.append(e)
            elif any(g.index not in idx for g in e.link_faces):
                border.append(e)
    border = list(dict.fromkeys(border))
    if len(border) < 3:
        return None
    link = {}
    for e in border:
        for v in e.verts:
            link.setdefault(v, []).append(e)
    if any(len(v) != 2 for v in link.values()):
        return None                     # branching or several rings
    start = border[0]
    ring = [start.verts[0], start.verts[1]]
    cur, prev = start, ring[1]
    while True:
        nxt = next((e for e in link[prev] if e is not cur), None)
        if nxt is None:
            return None
        v = nxt.other_vert(prev)
        if v is ring[0]:
            break
        ring.append(v)
        cur, prev = nxt, v
        if len(ring) > len(border):
            return None
    return ring if len(ring) == len(border) else None


def fan_to_centre(bm, faces, snap=None):
    """Replace a region's interior with a fan meeting at one point.

    Thinning by loops always leaves the loops that could not be removed ending
    somewhere in the middle - the loose ends Milad kept pointing at. A fan has
    no interior loops at all: every edge runs from the border to a single
    centre, so there is nothing left to trail off.

    `snap` is a BVH of the original surface; without it the centre sits at the
    ring's flat centroid and a domed floor would go flat.

    Returns the number of faces removed, or 0 when the region is not a single
    ring the fan can be built on.
    """
    ring = _ring_of(faces)
    if ring is None or len(ring) < 3:
        return 0
    mid = ring[0].co.copy()
    for v in ring[1:]:
        mid = mid + v.co
    mid = mid / len(ring)

    if snap is not None:
        # Cast along the region's own normal rather than taking the nearest
        # point on the surface. Nearest pulls the centre sideways onto whatever
        # wall happens to be closest - inside a bore it landed hard against the
        # side instead of sitting in the middle of the floor.
        nrm = None
        for f in faces:
            n = f.normal
            if n.length > 1e-12:
                nrm = n.copy() if nrm is None else nrm + n
        if nrm is not None and nrm.length > 1e-12:
            nrm.normalize()
            best = None
            for direction in (nrm, -nrm):
                hit = snap.ray_cast(mid - direction * 1e-4, direction)
                if hit and hit[0] is not None:
                    d = (hit[0] - mid).length
                    if best is None or d < best[1]:
                        best = (hit[0], d)
            if best is not None:
                mid = best[0]
            else:
                near = snap.find_nearest(mid)
                if near and near[0] is not None:
                    mid = near[0]

    before = len(bm.faces)
    bmesh.ops.delete(bm, geom=list(faces), context="FACES")
    centre = bm.verts.new(mid)
    bm.verts.index_update()
    for i, v in enumerate(ring):
        w = ring[(i + 1) % len(ring)]
        try:
            bm.faces.new((v, w, centre))
        except ValueError:
            pass
    bm.normal_update()
    return before - len(bm.faces)


def heal_stubs(bm, *, straight_deg=170.0, confine=None, overrun=10):
    """Carry on removing an edge that dead-ends into a straight run.

    A loop that could only be taken part of the way leaves its last edge
    stubbing into an otherwise unbroken run - the loose ends Milad kept
    pointing at. Measured on a real part: the model went in with none of these
    and came out of an 80% clean with twenty-seven.

    The vertex to look for has three edges where two run straight through; the
    odd one out is the stub. Rather than dissolve it and rescan - which took
    600 passes over 70k vertices to settle - each stub is followed along its
    own loop to wherever it ends, and the whole run goes at once.

    A tagged edge stops the walk: that is a line the user asked to keep.

    `confine` is the set of edges the walk may touch. Without it a run is
    followed wherever the loop goes, which is right for tidiness and wrong for
    a model where that same loop is shaping something else further along - it
    reaches over and takes that apart too.

    Confining it strictly went too far the other way: measured on a real part,
    32 loose ends survived with it on and 2 with it off, because a run that
    needs a few edges outside the area to reach an end never gets them. So the
    walk may cross the boundary for up to `overrun` edges. Anything still
    unfinished by then is a loop heading off across the model, and that run is
    dropped rather than followed.
    """
    limit = math.radians(straight_deg)

    def stub_at(v):
        """The edge left over at `v` when a run stopped here, or None.

        Two signals, because either alone misses cases. On a flat stretch the
        run reads as two edges in a straight line and the third is the stub -
        that is the angle test. On a fillet nothing is straight: measured on a
        real part, every one of these vertices came out between 120 and 167
        degrees, the same range as the model's own corners, so no threshold
        can separate them.

        What does separate them is the faces. A vertex that was always a pole
        has three quads round it - 54 of 64 on that part. A leftover has an
        n-gon, because the merge that removed the run left one, and the stub
        is the edge sitting between the two biggest faces.
        """
        es = list(v.link_edges)
        if len(es) != 3:
            return None

        def usable(e):
            return not e.tag and len(e.link_faces) == 2

        # Two of the three are the user's own lines and the third is not:
        # then the third is the stub, with nothing to guess at. This is the
        # common case where a run stopped against a marked line, and it was
        # being missed entirely - 32 of these survived a 50% clean.
        free = [e for e in es if not e.tag]
        if len(free) == 1 and usable(free[0]):
            return free[0]

        sizes = sorted((len(f.verts) for f in v.link_faces), reverse=True)
        if len(v.link_faces) == 3 and sizes[0] > 4:
            # structural: the edge between the two largest faces
            ranked = sorted(
                (e for e in es if usable(e)),
                key=lambda e: -sum(len(f.verts) for f in e.link_faces))
            if ranked and sum(len(f.verts) for f in ranked[0].link_faces) > 8:
                return ranked[0]

        # The angle test alone cannot tell a leftover from a pole the model
        # was built with. On Milad's dress it called all 132 of the mesh's own
        # three-way vertices loose ends, followed each one's loop across the
        # model, and took 1,658 faces down to 53 in a single step - after a
        # drop that had removed exactly one loop. The signal this function's
        # own reasoning relies on is the n-gon: a merge that removed a run
        # leaves one behind, and a pole that was always there has quads all
        # round. So the n-gon is now required, not merely preferred.
        if sizes[0] <= 4:
            return None
        best = None
        for i in range(3):
            for j in range(i + 1, 3):
                a = es[i].other_vert(v).co - v.co
                b = es[j].other_vert(v).co - v.co
                if a.length < 1e-12 or b.length < 1e-12:
                    continue
                ang = a.angle(b)
                if best is None or ang > best[0]:
                    best = (ang, 3 - i - j)
        if best is None or best[0] < limit:
            return None
        e = es[best[1]]
        return e if usable(e) else None

    doomed = set()
    for v in list(bm.verts):
        e = stub_at(v)
        if e is None or e in doomed:
            continue
        # follow this run to its far end, taking every edge on the way
        run = [e]
        outside = 0 if (confine is None or e in confine) else 1
        cur, at = e, e.other_vert(v)
        finished = True
        while True:
            nxt = _next_in_loop(cur, at)
            if nxt is None or nxt.tag or nxt in doomed:
                break
            if len(nxt.link_faces) != 2:
                break
            if confine is not None and nxt not in confine:
                outside += 1
                if outside > overrun:
                    finished = False    # heading off across the model
                    break
            run.append(nxt)
            at = nxt.other_vert(at)
            cur = nxt
        if finished:
            doomed.update(run)

    if doomed:
        dissolve_keeping_rims(bm, doomed)
    return len(doomed)


def _parallel_adjacent(loops):
    """Loops that run alongside each other, one face apart.

    Sharing a face is not enough: on a quad grid a loop also shares faces with
    every loop crossing it, and colouring through those gives a checkerboard
    rather than stripes - measured, 13 of 14 picks ended up next to another
    pick. Two loops only count as neighbours here when they sit on *opposite*
    edges of the same quad, which is what running parallel means.
    """
    owner = {}
    for i, loop in enumerate(loops):
        for e in loop:
            for f in e.link_faces:
                owner.setdefault(f, []).append((i, e))
    near = {i: set() for i in range(len(loops))}
    for f, entries in owner.items():
        if len(entries) < 2 or len(f.edges) != 4:
            continue
        ring = list(f.edges)
        for a in range(len(entries)):
            for b in range(a + 1, len(entries)):
                ia, ea = entries[a]
                ib, eb = entries[b]
                if ia == ib:
                    continue
                try:
                    if abs(ring.index(ea) - ring.index(eb)) == 2:
                        near[ia].add(ib)
                        near[ib].add(ia)
                except ValueError:
                    pass
    return near


def thin_alternate(edges, percent=100.0):
    """Take every other loop, walking along the grid rather than ranking.

    The second pass wants a plain, readable result: one line gone, one line
    kept. Sorting by how much shape each loop carries is right for the first
    pass, where the point is to protect a curve, but on the second it leaves a
    pattern nobody can predict.

    Loops are coloured by how far they sit from a starting loop, counted
    through shared faces, and the even colours are taken. `percent` trims how
    far along that sequence to go, so it can still be eased off.
    """
    loops = edge_loops(edges)
    if not loops:
        return set()
    near = _parallel_adjacent(loops)

    colour = {}
    order = []
    for seed in range(len(loops)):
        if seed in colour:
            continue
        colour[seed] = 0
        queue = [seed]
        while queue:
            i = queue.pop(0)
            order.append(i)
            for j in near[i]:
                if j not in colour:
                    colour[j] = 1 - colour[i]
                    queue.append(j)

    picks = [i for i in order if colour[i] == 0]
    if percent < 100.0:
        picks = picks[:int(round(len(picks) * max(percent, 0.0) / 100.0))]
    out = set()
    for i in picks:
        out.update(loops[i])
    return out


def dissolve_keeping_rims(bm, doomed, region=None, sag_limit=0.0,
                          polish=False):
    """Dissolve edges without letting a curved ring lose its vertices.

    `dissolve_edges(use_verts=True)` also merges any vertex left with two
    edges. On the rim of a bore that is every vertex whose spokes just went,
    so the ring survives as edges but collapses from a circle to a polygon -
    the holes in Milad's panel came out square.

    The rule is not about rims, regions or mesh borders, and every attempt to
    describe it that way missed a case: border edges are absent on a closed
    part, and a bend threshold misses a rim that is filleted, where each step
    is only a few degrees.

    What actually matters is whether removing the vertex moves the surface.
    Two edges in a straight line can be joined for nothing; two edges at an
    angle cannot, because the corner between them is the shape. So only
    collinear vertices go, and a circle keeps every point it had.

    `sag_limit` is the one exception, and it is the same budget Round Below
    spends: a vertex whose corner is shallower than that may go, because
    losing it moves the surface by less than the tolerance. Without this a
    thinned cylinder keeps every one of its old vertices as a two-edge point
    and the faces around it come out as n-gons - 2396 of them, measured on a
    128-segment sphere.
    """
    if not doomed:
        return
    bmesh.ops.dissolve_edges(bm, edges=sorted(doomed, key=lambda e: e.index), use_verts=False,
                             use_face_split=False)
    bm.normal_update()

    stranded = []
    for v in bm.verts:
        es = list(v.link_edges)
        if len(es) != 2:
            continue
        if es[0].tag or es[1].tag:
            continue
        a = es[0].other_vert(v).co - v.co
        b = es[1].other_vert(v).co - v.co
        if a.length < 1e-12 or b.length < 1e-12:
            continue
        if polish:
            # the whole-model drop: any unmarked vertex left with two edges
            # is litter from a removed loop, however much its corner bends.
            # Milad's fillet rings came back as rows of thousands of dots -
            # each kept because a curved ring never reads as straight. Only
            # the lines he marked keep every point; they are the circles
            # worth keeping round.
            stranded.append(v)
            continue
        if a.angle(b) >= STRAIGHT:
            stranded.append(v)
        elif sag_limit > 0.0:
            ab = b - a
            n = ab.length
            if n > 1e-12:
                t = min(max((-a).dot(ab) / (n * n), 0.0), 1.0)
                if (-(a + ab * t)).length <= sag_limit:
                    stranded.append(v)
    if stranded:
        bmesh.ops.dissolve_verts(bm, verts=stranded)
        bm.normal_update()


def parallel_chains(loops):
    """Order each family of parallel loops into a sequence.

    Loops that run alongside each other form a chain: first, second, third
    across the surface. Getting that order is what lets a percentage mean
    something regular - every second line, every third - instead of a set
    picked by score and scattered wherever the scores happened to fall.
    """
    near = _parallel_adjacent(loops)
    seen = set()
    chains = []
    for start in range(len(loops)):
        if start in seen:
            continue
        # walk to one end first so the chain comes out in order
        end, guard = start, 0
        prev = None
        while guard < len(loops):
            guard += 1
            nxt = [j for j in near[end] if j != prev]
            if not nxt:
                break
            prev, end = end, nxt[0]
            if end == start:
                break                      # a ring, any point will do
        chain, prev, cur = [], None, end
        while cur is not None and cur not in seen:
            seen.add(cur)
            chain.append(cur)
            nxt = [j for j in near[cur] if j != prev and j not in seen]
            prev, cur = cur, (nxt[0] if nxt else None)
        if chain:
            chains.append(chain)
    return chains


def thin_regular(edges, percent):
    """Take loops at even intervals along each family, not by score.

    Ranking by how much shape a loop carries protects curvature but gives no
    pattern a person can read - Milad's word for it was random. Spacing the
    removals evenly along each chain is the structure: at 50 every second line
    goes, at 33 every third, and the result is the same wherever you look.
    """
    if percent >= 100.0:
        return set(edges)
    if percent <= 0.0:
        return set()

    loops = edge_loops(edges)
    if not loops:
        return set()

    out = set()
    for chain in parallel_chains(loops):
        n = len(chain)
        take = int(round(n * percent / 100.0))
        if take <= 0:
            continue
        if take >= n:
            for i in chain:
                out.update(loops[i])
            continue
        # evenly spaced positions along the chain
        step = n / take
        for k in range(take):
            out.update(loops[chain[min(int(k * step + step / 2), n - 1)]])
    return out


def thin_keep_every(edges, n):
    """Keep one loop in every `n` along each family, drop the rest.

    A percentage cannot give a regular result: 41.74% has no whole-number
    meaning, so the gaps came out 3, 4, 3, 4 and it read as arbitrary. An
    integer does - keep 1 in 2 and every second line goes, 1 in 3 and two out
    of three go, the same everywhere on the model.
    """
    if n <= 1:
        return set()
    loops = edge_loops(edges)
    if not loops:
        return set()
    out = set()
    for chain in parallel_chains(loops):
        for k, i in enumerate(chain):
            if k % n:
                out.update(loops[i])
    return out


def region_border(faces):
    """The edges bounding a face group, and whether they form one clean ring."""
    idx = {f.index for f in faces}
    border = []
    for f in faces:
        for e in f.edges:
            if len(e.link_faces) != 2 or any(g.index not in idx for g in e.link_faces):
                border.append(e)
    border = list(dict.fromkeys(border))
    if len(border) < 4:
        return border, False
    at = {}
    for e in border:
        for v in e.verts:
            at.setdefault(v, []).append(e)
    single = all(len(v) == 2 for v in at.values())
    return border, single


def rebuild_region(bm, faces, snap=None):
    """Throw the inside away and lay a fresh quad grid across the border.

    NOT WIRED UP. Kept because the idea is sound and the notes below are worth
    having; the button was taken out because Grid Fill refuses most real
    regions - see `rebuild_region_rings`, which does not.

    Everything before this subtracted from what was there, and on a corner
    where two fillets meet there is no grid to subtract from - the loops end at
    poles and cross each other, so no ordering exists and the result reads as
    arbitrary however it is dressed up. Measured on Milad's part, the loops
    inside one region fell into chains of 30, 5, 4, 1 and 1: one real family
    and four strays.

    Building instead of subtracting sidesteps that. The border is kept exactly,
    so the region still meets the rest of the model on the same vertices, and
    the inside becomes a clean grid.

    `snap` is a BVH of the surface as it was; without it the new grid spans the
    border flat and any doming is lost.

    The faces are written down before they are deleted and put back if the fill
    does not take. Deleting first and hoping left the area simply empty - the
    grid fill refuses more often than it looks like it should, and there was
    nothing to fall back to.

    Returns the number of faces the region had, or 0 if it was left alone.
    """
    border, single = region_border(faces)
    if not single or len(border) < 4:
        return 0
    if len(border) % 2:
        return 0            # grid fill needs an even loop

    before = len(faces)
    # remember them as vertex lists, which survive the delete
    recipe = [[v for v in f.verts] for f in faces]

    bmesh.ops.delete(bm, geom=list(faces), context="FACES_ONLY")
    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.ensure_lookup_table()

    known = {v.index for v in bm.verts}
    made = 0
    try:
        n0 = len(bm.faces)
        bmesh.ops.grid_fill(bm, edges=border, mat_nr=0,
                            use_smooth=False, use_interp_simple=False)
        made = len(bm.faces) - n0
    except Exception:
        made = 0

    if made <= 0:
        # put the area back exactly as it was
        for verts in recipe:
            if all(v.is_valid for v in verts):
                try:
                    bm.faces.new(verts)
                except ValueError:
                    pass
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        return 0

    bm.normal_update()
    if snap is not None:
        for v in bm.verts:
            if v.index in known:
                continue
            hit = snap.find_nearest(v.co)
            if hit and hit[0] is not None:
                v.co = hit[0]
        bm.normal_update()
    return before


def min_three_edges(bm):
    """Every vertex must have at least three edges. Clear out the ones that do not.

    Three cases, and they need different treatment:

    - no edges at all: a stray point, deleted
    - one edge: a spur going nowhere, deleted with its edge
    - two edges: sitting mid-run, dissolved so the two edges become one

    The two-edge case is the one to watch. On a straight run joining the edges
    changes nothing, but on the rim of a bore every vertex has exactly two
    edges once its spokes are gone, and joining them turns the circle into a
    polygon. The count of those is returned so the caller can say so.
    """
    loose = [v for v in bm.verts if len(v.link_edges) == 0]
    spurs = [v for v in bm.verts if len(v.link_edges) == 1]
    pairs = [v for v in bm.verts if len(v.link_edges) == 2]

    bent = 0
    for v in pairs:
        a, b = (e.other_vert(v).co - v.co for e in v.link_edges)
        if a.length > 1e-12 and b.length > 1e-12 and a.angle(b) < STRAIGHT:
            bent += 1

    if loose or spurs:
        bmesh.ops.delete(bm, geom=loose + spurs, context="VERTS")
        bm.verts.ensure_lookup_table()
        pairs = [v for v in bm.verts if len(v.link_edges) == 2]
    if pairs:
        bmesh.ops.dissolve_verts(bm, verts=pairs)
    bm.normal_update()
    return {"loose": len(loose), "spurs": len(spurs),
            "two_edge": len(pairs), "of_those_on_a_curve": bent}


def min_four_edges(bm):
    """Every vertex must have at least four edges. Clear out the ones below.

    The same three cases as `min_three_edges`, and then one more: a vertex
    with exactly three edges. In a quad mesh that is a pole - the place where
    a loop dies - and dissolving it merges the three faces round it into one
    n-gon, which is how a run that stopped in the middle of a surface is made
    to carry on.

    This is a heavier hand than the three-edge pass and it is meant to be:
    poles are what a hand-built cage uses to change density, so a model that
    was built rather than scanned will lose that structure. The count of
    dissolved poles is returned so the caller can say how much went.
    """
    got = min_three_edges(bm)
    bm.verts.ensure_lookup_table()
    poles = [v for v in bm.verts if len(v.link_edges) == 3]
    # A pole on an open border is not a pole, it is a corner of the border,
    # and dissolving it eats into the edge of the mesh.
    poles = [v for v in poles
             if not any(len(e.link_faces) < 2 for e in v.link_edges)]
    if poles:
        bmesh.ops.dissolve_verts(bm, verts=poles)
        bm.normal_update()
    got["three_edge"] = len(poles)
    return got


def sweep_flat(bm, amount=0.3, keep_marked=True):
    """Dissolve the flattest of the leftover edges a loop drop cannot reach.

    The drop is whole-loop-or-nothing, which is what keeps it safe. What it
    leaves behind is everything that is not a loop: the zig-zag staircases
    running down the middle of Milad's beam, short runs that start and stop
    in the surface and belong to no ring at all. No setting removes them,
    because there is no loop there to remove.

    This works one edge at a time instead, taking the flattest first.

    It used to take an angle in degrees, and on a scanned surface that
    number meant nothing: the middle dihedral on Milad's beam is 20 degrees,
    so everything under about 10 swept nothing at all and everything over 25
    swept the same lot. `amount` is a share of the free edges instead - 0.3
    takes the flattest three in ten - so every step of the slider moves the
    result, and 1.0 is "all of them" rather than a number to go hunting for.

    Marks, seams and sharp edges are left alone, the same as everywhere else.
    """
    if amount <= 0.0:
        return 0
    free = []
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        if keep_marked and e.tag:
            continue
        f1, f2 = e.link_faces
        if not f1.normal.length or not f2.normal.length:
            continue
        free.append((f1.normal.angle(f2.normal), e.index, e))
    if not free:
        return 0
    free.sort(key=lambda r: (r[0], r[1]))
    take = int(round(len(free) * min(amount, 1.0)))
    if take <= 0:
        return 0
    doomed = [r[2] for r in free[:take]]
    bmesh.ops.dissolve_edges(bm, edges=doomed, use_verts=True,
                             use_face_split=False)
    bm.normal_update()
    return len(doomed)


def absorb_small(bm, pct=0.25, keep_marked=True):
    """Collapse the faces that are far smaller than the mesh's own average.

    A different tool from `sweep_flat`, and for a different reason. Sweeping
    asks "is this edge flat", which on a scanned surface is true nearly
    everywhere, so it merges the big faces too and the beam comes out
    flattened. This asks "is this face tiny", which is true only of the
    leftovers - the ladder of little quads a drop leaves strung along a
    surface - and leaves everything else exactly as it was.

    Each one is collapsed to its own centre rather than dissolved. Nothing
    is merged across it, so the faces around it keep their shape and their
    UV; the surface moves by the size of the face and no more. Measured on
    Milad's beam at a quarter of the median: 47 faces collapsed, 251 down to
    192, and the surface moved 0.076 on a model 93 across - eight hundredths
    of one percent.

    Faces on an open border are left alone, or the silhouette would be eaten
    into.
    """
    bm.faces.ensure_lookup_table()
    areas = [f.calc_area() for f in bm.faces]
    if not areas:
        return 0
    limit = sorted(areas)[len(areas) // 2] * pct
    small = []
    for f, a in zip(bm.faces, areas):
        if a >= limit:
            continue
        if any(len(e.link_faces) < 2 for e in f.edges):
            continue
        if keep_marked and all(e.tag for e in f.edges):
            continue        # a face fenced in on every side was meant to stay
        small.append([v for v in f.verts])
    if not small:
        return 0
    done = 0
    for verts in small:
        verts = [v for v in verts if v.is_valid]
        if len(verts) < 2:
            continue
        mid = verts[0].co.copy()
        for v in verts[1:]:
            mid += v.co
        mid /= len(verts)
        bmesh.ops.pointmerge(bm, verts=verts, merge_co=mid)
        done += 1
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.normal_update()
    return done


def _ordered_ring(border):
    """The border edges walked into an ordered vertex loop, or None."""
    at = {}
    for e in border:
        for v in e.verts:
            at.setdefault(v, []).append(e)
    if any(len(v) != 2 for v in at.values()):
        return None
    start = border[0]
    ring = [start.verts[0], start.verts[1]]
    cur, prev = start, ring[1]
    while True:
        nxt = next((e for e in at[prev] if e is not cur), None)
        if nxt is None:
            return None
        v = nxt.other_vert(prev)
        if v is ring[0]:
            break
        ring.append(v)
        cur, prev = nxt, v
        if len(ring) > len(border):
            return None
    return ring if len(ring) == len(border) else None


def rebuild_region_rings(bm, faces, snap=None, rings=None):
    """Fill a region with rings running inward from its border.

    NOT WIRED UP. It works - measured 17308 to 17363 faces on a real region
    with nothing non-manifold and no drift from the surface - but the result
    was not good enough to keep, so the button came out. Left here to pick up
    again rather than rebuilt from scratch.

    Grid Fill only takes a four-sided patch. On a real region it refuses -
    Blender's own operator says "connecting edge loops overlap" and makes
    nothing - so the whole rebuild did nothing at all.

    Working inward has no such condition. Each ring copies the one outside it,
    pulled toward the middle and dropped back onto the original surface, and
    the two are joined with quads. Only the innermost ring is closed off, so
    everything else is four sided and the border is untouched, which is what
    keeps the area stitched to the rest of the model.

    `rings` sets how many to build; left out, it follows the spacing the border
    already has so the new grid matches the density around it.
    """
    border, single = region_border(faces)
    if not single or len(border) < 4:
        return 0
    ring = _ordered_ring(border)
    if ring is None or len(ring) < 4:
        return 0

    n = len(ring)
    mid = ring[0].co.copy()
    for v in ring[1:]:
        mid = mid + v.co
    mid = mid / n

    if rings is None:
        # match the border's own spacing: how many steps of that size fit
        # between the border and the middle
        step = sum((ring[i].co - ring[(i + 1) % n].co).length
                   for i in range(n)) / n
        reach = sum((v.co - mid).length for v in ring) / n
        rings = max(1, min(24, int(round(reach / max(step, 1e-9)))))

    before = len(faces)
    recipe = [[v for v in f.verts] for f in faces]
    bmesh.ops.delete(bm, geom=list(faces), context="FACES_ONLY")
    bm.verts.ensure_lookup_table()

    made = []
    outer = ring
    try:
        for k in range(1, rings + 1):
            t = k / (rings + 1)
            if k == rings:
                inner = None            # close the middle instead
            else:
                inner = []
                for v in outer:
                    p = v.co.lerp(mid, 1.0 / (rings + 1 - (k - 1)))
                    if snap is not None:
                        hit = snap.find_nearest(p)
                        if hit and hit[0] is not None:
                            p = hit[0]
                    inner.append(bm.verts.new(p))
                bm.verts.index_update()
            if inner is None:
                made.append(bm.faces.new(outer))
                break
            for i in range(n):
                a, b = outer[i], outer[(i + 1) % n]
                c, d = inner[(i + 1) % n], inner[i]
                made.append(bm.faces.new((a, b, c, d)))
            outer = inner
    except Exception:
        for f in made:
            if f.is_valid:
                bm.faces.remove(f)
        for verts in recipe:
            if all(v.is_valid for v in verts):
                try:
                    bm.faces.new(verts)
                except ValueError:
                    pass
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        return 0

    bm.faces.ensure_lookup_table()
    bm.normal_update()
    return before


def _loop_impact(loop):
    """How far the surface would move if this loop went, in model units.

    The angle measure says which way the surface is turning but not by how
    much, so on a big gentle curve it reads as flat. This is the sag itself:
    for every vertex on the loop, the distance from the line joining its two
    neighbours across. That is the gap the surface has to bridge once the loop
    is gone.
    """
    worst = 0.0
    for e in loop:
        for v in e.verts:
            across = [o for o in v.link_edges if o not in loop]
            if len(across) != 2:
                continue
            a = across[0].other_vert(v).co
            b = across[1].other_vert(v).co
            ab = b - a
            n = ab.length
            if n < 1e-12:
                continue
            t = (v.co - a).dot(ab) / (n * n)
            t = min(max(t, 0.0), 1.0)
            worst = max(worst, (v.co - (a + ab * t)).length)
    return worst


def loop_axis(loop):
    """Which axis this loop runs along: 0 for X, 1 for Y, 2 for Z.

    The direction the loop's own edges travel in - what it looks like on
    screen. Milad's words: ticking Z should select the vertical lines.

    An earlier version answered with the direction the mesh gets thinner in
    when the loop goes, which for a ring round a beam is the beam's length.
    That is the more useful answer for the drop and the wrong answer for the
    eye: a plainly vertical line came back labelled X, because taking it
    makes the model coarser sideways. The eye wins - this is the number the
    Only Axis buttons are read against.

    The edge lengths are summed per axis and the largest takes it, so every
    loop belongs to exactly one axis and the three groups partition them. An
    exact tie is broken by axis order, never by floating-point noise.
    """
    x = y = z = 0.0
    for e in loop:
        d = e.verts[0].co - e.verts[1].co
        x += abs(d.x); y += abs(d.y); z += abs(d.z)
    comp = (x, y, z)
    top = max(comp)
    if top <= 0.0:
        return 0
    eps = top * 1e-9
    for i, c in enumerate(comp):
        if c >= top - eps:
            return i
    return 0


def _axis_match(loop, axes, purity=0.0, rot=None):
    """Does this loop count as belonging to a ticked axis?

    The same test Select Axis Loops uses, so the drop takes exactly what the
    selection shows. A loop is in if any one of its edges runs along a ticked
    axis - and the axis is read in world space, the way the gizmo in the
    corner of the viewport reads it.

    Four earlier tests were wrong. "Any ticked axis carrying over 40% of the
    length" let one loop answer to two axes. A tolerance of three quarters
    still overlapped. Then every edge had to point the same way, which was
    watertight and useless: a ring round a beam turns constantly, so it
    qualified for nothing. Then the direction the loop thins in, which is the
    better answer for the drop and the wrong one for the eye - a plainly
    vertical line came back labelled X.

    Milad settled it: ticking Z means the lines that look vertical, and the
    whole of each such line, however it turns further along. Loops can now
    fall under two axes, and that is correct - a line that runs up the front
    of a model and along the top really is both.

    `purity` is accepted and ignored; the slider it belonged to is gone.
    """
    if not any(axes):
        # every axis unticked reads as "no filter", not "remove nothing" -
        # all three off is how Milad's panel quietly turned the whole drop
        # dead and made it look like the feature had been removed.
        return True
    for e in loop:
        d = e.verts[0].co - e.verts[1].co
        if rot is not None:
            d = rot @ d
        comp = (abs(d.x), abs(d.y), abs(d.z))
        top = max(comp)
        if top <= 0.0:
            continue
        if axes[comp.index(top)]:
            return True
    return False


def thin_every(bm, n, keep_marked=True, axes=(True, True, True),
               purity=0.0, rot=None):
    """Remove `n` loops for every one kept, in order along the surface.

    This is the drop with the judgement removed: no flatness test, no scoring,
    just a regular pattern. Whole loops only, ordered by parallel_chains so
    the rhythm reads the same wherever you look, and each family keeps its
    first loop so the pattern anchors at a feature rather than mid-surface.
    """
    if n < 1:
        return set(), 0
    pool = []
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        if keep_marked and e.tag:
            continue
        pool.append(e)
    if not pool:
        return set(), 0
    whole, partial = complete_loops(pool)
    # The runs that never close are thinned too. Leaving them out is right
    # for Flat Below, which must not take a line half way, but this is a
    # pattern: skipping them left whole regions of Milad's plank untouched
    # while the region beside it was thinned, and there is no reading of
    # "one in three" that looks like that. 110 of the 894 runs on his part
    # were being passed over.
    whole = whole + partial
    if not all(axes):
        whole = [lp for lp in whole
                 if _axis_match(lp, axes, purity, rot)]
    if not whole:
        return set(), 0
    # `n` counts the lines removed for every one kept: 1 is every other
    # line, 2 leaves one in three, 3 one in four. Milad's first description
    # was the other way round - keep n-1, take one - and at 3 that read as
    # barely touching the mesh when he wanted it three times thinner.
    # Keepers are placed by distance along the surface, not by counting
    # loops off in steps. Counting treats every gap as equal, and on a mesh
    # that has already been thinned the gaps are anything but - two lines
    # sitting 0.4 apart next to a 26-wide space counted the same, so an
    # unlucky phase kept both halves of the tight pair. Walking the chain by
    # accumulated distance puts each keeper at an evenly spaced position on
    # the model itself, and of a doubled pair at one position only one can
    # be nearest it.
    doomed = set()
    dropped = 0
    period = n + 1
    # Every run gets a family, even if it is a family of one. parallel_chains
    # only reports the runs it could line up side by side, and on Milad's
    # plank 321 of the 894 selected runs were in none of them - the pattern
    # never reached those, and they were exactly the lines left standing
    # while their neighbours went.
    chains = parallel_chains(whole)
    grouped = set()
    for chain in chains:
        grouped.update(chain)
    chains = list(chains) + [[i] for i in range(len(whole))
                             if i not in grouped]
    for chain in chains:
        mids = []
        for idx in chain:
            xs = ys = zs = cnt = 0.0
            for e in whole[idx]:
                for v in e.verts:
                    xs += v.co.x; ys += v.co.y; zs += v.co.z; cnt += 1
            mids.append((xs / cnt, ys / cnt, zs / cnt))
        pos = [0.0]
        for a, b in zip(mids, mids[1:]):
            pos.append(pos[-1] + math.dist(a, b))
        total = pos[-1]
        # A short family used to keep its only line whatever the setting -
        # `max(1, ...)` - and on Milad's plank 36 of the 342 runs were alone
        # in their family and another 54 sat in families shorter than the
        # period. Those were exactly the lines left standing while the ones
        # beside them went, which is not a pattern anyone can read. A family
        # too short to hold even one keeper at this spacing is taken whole.
        keep_n = round(len(chain) / period)
        if keep_n <= 0:
            for idx in chain:           # the whole family goes
                doomed.update(whole[idx])
                dropped += 1
            continue
        if total <= 0.0:
            keep = set(range(0, len(chain), period))
        else:
            # march along the surface and keep the first loop past each
            # stride. Snapping to nearest-target could still land two
            # keepers on both halves of a tight pair when the targets
            # straddled it; a march can never keep two loops closer
            # together than the stride.
            # constant rhythm: each keeper is the loop closest to exactly
            # one stride past the previous keeper, never nearer than 0.6 of
            # it. Milad's rule - no kept line may sit closer than the rest;
            # the spacing is as constant as the lines on the surface allow.
            stride = total / keep_n
            keep = {0}
            last = pos[0]
            k = 1
            while k < len(chain):
                target = last + stride
                best = None
                for j in range(k, len(chain)):
                    if pos[j] - last < stride * 0.6:
                        continue
                    if best is None or abs(pos[j] - target) < abs(pos[best] - target):
                        best = j
                    if pos[j] > target:
                        break
                if best is None:
                    break
                keep.add(best)
                last = pos[best]
                k = best + 1
        for k, idx in enumerate(chain):
            if k not in keep:
                doomed.update(whole[idx])
                dropped += 1
    return doomed, dropped


def polish_verts(bm, uv_layers=None):
    """Sweep out every vertex left holding only two edges.

    The dissolve cleans up after itself, but heal_stubs runs after it and
    leaves new two-edge vertices of its own - 3293 of them on Milad's
    barrel, with nothing downstream to claim them. One last sweep, repeated
    because dissolving a vertex can expose its neighbour.

    Marked vertices used to be skipped outright, and on a model with UVs
    that meant skipping all of them: after a drop on Milad's beam, all 278
    stranded vertices sat on protected edges, so the loop came out but its
    vertices stayed strung along the surviving lines. They are what the
    little squares were made of.

    A marked vertex is now taken too, but only when the two edges meeting
    there are marked the same way and run straight on through it - in 3D and
    in every UV layer. The seam then continues as one longer edge and
    nothing about it is lost; a real corner, where the seam turns, is left
    alone.
    """
    straight = math.radians(170.0)
    layers = list(uv_layers) if uv_layers else []

    def same_mark(a, b):
        return (a.seam == b.seam and a.smooth == b.smooth
                and a.select == b.select and a.tag == b.tag)

    def runs_through(v):
        es = v.link_edges
        a = es[0].other_vert(v).co - v.co
        b = es[1].other_vert(v).co - v.co
        if a.length <= 1e-12 or b.length <= 1e-12:
            return False
        if a.angle(b) < straight:
            return False
        for lay in layers:
            for f in v.link_faces:
                here = other = None
                mine = [lp for lp in f.loops if lp.vert is v]
                if not mine:
                    continue
                here = mine[0][lay].uv
                ends = []
                for e in es:
                    w = e.other_vert(v)
                    got = [lp for lp in f.loops if lp.vert is w]
                    if got:
                        ends.append(got[0][lay].uv)
                if len(ends) != 2:
                    continue
                d1 = ends[0] - here
                d2 = ends[1] - here
                if d1.length <= 1e-9 or d2.length <= 1e-9:
                    return False
                if d1.angle(d2) < straight:
                    return False
        return True

    total = 0
    for _ in range(8):
        stranded = []
        for v in bm.verts:
            es = v.link_edges
            if len(es) != 2:
                continue
            if not (es[0].tag or es[1].tag):
                stranded.append(v)
            elif same_mark(es[0], es[1]) and runs_through(v):
                stranded.append(v)
        if not stranded:
            break
        bmesh.ops.dissolve_verts(bm, verts=stranded)
        total += len(stranded)
    if total:
        bm.normal_update()
    return total


class BudgetThinner:
    """`drop_to_budget` taken one round at a time.

    Blender cannot draw while an operator is inside a loop, so a job that
    runs for ten seconds looks exactly like a hang - no bar, no cursor, no
    way out. Handing the rounds back one at a time lets the operator return
    control between them, which is what makes a progress bar move and Escape
    work.
    """

    def __init__(self, bm, target_faces, keep_marked=True, crease_deg=25.0):
        self.bm = bm
        self.target = target_faces
        self.keep_marked = keep_marked
        self.removed = 0
        self.start_faces = len(bm.faces)
        self.span = max(self.start_faces - target_faces, 1)
        # faces actually freed per face predicted; learned as it goes
        self.ratio = 1.0
        crease = math.radians(crease_deg)
        self.hard = set()
        for e in bm.edges:
            if len(e.link_faces) != 2:
                continue
            a, b = e.link_faces
            if a.normal.angle(b.normal, 0.0) >= crease:
                self.hard.add(e)
                for v in e.verts:
                    self.hard.update(v.link_edges)

    @property
    def fraction(self):
        return min(1.0, (self.start_faces - len(self.bm.faces)) / self.span)

    def round(self):
        """One pass. False when there is nothing left worth doing."""
        bm = self.bm
        if len(bm.faces) <= self.target:
            return False
        bm.edges.ensure_lookup_table()
        pool = [e for e in bm.edges
                if len(e.link_faces) == 2
                and not (self.keep_marked and e.tag)]
        if not pool:
            return False
        # Poles are off again. Letting a loop end on one leaves the
        # pole with two edges, and sweeping those merged whole regions
        # into single faces - the model burst apart. Reaching the
        # target is not worth handing back a wreck.
        whole, _partial = complete_loops(pool)
        if not whole:
            return False
        cost = []
        for lp in whole:
            imp = _loop_impact(set(lp))
            span = 0.0
            for e in lp:
                span += (e.verts[0].co - e.verts[1].co).length
            span /= max(len(lp), 1)
            c = imp / max(span, 1e-12)
            touching = sum(1 for e in lp if e in self.hard)
            if touching:
                c *= 1.0 + 40.0 * (touching / len(lp))
            cost.append(c)
        near = _parallel_adjacent(whole)
        order = sorted(range(len(whole)), key=lambda i: (cost[i], i))
        # Half the loops each round. The survey that finds them is the
        # expensive part - 0.11s of every 0.16s round - so the fewer rounds
        # the better, and non-adjacent loops do not interfere anyway.
        # Two brakes. The budget one is the real limit: dissolving a loop of
        # N edges costs about N faces, and now that the healing pass runs
        # only at the end that estimate holds. Without it, letting loops end
        # on poles took 16255 faces down to 606 against a target of 4000 in
        # two rounds. The count of loops is a second, looser guard so one
        # round cannot swallow the whole survey.
        # How many faces a loop really costs is not its edge count: the
        # dissolve merges the leftover collinear vertices too, and a loop
        # ending on a pole takes a little more again. Rather than guess the
        # ratio, it is measured each round and used for the next - which is
        # what finally landed the count on the target instead of a quarter
        # under it.
        over = max(1, int((len(bm.faces) - self.target) / self.ratio))
        bite = max(1, len(whole) // 2)
        doomed = set()
        taken = set()
        freed = 0
        for i in order:
            if near[i] & taken:
                continue
            if freed and freed + len(whole[i]) > over:
                continue
            taken.add(i)
            doomed.update(whole[i])
            freed += len(whole[i])
            if freed >= over or len(taken) >= bite:
                break
        if not doomed:
            return False
        before = len(bm.faces)
        # Dissolve the edges only. `dissolve_keeping_rims` also sweeps the
        # vertices left with two edges, and on a quad field that sweep runs
        # away: each merge leaves the next vertex two-edged in turn, and
        # whole regions collapsed into single faces - the model burst apart.
        # The leftovers are dealt with one at a time below, where each can
        # be checked.
        bmesh.ops.dissolve_edges(bm, edges=sorted(doomed, key=lambda e: e.index), use_verts=False,
                                 use_face_split=False)
        bm.normal_update()
        bm.verts.ensure_lookup_table()
        # A vertex with two edges is only safe to remove when its two edges
        # run on as one line; otherwise the corner between them is shape and
        # merging the faces either side would flatten it.
        stranded = []
        for v in bm.verts:
            es = v.link_edges
            if len(es) != 2 or es[0].tag or es[1].tag:
                continue
            a = es[0].other_vert(v).co - v.co
            b = es[1].other_vert(v).co - v.co
            if a.length < 1e-12 or b.length < 1e-12:
                continue
            if a.angle(b) >= STRAIGHT:
                stranded.append(v)
        if stranded:
            bmesh.ops.dissolve_verts(bm, verts=stranded)
        bm.faces.ensure_lookup_table()
        if len(bm.faces) >= before:
            return False
        actual = before - len(bm.faces)
        if freed > 0 and actual > 0:
            seen = actual / freed
            self.ratio = self.ratio * 0.4 + seen * 0.6
        self.removed += len(taken)
        # Stop the moment the target is met rather than after one more
        # round: overshooting cannot be undone.
        return len(bm.faces) > self.target

    def finish(self):
        heal_stubs(self.bm)
        polish_verts(self.bm)
        # Ending a loop on a three-way pole leaves a pair of triangles
        # there. Joined back up, the result stays a quad mesh.
        self.bm.faces.ensure_lookup_table()
        tri = [f for f in self.bm.faces if len(f.verts) == 3]
        if tri:
            bmesh.ops.join_triangles(
                self.bm, faces=tri, angle_face_threshold=3.14,
                angle_shape_threshold=3.14, cmp_seam=False, cmp_sharp=False,
                cmp_uvs=False, cmp_vcols=False, cmp_materials=False)
        return self.removed


def drop_to_budget(bm, target_faces, keep_marked=True, rounds=40,
                   crease_deg=25.0, progress=None):
    """Thin a quad mesh down to `target_faces`, least important loop first.

    The flatness test asks "does this loop carry any shape at all", which is
    the right question for a machined part and the wrong one for a body:
    nothing on a character is flat, so it can free almost nothing. Here the
    loops are simply ranked by how far the surface would move without them
    and the cheapest are taken until the budget is met - dense where the
    form turns, sparse where it does not, which is how a modeller would
    spend the same faces.

    Neighbours are never taken together in one round, so the grid thins
    evenly instead of opening a gap.
    """
    # The hard edges are found once. Recomputing them every round meant walking
    # every face pair on a 127000-face mesh forty times over, and the whole
    # thinning took three to four minutes.
    crease = math.radians(crease_deg)
    hard = set()
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        a, b = e.link_faces
        if a.normal.angle(b.normal, 0.0) >= crease:
            hard.add(e)
            for v in e.verts:
                hard.update(v.link_edges)

    # How far along we are, for the bar. The count falls from `start` to
    # `target_faces`, so that span is the whole job.
    start_faces = len(bm.faces)
    span = max(start_faces - target_faces, 1)
    if progress:
        progress(f"spreading {start_faces:,} -> {target_faces:,} faces", 0.0)

    removed = 0
    for _ in range(rounds):
        now = len(bm.faces)
        if progress:
            progress(f"spreading {now:,} -> {target_faces:,} faces",
                     min(1.0, (start_faces - now) / span))
        if now <= target_faces:
            break
        bm.edges.ensure_lookup_table()
        pool = [e for e in bm.edges
                if len(e.link_faces) == 2 and not (keep_marked and e.tag)]
        if not pool:
            break
        whole, _partial = complete_loops(pool)
        if not whole:
            break
        # Impact measured against the loop's own spacing, not in absolute
        # units: a loop on a thigh and one on a finger are different sizes,
        # and judging them on the same scale took every fine loop first.
        # A loop that lies along a hard edge, or the ring supporting one, is
        # what holds the form there - taking it rounds the edge off. Those
        # are priced out of reach rather than forbidden, so they still go if
        # nothing else is left.
        cost = []
        for lp in whole:
            imp = _loop_impact(set(lp))
            span = 0.0
            for e in lp:
                span += (e.verts[0].co - e.verts[1].co).length
            span /= max(len(lp), 1)
            c = imp / max(span, 1e-12)
            touching = sum(1 for e in lp if e in hard)
            if touching:
                c *= 1.0 + 40.0 * (touching / len(lp))
            cost.append(c)
        near = _parallel_adjacent(whole)
        order = sorted(range(len(whole)), key=lambda i: (cost[i], i))
        # A small bite each round, then look again. Estimating how many
        # faces a set of loops will free does not work here: healing and the
        # vertex sweep merge more on their own, so 64 faces went for every
        # loop taken when the loop itself was 15 edges long. Guessing that
        # ratio landed 10000 at 4721; taking a twentieth of the loops and
        # re-measuring cannot run away like that.
        # A third of the loops each round, not a twentieth: the survey above
        # is the expensive part, so few large rounds beat many small ones.
        bite = max(1, len(whole) // 3)
        doomed = set()
        taken = set()
        for i in order:
            if near[i] & taken:
                continue
            taken.add(i)
            doomed.update(whole[i])
            if len(taken) >= bite:
                break
        if not doomed:
            break
        before = len(bm.faces)
        # Conservative on purpose. Sweeping every leftover vertex here
        # cascades: one loop of 15 edges took 3374 faces with it, because
        # each removal leaves neighbours with two edges and those merge in
        # turn. Only the vertices that sit on a straight line go, and the
        # sweep runs once at the end instead.
        dissolve_keeping_rims(bm, doomed)
        bm.faces.ensure_lookup_table()
        if len(bm.faces) >= before:
            break
        removed += len(taken)
        if progress:
            progress(f"spreading {len(bm.faces):,} -> {target_faces:,} faces",
                     min(1.0, (start_faces - len(bm.faces)) / span))
        # Measured: the dissolve itself took the 2 faces its loop was worth,
        # and heal_stubs then took 3281 more - it follows every stub along
        # its own loop, and on a mesh full of singularities that is most of
        # the model. It runs once at the end now, not on every round.
        # A round frees more than the loops it took: healing a stub and
        # sweeping the leftover vertices merge faces of their own. Taking
        # the whole remaining budget in one go therefore sails past it -
        # 10000 came out as 4721 - so each round claims a slice and the
        # count is measured again before the next.
    return removed


def drop_loops(bm, tol_deg=1.0, keep_marked=True, sag_pct=0.0,
               axes=(True, True, True), purity=0.0, rot=None):
    """Run the drop to completion, not just one pass.

    The round test only ever takes alternate loops, so a single pass can at
    most halve the vertical lines - which read on screen as the pass having
    ignored them. Repeating on the real mesh is safe where pre-planning many
    rounds is not: each round re-measures the sag on the geometry as it now
    stands, so the survivors' growing spans are the true spans, and the
    process stops itself the moment every remaining loop matters more than
    the budget.
    """
    limit = sag_limit(bm, sag_pct)
    total = 0
    partial = 0
    for _ in range(24):
        doomed, dropped, part = useless_loops(
            bm, tol_deg=tol_deg, keep_marked=keep_marked, sag_pct=sag_pct,
            axes=axes, purity=purity, rot=rot)
        partial = part
        if not doomed:
            break
        dissolve_keeping_rims(bm, doomed, sag_limit=limit, polish=True)
        heal_stubs(bm)
        total += dropped
        if not dropped:
            break
    polish_verts(bm, uv_layers=list(bm.loops.layers.uv.values()))
    return total, partial


def force_loop(bm, start, factor=0.5):
    """Cut an edge loop that refuses to stop.

    Blender's own loop cut gives up at the first n-gon, and after a drop the
    mesh is nothing but n-gons - which is exactly where Milad needs to put a
    line back. This walks face to face from the selected edge, splits each
    crossed edge at `factor`, and cuts every face on the way. In each face
    the exit is the edge most parallel to the entry that shares no corner
    with it, farthest wins a tie - on the long strips a drop leaves, that is
    the opposite side. Stops only at an open border or when the ring closes.
    """
    import bmesh.utils

    def exit_edge(face, entry):
        ev = set(entry.verts)
        d1 = (entry.verts[1].co - entry.verts[0].co).normalized()
        best = None
        score = -1.0
        for e in face.edges:
            if e is entry:
                continue
            if ev & set(e.verts):
                continue
            v = e.verts[1].co - e.verts[0].co
            if v.length < 1e-12:
                continue
            far = ((e.verts[0].co + e.verts[1].co) / 2 -
                   (entry.verts[0].co + entry.verts[1].co) / 2).length
            sc = abs(d1.dot(v.normalized())) + far * 1e-3
            if sc > score:
                score = sc
                best = e
        if best is None:
            # a triangle or a fan: no edge avoids the entry's corners
            for e in face.edges:
                if e is not entry:
                    return e
        return best

    faces = list(start.link_faces)
    if not faces:
        return 0
    _e, first_vert = bmesh.utils.edge_split(start, start.verts[0], factor)
    cuts = 0
    for direction in faces[:2]:
        face = direction
        entry = start
        entry_vert = first_vert
        visited = set()
        while face is not None and face not in visited:
            visited.add(face)
            out = exit_edge(face, entry)
            if out is None:
                break
            closing = entry_vert is not first_vert and first_vert in out.verts
            if closing:
                out_vert = first_vert
            else:
                _e2, out_vert = bmesh.utils.edge_split(out, out.verts[0],
                                                       factor)
            try:
                res = bmesh.ops.connect_vert_pair(
                    bm, verts=[entry_vert, out_vert])
                if res.get("edges"):
                    cuts += 1
            except Exception:
                break
            if closing:
                face = None
                break
            nxt = [f for f in out_vert.link_edges
                   for ff in f.link_faces] and None
            link = [f for f in out.link_faces if f not in visited]
            # out was split; the continuation face lies across either half
            nxt_face = None
            for e in out_vert.link_edges:
                for f in e.link_faces:
                    if f not in visited and entry_vert not in f.verts:
                        nxt_face = f
                        break
                if nxt_face:
                    break
            entry_vert = out_vert
            entry = out
            face = nxt_face
        if face is None:
            break                    # the ring closed, one pass was enough
    return cuts


def tag_marked(bm, keep_seams=False, uv_layer=None, uv_layers=None,
               use_selection=True):
    """Flag the lines the user is keeping. Returns how many there are.

    Sharp is a deliberate mark, so it always counts. Selection only counts
    when it singles something out. Blender leaves a whole mesh selected as a
    matter of course - after a remesh, after leaving edit mode, after almost
    anything - and reading that as intent made Drop Useless Loops protect all
    83968 edges of Milad's part and report "0 loops dropped" at every setting.
    A selection that covers everything says nothing about what to keep.
    """
    total = len(bm.edges)
    sel = 0
    for e in bm.edges:
        if e.select:
            sel += 1
    # `use_selection` off is for the axis buttons. Select Axis Loops
    # leaves the lines of that axis selected, and reading a selection as
    # a mark then protected the very lines the drop had been aimed at -
    # so it went and took others instead.
    use_sel = use_selection and 0 < sel < total * 0.9

    # A UV seam is where the texture is cut. Dissolving an edge merges the
    # two faces beside it and the merged face can only carry one side's
    # coordinates, so a loop crossing a seam tears the map. Away from a seam
    # the two faces already agree and the merge is exact - which is why
    # protecting the seams is enough to keep the UVs intact rather than
    # having to rebuild them afterwards.
    seam = set()
    if keep_seams:
        for e in bm.edges:
            if e.seam:
                seam.add(e)
                continue
            # Every layer, not just the active one. A model that has been
            # baked carries two - the texture's own map and the bake's - and
            # protecting one while tearing the other is no protection at all:
            # measured on Milad's part, 154 faces stretched across DiffuseUV
            # and 157 across BakeUV, the same damage in both.
            layers = uv_layers
            if layers is None:
                layers = [uv_layer] if uv_layer is not None else []
            if not layers or len(e.link_faces) != 2:
                continue
            found = False
            for lay in layers:
                # a seam without the flag: the two faces disagree on the
                # shared corners, which is what a cut looks like in the data
                pair = []
                for f in e.link_faces:
                    got = {}
                    for lp in f.loops:
                        if lp.vert in e.verts:
                            got[lp.vert] = lp[lay].uv.copy()
                    pair.append(got)
                for v in e.verts:
                    a = pair[0].get(v)
                    b = pair[1].get(v)
                    if a is not None and b is not None and (a - b).length > 1e-5:
                        found = True
                        break
                if found:
                    break
            if found:
                seam.add(e)

    n = 0
    for e in bm.edges:
        e.tag = (not e.smooth) or (use_sel and e.select) or (e in seam)
        if e.tag:
            n += 1
    return n


def sag_limit(bm, pct):
    """Turn a Round Below percentage into a distance in model units."""
    if pct <= 0.0:
        return 0.0
    co = [v.co for v in bm.verts]
    if not co:
        return 0.0
    span = max(max(p[i] for p in co) - min(p[i] for p in co) for i in range(3))
    return span * pct / 100.0


def _clean_pole(edge, v):
    """Is a loop ending at pole `v` a proper end, or a line left hanging?

    Taking the loop costs the pole one edge, and whether that reads as tidy
    depends entirely on what is left behind:

    - A wide fan (5 or more) simply loses a spoke. This is the middle of a
      cylinder cap, and refusing it is what kept 576 of the vertical loops
      round a cylinder permanently un-removable.
    - A three-way where the other two edges run straight through is a T. The
      loop is the stem of that T, so removing it heals the junction rather
      than damaging it - the leftover vertex sits on a straight line and gets
      dissolved away.
    - A three-way that is a real corner is not. Removing the stem strands the
      corner in open surface, and these were the 16 half lines in the
      dissolve.
    """
    es = [e for e in v.link_edges if e is not edge]
    if len(es) >= 4:
        return True
    if len(es) != 2:
        return False
    a = es[0].other_vert(v).co - v.co
    b = es[1].other_vert(v).co - v.co
    if a.length < 1e-12 or b.length < 1e-12:
        return False
    return a.angle(b) >= CONTINUES


def complete_loops(edges, allow_poles=False):
    """Loops that run to a proper end, and the ones that do not.

    A loop taken only part of the way leaves its last edge stopping in open
    surface - the half lines Milad keeps pointing at. A run counts as complete
    when it closes into a ring, or when both ends arrive somewhere the grid
    itself stops: a marked line, or a vertex that is not four-way.
    """
    # Index order, for the same reason as `drop_loops` above: a set of bmesh
    # elements iterates by memory address and made this non-deterministic.
    pool = set(edges)
    order = sorted(edges, key=lambda e: e.index)
    whole, partial = [], []
    for seed in order:
        if seed not in pool:
            continue
        pool.discard(seed)
        loop = [seed]
        clean = True
        closed = False
        for start in (seed.verts[0], seed.verts[1]):
            cur, v = seed, start
            while True:
                nxt = _next_in_loop(cur, v)
                if nxt is seed:
                    closed = True
                    break
                if nxt is None:
                    # The grid stops at a pole. Whether that is a clean end
                    # depends on how wide the pole is, because taking the loop
                    # costs it one edge:
                    #   3 -> 2   a corner left hanging in the surface. These
                    #            were the 16 half lines in the dissolve.
                    #   5+ -> 4  a fan simply gets one spoke narrower, which
                    #            is the join at the middle of a cylinder cap.
                    # Rejecting every pole is what kept 768 of the vertical
                    # loops round a cylinder permanently un-removable.
                    # `allow_poles` is for thinning a dense organic mesh.
                    # There a three-way pole is not a defect but the normal
                    # furniture of a quad field, and refusing to end on one
                    # left 1388 of 1566 loops untouchable - which is why the
                    # face count would not come down. The vertex left behind
                    # turns two quads into triangles; they are paired up
                    # again afterwards.
                    if not (allow_poles or _clean_pole(cur, v)):
                        clean = False
                    break
                if nxt.tag:
                    break               # ran into a line the user is keeping
                if nxt not in pool:
                    clean = False
                    break
                pool.discard(nxt)
                loop.append(nxt)
                v = nxt.other_vert(v)
                cur = nxt
            if closed:
                break
        (whole if (clean or closed) else partial).append(loop)
    return whole, partial


def surface_drift(bm, ref):
    """Worst distance from a face's middle to the surface as it was.

    Vertices never move when an edge is dissolved, so measuring them says
    nothing - it reads zero however much shape has been lost. What changes is
    the face spanning between them, so the face centres are what to ask.
    """
    worst = 0.0
    for f in bm.faces:
        hit = ref.find_nearest(f.calc_center_median())
        if hit and hit[0] is not None:
            d = (f.calc_center_median() - hit[0]).length
            if d > worst:
                worst = d
    return worst


def useless_loops(bm, tol_deg=1.0, keep_marked=True, sag_pct=0.0, size=None,
                  axes=(True, True, True), purity=0.0, rot=None):
    """Whole loops the model can lose, by two separate tests.

    **Flat** - the surface barely turns across the loop, so it is carrying no
    shape at all. Scale free, and safe at any setting.

    **Round** - the surface does turn across it, but taking the loop would
    move the surface less than `sag_pct` of the model's size. This is what
    thins the vertical lines round a cylinder, which the flat test protects on
    principle however many of them there are.

    The round test only ever takes alternate loops. Removing neighbours
    together compounds their sag - each is inside the tolerance and the pair
    is not - which is what made an earlier attempt collapse a part from 17848
    faces to 2079.

    A loop always goes whole or not at all, and a run ending at a pole does
    not count as whole: taking it leaves the pole an edge short.

    `axes` confines the drop to loops running along the ticked world axes -
    the dominant component of the loop's own edges, so on a cylinder standing
    on Z the vertical lines are the Z loops and the rings around it are X/Y.
    """
    limit = math.radians(tol_deg)
    pool = []
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        # `tag`, not a fresh look at sharp and selection: tag_marked has
        # already decided what counts, and it is the only place that knows a
        # whole-mesh selection is not a mark. Reading e.select here again is
        # what kept this returning "0 loops dropped" after that was fixed.
        if keep_marked and e.tag:
            continue
        pool.append(e)
    if not pool:
        return set(), 0, 0

    whole, partial = complete_loops(pool)

    if not all(axes):
        whole = [lp for lp in whole
                 if _axis_match(lp, axes, purity, rot)]

    doomed = set()
    dropped = 0
    left = []
    for loop in whole:
        if _loop_error(set(loop)) <= limit:
            doomed.update(loop)
            dropped += 1
        else:
            left.append(loop)

    if sag_pct > 0.0 and left:
        if size is None:
            xs = [v.co for v in bm.verts]
            size = max(max(p[i] for p in xs) - min(p[i] for p in xs)
                       for i in range(3)) if xs else 1.0
        sag_limit = size * sag_pct / 100.0
        near = _parallel_adjacent(left)
        order = sorted(range(len(left)),
                       key=lambda i: (_loop_impact(set(left[i])),
                                      min(e.index for e in left[i])))
        taken = set()
        for i in order:
            if near[i] & taken:
                continue                    # never two neighbours
            if _loop_impact(set(left[i])) > sag_limit:
                continue
            taken.add(i)
            doomed.update(left[i])
            dropped += 1

    return doomed, dropped, len(partial)


def _key(e):
    a, b = e.verts[0].index, e.verts[1].index
    return (a, b) if a < b else (b, a)
