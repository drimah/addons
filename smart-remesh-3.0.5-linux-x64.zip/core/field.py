"""Orientation and position fields - the two halves of field-guided remeshing.

The orientation field decides which way the quads run; the position field
decides where their corners land. Both are solved by Jacobi iteration over the
edge list, which vectorises cleanly and needs no linear solver.

Neither uses any Blender operator. The only external dependency is numpy.
"""

from __future__ import annotations

import numpy as np

from . import hierarchy as HR


def _accumulate(nv: int, idx: np.ndarray, vals: np.ndarray) -> np.ndarray:
    """Scatter-add of (n,3) vectors. bincount beats np.add.at by a wide margin."""
    out = np.empty((nv, 3))
    for k in range(3):
        out[:, k] = np.bincount(idx, weights=vals[:, k], minlength=nv)
    return out


def _normalize(x: np.ndarray, eps: float = 1e-20) -> np.ndarray:
    return x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), eps)


def _project(x: np.ndarray, n: np.ndarray) -> np.ndarray:
    return x - np.sum(x * n, axis=1, keepdims=True) * n


def _best_rosy(target: np.ndarray, other: np.ndarray, n: np.ndarray) -> np.ndarray:
    """Rotate `other` about `n` by whichever multiple of 90 deg matches `target`.

    A quad is unchanged by a 90 degree turn, so a cross field only defines a
    direction up to that symmetry. Comparing raw vectors instead of doing this
    is the single most common way to get a field solver subtly wrong.
    """
    a = _normalize(_project(other, n))
    b = np.cross(n, a)
    da = np.sum(target * a, axis=1)
    db = np.sum(target * b, axis=1)
    # The best of {a, b, -a, -b} is a if |da|>|db|, else b, signed by the dot.
    use_a = np.abs(da) >= np.abs(db)
    chosen = np.where(use_a[:, None], a, b)
    sign = np.where(use_a, np.sign(da), np.sign(db))
    sign = np.where(sign == 0, 1.0, sign)
    return chosen * sign[:, None]


# ----------------------------------------------------------------------
# feature constraints
# ----------------------------------------------------------------------
def feature_constraints(mesh, feature_mask: np.ndarray):
    """Per-vertex locked direction along creases, and a mask of corners.

    Feature directions are averaged in the exp(4i.theta) representation so two
    creases meeting at 90 degrees reinforce rather than cancel.
    """
    e = mesh.edges[feature_mask]
    n = mesh.normal
    u, v = mesh.frames
    nv = mesh.nv

    locked = np.zeros(nv, dtype=bool)
    if not len(e):
        return locked, np.zeros((nv, 3)), np.zeros(nv, dtype=bool), \
            np.zeros((nv, 3))

    d = mesh.V[e[:, 1]] - mesh.V[e[:, 0]]
    d = _normalize(d)

    zr = np.zeros(nv)
    zi = np.zeros(nv)
    tang = np.zeros((nv, 3))
    count = np.zeros(nv)

    for side, sign in ((e[:, 0], 1.0), (e[:, 1], -1.0)):
        dp = _normalize(_project(d * sign, n[side]))
        th = np.arctan2(np.sum(dp * v[side], axis=1),
                        np.sum(dp * u[side], axis=1))
        zr += np.bincount(side, weights=np.cos(4 * th), minlength=nv)
        zi += np.bincount(side, weights=np.sin(4 * th), minlength=nv)
        count += np.bincount(side, minlength=nv)
        tang += _accumulate(nv, side, dp)

    locked = count > 0
    theta = np.arctan2(zi, zr) / 4.0
    direction = np.cos(theta)[:, None] * u + np.sin(theta)[:, None] * v
    direction = _normalize(_project(direction, n))

    # A vertex where the crease changes direction is a corner: it must not
    # slide along anything, so it gets pinned in the position field.
    coherence = np.hypot(zr, zi) / np.maximum(count, 1)
    tang = _normalize(tang)
    corner = locked & (coherence < 0.5)
    # 3+ creases meeting is also a corner regardless of coherence.
    corner |= count >= 3
    return locked, direction, corner, tang


# ----------------------------------------------------------------------
# orientation field
# ----------------------------------------------------------------------
def orientation_field(mesh, iterations: int = 40, feature_angle: float = 30.0,
                      use_curvature: bool = True, progress=None):
    """Smooth 4-RoSy field over the surface, locked to creases."""
    n = mesh.normal
    e = mesh.edges
    i, j = e[:, 0], e[:, 1]
    nv = mesh.nv

    feat = mesh.feature_edges(feature_angle)
    locked, locked_dir, corner, feat_tangent = feature_constraints(mesh, feat)

    if use_curvature:
        _, _, dir1, aniso = mesh.curvature()
        o = _normalize(_project(dir1, n))
        bad = ~np.isfinite(o).all(axis=1) | (np.linalg.norm(o, axis=1) < 0.5)
        if bad.any():
            u, _ = mesh.frames
            o[bad] = u[bad]
    else:
        u, _ = mesh.frames
        o = u.copy()

    o[locked] = locked_dir[locked]

    # Edge weights: creases must dominate, or a strong smooth field will drag
    # the flow off the crease it is supposed to be running along.
    w = np.ones(len(e))
    w[feat] = 8.0

    def sweep(o_, n_, e_, w_, its, lock=None, lock_dir=None, cb=None):
        """The Jacobi solve. Identical at every level of the hierarchy."""
        ii, jj = e_[:, 0], e_[:, 1]
        m = len(n_)
        for k in range(its):
            acc = np.zeros((m, 3))
            acc += _accumulate(m, ii, _best_rosy(o_[ii], o_[jj], n_[ii]) * w_[:, None])
            acc += _accumulate(m, jj, _best_rosy(o_[jj], o_[ii], n_[jj]) * w_[:, None])
            acc += o_                               # keep some of the old value
            nxt = _normalize(_project(acc, n_))
            degenerate = np.linalg.norm(nxt, axis=1) < 0.5
            nxt[degenerate] = o_[degenerate]
            o_ = nxt
            if lock is not None:
                o_[lock] = lock_dir[lock]
            if cb is not None and k % 5 == 0:
                cb(k / max(its, 1))
        return o_

    # Coarse to fine. A sweep only moves information one edge, so on a fine
    # mesh the field settles into whatever it agreed on locally before the two
    # ends of the model ever hear from each other. Measured on a 33k-vertex
    # statue that is not a matter of too few sweeps - at 400 the field has
    # stopped changing and the result is worse than at 40. Starting from an
    # answer already agreed on a few hundred vertices is what changes which
    # minimum it lands in. Same solver, different starting point.
    levels = HR.build(mesh.V, n, e)
    if len(levels) > 1:
        coarse = o
        for lv in range(len(levels) - 1):
            coarse = HR.restrict(levels[lv]["parent"], levels[lv + 1]["nv"],
                                 coarse)
        for lv in range(len(levels) - 1, 0, -1):
            L = levels[lv]
            if len(L["edges"]):
                coarse = _normalize(_project(coarse, L["normal"]))
                bad = np.linalg.norm(coarse, axis=1) < 0.5
                if bad.any():
                    coarse[bad] = _normalize(_project(
                        np.roll(L["normal"][bad], 1, axis=1), L["normal"][bad]))
                coarse = sweep(coarse, L["normal"], L["edges"],
                               np.ones(len(L["edges"])), iterations)
            coarse = HR.prolong(levels[lv - 1]["parent"], coarse)
        seeded = _normalize(_project(coarse, n))
        ok = np.linalg.norm(seeded, axis=1) >= 0.5
        o[ok] = seeded[ok]
        o[locked] = locked_dir[locked]

    o = sweep(o, n, e, w, iterations, locked, locked_dir, progress)
    return o, locked, corner, feat_tangent


# ----------------------------------------------------------------------
# position field
# ----------------------------------------------------------------------
def comb_field(mesh, o: np.ndarray) -> np.ndarray:
    """Resolve the 90-degree ambiguity into one consistent representative.

    A 4-RoSy field only defines a direction up to a quarter turn, so before the
    field can be integrated its representative has to be *combed*: each vertex
    picks the rotation of its direction that agrees with its neighbour. Seams
    where this cannot be satisfied are exactly the field singularities, and
    they are what becomes a pole in the output.
    """
    start, nbr = mesh.adjacency
    n = mesh.normal

    # Plain Python floats in the traversal, not numpy scalars: this walk visits
    # every vertex once and a numpy call per step costs more than the whole
    # rest of the solver on a million-face mesh.
    ox, oy, oz = (o[:, 0].tolist(), o[:, 1].tolist(), o[:, 2].tolist())
    nx, ny, nz = (n[:, 0].tolist(), n[:, 1].tolist(), n[:, 2].tolist())
    nbr_l = nbr.tolist()
    start_l = start.tolist()
    visited = bytearray(mesh.nv)

    for seed in range(mesh.nv):
        if visited[seed]:
            continue
        visited[seed] = 1
        stack = [seed]
        while stack:
            a = stack.pop()
            ax, ay, az = ox[a], oy[a], oz[a]
            for k in range(start_l[a], start_l[a + 1]):
                b = nbr_l[k]
                if visited[b]:
                    continue
                visited[b] = 1
                bx, by, bz = ox[b], oy[b], oz[b]
                mx, my, mz = nx[b], ny[b], nz[b]
                # cross(n_b, o_b) is the 90-degree rotation of o_b in b's plane
                cx = my * bz - mz * by
                cy = mz * bx - mx * bz
                cz = mx * by - my * bx
                da = ax * bx + ay * by + az * bz
                db = ax * cx + ay * cy + az * cz
                if da * da >= db * db:
                    if da < 0.0:
                        bx, by, bz = -bx, -by, -bz
                else:
                    bx, by, bz = (cx, cy, cz) if db >= 0.0 else (-cx, -cy, -cz)
                ox[b], oy[b], oz[b] = bx, by, bz
                stack.append(b)

    return np.stack([np.asarray(ox), np.asarray(oy), np.asarray(oz)], axis=1)


def position_field(mesh, o: np.ndarray, scale, iterations: int = 40,
                   locked: np.ndarray | None = None,
                   corner: np.ndarray | None = None,
                   feat_tangent: np.ndarray | None = None,
                   progress=None) -> np.ndarray:
    """Per-vertex lattice position, kept local on purpose.

    A global 2D parameterisation would be the tidier formulation, but one does
    not exist: any closed surface that is not a torus forces the cross field to
    have singularities, and around those no consistent global chart can be
    integrated. So this stays local - each vertex carries a point on its own
    grid, neighbours agree up to a whole number of cells, and the places where
    they cannot agree are the singularities, which is where the output gets its
    poles.

    The hard clamp to half a cell around the vertex is what stops the smoothing
    term from dragging the entire field into one point.
    """
    n = mesh.normal
    e = mesh.edges
    i, j = e[:, 0], e[:, 1]
    nv = mesh.nv
    V = mesh.V

    t = np.cross(n, o)
    p = V.copy()
    anchor = 1.0

    # `scale` may be one number or one per vertex (adaptive sizing). An edge
    # uses the mean of its endpoints so the step is symmetric in i and j.
    sv = np.full(nv, float(scale)) if np.isscalar(scale) else np.asarray(scale,
                                                                        float)
    se = 0.5 * (sv[i] + sv[j])

    # Coarse-to-fine was tried here twice and neither version is kept. Both
    # are worth knowing about before anyone tries a third time.
    #
    # Handing a coarse position straight down does not work, and the reason is
    # not a bug: each vertex carries a point on *its own* lattice and
    # neighbours only agree up to a whole number of cells, so an inherited
    # point lands at an arbitrary fraction of the child's cell.
    #
    # Reducing it into the child's cell first - subtracting whole lattice steps
    # until it lies within half a cell, the same rounding the solver does on
    # every edge - is the correct fix and it does what it should: on the
    # statue it took quads 56.3% -> 68.4% and non-manifold edges 684 -> 577,
    # the best either figure has been.
    #
    # It is still not kept, because closure went the other way: boundary edges
    # 1628 -> 2237. Counting both kinds of defect per face, the flat solve is
    # 0.225, orientation-only 0.208, and this 0.385. A hole is fatal where a
    # stray triangle is cosmetic, so the configuration with the fewest holes
    # wins until something closes them.
    #
    # What is left to try: the extraction claims faces from a graph built by
    # collapsing the position field onto lattice sites, and with a sharper
    # field that clustering leaves 362 unclaimable rings, the largest 58-sided.
    # The next thing to look at is that collapse, not the fields.

    for it in range(iterations):
        acc = np.zeros((nv, 3))
        cnt = np.zeros(nv)
        for a, b in ((i, j), (j, i)):
            delta = p[b] - p[a]
            ka = np.round(np.sum(delta * o[a], axis=1) / se)
            kb = np.round(np.sum(delta * t[a], axis=1) / se)
            q = p[b] - se[:, None] * (ka[:, None] * o[a] + kb[:, None] * t[a])
            acc += _accumulate(nv, a, q)
            cnt += np.bincount(a, minlength=nv)

        acc += anchor * V
        cnt += anchor
        p = acc / cnt[:, None]

        # Only the tangential part of the drift is real surface movement.
        p = V + _project(p - V, n)

        # Hard leash: a lattice point that belongs to this vertex cannot be
        # further than half a cell away, by definition.
        d = p - V
        L = np.linalg.norm(d, axis=1)
        leash = 0.5 * sv
        far = L > leash
        if far.any():
            p[far] = V[far] + d[far] * (leash[far] / L[far])[:, None]

        if locked is not None and feat_tangent is not None:
            m = locked & ~(corner if corner is not None
                           else np.zeros(nv, dtype=bool))
            if m.any():
                dd = p[m] - V[m]
                tg = feat_tangent[m]
                p[m] = V[m] + np.sum(dd * tg, axis=1)[:, None] * tg
            if corner is not None and corner.any():
                p[corner] = V[corner]

        if progress is not None and it % 5 == 0:
            progress(it / iterations)

    return p
