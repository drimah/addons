"""Per-vertex target edge length - the adaptive sizing field.

Instant Meshes has no equivalent: its batch mode only takes one global `-s`.
This is therefore something our solver can do that the reference cannot, rather
than another thing it does better.

Two things drive density: proximity to a crease, and curvature. Both produce a
raw request for "smaller quads here", and both are useless on their own - the
field also has to be *gradient limited*, or the mesh is asked to jump from
large to small quads in one step and simply cannot.
"""

from __future__ import annotations

import numpy as np

RELAX_MAX = 128


def _relax_min(edges: np.ndarray, length: np.ndarray, value: np.ndarray,
               slope: float, nv: int, max_iter: int = RELAX_MAX) -> np.ndarray:
    """Enforce value_i <= value_j + slope * |ij| over the whole mesh.

    Used twice: as a distance transform (slope 1, seeds at 0) and as the
    Lipschitz limiter on the sizing field (slope = allowed growth rate).
    Bellman-Ford style relaxation - each pass is one vectorised sweep.
    """
    i, j = edges[:, 0], edges[:, 1]
    v = value.copy()
    step = slope * length
    for _ in range(max_iter):
        cand_i = np.full(nv, np.inf)
        cand_j = np.full(nv, np.inf)
        np.minimum.at(cand_i, i, v[j] + step)
        np.minimum.at(cand_j, j, v[i] + step)
        new = np.minimum(v, np.minimum(cand_i, cand_j))
        if np.allclose(new, v, rtol=0, atol=1e-12):
            return new
        v = new
    return v


def local_thickness(mesh):
    """How thick the solid is under each vertex, or None if it cannot tell.

    Shot along the inward normal from just under the surface: the first hit
    is the far wall. Vertices that hit nothing - an open sheet, the outside
    of a closed shape seen from within - are left as infinity so they place
    no demand on the field.
    """
    try:
        from mathutils import Vector
        from mathutils.bvhtree import BVHTree
    except ImportError:
        return None
    V = np.asarray(mesh.V, dtype=float)
    F = np.asarray(mesh.F, dtype=int)
    if not len(F):
        return None
    N = getattr(mesh, "VN", None)
    if N is None:
        N = np.zeros_like(V)
        tri = V[F]
        fn = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        for k in range(3):
            np.add.at(N, F[:, k], fn)
        ln = np.linalg.norm(N, axis=1, keepdims=True)
        N = N / np.maximum(ln, 1e-20)
    tree = BVHTree.FromPolygons([tuple(v) for v in V],
                                [tuple(f) for f in F])
    span = float(np.ptp(V, axis=0).max()) or 1.0
    eps = span * 1e-5
    out = np.full(len(V), np.inf)
    for i in range(len(V)):
        n = Vector(N[i])
        o = Vector(V[i]) - n * eps
        hit = tree.ray_cast(o, -n, span)
        if hit and hit[0] is not None and hit[3] > eps:
            out[i] = hit[3]
    return out


def sizing_field(mesh, base: float, feature_angle: float = 30.0,
                 feature_strength: float = 1.0,
                 curvature_strength: float = 1.0,
                 inner_density: float = 0.0,
                 outer_density: float = 0.0,
                 thin_strength: float = 1.0,
                 min_ratio: float = 0.3,
                 band: float = 2.5,
                 gradient_limit: float = 0.4) -> np.ndarray:
    """Per-vertex target edge length, clamped to [base*min_ratio, base].

    Args:
        base: the uniform size the mesh would have used.
        feature_strength: 0 disables crease refinement, 1 pulls crease
            neighbourhoods all the way down to the minimum.
        curvature_strength: same, for curvature.
        min_ratio: smallest allowed size as a fraction of `base`. Below about
            0.2 the input usually is not dense enough to resolve it anyway.
        band: how far crease refinement reaches, in units of `base`.
        gradient_limit: maximum growth of the size field per unit distance.
            0.4 means the quads may grow 40% of the distance travelled - low
            values give smooth transitions and more faces.
    """
    nv = mesh.nv
    edges = mesh.edges
    elen = np.linalg.norm(mesh.V[edges[:, 0]] - mesh.V[edges[:, 1]], axis=1)
    floor = base * float(min_ratio)

    request = np.full(nv, base)

    # --- creases -------------------------------------------------------
    if feature_strength > 0.0:
        feat = mesh.feature_edges(feature_angle)
        if feat.any():
            seed = np.zeros(nv, dtype=bool)
            seed[edges[feat].ravel()] = True
            dist = np.where(seed, 0.0, np.inf)
            dist = _relax_min(edges, elen, dist, 1.0, nv)
            # Linear ramp from the minimum at the crease to `base` at the edge
            # of the band.
            reach = max(band * base, 1e-20)
            t = np.clip(dist / reach, 0.0, 1.0)
            near = floor + (base - floor) * t
            request = np.minimum(request,
                                 base + (near - base) * float(feature_strength))

    # --- curvature -----------------------------------------------------
    if curvature_strength > 0.0:
        k1, k2, _, _ = mesh.curvature()
        kmag = np.maximum(np.abs(k1), np.abs(k2))
        kmag = np.nan_to_num(kmag, nan=0.0, posinf=0.0, neginf=0.0)
        # Normalise against a high percentile so one bad vertex cannot set the
        # scale for the whole model.
        ref = np.percentile(kmag, 95) if nv else 0.0
        if ref > 1e-12:
            t = np.clip(kmag / ref, 0.0, 1.0)
            curv = base + (floor - base) * t
            request = np.minimum(request,
                                 base + (curv - base) * float(curvature_strength))

    # --- inner vs outer edges -----------------------------------------
    # Concave and convex edges are separated by the cavity signal, so they can
    # be weighted independently: inner corners usually need the refinement more
    # than outer ones, because that is where deformation and shading artefacts
    # concentrate.
    if inner_density > 0.0 or outer_density > 0.0:
        from .detect import edge_field
        ef = edge_field(mesh, feature_angle,
                        inner_weight=float(inner_density),
                        outer_weight=float(outer_density))
        imp = np.clip(np.maximum(ef["inner"], ef["outer"]), 0.0, 1.0)
        request = np.minimum(request, base + (floor - base) * imp)

    # --- thin sheets ---------------------------------------------------
    # Curvature says nothing about a flat sheet of cloth, and a crease says
    # nothing about its middle - yet a quad wider than the cloth is thick
    # spans both of its sides at once and welds them together. That is the
    # hem of Milad's shirt tearing into itself at low face counts. Where the
    # model is thin, ask for quads smaller than that thickness.
    if thin_strength > 0.0:
        thin = local_thickness(mesh)
        if thin is not None:
            want = thin * 0.7
            want = np.where(np.isfinite(want) & (want > 0.0), want, base)
            request = np.minimum(
                request, base + (np.minimum(want, base) - base)
                * float(thin_strength))

    request = np.clip(request, floor, base)

    # --- gradient limit ------------------------------------------------
    # Without this the field can demand a jump straight from `base` to `floor`
    # between adjacent vertices. No quad layout can satisfy that, and the
    # extractor pays for it in stretched and non-manifold elements.
    return _relax_min(edges, elen, request, float(gradient_limit), nv)


def density_field(mesh, base: float, strength: float = 1.0,
                  min_ratio: float = 0.15, max_ratio: float = 5.0,
                  gradient_limit: float = 0.1) -> np.ndarray:
    """Per-vertex target size that follows the input mesh's own density.

    Curvature and creases say where a shape *bends*; this says nothing about
    bending and everything about how finely the reference was already built.
    Where the input has small triangles - a decorated panel, a detailed face -
    the reference author put detail there on purpose, and the remesh should
    keep quads small there too; where the input is coarse, the quads may be
    large. Milad's ask: read the reference's density and reproduce it.

    The local size at a vertex is the mean length of the edges meeting it.
    Scaled so the field averages to `base`, it is a straight map of the
    input's density onto the output. `strength` blends between that and a flat
    `base`: 1 follows the reference exactly, 0 ignores it. Unlike the crease
    and curvature field, this is allowed *above* base as well as below, so a
    coarse region really does come out coarse.
    """
    nv = mesh.nv
    edges = mesh.edges
    if not len(edges):
        return np.full(nv, base)
    elen = np.linalg.norm(mesh.V[edges[:, 0]] - mesh.V[edges[:, 1]], axis=1)
    acc = np.zeros(nv)
    cnt = np.zeros(nv)
    np.add.at(acc, edges[:, 0], elen)
    np.add.at(acc, edges[:, 1], elen)
    np.add.at(cnt, edges[:, 0], 1.0)
    np.add.at(cnt, edges[:, 1], 1.0)
    local = np.where(cnt > 0, acc / np.maximum(cnt, 1.0), base)
    mean = float(np.mean(local[cnt > 0])) if np.any(cnt > 0) else base
    if mean <= 1e-20:
        return np.full(nv, base)
    local = local * (base / mean)               # field averages to base
    req = base * (1.0 - strength) + local * strength
    req = np.clip(req, base * min_ratio, base * max_ratio)
    # Smooth only the downhill side, the same limiter the crease field uses,
    # so a dense island does not demand a step change its neighbours cannot
    # follow. The uphill (coarser) side needs no limit - fit_to_target scales
    # the whole field to the requested count afterwards.
    return _relax_min(edges, elen, req, float(gradient_limit), nv)


def estimate_faces(mesh, sizing: np.ndarray) -> float:
    """Roughly how many quads a given sizing field implies.

    Each triangle contributes its area divided by the square of the local
    target size. Used to rescale the field so that "target face count" still
    means something once density stops being uniform.
    """
    tri = mesh.F
    s = sizing[tri].mean(axis=1)
    return float(np.sum(mesh.face_area / np.maximum(s * s, 1e-20)))


def fit_to_target(mesh, sizing: np.ndarray, target_faces: int,
                  iterations: int = 12) -> np.ndarray:
    """Uniformly scale the sizing field until it implies `target_faces`.

    Adaptive refinement always adds faces, so a field built around a base size
    would overshoot the requested count. Solving for the multiplier keeps the
    two controls independent: adaptivity changes *where* the faces go, the
    target still decides how many.
    """
    if not target_faces:
        return sizing
    # The multiplier has to be free to grow. It was capped at 8, and a field
    # that refines every thin sheet of a clothed character asks for far more
    # than eight times the uniform size - so the search hit the ceiling and
    # the count came out four times the target however low it was set.
    lo, hi = 0.05, 1.0
    for _ in range(60):
        if estimate_faces(mesh, sizing * hi) <= target_faces:
            break
        lo = hi
        hi *= 2.0
    for _ in range(max(iterations, 40)):
        mid = 0.5 * (lo + hi)
        if estimate_faces(mesh, sizing * mid) > target_faces:
            lo = mid
        else:
            hi = mid
    return sizing * (0.5 * (lo + hi))
