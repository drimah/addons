"""Repairing the faces a UV transfer leaves reaching across the map.

Every rebuilt face has to take its corners from the original's UV, and a face
that lands on a seam takes some from one island and some from the next. Those
two islands are nowhere near each other on the map, so the face is drawn as a
line right across it. On Milad's `part_07` - 4206 faces - 154 faces did that
in `DiffuseUV` and 157 in `BakeUV`, and the UV editor was a cross-hatch of
diagonals.

Three stages, in this order, because each only has to clean up after the one
before it:

1. The island vote. A torn face's corners are clustered, the biggest cluster
   wins, and the strays are given the UV a neighbouring corner already uses
   over there - a real coordinate the model carries, not an invented one.
2. Laying the face out fresh. A handful of faces have corners on three
   islands and no cluster is a majority, and a few come out of stage 1 with
   no UV area at all. Those are flattened into their own plane, scaled by the
   mesh's own UV-to-3D ratio and dropped beside a healthy neighbour.
3. Un-smearing. A face can be whole and still render as a streak, because one
   of its directions is squashed and the other is not - the vertical smears
   down the side of Milad's plank. Those take their mapping from a flat
   neighbour across the shared edge, which leaves the shared corners exactly
   where they were. 339 faces of 4206 in `DiffuseUV` and 101 in `BakeUV`
   were past four to one; afterwards, one in each.

The test is a ratio, not a fixed distance. An absolute threshold catches the
big tears and walks past the mild ones: 0.35 of the map left 131 torn faces
on that part, where "UV perimeter more than three times what this face's 3D
size calls for" left 9, and the second stage took those to 0.
"""

import numpy as np
from mathutils import Vector

# How far past the mesh's own scale a face has to be before it is suspect.
# 3.0 for the first stage; the second sweeps at 1.35, but only acts on faces
# whose corners genuinely fall into separate clusters, so a face that is
# merely stretched by an honest unwrap is left alone.
TORN = 3.0
SUSPECT = 1.35
# Below this the face has been squashed onto a point, which is the same
# defect facing the other way. Kept well under half so that faces which are
# simply small in a dense part of the unwrap are not rebuilt.
COLLAPSED = 0.25
# A face can be whole - every corner on one island, sensible area - and still
# render as a smear, because one of its directions is squashed and the other
# is not. The measure is per edge: the longest edge's UV-to-3D ratio over the
# shortest's. On Milad's plank 339 faces of 4206 were past 4, and that is
# what drew the vertical streaks down the side of it.
SMEAR = 4.0


def _scales(bm, lay):
    """Per face: UV perimeter over 3D perimeter, UV area, and the median."""
    ratio = []
    area = []
    for f in bm.faces:
        lp = list(f.loops)
        p3 = p2 = 0.0
        cross = 0.0
        for i in range(len(lp)):
            p3 += (lp[i].vert.co - lp[i - 1].vert.co).length
            u, v = lp[i - 1][lay].uv, lp[i][lay].uv
            p2 += (v - u).length
            cross += u.x * v.y - v.x * u.y
        ratio.append((p2 / p3) if p3 > 1e-12 else 0.0)
        area.append(abs(cross) * 0.5)
    r = np.array(ratio)
    good = r[r > 0]
    return r, np.array(area), (float(np.median(good)) if len(good) else 0.0)


def _clusters(uvs, gap):
    """Group the corners that sit close enough to be on the same island."""
    groups = []
    for i, u in enumerate(uvs):
        hit = None
        for g in groups:
            if any((u - uvs[j]).length <= gap for j in g):
                hit = g
                break
        if hit is None:
            groups.append([i])
        else:
            hit.append(i)
    # a third corner can bridge two groups that were not near each other
    merged = True
    while merged:
        merged = False
        for x in range(len(groups)):
            for y in range(x + 1, len(groups)):
                if any((uvs[i] - uvs[j]).length <= gap
                       for i in groups[x] for j in groups[y]):
                    groups[x] += groups.pop(y)
                    merged = True
                    break
            if merged:
                break
    return groups


def _gap(f, med):
    """How far apart two corners of this face must be to be on two islands.

    Derived from what the face should measure in UV - its 3D perimeter times
    the mesh's own scale - so it holds on a face of any size.
    """
    lp = list(f.loops)
    p3 = sum((lp[i].vert.co - lp[i - 1].vert.co).length for i in range(len(lp)))
    return max(med * p3 * 0.6, 1e-5)


def _vote(bm, lay, by_vert):
    """Stage one: pull the stray corners back onto the winning island."""
    ratio, _area, med = _scales(bm, lay)
    if med <= 0:
        return 0
    moved = 0
    for i, f in enumerate(bm.faces):
        if ratio[i] <= med * TORN:
            continue
        lp = list(f.loops)
        uvs = [l[lay].uv.copy() for l in lp]
        gap = _gap(f, med)
        groups = _clusters(uvs, gap)
        if len(groups) < 2:
            continue
        win = max(groups, key=len)
        centre = Vector((0.0, 0.0))
        for j in win:
            centre += uvs[j]
        centre /= len(win)
        for g in groups:
            if g is win:
                continue
            for j in g:
                loop = lp[j]
                best, dist = None, 1e9
                for other in by_vert.get(loop.vert.index, ()):
                    if other is loop:
                        continue
                    d = (other[lay].uv - centre).length
                    if d < dist:
                        dist, best = d, other[lay].uv.copy()
                # Falling back to the centre leaves the face with no UV area,
                # which reads as one flat colour - stage two picks those up.
                loop[lay].uv = best if (best is not None
                                        and dist <= gap * 2) else centre
                moved += 1
    return moved


def _relay(bm, lay):
    """Stage two: rebuild the faces the vote could not settle."""
    ratio, area, med = _scales(bm, lay)
    if med <= 0:
        return 0
    doomed = []
    for i, f in enumerate(bm.faces):
        if ratio[i] > med * SUSPECT:
            uvs = [l[lay].uv.copy() for l in f.loops]
            if len(_clusters(uvs, _gap(f, med))) > 1:
                doomed.append(i)
        elif area[i] <= 1e-9 or (0.0 < ratio[i] < med * COLLAPSED):
            doomed.append(i)
    if not doomed:
        return 0
    sick = set(doomed)
    done = 0
    for i in doomed:
        f = bm.faces[i]
        anchor = None
        for e in f.edges:
            for nb in e.link_faces:
                if nb is not f and nb.index not in sick:
                    c = Vector((0.0, 0.0))
                    for l in nb.loops:
                        c += l[lay].uv
                    anchor = c / len(nb.loops)
                    break
            if anchor is not None:
                break
        if anchor is None:
            continue        # every neighbour is sick too; leave it be
        # A neighbour's own map first: that keeps the shared corners where
        # they are, so the face rejoins its island. Dropping it beside the
        # neighbour instead - which is what this used to do - left it cut
        # off on all four sides, and Protect UV then shielded it from every
        # cleanup there is. 45 of Milad's 444 faces ended up that way.
        got = _neighbour_map(f, lay, sick)
        if got is not None:
            ctr, t, b, M = got
            for l in f.loops:
                q = l.vert.co - ctr
                uv = np.array((q.dot(t), q.dot(b), 1.0)) @ M
                l[lay].uv = Vector((float(uv[0]), float(uv[1])))
            done += 1
            continue
        n = f.normal.normalized()
        t = Vector((1.0, 0.0, 0.0)) if abs(n.x) < 0.9 else Vector((0.0, 1.0, 0.0))
        t = (t - n * t.dot(n)).normalized()
        b = n.cross(t)
        ctr = f.calc_center_median()
        for l in f.loops:
            d = l.vert.co - ctr
            l[lay].uv = anchor + Vector((d.dot(t), d.dot(b))) * med
        done += 1
    return done


def _edge_ratios(f, lay):
    """Each edge of the face: how much UV it spans per unit of 3D length."""
    lp = list(f.loops)
    out = []
    for i in range(len(lp)):
        d3 = (lp[i].vert.co - lp[i - 1].vert.co).length
        if d3 > 1e-9:
            out.append((lp[i][lay].uv - lp[i - 1][lay].uv).length / d3)
    return out


def _is_smeared(f, lay):
    r = _edge_ratios(f, lay)
    if len(r) < 2:
        return False
    lo, hi = min(r), max(r)
    return lo <= 1e-12 or hi / lo > SMEAR


def _unsmear(bm, lay, dot_min):
    """Stage three: take the squashed faces off a healthy neighbour's mapping.

    A neighbour that is flat and unsmeared carries a real affine map from the
    surface to the UV - three of its corners fix it exactly. Extending that
    one map across the shared edge gives the bad face a proportioned UV and
    leaves the shared corners where they already were, so nothing tears.

    Fitting one map across the whole patch of bad faces instead was tried and
    does not work: the ring around such a patch is itself cut by seams, and
    the fit missed by 0.16 of the map at the median. Face by face off a
    single neighbour is exact.

    `dot_min` is how closely the neighbour's normal must follow this face's.
    The caller walks it down: 0.7 mends the faces with a genuinely flat
    neighbour, and the last few - on a rounded corner where nothing nearby is
    parallel - are taken from whatever is next to them.
    """
    bad = {f.index for f in bm.faces if _is_smeared(f, lay)}
    if not bad:
        return 0
    done = 0
    for fi in sorted(bad):
        f = bm.faces[fi]
        n = f.normal.normalized()
        if n.length < 0.5:
            continue
        t = Vector((1.0, 0.0, 0.0)) if abs(n.x) < 0.9 else Vector((0.0, 1.0, 0.0))
        t = (t - n * t.dot(n)).normalized()
        b = n.cross(t)
        ctr = f.calc_center_median()
        cands = []
        for e in f.edges:
            for nb in e.link_faces:
                if nb is f or nb.index in bad:
                    continue
                d = nb.normal.normalized().dot(n)
                if d > dot_min:
                    cands.append((d, nb))
        cands.sort(key=lambda c: -c[0])
        for _d, nb in cands:
            P, U = [], []
            for l in nb.loops:
                q = l.vert.co - ctr
                P.append((q.dot(t), q.dot(b), 1.0))
                U.append(tuple(l[lay].uv))
            if len(P) < 3:
                continue
            P = np.array(P)
            U = np.array(U)
            try:
                M = np.linalg.lstsq(P, U, rcond=None)[0]
            except Exception:
                continue
            span = float(np.abs(U.max(axis=0) - U.min(axis=0)).max()) or 1.0
            # The neighbour has to be flat enough that one affine map really
            # describes it; a warped one would carry its own distortion over.
            if float(np.abs(P @ M - U).max()) > max(1e-4, span * 0.05):
                continue
            for l in f.loops:
                q = l.vert.co - ctr
                uv = np.array((q.dot(t), q.dot(b), 1.0)) @ M
                l[lay].uv = Vector((float(uv[0]), float(uv[1])))
            bad.discard(fi)
            done += 1
            break
    return done


def _neighbour_map(f, lay, sick=()):
    """The affine map from surface to UV that a healthy neighbour carries.

    Returns (origin, t, b, M) ready to place `f`'s corners with, or None.
    Three corners of a flat neighbour fix such a map exactly, and extending
    it across the shared edge leaves the shared corners where they already
    were - so the face rejoins the island instead of becoming one.
    """
    n = f.normal.normalized()
    if n.length < 0.5:
        return None
    t = Vector((1.0, 0.0, 0.0)) if abs(n.x) < 0.9 else Vector((0.0, 1.0, 0.0))
    t = (t - n * t.dot(n)).normalized()
    b = n.cross(t)
    ctr = f.calc_center_median()
    best = None
    for e in f.edges:
        for nb in e.link_faces:
            if nb is f or nb.index in sick:
                continue
            d = nb.normal.normalized().dot(n)
            if best is None or d > best[0]:
                best = (d, nb)
    if best is None:
        return None
    nb = best[1]
    P, U = [], []
    for l in nb.loops:
        q = l.vert.co - ctr
        P.append((q.dot(t), q.dot(b), 1.0))
        U.append(tuple(l[lay].uv))
    if len(P) < 3:
        return None
    P = np.array(P)
    U = np.array(U)
    try:
        M = np.linalg.lstsq(P, U, rcond=None)[0]
    except Exception:
        return None
    span = float(np.abs(U.max(axis=0) - U.min(axis=0)).max()) or 1.0
    if float(np.abs(P @ M - U).max()) > max(1e-4, span * 0.05):
        return None            # the neighbour is warped; its map would lie
    return ctr, t, b, M


def _across_edge(f, lay, sick=()):
    """Fall back to matching one shared edge exactly.

    `_neighbour_map` needs a neighbour flat enough that a single affine map
    really describes it, and refuses when none is. That left 34 of Milad's
    45 lone quads still islands. This asks for much less: take a neighbour's
    UVs on the two vertices of the shared edge, and carry the rest of the
    face across on the similarity that edge defines - same shape, same scale
    as the surface says. The shared edge then matches on both sides, which
    is all it takes for the face to stop being an island of its own.
    """
    for e in f.edges:
        if len(e.link_faces) != 2:
            continue
        nb = next((g for g in e.link_faces if g is not f), None)
        if nb is None or nb.index in sick:
            continue
        v0, v1 = e.verts
        want = {}
        for l in nb.loops:
            if l.vert in (v0, v1):
                want[l.vert] = l[lay].uv.copy()
        if v0 not in want or v1 not in want:
            continue
        d3 = v1.co - v0.co
        if d3.length < 1e-12:
            continue
        d2 = want[v1] - want[v0]
        if d2.length < 1e-12:
            continue
        scale = d2.length / d3.length
        n = f.normal.normalized()
        if n.length < 0.5:
            continue
        t = d3.normalized()
        b = n.cross(t)
        # the UV frame the shared edge sets up, kept right-handed against
        # the face's own normal so the mapping is not mirrored
        ex = d2 / d2.length
        ey = Vector((-ex.y, ex.x))
        flip = 1.0
        for l in nb.loops:
            if l.vert in (v0, v1):
                continue
            q = l.vert.co - v0.co
            if q.length < 1e-12:
                continue
            side3 = q.dot(b)
            side2 = (l[lay].uv - want[v0]).dot(ey)
            if abs(side3) > 1e-12 and abs(side2) > 1e-12:
                flip = -1.0 if (side3 > 0) != (side2 > 0) else 1.0
                break
        for l in f.loops:
            q = l.vert.co - v0.co
            l[lay].uv = (want[v0] + ex * (q.dot(t) * scale)
                         + ey * (q.dot(b) * scale * flip))
        return True
    return False


def _rejoin(bm, lay):
    """Put back the faces an earlier repair left as islands of their own.

    Laying a face out fresh beside a neighbour fixes its shape but cuts it
    off: every one of its edges becomes a UV discontinuity, so the face is a
    one-face island. That is not just untidy - Protect UV then shields all
    four of its edges, and no cleanup can ever touch it. On Milad's `part_02`
    that left 45 lone quads out of 444 faces, in 47 islands where there
    should have been two, and they were the squares that survived every
    sweep he tried.

    Each one is given a neighbour's own mapping instead, so the shared
    corners match and the face rejoins the island it came from.
    """
    lone = []
    for f in bm.faces:
        if all(_edge_splits(e, lay) for e in f.edges):
            lone.append(f)
    if not lone:
        return 0
    sick = {f.index for f in lone}
    done = 0
    for f in lone:
        got = _neighbour_map(f, lay, sick)
        if got is not None:
            ctr, t, b, M = got
            for l in f.loops:
                q = l.vert.co - ctr
                uv = np.array((q.dot(t), q.dot(b), 1.0)) @ M
                l[lay].uv = Vector((float(uv[0]), float(uv[1])))
        elif not _across_edge(f, lay, sick):
            continue
        sick.discard(f.index)
        done += 1
    return done


def _edge_splits(e, lay):
    """Do the two faces of `e` disagree about the UV along it?"""
    if len(e.link_faces) != 2:
        return True
    pair = []
    for f in e.link_faces:
        got = {}
        for l in f.loops:
            if l.vert in e.verts:
                got[l.vert] = l[lay].uv
        pair.append(got)
    for v in e.verts:
        a = pair[0].get(v)
        b = pair[1].get(v)
        if a is not None and b is not None and (a - b).length > 1e-5:
            return True
    return False


def heal(me, rounds=6):
    """Mend every UV layer of `me` in place. Returns corners touched.

    Both stages are repeated: mending one face changes which cluster is the
    biggest on the next, so a face with corners on three islands needs
    another look. They stop as soon as a round changes nothing.
    """
    import bmesh

    if me is None or not me.uv_layers or not len(me.polygons):
        return 0
    if len(me.uv_layers[0].data) != len(me.loops):
        return 0            # in Edit Mode; the UV arrays are not readable
    total = 0
    # torn first, then whatever the vote could not settle, then the faces
    # that are whole but squashed. Each stage assumes the one before it ran.
    stages = [("vote", None), ("relay", None)]
    stages += [("smear", d) for d in (0.7, 0.4, 0.0)]
    stages += [("rejoin", None)]
    for kind, dot_min in stages:
        for _ in range(rounds):
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.faces.ensure_lookup_table()
            bm.faces.index_update()
            layers = list(bm.loops.layers.uv.values())
            if kind == "vote":
                by_vert = {}
                for f in bm.faces:
                    for l in f.loops:
                        by_vert.setdefault(l.vert.index, []).append(l)
                did = sum(_vote(bm, lay, by_vert) for lay in layers)
            elif kind == "relay":
                did = sum(_relay(bm, lay) for lay in layers)
            elif kind == "rejoin":
                did = sum(_rejoin(bm, lay) for lay in layers)
            else:
                did = sum(_unsmear(bm, lay, dot_min) for lay in layers)
            if did:
                bm.to_mesh(me)
            bm.free()
            total += did
            if not did:
                break
    if total:
        me.update()
    return total
