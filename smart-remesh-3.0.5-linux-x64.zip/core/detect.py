"""Our own mesh analysis - what the engine should be told about this model.

A fixed dihedral threshold is not detection, it is a guess the user has to make
for every model, and getting it wrong wrecks the result. This module derives
the parameters from the mesh itself.

numpy only, so it runs inside Blender unchanged.
"""

from __future__ import annotations

import numpy as np


def dihedral_angles(mesh) -> np.ndarray:
    """Angle in degrees between the two faces of each manifold edge."""
    ef = mesh.edge_faces
    inner = (ef[:, 0] >= 0) & (ef[:, 1] >= 0)
    fn = mesh.face_normal
    mag = np.linalg.norm(fn, axis=1, keepdims=True)
    fnn = fn / np.maximum(mag, 1e-20)
    cos = np.sum(fnn[ef[inner, 0]] * fnn[ef[inner, 1]], axis=1)
    return np.degrees(np.arccos(np.clip(cos, -1.0, 1.0)))


def crease_angle(mesh, lo: float = 18.0, hi: float = 75.0,
                 target_fraction: float = 0.03) -> dict:
    """Pick a crease threshold from the model's own dihedral distribution.

    Looks for the widest gap in the upper tail of the angle histogram - a
    hard-surface model has a genuine valley between "flat panel" and "edge",
    and the threshold belongs in it. Falls back to whatever angle marks the
    top `target_fraction` of edges when there is no clear valley, which is the
    case for scanned or AI-generated meshes where the tail is smooth.
    """
    ang = dihedral_angles(mesh)
    if not len(ang):
        return {"angle": 30.0, "method": "default (no interior edges)",
                "crease_fraction": 0.0}

    ang_sorted = np.sort(ang)
    fallback = float(np.clip(
        np.percentile(ang_sorted, 100.0 * (1.0 - target_fraction)), lo, hi))

    # Valley search: histogram the candidate range and find the emptiest bin
    # that still has meaningful mass on both sides of it.
    bins = np.linspace(lo, hi, 25)
    counts, _ = np.histogram(ang, bins=bins)
    centres = 0.5 * (bins[:-1] + bins[1:])
    total = max(counts.sum(), 1)
    above = counts[::-1].cumsum()[::-1] / total

    valley = None
    usable = (above > 0.005) & (above < 0.25)
    if usable.any():
        idx = np.flatnonzero(usable)
        valley = int(idx[np.argmin(counts[idx])])

    if valley is not None and counts[valley] < 0.25 * counts.mean():
        angle = float(centres[valley])
        method = "histogram valley"
    else:
        angle = fallback
        method = f"top {target_fraction:.0%} of edges"

    frac = float((ang > angle).mean())
    return {"angle": float(np.clip(angle, lo, hi)), "method": method,
            "crease_fraction": frac,
            "dihedral_p50": float(np.percentile(ang, 50)),
            "dihedral_p99": float(np.percentile(ang, 99))}


def _smooth_positions(mesh, iterations: int, strength: float = 0.5):
    """Umbrella-operator smoothing of the vertex positions."""
    start, nbr = mesh.adjacency
    counts = np.diff(start)
    P = mesh.V.copy()
    src = np.repeat(np.arange(mesh.nv), counts)
    for _ in range(iterations):
        acc = np.zeros_like(P)
        for k in range(3):
            acc[:, k] = np.bincount(src, weights=P[nbr, k], minlength=mesh.nv)
        acc /= np.maximum(counts, 1)[:, None]
        P += strength * (acc - P)
    return P


def orientation_sign(mesh) -> float:
    """+1 if the normals point out of the solid, -1 if they point into it.

    Everything about inner-versus-outer hangs on this. Get it wrong and the
    detector confidently reports every ridge as a valley - which is exactly
    what the dented-sphere test caught, because that mesh happens to be wound
    inwards.
    """
    P = mesh.V[mesh.F]
    # Divergence theorem: signed volume is negative when winding is inverted.
    vol = float(np.sum(np.einsum("ij,ij->i", P[:, 0],
                                 np.cross(P[:, 1], P[:, 2]))) / 6.0)
    if abs(vol) > 1e-12 and (mesh.edge_faces[:, 1] < 0).sum() == 0:
        return 1.0 if vol > 0 else -1.0

    # Open surfaces have no volume to speak of, so fall back to asking whether
    # the normals mostly point away from the centre of mass.
    centre = mesh.V.mean(axis=0)
    away = mesh.V - centre
    agree = float(np.sum(np.sum(away * mesh.normal, axis=1)))
    return 1.0 if agree >= 0 else -1.0


def cavity(mesh, scales=(1, 4, 16)) -> dict:
    """Signed concavity per vertex - our stand-in for ambient occlusion.

    For each smoothing scale, compare the vertex to where smoothing wants to
    put it, measured along the normal:

        positive -> the neighbourhood sits above the vertex: a valley, an
                    *inner* edge, and the part a real AO bake would darken
        negative -> a ridge, an *outer* edge

    Doing it at several scales separates a tight crease from a broad dish, and
    it needs no ray casting, no BVH and no bake - which keeps the whole thing
    numpy-only and independent of Blender.
    """
    sign = orientation_sign(mesh)
    n = mesh.normal * sign
    diag = mesh.diagonal
    out = {"orientation": sign}
    combined = np.zeros(mesh.nv)
    for s in scales:
        P = _smooth_positions(mesh, s)
        d = np.sum((P - mesh.V) * n, axis=1) / diag
        # Normalise per scale: displacement grows with the smoothing radius,
        # so raw values across scales are not comparable.
        ref = np.percentile(np.abs(d), 95)
        dn = d / max(ref, 1e-12)
        out[f"scale_{s}"] = dn
        combined += dn
    combined /= len(scales)
    out["signed"] = combined
    out["concave"] = np.clip(combined, 0.0, None)
    out["convex"] = np.clip(-combined, 0.0, None)
    return out


def edge_field(mesh, feature_angle: float | None = None,
               inner_weight: float = 1.0, outer_weight: float = 1.0) -> dict:
    """Per-vertex edge importance, split into inner (concave) and outer (convex).

    Three signals are combined: the dihedral sharpness of incident edges, the
    magnitude of principal curvature, and the multi-scale cavity above. The
    first two say *how much* of an edge this is; the cavity says which *side*
    of one, which is the part a plain angle threshold throws away.
    """
    if feature_angle is None:
        feature_angle = crease_angle(mesh)["angle"]

    nv = mesh.nv
    ang = dihedral_angles(mesh)
    ef = mesh.edge_faces
    inner_mask = (ef[:, 0] >= 0) & (ef[:, 1] >= 0)
    e = mesh.edges[inner_mask]

    # Sharpness carried to vertices: the strongest incident edge wins, because
    # a vertex sitting on one crease is on a crease.
    sharp = np.zeros(nv)
    val = np.clip(ang / max(feature_angle, 1e-6), 0.0, 2.0)
    np.maximum.at(sharp, e[:, 0], val)
    np.maximum.at(sharp, e[:, 1], val)

    k1, k2, _, _ = mesh.curvature()
    kmag = np.nan_to_num(np.maximum(np.abs(k1), np.abs(k2))) * mesh.diagonal
    kref = np.percentile(kmag, 95) if nv else 1.0
    kn = np.clip(kmag / max(kref, 1e-12), 0.0, 1.0)

    cav = cavity(mesh)
    concave = np.clip(cav["concave"], 0.0, 1.0)
    convex = np.clip(cav["convex"], 0.0, 1.0)

    # An edge is interesting if it is sharp or curved; the cavity decides
    # whether it counts as inner or outer.
    strength = np.maximum(np.clip(sharp, 0.0, 1.0), kn)
    inner = strength * concave * float(inner_weight)
    outer = strength * convex * float(outer_weight)

    return {
        "sharpness": sharp,
        "curvature": kn,
        "signed_cavity": cav["signed"],
        "inner": inner,
        "outer": outer,
        "importance": np.clip(np.maximum(inner, outer), 0.0, 1.0),
        "feature_angle": float(feature_angle),
        "stats": {
            "inner_verts": int((inner > 0.3).sum()),
            "outer_verts": int((outer > 0.3).sum()),
            "sharp_verts": int((sharp > 1.0).sum()),
        },
    }


def describe(mesh) -> dict:
    """Everything the parameter chooser needs to know about the input."""
    ang = dihedral_angles(mesh)
    ef = mesh.edge_faces
    boundary = int((ef[:, 1] < 0).sum())

    k1, k2, _, aniso = mesh.curvature()
    kmag = np.nan_to_num(np.maximum(np.abs(k1), np.abs(k2)))
    diag = mesh.diagonal
    kn = kmag * diag

    cre = crease_angle(mesh)
    # Flatness: how much of the surface is genuinely planar. Hard-surface
    # models sit high here, organic scans low, and they want different
    # treatment - a hard-surface model tolerates a coarser lattice on its
    # panels, an organic one does not.
    flat_frac = float((kn < 1.0).mean())

    return {
        "verts": int(mesh.nv),
        "tris": int(mesh.nf),
        "mean_edge": float(mesh.mean_edge),
        "diagonal": float(diag),
        "area": float(mesh.total_area),
        "boundary_edges": boundary,
        "closed": boundary == 0,
        "crease": cre,
        "flat_fraction": flat_frac,
        "curvature_p90": float(np.percentile(kn, 90)) if len(kn) else 0.0,
        "dihedral_mean": float(ang.mean()) if len(ang) else 0.0,
        "kind": "hard-surface" if flat_frac > 0.55 and cre["crease_fraction"] < 0.15
                else "organic",
    }
