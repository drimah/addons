"""A card of controls drawn into the viewport itself.

The sidebar is where every setting lives and it stays that way. This is the
same set, laid out the way Milad drew it: a titled card with the engine at the
top, the settings under headings that say what they are for, the folded extras
under those, and the run button with the tools pinned at the bottom behind a
rule, so the thing pressed most is always in the same place.

Nothing here is Blender's own UI. The card is drawn as flat rounded rectangles
through `gpu` with text through `blf`, and a modal operator decides for every
event whether the card wants it or Blender should still see it. That is the
same shape as the overlay UIs shipping in other add-ons, minus their renderer:
Skia would draw this more prettily and would also carry a quarter of a gigabyte
of wheels behind it, where `gpu` and `blf` are already in the process.

Three things here are easy to get wrong, all three learned the hard way:

* **Screen scale.** Everything is authored at 1x and multiplied by `ui_scale`
  at draw time. Reading a hit rect in unscaled pixels and drawing it in scaled
  ones puts every button a finger's width from where it looks.
* **Which corner a rectangle is given by.** Blender takes the bottom left while
  the card is laid out downwards from its top, so a row goes in at ``y - h``
  and the cursor drops by ``h + gap``. Placing it at ``y`` is what put the
  first draft's sliders through the switches above them.
* **Letting go of events.** The pointer being over the card is what makes it
  swallow a click; anywhere else the event passes straight through, so orbit,
  select and every shortcut still work with the card up.
"""

from __future__ import annotations

import math
import time

import blf
import bpy
import colorsys
import os
import gpu
from gpu_extras.batch import batch_for_shader


# -- the look ---------------------------------------------------------------

CARD = (0.106, 0.106, 0.114, 0.97)
EDGE = (1.0, 1.0, 1.0, 0.09)
CONTROL = (1.0, 1.0, 1.0, 0.055)
CONTROL_HOVER = (1.0, 1.0, 1.0, 0.10)
PICKED = (0.235, 0.157, 0.055, 1.0)
TRACK = (1.0, 1.0, 1.0, 0.14)
RULE = (1.0, 1.0, 1.0, 0.07)
TEXT = (0.910, 0.910, 0.925, 1.0)
TEXT_DIM = (0.478, 0.478, 0.494, 1.0)
ACCENT = (1.0, 0.576, 0.078, 1.0)
ACCENT_HOVER = (1.0, 0.655, 0.220, 1.0)
ON_ACCENT = (0.110, 0.063, 0.008, 1.0)
KNOB = (0.980, 0.980, 0.988, 1.0)

# Orange is our colour, not necessarily the buyer's, and a colour you cannot
# change is a colour you have to put up with. Hue and saturation are kept in
# the add-on preferences so the choice outlives the file, and everything the
# card draws in the accent is derived from them rather than written down.
ACCENT_HUE = 0.0901          # the hue and saturation of #ff9314
ACCENT_SAT = 0.922


def _ac(alpha=1.0):
    """The accent colour at a given strength."""
    return (ACCENT[0], ACCENT[1], ACCENT[2], alpha)


def accent_rgb(hue, sat):
    return colorsys.hsv_to_rgb(hue % 1.0, max(0.0, min(1.0, sat)), 1.0)


def retint():
    """Rebuild every accent-derived colour from the saved hue and saturation.

    PICKED and ON_ACCENT are not free choices - one is the accent sunk to a
    background and the other is what stays readable on top of it - so they
    follow the accent rather than being picked alongside it.
    """
    global ACCENT, ACCENT_HOVER, ON_ACCENT, PICKED
    hue, sat = ACCENT_HUE, ACCENT_SAT
    prefs = _prefs()
    if prefs is not None:
        hue = float(getattr(prefs, "accent_hue", hue))
        sat = float(getattr(prefs, "accent_sat", sat))
    r, g, b = accent_rgb(hue, sat)
    ACCENT = (r, g, b, 1.0)
    ACCENT_HOVER = accent_rgb(hue, sat * 0.78) + (1.0,)
    ON_ACCENT = (r * 0.11, g * 0.11, b * 0.11, 1.0)
    PICKED = (r * 0.235, g * 0.235, b * 0.235, 1.0)

    # How round the corners are is one number, not four. The card, the
    # buttons, the value boxes and the logo all keep the proportions they were
    # drawn with and follow it together, so square is square everywhere and
    # round is round everywhere.
    global R_CARD, R_CTL, R_BOX, R_LOGO
    corner = CORNER
    if prefs is not None:
        corner = float(getattr(prefs, "corner", corner))
    R_CTL = corner
    R_CARD = corner * 1.75
    R_BOX = corner * 0.75
    R_LOGO = corner * 0.875


def _prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return None

R_CARD = 14.0
R_CTL = 8.0
R_BOX = 6.0
R_LOGO = 7.0
CORNER = 8.0                 # what the control radius is when nothing is set

# Wide enough to read, narrow enough to leave the viewport's own gizmo column
# clear. At 268 the card's left edge sat over the axis widget and the zoom and
# pan buttons under it; 234 cleared them and read as a splinter, so it sits a
# tenth wider than that.
CARD_W = 257.0
TAB_STRIP = 26.0          # the sidebar collapsed to its tabs alone
PAD = 14.0
GAP = 8.0
ROW = 30.0
TAB = "Smart Remesh"

_state = {
    "group": "ORGANIC",
    "open": set(),
    "tip": None,          # (widget index, key, when the pointer settled)
    "ticking": False,
    "handle": None,
    "modal": False,
    "quit": False,
    "widgets": [],
    "hover": None,
    "drag": None,
    "note": None,         # a line the card says back, and when
    "painted": 0.0,       # last repaint we asked for
    "beat": 0.0,          # last event the modal saw
    "drawn": 0.0,         # last time the card was painted
    "asked": 0.0,         # when we last asked for a repaint, 0 if not waiting
    "cost": 0.02,         # what a repaint of this scene actually takes
    "dirty": False,       # a repaint we skipped and still owe
    "was_up": False,      # whether the card was showing last time we looked
    "typing": None,       # the number box being typed into, if any
    "scroll": 0.0,        # how far the contents are pushed up
    "over": 0.0,          # how much taller than the room it has, last draw
}


def register_draw():
    """Put the card's draw handler back after the classic panel had its turn."""
    if _state["handle"] is None:
        _drop_stale_card()
        _state["handle"] = bpy.types.SpaceView3D.draw_handler_add(
            _draw, (), "WINDOW", "POST_PIXEL")
        bpy.app.driver_namespace[_CARD_HANDLE] = _state["handle"]
    _state["quit"] = False


def _visible(context, area=None):
    """The card is up exactly when our own tab in the sidebar is.

    Milad's words: it should behave like the N panel itself. So it is not a
    button of its own - it follows the sidebar being open and the Smart Remesh
    tab being the one on top, and closing that tab closes the card with it.
    """
    prefs = _prefs()
    if prefs is not None and getattr(prefs, "classic_panel", False):
        return False        # the old side panel has the floor
    if area is None:
        area = getattr(context, "area", None)
    if area is None or area.type != "VIEW_3D":
        return False
    space = area.spaces.active
    if not getattr(space, "show_region_ui", False):
        return False
    for region in area.regions:
        if region.type == "UI":
            # A sidebar dragged shut is still "shown" and still remembers its
            # tab, so the flag and the category both say yes while nothing is
            # on screen. Its width is what actually tells: open it reads a few
            # hundred pixels, dragged shut it reads 26.
            if region.width < 60:
                return False
            return getattr(region, "active_panel_category", "") == TAB
    return False


# -- drawing ----------------------------------------------------------------

def _round_rect(x, y, w, h, r, steps=5):
    """Triangles for a rounded rectangle, as one fan around its middle."""
    r = max(0.0, min(r, w * 0.5, h * 0.5))
    pts = []
    corners = ((x + w - r, y + h - r, 0.0),
               (x + r, y + h - r, math.pi * 0.5),
               (x + r, y + r, math.pi),
               (x + w - r, y + r, math.pi * 1.5))
    for cx, cy, a0 in corners:
        for i in range(steps + 1):
            a = a0 + (math.pi * 0.5) * (i / steps)
            pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    mid = (x + w * 0.5, y + h * 0.5)
    tris = []
    for i in range(len(pts)):
        tris.extend((mid, pts[i], pts[(i + 1) % len(pts)]))
    return tris


def _fill(shader, x, y, w, h, r, color):
    if w <= 0.0 or h <= 0.0:
        return
    batch = batch_for_shader(shader, "TRIS",
                             {"pos": _round_rect(x, y, w, h, r)})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _text(s, x, y, size, color, scale, right=None, mid=None, bold=False):
    blf.size(0, size * scale)
    blf.color(0, *color)
    if right is not None or mid is not None:
        tw, _ = blf.dimensions(0, s)
        x = (right - tw) if right is not None else (mid - tw * 0.5)
    blf.position(0, x, y, 0)
    blf.draw(0, s)
    if bold:
        # blf has one weight, so a heavier line is the same glyphs a breath to
        # the right - enough to read as bold at this size, and cheaper than
        # shipping a second font to say one word louder.
        blf.position(0, x + max(0.6, 0.5 * scale), y, 0)
        blf.draw(0, s)


# -- what a control means, shown rather than written ------------------------
#
# A number on a slider says nothing about what it does to a mesh. Rest on one
# for a moment and a small card opens beside the panel with the idea drawn out
# and moving: the grid getting finer as the count climbs, the fold passing the
# angle and turning into an edge, the two panels coming apart to be remeshed
# on their own. The drawing is the explanation; the sentence under it is a
# reminder, not the lesson.

TIP_DELAY = 0.55
TIP_W = 244.0

TIPS = {
    "faces": ("Face count",
              "How many quads the result is built from. More of them follow "
              "the shape closer and cost more to carry.", "grid"),
    "edge": ("Edge length",
             "How long one quad's side should be. Smaller means a denser "
             "grid, whatever the model's size.", "grid"),
    "sharp": ("Sharp angle",
              "A fold steeper than this counts as an edge of the form and is "
              "kept. Softer than this is smoothed over.", "fold"),
    "separate": ("Remesh separately",
                 "The model is opened out into its UV islands, and each "
                 "island is remeshed on its own.", "split"),
    "meet": ("Meet distance",
             "How far apart two panels' border points may be and still be "
             "pulled onto each other.", "meet"),
    "weld": ("Weld panels",
             "The points that met are made into one, so the seam becomes a "
             "single line rather than two lying on each other.", "weld"),
    "tears": ("Close tears",
              "Holes smaller than the model's own openings are filled, so a "
              "torn simulation does not stay torn.", "tear"),
    "shells": ("Merge shells",
               "Pieces lying on top of each other are welded first, so the "
               "remesh sees one surface instead of two.", "shells"),
    "pick": ("Pick a piece",
             "Move over the model and the piece under the pointer lights up. "
             "Click and that piece is taken out on its own.", "pick"),
    "isolate": ("Isolate piece",
                "Puts everything but the selected piece away, and pressing it "
                "again brings the rest back.", "isolate"),
    "relax": ("Relax brush",
              "A brush to drag over the surface. Wherever it passes, crumpled "
              "mesh is smoothed out and evened up.", "relax"),
    "uvkeep": ("Bake into existing UV",
               "The remesh is laid onto the UV the model already has, so the "
               "islands land where the old ones were.", "uvkeep"),
    "seams": ("Show UV seams",
              "The flat layout folds back into the model, and the edges it "
              "was cut along light up. Those are the seams.", "seams"),
    "seamsharp": ("Seams as sharp",
                  "The UV cuts are also marked as hard edges, so the shading "
                  "breaks where the pieces do.", "sharpedge"),
    "bake": ("Bake from original",
             "Carries the original's surface - its colour and its maps - onto "
             "the remesh, through the new UV.", "bake"),
    "unbake": ("Unbake",
               "Takes the baked surface back off and puts the materials and "
               "the UV the model had before it back, and deletes the images "
               "the bake wrote.", "unbake"),
    "pbr": ("Bake PBR",
            "Bakes the whole set of maps rather than colour alone: roughness, "
            "metal, normal, whatever the material carries.", "pbr"),
    "gpu": ("Bake on GPU",
            "Runs the bake on the graphics card. Much faster where the card "
            "can take it, and falls back on its own where it cannot.", "gpu"),
    "purequad": ("Pure quads",
                 "Leaves no triangle anywhere. Off, the remesh puts a "
                 "triangle in wherever quads alone will not close, which is "
                 "tidier flow but not an all-quad mesh.", "purequad"),
    "reproject": ("Reprojection steps",
                  "The remesh builds an even lattice first and then pulls it "
                  "back onto the original surface. Each step drags it closer: "
                  "too few and the result floats over the detail, too many "
                  "and the flow smooths out. Two is a good place to sit.",
                  "reproject"),
    "accent": ("Card colour",
               "The top strip picks the hue, the one under it how strong it "
               "is - slide it to the left and the card goes grey. The choice "
               "is kept in the add-on, so it stays across files.", "accent"),
    "corner": ("Corner rounding",
               "How round every corner on the card is. All the way down is "
               "square, all the way up is a pill.", "corner"),
    "remesh": ("Remesh",
               "Builds the model again on an even quad mesh, at the size you "
               "asked for, keeping the shape it already had.", "remesh"),
    "hardsurface": ("Remesh hardsurface",
                    "Reads the model's own hard edges and lays the new quads "
                    "along them, so panels stay panels and corners stay "
                    "corners.", "hardsurface"),
    "crease": ("Detect crease angle",
               "Finds the angle at which this model's edges actually turn, "
               "and treats anything sharper than that as an edge to keep. Off, "
               "you set the angle yourself.", "crease"),
    "calibrate": ("Calibrate face count",
                  "The engine rarely lands on the count first time. This "
                  "measures what came out and runs it again aimed at your "
                  "number, so the result is the count you asked for.",
                  "calibrate"),
    "search": ("Search settings",
               "Tries the remesh at several settings and keeps whichever came "
               "out best, instead of taking the first result. Slower, and "
               "usually cleaner.", "search"),
    "autothresh": ("Automatic thresholds",
                   "Works the crease and coplanar numbers out from the model "
                   "itself. Turn it off to dial them in by hand.",
                   "autothresh"),
    "weldclose": ("Weld close lines",
                  "Two lines running almost on top of each other are one "
                  "line the model found twice. Anything closer together than "
                  "this is merged into a single line.", "weldlines"),
    "straight": ("Remove straight loops",
                 "A loop crossing flat ground carries no shape and only costs "
                 "faces. Loops flatter than this are dissolved.",
                 "straightloop"),
    "minlen": ("Min length",
               "Short stubs of line are noise, not features. Anything shorter "
               "than this is dropped before the mesh is built.", "minlen"),
    "circles": ("Keep circles round",
                "A hole read off the mesh comes back as a polygon. This puts "
                "it back on a true circle so the ring stays round.",
                "circle"),
    "typed": ("Flat and curved boundaries",
              "Tells a straight border from a curved one and holds each to "
              "its own shape, instead of fitting one rule to both.", "typed"),
    "gaps": ("Close gaps",
             "A line that stops short of the one facing it leaves a hole. "
             "This carries it across and closes it.", "gap"),
    "gapspan": ("Gap reach",
                "How far a line is allowed to reach to find the one facing "
                "it. Too far and lines meet that were never meant to.",
                "gap"),
    "fillgaps": ("Fill Missed Gaps",
                 "Finds the openings left in the retopology and closes them, "
                 "carrying the lines across so the new faces fit the ones "
                 "already there.", "gap"),
    "mirror": ("Mirror retopology",
               "Retopologises one side and takes the other side from it, so "
               "the two halves match exactly.", "mirror"),
    "usemarked": ("Include my lines",
                  "Counts the edges you marked by hand along with the ones "
                  "the model found on its own.", "marked"),
    "onlymarked": ("Only my lines",
                   "Ignores everything the model found and works from the "
                   "edges you marked, and nothing else.", "marked"),
    "cleanamount": ("Remove",
                    "How much of the knotted area is taken out and laid "
                    "again as plain rows. Higher clears more of it.",
                    "clean"),
    "clean": ("Clean",
              "Takes the knotted area out and lays it again as plain rows of "
              "quads.", "clean"),
    "confine": ("Stay inside lines",
                "The tidying stops at the lines you marked and does not run "
                "out into the rest of the model.", "confine"),
    "useless": ("Flat below",
                "A loop crossing flat ground holds no shape. Loops flatter "
                "than this are the ones offered up for removal.", "useless"),
    "every": ("Remove per kept",
              "Out of every few loops, one is kept. Thins an over-dense area "
              "evenly instead of clearing it.", "every"),
    "usethis": ("Use this mesh",
                "Works from what is on screen. With Replace original on, the "
                "add-on keeps reading the mesh the result was built from, and "
                "a piece pulled out of a result carries that link with it - "
                "so remeshing the piece would rebuild the whole model "
                "instead. This breaks the link.", "usethis"),
    "cage": ("Build subdiv cage",
             "Builds a small all-quad cage over the model, sits it on the "
             "surface, finds the model's own hard edges and creases them into "
             "the cage, then puts a Subdivision Surface on top. The same three "
             "things a box-modelled cage does, without the hour of knife work.",
             "cage"),
    "cagefaces": ("Cage faces",
                  "How many faces the cage is built with. Hand made cages sit "
                  "between a few hundred and a thousand: enough to hold the "
                  "form, few enough to move by hand afterwards.", "cage"),
    "cagecrease": ("Crease over",
                   "A fold in the model sharper than this is creased into the "
                   "cage, so subdivision keeps it sharp instead of rounding "
                   "it off. This is what support loops do by hand.", "cage"),
    "reset": ("Back to original",
              "Takes off everything the add-on put on this model - lines, "
              "cleanups, chamfers - and leaves what you started with.",
              "reset"),
    "mergedist": ("Merge distance",
                  "Points closer together than this are made into one, so a "
                  "seam that should be shut is shut.", "merge"),
    "meetbtn": ("Meet panel vertices",
                "Walks the panel borders and brings the vertices facing each "
                "other onto the same point, so the panels meet cleanly.",
                "meet"),
    "confirm": ("Confirm",
                "Keeps the result and carries on with it as the model, so "
                "the next thing you do works on the new mesh.", "confirm"),
    "restore": ("Restore",
                "Puts the model you started with back and sets the remesh "
                "aside.", "restore"),
    "flatfan": ("Rebuild flat areas",
                "Finds the areas that are flat and takes each one out as a "
                "single face, so the fans and diagonals across them go, along "
                "with the points sitting on those diagonals. Those points "
                "hold three edges each, which is why At least 3 edges never "
                "touches them.", "flatfan"),
    "flatkeep": ("Keep my lines",
                 "Rebuild flat areas never dissolves across an edge you "
                 "marked Sharp, marked as a seam, or selected. Without it a "
                 "line drawn on a flat panel goes with the fan around it.",
                 "flatkeep"),
    "valence": ("At least 3 edges",
                "Clears out every vertex holding fewer than three edges: "
                "loose points and spurs are deleted, and a point sitting "
                "between just two edges is dissolved into one line.",
                "valence"),
    "hardtut": ("Hardsurface - Tutorial",
                "Opens the walkthrough for remeshing a hard surface model on "
                "YouTube: the lines it reads, the panels it builds, and the "
                "cleanup that follows.", "watchhard"),
    "clothtut": ("Cloth Remeshing - Tutorial",
                 "Opens the walkthrough for remeshing a garment on YouTube: "
                 "the panels, the seams, and which settings matter.",
                 "watchcloth"),
    "watch": ("Smart Remesh 3 - Quick Overview",
              "Opens the overview video on YouTube in your browser.",
              "watch"),
    "classic": ("Classic panel",
                "Swaps this card for the side panel the add-on shipped with. "
                "The way back is the first button at the top of that panel. "
                "The choice is kept in the add-on.", "classic"),
    "replace": ("Replace original",
                "On, the object carrying the old mesh is deleted and the "
                "remesh takes its place. Restore brings it back.", "swap"),
    "closeholes": ("Close holes",
                   "Seals the openings of the model before the remesh. Use it "
                   "when the result has holes, e.g. a face cut open along the "
                   "hairline. Leave it off for models open on purpose.",
                   "shells"),
}


def _quad(shader, a, b, c, d, color, scale):
    """Any four-cornered patch, as two triangles."""
    pts = [(p[0] * scale, p[1] * scale) for p in (a, b, c, d)]
    batch = batch_for_shader(shader, "TRIS", {"pos": (
        pts[0], pts[1], pts[2], pts[0], pts[2], pts[3])})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _seg(shader, a, b, width, color, scale):
    """A straight line of a given width, at any angle."""
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    length = math.hypot(dx, dy)
    if length < 1e-6:
        return
    nx = -dy / length * width * 0.5
    ny = dx / length * width * 0.5
    _quad(shader, (a[0] + nx, a[1] + ny), (b[0] + nx, b[1] + ny),
          (b[0] - nx, b[1] - ny), (a[0] - nx, a[1] - ny), color, scale)


def _lerp(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)


def _tip_grid(shader, x, y, w, h, phase, scale):
    """A square that gets finer and coarser again."""
    n = 2 + int(round(abs(math.sin(phase * math.pi)) * 5))
    side = min(w, h) - 8.0
    ox = x + (w - side) * 0.5
    oy = y + (h - side) * 0.5
    t = 1.2
    for i in range(n + 1):
        at = i * (side - t) / n
        _fill(shader, ox * scale, (oy + at) * scale, side * scale, t * scale,
              0.0, ACCENT if i in (0, n) else TRACK)
        _fill(shader, (ox + at) * scale, oy * scale, t * scale, side * scale,
              0.0, ACCENT if i in (0, n) else TRACK)


def _tip_fold(shader, x, y, w, h, phase, scale):
    """Two panes hinged at the middle; the crease lights when it is steep."""
    ang = 20.0 + abs(math.sin(phase * math.pi)) * 70.0
    side = min(w * 0.42, h - 16.0)
    cx = x + w * 0.5
    cy = y + h * 0.5
    lean = math.cos(math.radians(ang)) * side
    drop = math.sin(math.radians(ang)) * side * 0.5
    _fill(shader, (cx - lean) * scale, (cy - drop) * scale, lean * scale,
          2.0 * scale, 0.0, TRACK)
    _fill(shader, cx * scale, (cy - drop) * scale, lean * scale, 2.0 * scale,
          0.0, TRACK)
    _fill(shader, (cx - lean) * scale, (cy - drop - side * 0.45) * scale,
          2.0 * scale, side * 0.45 * scale, 0.0, TRACK)
    _fill(shader, (cx + lean - 2.0) * scale,
          (cy - drop - side * 0.45) * scale, 2.0 * scale,
          side * 0.45 * scale, 0.0, TRACK)
    hot = ACCENT if ang > 45.0 else TRACK
    _fill(shader, (cx - 2.0) * scale, (cy - drop - 3.0) * scale, 4.0 * scale,
          (side * 0.45 + 8.0) * scale, 2.0 * scale, hot)


def _cube_and_net(x, y, w, h):
    """The six faces of a cube, as (standing, opened out) corner pairs.

    Shared by the two drawings that need it: one folds a cube open to show
    where the UV islands come from, the other folds the flat layout back up to
    show where the seams are.
    """
    cell = min((w - 10.0) / 4.2, (h - 8.0) / 3.2)
    nx = x + (w - cell * 4.0) * 0.5
    ny = y + (h - cell * 3.0) * 0.5

    def net(cx, cy):
        px = nx + cx * cell
        py = ny + cy * cell
        pad = cell * 0.06
        return ((px + pad, py + pad), (px + cell - pad, py + pad),
                (px + cell - pad, py + cell - pad), (px + pad, py + cell - pad))

    side = cell * 0.92
    ux, uy = 0.866 * side, -0.5 * side
    vx, vy = -0.866 * side, -0.5 * side
    ax = x + w * 0.5
    ay = y + h * 0.5 + side * 0.95

    def at(du, dv, dd):
        return (ax + ux * du + vx * dv, ay + uy * du + vy * dv - side * dd)

    top = (at(0, 0, 0), at(1, 0, 0), at(1, 1, 0), at(0, 1, 0))
    right = (at(1, 0, 0), at(1, 0, 1), at(1, 1, 1), at(1, 1, 0))
    leftf = (at(0, 1, 0), at(1, 1, 0), at(1, 1, 1), at(0, 1, 1))
    return ((top, net(1, 2)), (leftf, net(0, 1)), (right, net(1, 1)),
            (top, net(1, 0)), (right, net(2, 1)), (leftf, net(3, 1)))


def _tip_split(shader, x, y, w, h, phase, scale):
    """A cube, opened out into its UV net, and gridded evenly all over.

    Milad's note on the first pass was that the cube was not a cube - it was
    three squares stacked, which reads as paper, not as a solid. So the faces
    are real four-cornered patches now and the cube is drawn in the ordinary
    isometric way, three faces meeting at a corner. Unfolding is then just the
    same four corners walking to where they sit on the flat net, one lerp per
    corner, and the grid rides along with them.

    Every face gets the same number of cells, because that is the truth of it:
    the pieces are remeshed apart from one another, not at different densities.
    """
    t = phase % 1.0
    open_ = 0.0 if t < 0.22 else min(1.0, (t - 0.22) / 0.34)
    open_ = open_ * open_ * (3.0 - 2.0 * open_)
    lay = 0.0 if t < 0.60 else min(1.0, (t - 0.60) / 0.28)

    faces = _cube_and_net(x, y, w, h)

    cells = 3
    line = (1.0, 1.0, 1.0, 0.20 * lay)
    for start, end in faces:
        corner = [_lerp(start[i], end[i], open_) for i in range(4)]
        _quad(shader, corner[0], corner[1], corner[2], corner[3], CONTROL,
              scale)
        edge = _ac(0.35 + 0.65 * open_)
        for i in range(4):
            _seg(shader, corner[i], corner[(i + 1) % 4], 1.4, edge, scale)
        if lay <= 0.0:
            continue
        for i in range(1, cells):
            f = i / cells
            _seg(shader, _lerp(corner[0], corner[1], f),
                 _lerp(corner[3], corner[2], f), 1.1, line, scale)
            _seg(shader, _lerp(corner[0], corner[3], f),
                 _lerp(corner[1], corner[2], f), 1.1, line, scale)


def _tip_shells(shader, x, y, w, h, phase, scale):
    """Two sheets lying on each other, welded into one."""
    close = abs(math.sin(phase * math.pi))
    side = min(w * 0.5, h - 20.0)
    off = (1.0 - close) * 18.0
    cx = x + w * 0.5
    cy = y + (h - side) * 0.5
    for sign, tone in ((-1.0, TRACK), (1.0, TRACK)):
        ox = cx - side * 0.5 + sign * off * 0.5
        oy = cy + sign * off * 0.35
        _fill(shader, ox * scale, oy * scale, side * scale, side * scale,
              3.0 * scale, ACCENT if off < 3.0 else tone)
        _fill(shader, (ox + 2.0) * scale, (oy + 2.0) * scale,
              (side - 4.0) * scale, (side - 4.0) * scale, 2.0 * scale, CARD)


def _tip_weld(shader, x, y, w, h, phase, scale):
    """Two points brought together and made into one."""
    close = abs(math.sin(phase * math.pi))
    cx = x + w * 0.5
    cy = y + h * 0.5
    gapx = (1.0 - close) * 22.0
    if gapx < 2.5:
        _fill(shader, (cx - 6.0) * scale, (cy - 6.0) * scale, 12.0 * scale,
              12.0 * scale, 6.0 * scale, ACCENT)
    else:
        for sign in (-1.0, 1.0):
            _fill(shader, (cx + sign * gapx - 4.0) * scale, (cy - 4.0) * scale,
                  8.0 * scale, 8.0 * scale, 4.0 * scale, TRACK)
    _fill(shader, (cx - 30.0) * scale, (cy - 1.0) * scale, 60.0 * scale,
          2.0 * scale, 0.0, RULE)


def _tip_meet(shader, x, y, w, h, phase, scale):
    """Two rows of points closing on each other until they touch."""
    close = abs(math.sin(phase * math.pi))
    gapx = (1.0 - close) * 26.0 + 3.0
    cx = x + w * 0.5
    for i in range(5):
        py = y + 14.0 + i * (h - 28.0) / 4.0
        for sign in (-1.0, 1.0):
            hot = ACCENT if gapx < 6.0 else TRACK
            _fill(shader, (cx + sign * gapx - 3.0) * scale, (py - 3.0) * scale,
                  6.0 * scale, 6.0 * scale, 3.0 * scale, hot)
        _fill(shader, (cx - gapx) * scale, (py - 1.0) * scale,
              gapx * 2.0 * scale, 2.0 * scale, 0.0,
              ACCENT if gapx < 6.0 else RULE)


def _tip_tear(shader, x, y, w, h, phase, scale):
    """A hole in a sheet closing up."""
    open_ = 1.0 - abs(math.sin(phase * math.pi))
    side = min(w - 40.0, h - 16.0)
    ox = x + (w - side) * 0.5
    oy = y + (h - side) * 0.5
    _fill(shader, ox * scale, oy * scale, side * scale, side * scale,
          4.0 * scale, CONTROL)
    r = 4.0 + open_ * 16.0
    _fill(shader, (ox + side * 0.5 - r) * scale, (oy + side * 0.5 - r) * scale,
          r * 2.0 * scale, r * 2.0 * scale, r * scale,
          CARD if open_ > 0.15 else ACCENT)


def _tip_swap(shader, x, y, w, h, phase, scale):
    """Two objects, one of them going, the other taking its place.

    Two drawings before this one missed it. Sliding blocks said "now there are
    two", and fading one square into another said "it changed in place" - and
    the switch is neither. There are two objects on the desk, the one carrying
    the old mesh is deleted, and the one carrying the new mesh moves into the
    place it left.
    """
    t = phase % 1.0
    fade = 0.0 if t < 0.28 else min(1.0, (t - 0.28) / 0.24)
    move = 0.0 if t < 0.58 else min(1.0, (t - 0.58) / 0.30)
    move = move * move * (3.0 - 2.0 * move)

    side = min((w - 34.0) * 0.5, h - 22.0)
    gapx = 18.0
    oy = y + (h - side) * 0.5
    lx = x + (w - side * 2.0 - gapx) * 0.5
    rx = lx + side + gapx

    def square(px, cells, alpha, hot):
        p0 = (px, oy)
        p1 = (px + side, oy)
        p2 = (px + side, oy + side)
        p3 = (px, oy + side)
        _quad(shader, p0, p1, p2, p3, (1.0, 1.0, 1.0, 0.055 * alpha), scale)
        edge = (_ac(alpha) if hot
                else (1.0, 1.0, 1.0, 0.20 * alpha))
        for i in range(4):
            _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.4, edge,
                 scale)
        line = (1.0, 1.0, 1.0, (0.22 if hot else 0.16) * alpha)
        for i in range(1, cells):
            f = i / cells
            _seg(shader, _lerp(p0, p1, f), _lerp(p3, p2, f), 1.0, line, scale)
            _seg(shader, _lerp(p0, p3, f), _lerp(p1, p2, f), 1.0, line, scale)
        if not hot:
            for i in range(cells):
                _seg(shader, _lerp(p0, p1, i / cells),
                     _lerp(p3, p2, (i + 1) / cells), 1.0, line, scale)

    # the old one, dense and triangulated, deleted as the switch goes on
    if fade < 1.0:
        square(lx, 6, 1.0 - fade, False)
    # the new one, clean quads, moving into the place the old one left
    square(rx + (lx - rx) * move, 3, 1.0, True)


def _cursor(shader, x, y, size, scale):
    """A pointer, so a drawing can say "the mouse is here"."""
    a = (x, y)
    b = (x, y - size)
    c = (x + size * 0.72, y - size * 0.72)
    _quad(shader, a, b, c, c, (1.0, 1.0, 1.0, 0.92), scale)
    _quad(shader, (a[0] + 1.0, a[1] - 1.0), (b[0] + 1.0, b[1] + 1.5),
          (c[0] - 1.0, c[1] + 0.5), (c[0] - 1.0, c[1] + 0.5),
          (0.1, 0.1, 0.12, 1.0), scale)


def _ring(shader, cx, cy, r, width, color, scale, steps=18):
    """A circle outline, for a brush."""
    import math as _m
    prev = None
    for i in range(steps + 1):
        a = 2.0 * _m.pi * i / steps
        pt = (cx + _m.cos(a) * r, cy + _m.sin(a) * r)
        if prev is not None:
            _seg(shader, prev, pt, width, color, scale)
        prev = pt


def _tip_pick(shader, x, y, w, h, phase, scale):
    """Hovering lights a piece; clicking takes that piece out on its own."""
    t = phase % 1.0
    parts = 3
    gapx = 8.0
    pw = (w - 16.0 - gapx * (parts - 1)) / parts
    ph = min(h - 26.0, pw * 1.15)
    oy = y + (h - ph) * 0.5 - 4.0
    ox = x + 8.0

    sweep = min(1.0, t / 0.62)
    under = min(parts - 1, int(sweep * parts))
    taken = t > 0.70

    for k in range(parts):
        px = ox + k * (pw + gapx)
        p0 = (px, oy)
        p1 = (px + pw, oy)
        p2 = (px + pw, oy + ph)
        p3 = (px, oy + ph)
        lit = (k == under)
        if taken and not lit:
            continue                     # the rest are gone once one is taken
        fill = _ac(0.16) if lit else (1.0, 1.0, 1.0, 0.055)
        _quad(shader, p0, p1, p2, p3, fill, scale)
        edge = (_ac(1.0) if lit
                else (1.0, 1.0, 1.0, 0.16))
        for i in range(4):
            _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.4, edge,
                 scale)
        line = (1.0, 1.0, 1.0, 0.14)
        for i in (1, 2):
            f = i / 3.0
            _seg(shader, _lerp(p0, p1, f), _lerp(p3, p2, f), 1.0, line, scale)
            _seg(shader, _lerp(p0, p3, f), _lerp(p1, p2, f), 1.0, line, scale)

    if not taken:
        cx = ox + under * (pw + gapx) + pw * 0.55
        _cursor(shader, cx, oy + ph * 0.62, 11.0, scale)


def _tip_isolate(shader, x, y, w, h, phase, scale):
    """One piece kept, the rest put away - and brought back again."""
    alone = abs(math.sin(phase * math.pi))
    parts = 3
    gapx = 8.0
    pw = (w - 16.0 - gapx * (parts - 1)) / parts
    ph = min(h - 26.0, pw * 1.15)
    oy = y + (h - ph) * 0.5
    ox = x + 8.0
    keep = 1

    for k in range(parts):
        fade = 1.0 if k == keep else 1.0 - alone
        if fade < 0.02:
            continue
        px = ox + k * (pw + gapx)
        p0 = (px, oy)
        p1 = (px + pw, oy)
        p2 = (px + pw, oy + ph)
        p3 = (px, oy + ph)
        held = (k == keep)
        _quad(shader, p0, p1, p2, p3,
              _ac(0.16) if held else (1.0, 1.0, 1.0,
                                                      0.055 * fade), scale)
        edge = (_ac(1.0) if held
                else (1.0, 1.0, 1.0, 0.16 * fade))
        for i in range(4):
            _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.4, edge,
                 scale)


def _tip_relax(shader, x, y, w, h, phase, scale):
    """A brush dragged over crumpled mesh, leaving it even behind it."""
    t = phase % 1.0
    front = x + 10.0 + (w - 20.0) * min(1.0, t / 0.85)
    cols, rows = 7, 4
    ox = x + 10.0
    oy = y + (h - 12.0 - (h - 34.0)) * 0.5 + 6.0
    gw = w - 20.0
    gh = h - 34.0

    def point(i, j):
        px = ox + gw * i / cols
        py = oy + gh * j / rows
        if px > front:
            # not reached yet: still crumpled
            px += math.sin((i * 1.7 + j * 2.3) * 1.9) * 3.4
            py += math.cos((i * 2.1 + j * 1.3) * 1.7) * 3.0
        return (px, py)

    line = (1.0, 1.0, 1.0, 0.20)
    for j in range(rows + 1):
        for i in range(cols):
            _seg(shader, point(i, j), point(i + 1, j), 1.1, line, scale)
    for i in range(cols + 1):
        for j in range(rows):
            _seg(shader, point(i, j), point(i, j + 1), 1.1, line, scale)

    _ring(shader, front, oy + gh * 0.5, 13.0, 1.6, _ac(1.0),
          scale)
    _ring(shader, front, oy + gh * 0.5, 13.0, 26.0,
          _ac(0.10), scale, steps=10)


def _checker(shader, p0, p1, p2, p3, n, alpha, scale):
    """A checkerboard laid inside any four-cornered patch."""
    for i in range(n):
        for j in range(n):
            if (i + j) % 2:
                continue
            a = _lerp(_lerp(p0, p1, i / n), _lerp(p3, p2, i / n), j / n)
            b = _lerp(_lerp(p0, p1, (i + 1) / n), _lerp(p3, p2, (i + 1) / n),
                      j / n)
            c = _lerp(_lerp(p0, p1, (i + 1) / n), _lerp(p3, p2, (i + 1) / n),
                      (j + 1) / n)
            d = _lerp(_lerp(p0, p1, i / n), _lerp(p3, p2, i / n), (j + 1) / n)
            _quad(shader, a, b, c, d, _ac(alpha), scale)


def _tip_uvkeep(shader, x, y, w, h, phase, scale):
    """The new mesh's islands landing where the old ones already were."""
    snap = abs(math.sin(phase * math.pi))
    box = min(w - 16.0, h - 12.0)
    ox = x + (w - box) * 0.5
    oy = y + (h - box) * 0.5
    spots = ((0.04, 0.52, 0.42, 0.42), (0.52, 0.52, 0.42, 0.42),
             (0.28, 0.06, 0.42, 0.40))
    stray = ((0.30, 0.30), (-0.22, 0.24), (0.16, -0.26))

    for (rx, ry, rw, rh), (dx, dy) in zip(spots, stray):
        # where the original UV already sits
        p0 = (ox + rx * box, oy + ry * box)
        p1 = (p0[0] + rw * box, p0[1])
        p2 = (p1[0], p0[1] + rh * box)
        p3 = (p0[0], p2[1])
        for i in range(4):
            _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.2,
                 (1.0, 1.0, 1.0, 0.18), scale)
        # and the new one, walking onto it
        ox2 = dx * box * (1.0 - snap)
        oy2 = dy * box * (1.0 - snap)
        q = [(pt[0] + ox2, pt[1] + oy2) for pt in (p0, p1, p2, p3)]
        _quad(shader, q[0], q[1], q[2], q[3],
              _ac(0.10 + 0.12 * snap), scale)
        for i in range(4):
            _seg(shader, q[i], q[(i + 1) % 4], 1.4,
                 _ac(0.45 + 0.55 * snap), scale)


def _tip_seams(shader, x, y, w, h, phase, scale):
    """Where the UV was cut, said the way a modeller would show it.

    A square with two lines on it said nothing about where those lines came
    from. So this runs the unfolding backwards: the flat layout first, then it
    folds up into the model, and then the edges it was cut along light up on
    the folded thing. Those edges are the seams.
    """
    t = phase % 1.0
    shut = 0.0 if t < 0.28 else min(1.0, (t - 0.28) / 0.34)
    shut = shut * shut * (3.0 - 2.0 * shut)
    glow = 0.0 if t < 0.66 else min(1.0, (t - 0.66) / 0.24)
    faces = _cube_and_net(x, y, w, h)

    for start, end in faces:
        corner = [_lerp(end[i], start[i], shut) for i in range(4)]
        _quad(shader, corner[0], corner[1], corner[2], corner[3], CONTROL,
              scale)
        edge = _ac(0.16 + 0.20 * (1.0 - shut) + 0.64 * glow)
        for i in range(4):
            _seg(shader, corner[i], corner[(i + 1) % 4], 1.3 + 1.2 * glow,
                 edge, scale)
        line = (1.0, 1.0, 1.0, 0.14)
        for i in (1, 2):
            f = i / 3.0
            _seg(shader, _lerp(corner[0], corner[1], f),
                 _lerp(corner[3], corner[2], f), 1.0, line, scale)
            _seg(shader, _lerp(corner[0], corner[3], f),
                 _lerp(corner[1], corner[2], f), 1.0, line, scale)


def _tip_bake(shader, x, y, w, h, phase, scale):
    """The original's surface carried onto the remesh."""
    t = phase % 1.0
    take = min(1.0, max(0.0, (t - 0.30) / 0.40))
    side = min((w - 40.0) * 0.5, h - 20.0)
    oy = y + (h - side) * 0.5
    lx = x + (w - side * 2.0 - 20.0) * 0.5
    rx = lx + side + 20.0

    def square(px, cells, checker):
        p0 = (px, oy)
        p1 = (px + side, oy)
        p2 = (px + side, oy + side)
        p3 = (px, oy + side)
        _quad(shader, p0, p1, p2, p3, (1.0, 1.0, 1.0, 0.055), scale)
        if checker > 0.01:
            _checker(shader, p0, p1, p2, p3, 4, 0.55 * checker, scale)
        line = (1.0, 1.0, 1.0, 0.18)
        for i in range(1, cells):
            f = i / cells
            _seg(shader, _lerp(p0, p1, f), _lerp(p3, p2, f), 1.0, line, scale)
            _seg(shader, _lerp(p0, p3, f), _lerp(p1, p2, f), 1.0, line, scale)
        for i in range(4):
            _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.3,
                 (1.0, 1.0, 1.0, 0.20), scale)

    square(lx, 7, 1.0)
    square(rx, 3, take)
    # the hand-off
    ax = lx + side + 5.0
    bx = rx - 5.0
    ay = oy + side * 0.5
    _seg(shader, (ax, ay), (bx, ay), 1.6, _ac(1.0), scale)
    _quad(shader, (bx, ay), (bx - 5.0, ay + 4.0), (bx - 5.0, ay - 4.0),
          (bx - 5.0, ay - 4.0), _ac(1.0), scale)


def _tip_pbr(shader, x, y, w, h, phase, scale):
    """One map, or the whole set of them."""
    lift = abs(math.sin(phase * math.pi))
    side = min(w * 0.42, h - 26.0)
    cx = x + w * 0.5
    cy = y + (h - side) * 0.5
    for k in range(3):
        off = k * 9.0 * lift
        px = cx - side * 0.5 - off * 0.6
        py = cy + off
        _quad(shader, (px, py), (px + side, py), (px + side, py + side),
              (px, py + side),
              (1.0, 1.0, 1.0, 0.05 + 0.03 * (2 - k)), scale)
        for i in range(4):
            a = ((px, py), (px + side, py), (px + side, py + side),
                 (px, py + side))[i]
            b = ((px + side, py), (px + side, py + side), (px, py + side),
                 (px, py))[i]
            _seg(shader, a, b, 1.2,
                 _ac(0.9 if k == 0 else 0.35), scale)


def _tip_gpu(shader, x, y, w, h, phase, scale):
    """The same bake, on the card and on the processor."""
    t = phase % 1.0
    fast = min(1.0, t * 2.4)
    slow = min(1.0, t * 0.85)
    bw = w - 24.0
    bx = x + 12.0
    for k, (frac, color) in enumerate(((fast, _ac(1.0)),
                                       (slow, (1.0, 1.0, 1.0, 0.22)))):
        by = y + h * (0.62 - k * 0.30)
        _fill(shader, bx * scale, by * scale, bw * scale, 9.0 * scale,
              4.5 * scale, (1.0, 1.0, 1.0, 0.10))
        _fill(shader, bx * scale, by * scale, bw * frac * scale, 9.0 * scale,
              4.5 * scale, color)


def _tip_sharp(shader, x, y, w, h, phase, scale):
    """A solid whose hard edges light up, and whose shading breaks on them.

    Sharp is not a line you draw on a model, it is a break in the shading: the
    two faces stop blending into each other. So the drawing shows the same
    solid twice over - soft, with the faces all one wash, then hard, with each
    face on its own tone and the edges between them lit.
    """
    on = abs(math.sin(phase * math.pi))
    side = min((w - 26.0) * 0.42, (h - 20.0) * 0.55)
    ux, uy = 0.866 * side, -0.5 * side
    vx, vy = -0.866 * side, -0.5 * side
    ax = x + w * 0.5
    ay = y + h * 0.5 + side * 0.92

    def at(du, dv, dd):
        return (ax + ux * du + vx * dv, ay + uy * du + vy * dv - side * dd)

    top = (at(0, 0, 0), at(1, 0, 0), at(1, 1, 0), at(0, 1, 0))
    right = (at(1, 0, 0), at(1, 0, 1), at(1, 1, 1), at(1, 1, 0))
    front = (at(0, 1, 0), at(1, 1, 0), at(1, 1, 1), at(0, 1, 1))

    # soft: one wash over all three. hard: each face its own tone.
    soft = 0.10
    for face, tone in ((top, 0.20), (front, 0.11), (right, 0.05)):
        v = soft + (tone - soft) * on
        _quad(shader, face[0], face[1], face[2], face[3],
              (1.0, 1.0, 1.0, v), scale)

    # the outline is always there, faint - it is the silhouette, not a mark
    for face in (top, right, front):
        for i in range(4):
            _seg(shader, face[i], face[(i + 1) % 4], 1.1,
                 (1.0, 1.0, 1.0, 0.16), scale)

    # the three edges where the faces meet: these are the sharp ones
    glow = _ac(0.12 + 0.88 * on)
    for a, b in ((at(0, 1, 0), at(1, 1, 0)),
                 (at(1, 1, 0), at(1, 0, 0)),
                 (at(1, 1, 0), at(1, 1, 1))):
        _seg(shader, a, b, 1.3 + 1.6 * on, glow, scale)


def _tip_unbake(shader, x, y, w, h, phase, scale):
    """The baked skin lifted straight off the model and let go.

    A wipe read as nothing much - it was the same square either way. This is
    the skin itself coming away: it peels up off the surface as one sheet,
    tilts as it goes, and thins out to nothing, leaving the bare model behind
    it. One object, one thing happening to it, and nothing it shares with the
    Bake drawing.
    """
    t = phase % 1.0
    lift = min(1.0, max(0.0, (t - 0.08) / 0.72))
    lift = lift * lift * (3.0 - 2.0 * lift)          # ease in and out

    side = min(w * 0.48, h - 30.0)
    ox = x + w * 0.30 - side * 0.5
    oy = y + (h - side) * 0.5 - 6.0
    p0 = (ox, oy)
    p1 = (ox + side, oy)
    p2 = (ox + side, oy + side)
    p3 = (ox, oy + side)

    # the model, always there under it
    _quad(shader, p0, p1, p2, p3, (1.0, 1.0, 1.0, 0.055), scale)
    line = (1.0, 1.0, 1.0, 0.18)
    for k in range(1, 4):
        f = k / 4.0
        _seg(shader, _lerp(p0, p1, f), _lerp(p3, p2, f), 1.0, line, scale)
        _seg(shader, _lerp(p0, p3, f), _lerp(p1, p2, f), 1.0, line, scale)
    for k in range(4):
        _seg(shader, (p0, p1, p2, p3)[k], (p1, p2, p3, p0)[k], 1.3,
             (1.0, 1.0, 1.0, 0.22), scale)

    # the baked skin, coming off it
    fade = 1.0 - min(1.0, max(0.0, (lift - 0.45) / 0.55))
    if fade <= 0.01:
        return
    dx = side * 0.72 * lift
    dy = side * 0.22 * lift
    lean = side * 0.20 * lift            # the far edge runs ahead: it tilts
    shrink = 1.0 - 0.18 * lift

    def moved(pt, extra):
        cx = ox + side * 0.5
        cy = oy + side * 0.5
        return (cx + (pt[0] - cx) * shrink + dx + extra,
                cy + (pt[1] - cy) * shrink + dy)

    s0 = moved(p0, 0.0)
    s1 = moved(p1, 0.0)
    s2 = moved(p2, lean)
    s3 = moved(p3, lean)
    _checker(shader, s0, s1, s2, s3, 4, 0.55 * fade, scale)
    edge = _ac(0.30 + 0.55 * fade)
    for k in range(4):
        _seg(shader, (s0, s1, s2, s3)[k], (s1, s2, s3, s0)[k], 1.4, edge,
             scale)


def _tip_purequad(shader, x, y, w, h, phase, scale):
    """A patch that still has triangles in it, and the same patch without.

    Quad-dominant means "quads where it can, triangles where it cannot". Pure
    quads means there is no triangle left anywhere - so the drawing is one
    piece of mesh with the diagonals showing, and then the same piece with
    them gone.
    """
    on = abs(math.sin(phase * math.pi))
    cols, rows = 4, 3
    cw = (w - 20.0) / cols
    ch = min((h - 22.0) / rows, cw)
    ox = x + (w - cw * cols) * 0.5
    oy = y + (h - ch * rows) * 0.5

    def pt(i, j):
        return (ox + i * cw, oy + j * ch)

    # the faces, tinted as they come good
    _quad(shader, pt(0, 0), pt(cols, 0), pt(cols, rows), pt(0, rows),
          _ac(0.04 + 0.10 * on), scale)

    line = (1.0, 1.0, 1.0, 0.22)
    for i in range(cols + 1):
        _seg(shader, pt(i, 0), pt(i, rows), 1.1, line, scale)
    for j in range(rows + 1):
        _seg(shader, pt(0, j), pt(cols, j), 1.1, line, scale)

    # the diagonals are the triangles. They are what "pure quads" removes.
    gone = (1.0, 0.45, 0.35, 0.85 * (1.0 - on))
    if 1.0 - on > 0.02:
        for i, j in ((0, 2), (2, 1), (3, 0)):
            _seg(shader, pt(i, j), pt(i + 1, j + 1), 1.5, gone, scale)


def _tip_reproject(shader, x, y, w, h, phase, scale):
    """The new mesh pulled back down onto the shape it came from.

    A remesher builds an even lattice first and only then asks where the old
    surface actually was. Each step drags the new points back onto it, so a
    low count leaves the result floating over the detail and a high one hugs
    it - at the price of the flow being smoothed as it goes.
    """
    steps = 4
    k = min(1.0, (phase % 1.0) / 0.85)
    k = math.floor(k * steps) / float(steps)      # it moves in steps, not flow

    x0 = x + 12.0
    x1 = x + w - 12.0
    mid = y + h * 0.5
    amp = min(h * 0.24, 22.0)

    def surf(u):
        return (x0 + (x1 - x0) * u,
                mid + math.sin(u * math.pi * 1.6 - 0.5) * amp)

    def flat(u):
        return (x0 + (x1 - x0) * u, mid + amp * 0.55)

    # the original surface
    prev = None
    for i in range(41):
        pt = surf(i / 40.0)
        if prev is not None:
            _seg(shader, prev, pt, 1.4, (1.0, 1.0, 1.0, 0.28), scale)
        prev = pt

    # the new mesh, on its way back onto it
    pts = []
    for i in range(9):
        u = i / 8.0
        a = flat(u)
        b = surf(u)
        pts.append((a[0], a[1] + (b[1] - a[1]) * k))

    if k < 0.999:
        for i, pt in enumerate(pts):
            b = surf(i / 8.0)
            _seg(shader, pt, b, 1.0, (1.0, 1.0, 1.0, 0.16), scale)

    for i in range(len(pts) - 1):
        _seg(shader, pts[i], pts[i + 1], 1.8, _ac(1.0), scale)
    for pt in pts:
        _fill(shader, (pt[0] - 2.0) * scale, (pt[1] - 2.0) * scale,
              4.0 * scale, 4.0 * scale, 2.0 * scale, _ac(1.0))


def _tip_accent(shader, x, y, w, h, phase, scale):
    """The same card, wearing a different colour."""
    t = phase % 1.0
    hue = t
    band = min(h - 34.0, 16.0)
    bw = w - 24.0
    bx = x + 12.0
    by = y + h - band - 10.0
    steps = 30
    step = bw / float(steps)
    for i in range(steps):
        _fill(shader, (bx + i * step) * scale, by * scale,
              (step + 0.8) * scale, band * scale, 0.0,
              accent_rgb(i / (steps - 1.0), 0.92) + (1.0,))
    kx = bx + bw * hue
    _fill(shader, (kx - 6.0) * scale, (by - 3.0) * scale, 12.0 * scale,
          (band + 6.0) * scale, 6.0 * scale, KNOB)

    # and what it is doing: a control, in whatever colour is under the knob
    col = accent_rgb(hue, 0.92) + (1.0,)
    ry = y + 8.0
    rh = min(h - band - 30.0, 22.0)
    _fill(shader, bx * scale, ry * scale, (bw * 0.52) * scale, rh * scale,
          8.0 * scale, col)
    _fill(shader, (bx + bw * 0.58) * scale, (ry + rh * 0.5 - 4.0) * scale,
          (bw * 0.42) * scale, 8.0 * scale, 4.0 * scale, col)


def _tip_corner(shader, x, y, w, h, phase, scale):
    """The same three controls, from square to fully rounded."""
    f = abs(math.sin(phase * math.pi))
    bw = w - 40.0
    bx = x + 20.0
    for k, (bh, col) in enumerate(((22.0, _ac(1.0)),
                                   (18.0, CONTROL_HOVER),
                                   (18.0, CONTROL))):
        by = y + h - 16.0 - k * 26.0
        _fill(shader, bx * scale, by * scale, bw * scale, bh * scale,
              (bh * 0.5) * f * scale, col)


def _patch(shader, x, y, w, h, cols, rows, scale, fill=None,
           line=(1.0, 1.0, 1.0, 0.18), border=(1.0, 1.0, 1.0, 0.22)):
    """A rectangle with a grid ruled across it - the stand-in for a mesh."""
    p0 = (x, y)
    p1 = (x + w, y)
    p2 = (x + w, y + h)
    p3 = (x, y + h)
    if fill is not None:
        _quad(shader, p0, p1, p2, p3, fill, scale)
    for i in range(1, cols):
        f = i / float(cols)
        _seg(shader, _lerp(p0, p1, f), _lerp(p3, p2, f), 1.0, line, scale)
    for j in range(1, rows):
        f = j / float(rows)
        _seg(shader, _lerp(p0, p3, f), _lerp(p1, p2, f), 1.0, line, scale)
    for i in range(4):
        _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.3, border,
             scale)


def _dot(shader, px, py, r, color, scale):
    _fill(shader, (px - r) * scale, (py - r) * scale, r * 2.0 * scale,
          r * 2.0 * scale, r * scale, color)


def _arc(shader, cx, cy, r, a0, a1, width, color, scale, steps=16):
    prev = None
    for i in range(steps + 1):
        a = a0 + (a1 - a0) * i / steps
        pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
        if prev is not None:
            _seg(shader, prev, pt, width, color, scale)
        prev = pt


def _box_edges(shader, ox, oy, pw, ph, scale, color=(1.0, 1.0, 1.0, 0.22)):
    c = ((ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph))
    for i in range(4):
        _seg(shader, c[i], c[(i + 1) % 4], 1.3, color, scale)


def _tip_remesh(shader, x, y, w, h, phase, scale):
    """Uneven mesh, then the same shape carried on even quads."""
    t = phase % 1.0
    done = min(1.0, max(0.0, (t - 0.15) / 0.55))
    side = min((w - 60.0) * 0.5, h - 20.0)
    oy = y + (h - side) * 0.5
    lx = x + (w - side * 2.0 - 18.0) * 0.5
    rx = lx + side + 18.0

    _quad(shader, (lx, oy), (lx + side, oy), (lx + side, oy + side),
          (lx, oy + side), (1.0, 1.0, 1.0, 0.05), scale)
    rows = ((0.0, 0.34, 3), (0.34, 0.62, 5), (0.62, 1.0, 2))
    for a, b, n in rows:
        ya = oy + side * a
        yb = oy + side * b
        _seg(shader, (lx, ya), (lx + side, ya), 1.0, (1.0, 1.0, 1.0, 0.20),
             scale)
        for k in range(1, n):
            f = k / float(n)
            _seg(shader, (lx + side * f, ya),
                 (lx + side * min(1.0, f + 0.10), yb), 1.0,
                 (1.0, 1.0, 1.0, 0.20), scale)
    _box_edges(shader, lx, oy, side, side, scale)

    if done > 0.02:
        _patch(shader, rx, oy, side, side, 4, 4, scale,
               fill=_ac(0.05 + 0.07 * done),
               line=(1.0, 1.0, 1.0, 0.18 * done),
               border=_ac(0.30 + 0.60 * done))
    ay = oy + side * 0.5
    _seg(shader, (lx + side + 4.0, ay), (rx - 4.0, ay), 1.6, _ac(0.9), scale)


def _tip_hardsurface(shader, x, y, w, h, phase, scale):
    """A panelled shape, re-ruled so the quads run along its own edges."""
    t = phase % 1.0
    snap = min(1.0, max(0.0, (t - 0.20) / 0.50))
    side = min(w - 30.0, h - 20.0)
    ox = x + (w - side) * 0.5
    oy = y + (h - side) * 0.5
    cut = side * 0.38

    poly = ((ox, oy), (ox + side, oy), (ox + side, oy + side - cut),
            (ox + side - cut, oy + side - cut), (ox + side - cut, oy + side),
            (ox, oy + side))
    _quad(shader, poly[0], poly[1], poly[2], poly[5], (1.0, 1.0, 1.0, 0.05),
          scale)
    _quad(shader, poly[5], poly[2], poly[3], poly[4], (1.0, 1.0, 1.0, 0.05),
          scale)

    n = 4
    sk = (1.0 - snap) * side * 0.22
    for i in range(1, n):
        f = i / float(n)
        _seg(shader, (ox + side * f + sk, oy),
             (ox + side * f - sk, oy + side), 1.0,
             (1.0, 1.0, 1.0, 0.16 + 0.10 * snap), scale)
        _seg(shader, (ox, oy + side * f - sk),
             (ox + side, oy + side * f + sk), 1.0,
             (1.0, 1.0, 1.0, 0.16 + 0.10 * snap), scale)

    for i in range(len(poly)):
        _seg(shader, poly[i], poly[(i + 1) % len(poly)], 1.5,
             _ac(0.35 + 0.65 * snap), scale)


def _tip_crease(shader, x, y, w, h, phase, scale):
    """Two faces meeting, and the angle between them being measured."""
    t = phase % 1.0
    ang = math.radians(20.0 + 130.0 * abs(math.sin(t * math.pi)))
    cx = x + w * 0.5
    cy = y + h * 0.40
    L = min(w * 0.34, h * 0.50)
    a = (cx - L, cy)
    b = (cx + math.cos(math.pi - ang) * L, cy + math.sin(math.pi - ang) * L)
    hot = ang > math.radians(75.0)
    _seg(shader, a, (cx, cy), 2.0, (1.0, 1.0, 1.0, 0.30), scale)
    _seg(shader, (cx, cy), b, 2.0, (1.0, 1.0, 1.0, 0.30), scale)
    _arc(shader, cx, cy, L * 0.34, math.pi, math.pi - ang, 1.2,
         (1.0, 1.0, 1.0, 0.22), scale)
    if hot:
        _dot(shader, cx, cy, 7.0, _ac(0.20), scale)
    _dot(shader, cx, cy, 3.5 if hot else 2.2,
         _ac(1.0) if hot else (1.0, 1.0, 1.0, 0.35), scale)


def _tip_calibrate(shader, x, y, w, h, phase, scale):
    """Asked for a count, missed it, measured, and came back onto it."""
    t = phase % 1.0
    x0 = x + 16.0
    x1 = x + w - 16.0
    tx = x0 + (x1 - x0) * 0.55
    ty = y + h * 0.5
    _seg(shader, (x0, ty), (x1, ty), 1.2, (1.0, 1.0, 1.0, 0.20), scale)
    _seg(shader, (tx, ty - 9.0), (tx, ty + 9.0), 1.6, (1.0, 1.0, 1.0, 0.45),
         scale)
    if t < 0.30:
        px = x0 + (x1 - x0) * (t / 0.30)
    elif t < 0.55:
        px = x1
    elif t < 0.82:
        f = (t - 0.55) / 0.27
        px = x1 + (tx - x1) * f
    else:
        px = tx
    _dot(shader, px, ty, 5.0, _ac(1.0), scale)


def _tip_search(shader, x, y, w, h, phase, scale):
    """Several settings tried, and the one that came out best kept."""
    t = phase % 1.0
    n = 3
    gap = 8.0
    pw = (w - 24.0 - gap * (n - 1)) / n
    ph = min(h - 24.0, pw)
    oy = y + (h - ph) * 0.5
    ox = x + 12.0
    tried = min(n, int(t / 0.22))
    best = 1
    picked = t > 0.62
    for k in range(n):
        px = ox + k * (pw + gap)
        show = k < tried
        win = picked and k == best
        _patch(shader, px, oy, pw, ph, 2 + k, 2 + k, scale,
               fill=_ac(0.14) if win else (1.0, 1.0, 1.0,
                                           0.05 if show else 0.02),
               line=(1.0, 1.0, 1.0, 0.18 if show else 0.0),
               border=_ac(1.0) if win else (1.0, 1.0, 1.0,
                                            0.20 if show else 0.08))


def _tip_autothresh(shader, x, y, w, h, phase, scale):
    """The numbers found for you instead of dialled in by hand."""
    t = phase % 1.0
    bw = w - 36.0
    bx = x + 18.0
    for k, target in enumerate((0.62, 0.34)):
        by = y + h * (0.58 - k * 0.24)
        _fill(shader, bx * scale, by * scale, bw * scale, 5.0 * scale,
              2.5 * scale, (1.0, 1.0, 1.0, 0.14))
        f = min(1.0, max(0.0, (t - 0.10 - k * 0.14) / 0.45)) * target
        _fill(shader, bx * scale, by * scale, bw * f * scale, 5.0 * scale,
              2.5 * scale, _ac(1.0))
        _dot(shader, bx + bw * f, by + 2.5, 6.0, KNOB, scale)


def _tip_weldlines(shader, x, y, w, h, phase, scale):
    """Two lines almost on top of each other, made into one."""
    t = phase % 1.0
    close = min(1.0, max(0.0, (t - 0.15) / 0.55))
    x0 = x + 16.0
    x1 = x + w - 16.0
    cy = y + h * 0.5
    d = 9.0 * (1.0 - close)
    for s in (1.0, -1.0):
        prev = None
        for i in range(25):
            u = i / 24.0
            pt = (x0 + (x1 - x0) * u, cy + s * d + math.sin(u * 5.0) * 4.0)
            if prev is not None:
                _seg(shader, prev, pt, 1.6,
                     _ac(0.35 + 0.65 * close) if close > 0.75
                     else (1.0, 1.0, 1.0, 0.45),
                     scale)
            prev = pt
    if close < 0.98:
        for u in (0.2, 0.5, 0.8):
            px = x0 + (x1 - x0) * u
            py = cy + math.sin(u * 5.0) * 4.0
            _seg(shader, (px, py - d), (px, py + d), 1.0,
                 (1.0, 1.0, 1.0, 0.18), scale)


def _tip_straightloop(shader, x, y, w, h, phase, scale):
    """Loops that cross flat ground and say nothing, taken out."""
    keep = abs(math.sin(phase * math.pi))
    pw = w - 28.0
    ph = min(h - 24.0, 52.0)
    ox = x + 14.0
    oy = y + (h - ph) * 0.5
    _quad(shader, (ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph),
          (1.0, 1.0, 1.0, 0.05), scale)
    for i in range(1, 8):
        f = i / 8.0
        extra = i % 2 == 1
        if extra:
            col = _ac(0.60 * keep)
        else:
            col = (1.0, 1.0, 1.0, 0.20)
        _seg(shader, (ox + pw * f, oy), (ox + pw * f, oy + ph), 1.1, col,
             scale)
    _box_edges(shader, ox, oy, pw, ph, scale)


def _tip_minlen(shader, x, y, w, h, phase, scale):
    """Stubs too short to be worth a line, dropped."""
    keep = abs(math.sin(phase * math.pi))
    x0 = x + 16.0
    span = w - 32.0
    lens = (1.0, 0.18, 0.72, 0.10, 0.55, 0.24)
    n = len(lens)
    for i, L in enumerate(lens):
        ly = y + h - 14.0 - i * ((h - 26.0) / float(n - 1))
        short = L < 0.30
        a = 0.55 if not short else 0.55 * keep
        _seg(shader, (x0, ly), (x0 + span * L, ly), 2.0,
             _ac(a) if short else (1.0, 1.0, 1.0, a), scale)


def _tip_circle(shader, x, y, w, h, phase, scale):
    """A ring that came out of the mesh as a polygon, put back on a circle."""
    r = min(w, h) * 0.30
    cx = x + w * 0.5
    cy = y + h * 0.5
    round_ = abs(math.sin(phase * math.pi))
    n = 7
    _arc(shader, cx, cy, r, 0.0, 2.0 * math.pi, 1.0, (1.0, 1.0, 1.0, 0.16),
         scale, steps=30)
    prev = None
    for i in range(n + 1):
        a = 2.0 * math.pi * i / n
        rr = r * (1.0 - 0.18 * (1.0 - round_) * abs(math.cos(a * 1.5)))
        pt = (cx + math.cos(a) * rr, cy + math.sin(a) * rr)
        if prev is not None:
            _seg(shader, prev, pt, 1.8, _ac(0.35 + 0.65 * round_), scale)
        prev = pt


def _tip_typed(shader, x, y, w, h, phase, scale):
    """A straight border kept straight, a curved one kept curved."""
    on = abs(math.sin(phase * math.pi))
    x0 = x + 16.0
    x1 = x + w - 16.0
    top = y + h * 0.72
    bot = y + h * 0.28
    _seg(shader, (x0, top), (x1, top), 2.0, _ac(0.25 + 0.75 * on), scale)
    prev = None
    for i in range(25):
        u = i / 24.0
        pt = (x0 + (x1 - x0) * u, bot + math.sin(u * math.pi) * 16.0)
        if prev is not None:
            _seg(shader, prev, pt, 2.0, _ac(0.25 + 0.75 * on), scale)
        prev = pt
    for ys in (top, bot):
        prev = None
        for i in range(13):
            u = i / 12.0
            base = ys + (math.sin(u * math.pi) * 16.0 if ys == bot else 0.0)
            pt = (x0 + (x1 - x0) * u, base + math.sin(u * 9.0) * 3.0
                  * (1.0 - on))
            if prev is not None:
                _seg(shader, prev, pt, 1.0,
                     (1.0, 1.0, 1.0, 0.18 * (1.0 - on)), scale)
            prev = pt


def _tip_gap(shader, x, y, w, h, phase, scale):
    """A line that stops short, carried across to the one facing it."""
    t = phase % 1.0
    grow = min(1.0, max(0.0, (t - 0.20) / 0.50))
    cy = y + h * 0.5
    x0 = x + 14.0
    x1 = x + w - 14.0
    ga = x0 + (x1 - x0) * 0.30
    gb = x0 + (x1 - x0) * 0.74
    _seg(shader, (x0, cy), (ga, cy), 2.0, (1.0, 1.0, 1.0, 0.40), scale)
    _seg(shader, (gb, cy), (x1, cy), 2.0, (1.0, 1.0, 1.0, 0.40), scale)
    _dot(shader, ga, cy, 2.6, (1.0, 1.0, 1.0, 0.55), scale)
    _dot(shader, gb, cy, 2.6, (1.0, 1.0, 1.0, 0.55), scale)
    if grow > 0.01:
        _seg(shader, (ga, cy), (ga + (gb - ga) * grow, cy), 3.2, _ac(1.0),
             scale)
        _dot(shader, ga + (gb - ga) * grow, cy, 3.0, _ac(1.0), scale)



def _tip_mirror(shader, x, y, w, h, phase, scale):
    """One side built, the other side taken from it."""
    t = phase % 1.0
    over = min(1.0, max(0.0, (t - 0.20) / 0.50))
    side = min(w * 0.36, h - 22.0)
    cx = x + w * 0.5
    oy = y + (h - side) * 0.5
    _patch(shader, cx - side - 6.0, oy, side, side, 3, 3, scale,
           fill=_ac(0.10), border=_ac(0.85))
    _seg(shader, (cx, oy - 8.0), (cx, oy + side + 8.0), 1.2,
         (1.0, 1.0, 1.0, 0.30), scale)
    if over > 0.02:
        _patch(shader, cx + 6.0, oy, side * over, side, 3, 3, scale,
               fill=_ac(0.10 * over), border=_ac(0.85 * over))







def _tip_marked(shader, x, y, w, h, phase, scale):
    """The lines it found, and the lines you drew, on the same model."""
    only = abs(math.sin(phase * math.pi))
    pw = w - 28.0
    ph = min(h - 24.0, 56.0)
    ox = x + 14.0
    oy = y + (h - ph) * 0.5
    _quad(shader, (ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph),
          (1.0, 1.0, 1.0, 0.05), scale)
    found = (1.0, 1.0, 1.0, 0.32 * (1.0 - only))
    for f in (0.22, 0.50, 0.78):
        _seg(shader, (ox + pw * f, oy), (ox + pw * f, oy + ph), 1.3, found,
             scale)
    _seg(shader, (ox, oy + ph * 0.55), (ox + pw, oy + ph * 0.55), 1.3, found,
         scale)
    _seg(shader, (ox + pw * 0.12, oy + ph * 0.20),
         (ox + pw * 0.88, oy + ph * 0.80), 2.0, _ac(1.0), scale)
    _box_edges(shader, ox, oy, pw, ph, scale)


def _tip_clean(shader, x, y, w, h, phase, scale):
    """A knotted patch taken out and laid again as plain rows."""
    t = phase % 1.0
    fixed = min(1.0, max(0.0, (t - 0.20) / 0.50))
    pw = w - 28.0
    ph = min(h - 24.0, 56.0)
    ox = x + 14.0
    oy = y + (h - ph) * 0.5
    _quad(shader, (ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph),
          (1.0, 1.0, 1.0, 0.05), scale)
    mess = (1.0, 0.45, 0.35, 0.55 * (1.0 - fixed))
    if fixed < 0.98:
        knots = (((0.18, 0.10), (0.44, 0.86)), ((0.30, 0.90), (0.62, 0.14)),
                 ((0.12, 0.55), (0.78, 0.42)), ((0.55, 0.08), (0.86, 0.72)))
        for a, b in knots:
            _seg(shader, (ox + pw * a[0], oy + ph * a[1]),
                 (ox + pw * b[0], oy + ph * b[1]), 1.4, mess, scale)
    if fixed > 0.02:
        for i in range(1, 5):
            f = i / 5.0
            _seg(shader, (ox + pw * f, oy), (ox + pw * f, oy + ph), 1.1,
                 _ac(0.55 * fixed), scale)
        for j in range(1, 3):
            f = j / 3.0
            _seg(shader, (ox, oy + ph * f), (ox + pw, oy + ph * f), 1.1,
                 _ac(0.55 * fixed), scale)
    _box_edges(shader, ox, oy, pw, ph, scale)


def _tip_confine(shader, x, y, w, h, phase, scale):
    """The tidying stops at the line and does not run past it."""
    t = phase % 1.0
    grow = min(1.0, max(0.0, (t - 0.15) / 0.55))
    pw = w - 28.0
    ph = min(h - 24.0, 56.0)
    ox = x + 14.0
    oy = y + (h - ph) * 0.5
    bound = ox + pw * 0.62
    _quad(shader, (ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph),
          (1.0, 1.0, 1.0, 0.05), scale)
    _quad(shader, (ox, oy), (ox + pw * 0.62 * grow, oy),
          (ox + pw * 0.62 * grow, oy + ph), (ox, oy + ph), _ac(0.16), scale)
    _seg(shader, (bound, oy - 6.0), (bound, oy + ph + 6.0), 2.0, _ac(1.0),
         scale)
    _box_edges(shader, ox, oy, pw, ph, scale)


def _tip_useless(shader, x, y, w, h, phase, scale):
    """Loops on flat ground go, loops that hold a curve stay."""
    keep = abs(math.sin(phase * math.pi))
    x0 = x + 14.0
    x1 = x + w - 14.0
    base = y + h * 0.40

    def prof(u):
        if u < 0.5:
            return base
        return base + math.sin((u - 0.5) * math.pi * 2.0) * 20.0

    prev = None
    for i in range(41):
        u = i / 40.0
        pt = (x0 + (x1 - x0) * u, prof(u))
        if prev is not None:
            _seg(shader, prev, pt, 1.6, (1.0, 1.0, 1.0, 0.35), scale)
        prev = pt
    for i in range(1, 12):
        u = i / 12.0
        px = x0 + (x1 - x0) * u
        py = prof(u)
        flat = u < 0.5
        a = 0.55 if not flat else 0.55 * keep
        _seg(shader, (px, py - 9.0), (px, py + 9.0), 1.4,
             _ac(a) if flat else (1.0, 1.0, 1.0, a), scale)


def _tip_every(shader, x, y, w, h, phase, scale):
    """One loop out of every few kept, the rest let go."""
    keep = abs(math.sin(phase * math.pi))
    x0 = x + 14.0
    span = w - 28.0
    cy = y + h * 0.5
    n = 10
    for i in range(n):
        px = x0 + span * i / float(n - 1)
        stay = i % 3 == 0
        a = 0.60 if stay else 0.60 * (1.0 - keep)
        _seg(shader, (px, cy - 16.0), (px, cy + 16.0), 1.8,
             _ac(a) if stay else (1.0, 1.0, 1.0, a), scale)


def _tip_reset(shader, x, y, w, h, phase, scale):
    """Everything the add-on put on the model, taken back off."""
    t = phase % 1.0
    wipe = min(1.0, max(0.0, (t - 0.15) / 0.55))
    pw = w - 28.0
    ph = min(h - 24.0, 56.0)
    ox = x + 14.0
    oy = y + (h - ph) * 0.5
    _quad(shader, (ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph),
          (1.0, 1.0, 1.0, 0.05), scale)
    left = 1.0 - wipe
    for i in range(1, 6):
        f = i / 6.0
        if f > left:
            continue
        _seg(shader, (ox + pw * f, oy), (ox + pw * f, oy + ph), 1.4,
             _ac(0.75), scale)
    _seg(shader, (ox + pw * left, oy - 5.0), (ox + pw * left, oy + ph + 5.0),
         1.6, (1.0, 1.0, 1.0, 0.30), scale)
    _box_edges(shader, ox, oy, pw, ph, scale)


def _tip_merge(shader, x, y, w, h, phase, scale):
    """Points closer together than the distance, made into one."""
    t = phase % 1.0
    close = min(1.0, max(0.0, (t - 0.15) / 0.55))
    cx = x + w * 0.5
    cy = y + h * 0.5
    r = min(w, h) * 0.22
    _arc(shader, cx, cy, r, 0.0, 2.0 * math.pi, 1.0, (1.0, 1.0, 1.0, 0.20),
         scale, steps=28)
    if close > 0.9:
        _dot(shader, cx, cy, 6.0, _ac(0.25), scale)
    for dx, dy in ((-0.75, 0.35), (0.62, 0.58), (0.30, -0.70),
                   (-0.55, -0.45)):
        _dot(shader, cx + dx * r * (1.0 - close),
             cy + dy * r * (1.0 - close), 3.2, _ac(1.0), scale)


def _tip_confirm(shader, x, y, w, h, phase, scale):
    """The result kept, and carried on with as the model."""
    t = phase % 1.0
    tick = min(1.0, max(0.0, (t - 0.25) / 0.45))
    side = min(w - 40.0, h - 22.0)
    ox = x + (w - side) * 0.5
    oy = y + (h - side) * 0.5
    _patch(shader, ox, oy, side, side, 4, 4, scale, fill=_ac(0.08),
           border=_ac(0.55))
    # a tick, drawn on
    a = (ox + side * 0.22, oy + side * 0.52)
    b = (ox + side * 0.44, oy + side * 0.28)
    c = (ox + side * 0.82, oy + side * 0.76)
    if tick > 0.0:
        f = min(1.0, tick / 0.4)
        _seg(shader, a, (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f),
             3.0, _ac(1.0), scale)
    if tick > 0.4:
        f = min(1.0, (tick - 0.4) / 0.6)
        _seg(shader, b, (b[0] + (c[0] - b[0]) * f, b[1] + (c[1] - b[1]) * f),
             3.0, _ac(1.0), scale)


def _tip_restore(shader, x, y, w, h, phase, scale):
    """The remesh set aside and the model you started with brought back."""
    t = phase % 1.0
    back = min(1.0, max(0.0, (t - 0.15) / 0.55))
    side = min(w * 0.40, h - 24.0)
    cx = x + w * 0.5
    oy = y + (h - side) * 0.5
    # the remesh, sliding out to the right and fading
    if back < 0.98:
        px = cx - side * 0.5 + side * 1.3 * back
        _patch(shader, px, oy, side, side, 4, 4, scale,
               fill=_ac(0.08 * (1.0 - back)),
               line=(1.0, 1.0, 1.0, 0.16 * (1.0 - back)),
               border=_ac(0.75 * (1.0 - back)))
    # the original, coming back in from the left
    if back > 0.02:
        px = cx - side * 0.5 - side * 1.3 * (1.0 - back)
        _patch(shader, px, oy, side, side, 2, 2, scale,
               fill=(1.0, 1.0, 1.0, 0.06 * back),
               line=(1.0, 1.0, 1.0, 0.20 * back),
               border=(1.0, 1.0, 1.0, 0.30 * back))


def _tip_valence(shader, x, y, w, h, phase, scale):
    """Stray points, spurs and pass-through vertices, cleared out.

    A vertex with fewer than three edges is not holding anything: a loose
    point holds nothing at all, a spur holds one edge that goes nowhere, and
    a point sitting between two edges is a bend in a line that could be one
    line. All three go.
    """
    gone = abs(math.sin(phase * math.pi))
    left = 1.0 - gone
    pw = w - 30.0
    ph = min(h - 26.0, 54.0)
    ox = x + 15.0
    oy = y + (h - ph) * 0.5

    _quad(shader, (ox, oy), (ox + pw, oy), (ox + pw, oy + ph), (ox, oy + ph),
          (1.0, 1.0, 1.0, 0.05), scale)
    line = (1.0, 1.0, 1.0, 0.22)
    for i in range(1, 3):
        f = i / 3.0
        _seg(shader, (ox + pw * f, oy), (ox + pw * f, oy + ph), 1.1, line,
             scale)
    _seg(shader, (ox, oy + ph * 0.5), (ox + pw, oy + ph * 0.5), 1.1, line,
         scale)
    _box_edges(shader, ox, oy, pw, ph, scale)

    # a point loose in the middle of nothing
    _dot(shader, ox + pw * 0.52, oy + ph * 0.78, 3.0, _ac(left), scale)
    # a spur: one edge hanging off the border and stopping
    sx = ox + pw * 0.33
    _seg(shader, (sx, oy), (sx, oy - 13.0), 1.8, _ac(left), scale)
    _dot(shader, sx, oy - 13.0, 3.0, _ac(left), scale)
    # and a point sitting between two edges, where one line would do
    _dot(shader, ox + pw * 0.667, oy + ph * 0.5, 3.0, _ac(left), scale)


# -- tutorial posters -------------------------------------------------------
#
# A play triangle says "there is a video". The video's own thumbnail says
# which video, which is the thing worth knowing before clicking. Posters live
# beside this file in assets/ and are loaded once: Blender decodes the file,
# the pixels are copied into a texture, and the image datablock is thrown away
# again so nothing is left behind in the user's .blend.

_POSTERS = {}


def _poster(name):
    """The named thumbnail as a texture, or None if it is not shipped."""
    if name in _POSTERS:
        return _POSTERS[name]
    tex = None
    folder = os.path.join(os.path.dirname(__file__), "assets")
    for ext in (".png", ".jpg", ".jpeg", ".webp"):
        path = os.path.join(folder, name + ext)
        if not os.path.exists(path):
            continue
        img = None
        try:
            img = bpy.data.images.load(path)
            # Read the file's own values, not a colour-managed version of
            # them: what is drawn here goes straight to the screen.
            img.colorspace_settings.name = "Non-Color"
            # Small, because the popup is small. A full thumbnail is two
            # million pixels to copy through Python for a 170 pixel picture.
            img.scale(384, 216)
            w, h = img.size
            buf = gpu.types.Buffer("FLOAT", w * h * 4, img.pixels[:])
            tex = gpu.types.GPUTexture((w, h), format="RGBA16F", data=buf)
        except Exception:
            tex = None
        finally:
            if img is not None:
                try:
                    bpy.data.images.remove(img)
                except Exception:
                    pass
        break
    _POSTERS[name] = tex
    return tex


def forget_posters():
    _POSTERS.clear()


def _draw_poster(tex, x, y, w, h, scale):
    """One textured rectangle. Leaves the shader unbound - the caller rebinds."""
    sh = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(sh, "TRI_FAN", {
        "pos": ((x * scale, y * scale), ((x + w) * scale, y * scale),
                ((x + w) * scale, (y + h) * scale),
                (x * scale, (y + h) * scale)),
        "texCoord": ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))})
    sh.bind()
    sh.uniform_sampler("image", tex)
    batch.draw(sh)


def _tip_watch_cloth(shader, x, y, w, h, phase, scale):
    """The cloth lesson's own thumbnail."""
    _tip_watch(shader, x, y, w, h, phase, scale, poster="tutorial_cloth")


def _tip_watch_hard(shader, x, y, w, h, phase, scale):
    """The hard surface lesson's own thumbnail."""
    _tip_watch(shader, x, y, w, h, phase, scale, poster="tutorial_hardsurface")


def _tip_watch(shader, x, y, w, h, phase, scale, poster="tutorial_overview"):
    """The tutorial's own thumbnail, with a play mark over it."""
    pulse = 0.5 + 0.5 * abs(math.sin(phase * math.pi))
    fw = min(w - 24.0, 160.0)
    fh = fw * 0.5625
    if fh > h - 16.0:
        fh = h - 16.0
        fw = fh / 0.5625
    ox = x + (w - fw) * 0.5
    oy = y + (h - fh) * 0.5

    tex = _poster(poster)
    if tex is not None:
        _draw_poster(tex, ox, oy, fw, fh, scale)
        shader.bind()                       # the tip carries on in flat colour
        # a soft scrim so the play mark reads over a bright frame
        _fill(shader, ox * scale, oy * scale, fw * scale, fh * scale, 0.0,
              (0.0, 0.0, 0.0, 0.12))
    else:
        # nothing shipped yet: the frame on its own
        _fill(shader, ox * scale, oy * scale, fw * scale, fh * scale,
              7.0 * scale, _ac(0.20 + 0.25 * pulse))
        _fill(shader, (ox + 1.5) * scale, (oy + 1.5) * scale,
              (fw - 3.0) * scale, (fh - 3.0) * scale, 6.0 * scale,
              (0.09, 0.09, 0.10, 1.0))

    side = fh * 0.24
    cx = ox + fw * 0.5
    cy = oy + fh * 0.5
    r = side * 0.92
    _fill(shader, (cx - r) * scale, (cy - r) * scale, r * 2.0 * scale,
          r * 2.0 * scale, r * scale, _ac(0.55 + 0.35 * pulse))
    bx = (cx - side * 0.28) * scale
    by = (cy - side * 0.5) * scale
    s3 = side * scale
    batch = batch_for_shader(shader, "TRIS", {"pos": (
        (bx, by), (bx, by + s3), (bx + s3 * 0.88, by + s3 * 0.5))})
    shader.uniform_float("color", ON_ACCENT)
    batch.draw(shader)


def _tip_classic(shader, x, y, w, h, phase, scale):
    """This card, or the side panel the add-on shipped with."""
    over = abs(math.sin(phase * math.pi))
    pw = min(w * 0.40, 76.0)
    ph = min(h - 20.0, 82.0)
    cx = x + w * 0.5
    oy = y + (h - ph) * 0.5

    def frame(px, lit, rounded):
        r = (7.0 if rounded else 1.0) * scale
        _fill(shader, px * scale, oy * scale, pw * scale, ph * scale, r,
              (1.0, 1.0, 1.0, 0.05 + 0.06 * lit))
        rows = 5
        for i in range(rows):
            ry = oy + ph - 14.0 - i * ((ph - 20.0) / rows)
            rw = pw - 16.0
            rr = (5.0 if rounded else 0.0) * scale
            colour = _ac(0.25 + 0.65 * lit) if i == 0 else (
                1.0, 1.0, 1.0, 0.10 + 0.12 * lit)
            _fill(shader, (px + 8.0) * scale, ry * scale, rw * scale,
                  8.0 * scale, rr, colour)

    frame(cx - pw - 8.0, 1.0 - over, True)
    frame(cx + 8.0, over, False)


def _tip_flatfan(shader, x, y, w, h, phase, scale):
    """A flat panel cut into a fan, and the same panel as one face.

    The points Milad circled sit on the long diagonal of a fan. They are not
    loose - they each hold three edges - so nothing that hunts loose points
    will ever reach them. The area has to come out and go back in whole.
    """
    clean = abs(math.sin(phase * math.pi))
    side = min(w - 30.0, h - 20.0)
    ox = x + (w - side) * 0.5
    oy = y + (h - side) * 0.5
    p0 = (ox, oy)
    p1 = (ox + side, oy)
    p2 = (ox + side, oy + side)
    p3 = (ox, oy + side)
    _quad(shader, p0, p1, p2, p3, _ac(0.05 + 0.08 * clean), scale)

    # the fan, and the points sitting along its long edge
    fade = 1.0 - clean
    if fade > 0.02:
        line = (1.0, 1.0, 1.0, 0.30 * fade)
        for f in (0.25, 0.5, 0.75, 1.0):
            _seg(shader, p0, _lerp(p3, p2, f), 1.1, line, scale)
        for f in (0.3, 0.55, 0.8):
            pt = _lerp(p0, p2, f)
            _seg(shader, pt, _lerp(p1, p2, f * 0.9), 1.0, line, scale)
            _dot(shader, pt[0], pt[1], 2.6, _ac(0.9 * fade), scale)

    for i in range(4):
        _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i],
             1.4 + 1.0 * clean, _ac(0.35 + 0.65 * clean), scale)


def _tip_flatkeep(shader, x, y, w, h, phase, scale):
    """The same flat panel, with one line on it that has to stay."""
    clean = abs(math.sin(phase * math.pi))
    side = min(w - 30.0, h - 20.0)
    ox = x + (w - side) * 0.5
    oy = y + (h - side) * 0.5
    p0 = (ox, oy)
    p1 = (ox + side, oy)
    p2 = (ox + side, oy + side)
    p3 = (ox, oy + side)
    _quad(shader, p0, p1, p2, p3, (1.0, 1.0, 1.0, 0.05), scale)
    fade = 1.0 - clean
    if fade > 0.02:
        line = (1.0, 1.0, 1.0, 0.28 * fade)
        for f in (0.25, 0.5, 0.75, 1.0):
            _seg(shader, p0, _lerp(p3, p2, f), 1.1, line, scale)
    for i in range(4):
        _seg(shader, (p0, p1, p2, p3)[i], (p1, p2, p3, p0)[i], 1.3,
             (1.0, 1.0, 1.0, 0.22), scale)
    # the line that was asked for, untouched throughout
    _seg(shader, _lerp(p0, p3, 0.45), _lerp(p1, p2, 0.45), 2.4, _ac(1.0),
         scale)



def _wrap(text, width, size, scale):
    blf.size(0, size * scale)
    out = []
    line = ""
    for word in text.split():
        probe = (line + " " + word).strip()
        if blf.dimensions(0, probe)[0] > width * scale and line:
            out.append(line)
            line = word
        else:
            line = probe
    if line:
        out.append(line)
    return out[:4]


def _tip_usethis(shader, x, y, w, h, phase, scale):
    """A piece pulled out of a result, told to stand on its own.

    The link back to the model it came from is what makes a remesh of the
    piece rebuild the whole thing, so the drawing is that link breaking.
    """
    t = phase % 1.0
    cut = min(1.0, max(0.0, (t - 0.25) / 0.45))
    big = min(w * 0.34, h - 26.0)
    small = big * 0.42
    ly = y + (h - big) * 0.5
    lx = x + w * 0.18 - big * 0.5
    rx = x + w * 0.80 - small * 0.5
    ry = y + (h - small) * 0.5

    _patch(shader, lx, ly, big, big, 3, 3, scale,
           fill=(1.0, 1.0, 1.0, 0.05),
           line=(1.0, 1.0, 1.0, 0.16),
           border=(1.0, 1.0, 1.0, 0.22 + 0.0 * cut))
    _patch(shader, rx, ry, small, small, 2, 2, scale,
           fill=_ac(0.08 + 0.10 * cut),
           line=(1.0, 1.0, 1.0, 0.18),
           border=_ac(0.35 + 0.65 * cut))

    # the tie between them, breaking in the middle
    ax = lx + big + 6.0
    bx = rx - 6.0
    cy = y + h * 0.5
    mid = (ax + bx) * 0.5
    gap = (bx - ax) * 0.5 * cut
    _seg(shader, (ax, cy), (mid - gap, cy), 1.8,
         (1.0, 1.0, 1.0, 0.35 * (1.0 - cut) + 0.12), scale)
    _seg(shader, (mid + gap, cy), (bx, cy), 1.8,
         (1.0, 1.0, 1.0, 0.35 * (1.0 - cut) + 0.12), scale)


def _tip_cage(shader, x, y, w, h, phase, scale):
    """A dense model, a small cage over it, and the cage smoothed back onto it.

    Three steps, left to right: what came in, the handful of quads laid over
    it, and what those quads become once they are subdivided with the hard
    edges creased.
    """
    t = phase % 1.0
    step = min(1.0, max(0.0, (t - 0.10) / 0.75)) * 2.0
    side = min((w - 40.0) / 3.0, h - 22.0)
    oy = y + (h - side) * 0.5
    gap = (w - side * 3.0) / 4.0

    def at(i):
        return x + gap + i * (side + gap)

    # the model as it arrives
    _patch(shader, at(0), oy, side, side, 6, 6, scale,
           fill=(1.0, 1.0, 1.0, 0.05),
           line=(1.0, 1.0, 1.0, 0.16),
           border=(1.0, 1.0, 1.0, 0.22))
    # the cage
    a = min(1.0, max(0.0, step))
    if a > 0.02:
        _patch(shader, at(1), oy, side, side, 2, 2, scale,
               fill=_ac(0.06 * a), line=_ac(0.55 * a), border=_ac(0.85 * a))
    # and what it becomes
    b = min(1.0, max(0.0, step - 1.0))
    if b > 0.02:
        _patch(shader, at(2), oy, side, side, 4, 4, scale,
               fill=_ac(0.10 * b),
               line=(1.0, 1.0, 1.0, 0.20 * b),
               border=_ac(0.9 * b))
        # the creased edge that stays sharp through the smoothing
        p0 = (at(2), oy + side * 0.5)
        p1 = (at(2) + side, oy + side * 0.5)
        _seg(shader, p0, p1, 2.4, _ac(b), scale)
    for i in (0, 1):
        if step > i:
            ax = at(i) + side + gap * 0.15
            bx = at(i + 1) - gap * 0.15
            cy = oy + side * 0.5
            _seg(shader, (ax, cy), (bx, cy), 1.6, _ac(0.8), scale)


# Which drawing goes with which explanation. Rebuilt after a careless
# regex took the whole table out with one of its entries.
_TIP_ART = {
    "cage": _tip_cage,
    "watchhard": _tip_watch_hard,
    "usethis": _tip_usethis,
    "accent": _tip_accent,
    "autothresh": _tip_autothresh,
    "bake": _tip_bake,
    "calibrate": _tip_calibrate,
    "circle": _tip_circle,
    "classic": _tip_classic,
    "clean": _tip_clean,
    "confine": _tip_confine,
    "confirm": _tip_confirm,
    "corner": _tip_corner,
    "crease": _tip_crease,
    "every": _tip_every,
    "flatfan": _tip_flatfan,
    "flatkeep": _tip_flatkeep,
    "fold": _tip_fold,
    "gap": _tip_gap,
    "gpu": _tip_gpu,
    "grid": _tip_grid,
    "hardsurface": _tip_hardsurface,
    "isolate": _tip_isolate,
    "marked": _tip_marked,
    "meet": _tip_meet,
    "merge": _tip_merge,
    "minlen": _tip_minlen,
    "mirror": _tip_mirror,
    "pbr": _tip_pbr,
    "pick": _tip_pick,
    "purequad": _tip_purequad,
    "relax": _tip_relax,
    "remesh": _tip_remesh,
    "reproject": _tip_reproject,
    "reset": _tip_reset,
    "restore": _tip_restore,
    "seams": _tip_seams,
    "search": _tip_search,
    "sharpedge": _tip_sharp,
    "shells": _tip_shells,
    "split": _tip_split,
    "straightloop": _tip_straightloop,
    "swap": _tip_swap,
    "tear": _tip_tear,
    "typed": _tip_typed,
    "unbake": _tip_unbake,
    "useless": _tip_useless,
    "uvkeep": _tip_uvkeep,
    "valence": _tip_valence,
    "watch": _tip_watch,
    "watchcloth": _tip_watch_cloth,
    "weld": _tip_weld,
    "weldlines": _tip_weldlines,
}


def _bake_state():
    """The bake in progress, as the bake operator reports it."""
    import sys
    mod = sys.modules.get(__package__ + ".lines_preview")
    return getattr(mod, "BAKE", None)


def _run_state():
    """The remesh in progress, as the Organic operator reports it."""
    import sys
    pkg = sys.modules.get(__package__)
    return getattr(pkg, "RUN", None)


def _draw_tip(shader, card, scale):
    tip = _state["tip"]
    if tip is None:
        return
    index, key, since = tip
    waited = time.time() - since
    if waited < TIP_DELAY:
        return
    found = TIPS.get(key)
    widgets = _state["widgets"]
    if not found or index >= len(widgets):
        return
    title, body, art = found
    wx, wy, ww, wh = widgets[index]["rect"]
    # blf leaves its own blend state behind, and the tip is drawn after the
    # text - without setting it back, every translucent fill here lands opaque
    # and the whole drawing came out as one white square.
    gpu.state.blend_set("ALPHA")
    shader.bind()

    lines = _wrap(body, TIP_W - 24.0, 11, scale)
    art_h = 96.0
    h = 16.0 + 16.0 + 6.0 + len(lines) * 15.0 + 10.0 + art_h + 14.0
    x = card[0] - TIP_W - 10.0
    y = min(max(wy + wh - h, 20.0), card[1] + card[3] - h)

    _fill(shader, (x - 1.0) * scale, (y - 1.0) * scale, (TIP_W + 2.0) * scale,
          (h + 2.0) * scale, 13.0 * scale, EDGE)
    _fill(shader, x * scale, y * scale, TIP_W * scale, h * scale,
          12.0 * scale, CARD)

    _TIP_ART.get(art, _tip_grid)(shader, x + 12.0, y + 12.0, TIP_W - 24.0,
                                 art_h, (time.time() - since) * 0.55, scale)

    ty = y + h - 24.0
    _text(title, (x + 12.0) * scale, ty * scale, 12, TEXT, scale, bold=True)
    ty -= 17.0
    for line in lines:
        _text(line, (x + 12.0) * scale, ty * scale, 11, TEXT_DIM, scale)
        ty -= 15.0


def _settle():
    """Pay back a repaint the throttle skipped.

    Blender stops sending mouse moves the moment the pointer stops, so the
    last move of a sweep is often the one the throttle drops - and the
    highlight would then sit on the row before the one under the pointer until
    something else happened to force a paint.
    """
    if not _state["dirty"] or _state["quit"]:
        _state["dirty"] = False
        return None
    _state["dirty"] = False
    _state["painted"] = time.time()
    _state["asked"] = _state["painted"]
    for win in bpy.context.window_manager.windows:
        for a in win.screen.areas:
            if a.type == "VIEW_3D":
                a.tag_redraw()
    return None


def _tick():
    """Redraw while a tip is open, so its drawing can move.

    The animation is never worth more than about a quarter of the machine. On
    a light scene that leaves it at its full twenty frames a second; on a
    heavy one it slows itself down instead of fighting the viewport for every
    frame.
    """
    if _state["quit"] or _state["tip"] is None:
        _state["ticking"] = False
        return None
    if _state["asked"]:
        return 0.02              # the last one has not come back yet
    _state["asked"] = time.time()
    area = getattr(bpy.context, "area", None)
    if area is not None and area.type == "VIEW_3D":
        area.tag_redraw()
    else:
        for win in bpy.context.window_manager.windows:
            for a in win.screen.areas:
                if a.type == "VIEW_3D":
                    a.tag_redraw()
    return min(0.5, max(0.05, _state["cost"] * 4.0))


# What to say when an action will not run. "That one cannot run here" is true
# and useless: it says nothing about what is missing or what to do about it,
# and Milad hit exactly that pressing Confirm with nothing to confirm.

WHY = {
    "mesh.quadremesh_to_hardsurface":
        "Confirm keeps a result and carries on with it. Remesh or relax "
        "something first, then Confirm.",
    "mesh.quadremesh_run":
        "Select a mesh object to remesh.",
    "mesh.quadremesh_panels_build":
        "Select a mesh object to remesh.",
    "mesh.quadremesh_restore":
        "Nothing to put back - there is no remesh behind this object.",
    "mesh.quadremesh_isolate":
        "Select a mesh, and put back the piece already out on its own first.",
    "mesh.quadremesh_isolate_exit":
        "Nothing is out on its own right now.",
    "mesh.quadremesh_pick_island":
        "Pick needs a mesh in Object Mode, with a UV map to read the pieces "
        "from.",
    "mesh.quadremesh_relax_brush":
        "Select a mesh object to brush.",
    "mesh.quadremesh_leave_sculpt":
        "Not in Sculpt Mode.",
    "mesh.quadremesh_meet_verts":
        "Meet works on a result built with Remesh Separately.",
    "mesh.quadremesh_fill_gaps":
        "Select a mesh in Object Mode.",
    "mesh.quadremesh_join_points":
        "Select a mesh in Object Mode.",
    "mesh.quadremesh_use_this_mesh":
        "This object is already read as itself - there is no model behind it.",
    "mesh.quadremesh_subdiv_cage":
        "Select a mesh in Object Mode with more than eight faces.",
    "mesh.quadremesh_flatten_fans":
        "Select a mesh with more than two faces.",
    "mesh.quadremesh_flatten_fans_undo":
        "Nothing to put back - Rebuild flat areas has not been run here.",
    "mesh.quadremesh_min_valence":
        "Select a mesh object.",
    "mesh.quadremesh_min_valence_undo":
        "Nothing to put back - 3 Edges has not been run on this mesh.",
    "mesh.quadremesh_clean_confirm":
        "There is no cleaned area waiting to be kept.",
    "mesh.quadremesh_bake_from_original":
        "Baking needs a remesh and the original it came from.",
}


# -- what the card holds ----------------------------------------------------

def _settings(context):
    return getattr(context.scene, "quadremesh", None)


def _build(context, region):
    """Lay the card out and return its widgets, in unscaled pixels."""
    st = _settings(context)
    if st is None:
        return [], (0.0, 0.0, 0.0, 0.0)
    lines = getattr(context.scene, "quadremesh_lines", None)

    scale = context.preferences.system.ui_scale or 1.0
    # The sidebar is drawn over the window region rather than beside it, so
    # its width has to come off by hand.
    heads = 0.0
    area = getattr(context, "area", None)
    if area is not None:
        for r in area.regions:
            if r.type in {"HEADER", "TOOL_HEADER"}:
                # Both are drawn over the top of the window region, so the
                # card started underneath them and its title sat behind the
                # tool bar. Their height is what has to come off.
                heads += r.height
    # Against the tab strip, not against the sidebar's outer edge. The
    # sidebar is as wide as its panels ask for, and the card standing off by
    # that width left a band of empty panel between the two - the card is the
    # panel now, so it takes that room and sits on the tabs.
    x = region.width / scale - TAB_STRIP - CARD_W
    top = (region.height - heads) / scale - 6.0

    w = []
    inner = CARD_W - PAD * 2.0
    left = x + PAD
    y = [top - PAD + _state["scroll"]]

    def put(kind, h, gap=GAP, **kw):
        kw["kind"] = kind
        kw["rect"] = (left, y[0] - h, inner, h)
        w.append(kw)
        y[0] -= h + gap
        return kw

    def section(text):
        put("section", 16.0, gap=4.0, text=text)

    def chips(items, cur, prop, h=32.0):
        n = len(items)
        cw = (inner - 6.0 * (n - 1)) / n
        for k, item in enumerate(items):
            name, code = item[0], item[1]
            tip = item[2] if len(item) > 2 else None
            w.append({"kind": "chip",
                      "rect": (left + k * (cw + 6.0), y[0] - h, cw, h),
                      "text": name, "on": cur == code, "tip": tip,
                      "act": (prop, code)})
        y[0] -= h + GAP

    def check(text, act):
        put("check", 24.0, text=text, on=True, act=act)

    def switch(text, owner, prop, tip=None):
        if hasattr(owner, prop):
            put("switch", 34.0, gap=0.0, text=text, tip=tip,
                on=bool(getattr(owner, prop)), act=("prop", (owner, prop)))

    def field(text, owner, prop, lo, hi, decimals=0, suffix="", tip=None,
              save=False):
        if not hasattr(owner, prop):
            return
        val = getattr(owner, prop)
        shown = (f"{int(val):,}" if not decimals else f"{val:.{decimals}f}")
        put("field", 26.0, gap=6.0, text=text, shown=shown + suffix, tip=tip,
            save=save, act=("type", (owner, prop, lo, hi, decimals)))
        put("bar", 14.0, value=val, lo=lo, hi=hi, decimals=decimals, tip=tip,
            save=save, act=("slide", (owner, prop)))

    def button(text, idname, kind="btn", h=ROW, tip=None):
        put(kind, h, text=text, tip=tip, act=("op", idname))

    def lesson(text, idname, tip="watch"):
        """A tutorial link. Every one of these opens the same kind of popup -
        hold the pointer on it and it says what the video covers."""
        put("play", 26.0, text=text, tip=tip, act=("op", idname))

    def row(items, kind="tool"):
        n = len(items)
        cw = (inner - 6.0 * (n - 1)) / n
        for k, item in enumerate(items):
            name, idname = item[0], item[1]
            tip = item[2] if len(item) > 2 else None
            w.append({"kind": kind,
                      "rect": (left + k * (cw + 6.0), y[0] - ROW, cw, ROW),
                      "text": name, "tip": tip, "act": ("op", idname)})
        y[0] -= ROW + GAP

    def enum_row(owner, prop, items, h=28.0):
        """One chip per choice of an enum on any owner."""
        n = len(items)
        cw = (inner - 6.0 * (n - 1)) / n
        cur = getattr(owner, prop)
        for k, (name, code) in enumerate(items):
            w.append({"kind": "chip",
                      "rect": (left + k * (cw + 6.0), y[0] - h, cw, h),
                      "text": name, "on": cur == code, "tip": None,
                      "act": ("enum", (owner, prop, code))})
        y[0] -= h + GAP

    def toggle_row(owner, props, h=28.0):
        """Chips that each switch one boolean on and off."""
        n = len(props)
        cw = (inner - 6.0 * (n - 1)) / n
        for k, (name, prop) in enumerate(props):
            w.append({"kind": "chip",
                      "rect": (left + k * (cw + 6.0), y[0] - h, cw, h),
                      "text": name, "on": bool(getattr(owner, prop)),
                      "tip": None, "act": ("prop", (owner, prop))})
        y[0] -= h + GAP

    def note_line(text, color=None):
        w.append({"kind": "label", "rect": (left, y[0] - 12.0, 0, 0),
                  "text": text, "size": 11,
                  "color": TEXT_DIM if color is None else color})
        y[0] -= 16.0

    def fold(key, text):
        open_ = key in _state["open"]
        put("fold", ROW, text=text, on=open_, act=("fold", key))
        return open_

    def quiet_fold(key, text):
        """A heading that opens, drawn as a heading and not as a button.

        Every fold on the card carries a filled slab behind it, and one more
        of those at the foot only makes the card look busier. This one is the
        arrow and the words, nothing else - it still opens, it just does not
        announce itself as somewhere to press.
        """
        open_ = key in _state["open"]
        put("quietfold", 22.0, gap=4.0, text=text, on=open_,
            act=("fold", key))
        return open_

    def links(items):
        """Three names on one line, clickable, with no button around them."""
        n = len(items)
        cw = inner / n
        for k, (name, url) in enumerate(items):
            w.append({"kind": "linktext",
                      "rect": (left + k * cw, y[0] - 22.0, cw, 22.0),
                      "text": name, "act": ("url", url)})
        y[0] -= 22.0 + GAP

    def rule():
        put("rule", 1.0, gap=GAP + 2.0)

    # header ---------------------------------------------------------------
    w.append({"kind": "logo", "rect": (left, y[0] - 26.0, 26.0, 26.0)})
    w.append({"kind": "title", "rect": (left + 36.0, y[0] - 19.0, 0, 0),
              "text": "Smart Remesh 3"})
    try:
        from . import YOUTUBE_URL
    except Exception:
        YOUTUBE_URL = ""
    w.append({"kind": "playbtn",
              "rect": (left + inner - 26.0, y[0] - 26.0, 26.0, 26.0),
              "tip": "watch", "act": ("url", YOUTUBE_URL)})
    y[0] -= 26.0 + GAP + 2.0

    # The two halves of the add-on. Each one shows its own controls and only
    # its own: Cloth has no density and Hardsurface has no engine, and a card
    # that offers either anyway is a card that has to be read before it can be
    # used.
    group = _state["group"]
    chips((("Organic", "ORGANIC", "remesh"),
           ("Hard Surface", "HARD", "hardsurface")), group, "group")

    if group == "ORGANIC":
        chips((("Cloth", "CLOTH", "separate"),
               ("Manual", "STABLE", "purequad"),
               ("Auto", "AUTO", "search")), st.backend, "backend")
        # The classic panel explains a blocked engine on macOS and offers the
        # one click that clears it; without this the card only showed an
        # error when Remesh was pressed.
        try:
            import sys
            blocked = getattr(sys.modules.get(__package__), "engine_blocked",
                              lambda: "")()
        except Exception:
            blocked = ""
        if blocked:
            note_line("Organic engine is blocked by macOS", ACCENT)
            note_line("It carries no Apple signature. One click")
            note_line("clears that, showing the command first.")
            button("Allow Organic Engine", "mesh.quadremesh_unquarantine")
        busy = _run_state()
        if busy is not None and busy["busy"]:
            put("running", 38.0, text="Remeshing  %d%%"
                % int(busy["shown"] * 100.0), frac=busy["shown"])
            put("runline", 14.0, text="%s  |  %ds  |  Esc to stop" % (
                busy["stage"], int(time.time() - busy["t0"])))
        else:
            button("Remesh", "mesh.quadremesh_run", "run", 38.0,
                   tip="remesh")
        if st.backend == "CLOTH":
            put("play", 26.0, text="Cloth Remeshing - Tutorial",
                tip="clothtut", act=("op", "__lesson__"))

        section("TARGET GEOMETRY")
        chips((("Face count", "FACES", "faces"),
               ("Edge length", "EDGE", "edge")), st.mode, "mode")
        if st.mode == "FACES":
            field("Faces", st, "target_faces", 20, 20000, tip="faces")
        else:
            field("Edge length", st, "target_edge", 0.001, 2.0, 3, tip="edge")

        if st.backend == "CLOTH":
            section("PANELS")
            switch("Remesh separately", st, "uv_panels", tip="separate")
            y[0] -= GAP
            if st.uv_panels:
                field("Meet distance", st, "meet_dist", 0.0, 2.0, 2,
                      tip="meet")
                switch("Weld panels", st, "meet_weld", tip="weld")
                y[0] -= GAP
                button("Meet panel vertices",
                       "mesh.quadremesh_meet_verts", tip="meetbtn")
            else:
                field("Merge distance", st, "merge_dist", 0.0, 1.0, 3,
                      tip="mergedist")
                field("Max tear", st, "tear_size", 0.0, 1.0, 2, tip="tears")
            switch("Merge shells", st, "merge_shells", tip="shells")
            y[0] -= GAP
            if st.merge_shells:
                field("Merge distance", st, "merge_dist", 0.0, 1.0, 3,
                      tip="mergedist")
        elif st.backend == "AUTO":
            section("ENGINE")
            switch("Detect crease angle", st, "auto_crease",
                   tip="crease")
            y[0] -= GAP
            if not st.auto_crease:
                field("Sharp angle", st, "feature_angle", 1.0, 180.0,
                      suffix="\u00b0", tip="sharp")
            switch("Calibrate face count", st, "auto_calibrate",
                   tip="calibrate")
            switch("Search settings", st, "auto_search", tip="search")
            y[0] -= GAP
            field("Reprojection steps", st, "smooth_iterations", 0, 20,
                  tip="reproject")
        else:
            section("ENGINE")
            field("Reprojection steps", st, "smooth_iterations", 0, 20,
                  tip="reproject")

        if st.backend != "CLOTH":
            switch("Close holes", st, "close_holes", tip="closeholes")
        switch("Replace original", st, "replace", tip="replace")
        switch("Mark sharp edges", st, "mark_sharp")
        y[0] -= GAP
        # Pick, Isolate and Relax belong to Cloth and to nothing else. Pick
        # reads the pattern pieces off the UV islands a garment has and the
        # other two are the way around that same piece, so on Manual and Auto
        # they are three buttons that answer a question nobody asked.
        if st.backend == "CLOTH":
            sculpting = (context.active_object is not None
                         and context.active_object.mode == "SCULPT")
            # A piece that is out on its own has to have its way back on the
            # card, the way the sidebar always did - it is the only button
            # that undoes what Isolate did, and without it the rest of the
            # model stays hidden.
            try:
                from . import _isolated_piece
                alone = _isolated_piece(context) is not None
            except Exception:
                alone = False
            row((("Pick", "mesh.quadremesh_pick_island", "pick"),
                 ("Exit", "mesh.quadremesh_isolate_exit", "isolate") if alone
                 else ("Isolate", "mesh.quadremesh_isolate", "isolate"),
                 ("Done", "mesh.quadremesh_leave_sculpt", "relax")
                 if sculpting
                 else ("Relax", "mesh.quadremesh_relax_brush", "relax")))
        cw = (inner - 6.0) / 2.0
        w.append({"kind": "ghost", "rect": (left, y[0] - ROW, cw, ROW),
                  "text": "Confirm", "tip": "confirm",
                  "act": ("op", "mesh.quadremesh_to_hardsurface")})
        w.append({"kind": "tool",
                  "rect": (left + cw + 6.0, y[0] - ROW, cw, ROW),
                  "text": "Restore", "tip": "restore",
                  "act": ("op", "mesh.quadremesh_restore")})
        y[0] -= ROW + GAP

    elif lines is not None:
        button("Remesh hardsurface", "mesh.quadremesh_panels_build",
               "run", 38.0, tip="hardsurface")
        lesson("Hardsurface - Tutorial", "__lesson_hard__", tip="hardtut")
        # These two decide what the Remesh button does with its result, so
        # they belong against it and not at the far end of the card.
        switch("Replace original", lines, "hs_replace", tip="replace")
        switch("Mirror retopology", lines, "hs_mirror", tip="mirror")
        if getattr(lines, "hs_mirror", False):
            y[0] -= 4.0
            enum_row(lines, "hs_mirror_axis",
                     (("Auto", "AUTO"), ("X", "X"), ("Y", "Y"), ("Z", "Z")))
        y[0] -= GAP
        cw2 = (inner - 6.0) / 2.0
        w.append({"kind": "tool", "rect": (left, y[0] - ROW, cw2, ROW),
                  "text": "Use this mesh", "tip": "usethis",
                  "act": ("op", "mesh.quadremesh_use_this_mesh")})
        w.append({"kind": "tool",
                  "rect": (left + cw2 + 6.0, y[0] - ROW, cw2, ROW),
                  "text": "Back to original", "tip": "reset",
                  "act": ("op", "mesh.quadremesh_reset_all")})
        y[0] -= ROW + GAP
        row((("Mesh cleanup", "mesh.quadremesh_tris_to_quads"),))

        section("PRESET")
        try:
            shown_preset = bpy.types.UILayout.enum_item_name(
                lines, "preset", lines.preset) or "Choose"
        except Exception:
            shown_preset = "Choose"
        cw3 = (inner - 18.0) / 4.0
        w.append({"kind": "tool", "rect": (left, y[0] - ROW, cw3 * 2.0 + 6.0, ROW),
                  "text": shown_preset + "  v", "tip": None,
                  "act": ("enum_menu", "scene.quadremesh_lines.preset")})
        w.append({"kind": "tool",
                  "rect": (left + cw3 * 2.0 + 12.0, y[0] - ROW, cw3, ROW),
                  "text": "Save", "tip": None,
                  "act": ("op", "mesh.quadremesh_preset_save")})
        w.append({"kind": "tool",
                  "rect": (left + cw3 * 3.0 + 18.0, y[0] - ROW, cw3, ROW),
                  "text": "Delete", "tip": None,
                  "act": ("op", "mesh.quadremesh_preset_delete")})
        y[0] -= ROW + GAP

        section("SUBDIV CAGE")
        field("Cage faces", lines, "cage_faces", 20, 5000, tip="cagefaces")
        field("Crease over", lines, "cage_crease", 1.0, 180.0,
              suffix="°", tip="cagecrease")
        field("Subdiv levels", lines, "cage_levels", 0, 4, tip="cage")
        button("Build subdiv cage", "mesh.quadremesh_subdiv_cage", tip="cage")

        section("LINES")
        switch("Automatic thresholds", lines, "auto_thresholds",
               tip="autothresh")
        y[0] -= GAP
        if not getattr(lines, "auto_thresholds", True):
            field("Crease", lines, "crease_deg", 0.0, 90.0,
                  suffix="\u00b0", tip="crease")
            field("Coplanar", lines, "flat_deg", 0.1, 15.0, 2,
                  tip="straight")
        field("Weld close lines", lines, "weld_close", 0.0, 0.02, 5,
              tip="weldclose")
        field("Remove straight loops", lines, "dissolve_straight", 0.0,
              0.005, 5, tip="straight")
        field("Min length", lines, "min_chain", 0.0, 1.0, 4,
              tip="minlen")
        switch("Keep circles round", lines, "refit_circles",
               tip="circles")
        switch("Flat and curved boundaries", lines, "use_type",
               tip="typed")
        switch("Close gaps", lines, "close_gaps", tip="gaps")
        y[0] -= GAP
        if getattr(lines, "close_gaps", False):
            field("Gap reach", lines, "gap_span", 0.0, 4.0, 3,
                  tip="gapspan")

        section("REPAIR")
        button("Fill Missed Gaps", "mesh.quadremesh_fill_gaps",
               tip="fillgaps")

        if fold("cleanup", "Smart cleanup"):
            switch("Include my lines", lines, "hs_use_marked",
                   tip="usemarked")
            switch("Only my lines", lines, "hs_only_marked",
                   tip="onlymarked")
            y[0] -= GAP
            field("Remove", lines, "pz_amount", 0, 100,
                  tip="cleanamount")
            switch("Stay inside lines", lines, "pz_confine",
                   tip="confine")
            y[0] -= GAP
            row((("Clean", "mesh.quadremesh_clean_between", "clean"),
                 ("Keep", "mesh.quadremesh_clean_confirm", "clean"),
                 ("Undo", "mesh.quadremesh_clean_reset", "clean")))
            row((("Revert all cleaning", "mesh.quadremesh_clean_revert_all",
                  "clean"),))
            row((("3 Edges", "mesh.quadremesh_min_valence", "valence"),
                 ("Undo", "mesh.quadremesh_min_valence_undo", "valence")))
            switch("Keep my lines", lines, "flat_keep_marked",
                   tip="flatkeep")
            y[0] -= GAP
            field("Flat within", lines, "flat_fan_angle", 0.01, 30.0, 2,
                  suffix="°", tip="flatfan")
            row((("Rebuild flat", "mesh.quadremesh_flatten_fans", "flatfan"),
                 ("Undo", "mesh.quadremesh_flatten_fans_undo", "flatfan")))
        if fold("loops", "Erase useless loops"):
            field("Flat below", lines, "pz_useless", 0.0, 10.0, 2,
                  tip="useless")
            field("Remove per kept", lines, "pz_every", 0, 10,
                  tip="every")
            switch("Spare my lines", lines, "pz_keep_marked")
            tgt = context.active_object
            if (tgt is not None and tgt.type == "MESH"
                    and tgt.data.uv_layers):
                switch("Protect UV seams", lines, "pz_keep_seams")
            y[0] -= GAP
            row((("Drop", "mesh.quadremesh_drop_useless", "useless"),
                 ("Keep", "mesh.quadremesh_drop_confirm", "useless"),
                 ("Undo", "mesh.quadremesh_drop_reset", "useless")))
            row((("Drop from original", "mesh.quadremesh_drop_original",
                  "useless"),))
            row((("Align axes", "mesh.quadremesh_align_axes"),
                 ("Undo", "mesh.quadremesh_align_axes_undo")))
            section("ONLY AXIS")
            toggle_row(lines, (("X", "pz_axis_x"), ("Y", "pz_axis_y"),
                               ("Z", "pz_axis_z")))
            row((("Select axis loops", "mesh.quadremesh_select_axis_loops"),))
            switch("Whole loops", lines, "pz_sel_whole_loops")
            # how many loops each axis owns, as the classic panel shows it
            counts = None
            if tgt is not None and tgt.type == "MESH" and len(tgt.data.polygons):
                try:
                    import sys
                    lp = sys.modules.get(__package__ + ".lines_preview")
                    counts = lp.axis_loop_counts(tgt)
                except Exception:
                    counts = None
                if counts is None:
                    row((("Count loops", "mesh.quadremesh_count_loops"),))
                else:
                    note_line("X %d  Y %d  Z %d  |  %d loops%s" % (
                        counts[0], counts[1], counts[2], counts[3],
                        (", %d open" % counts[4]) if counts[4] else ""))

    if lines is not None and fold("uv", "UV & bake"):
        switch("Bake into existing UV", lines, "uv_keep_islands",
               tip="uvkeep")
        switch("Show UV seams", lines, "uv_show_seams", tip="seams")
        switch("Seams as sharp", lines, "uv_seams_sharp",
               tip="seamsharp")
        switch("Bake PBR", lines, "bake_pbr", tip="pbr")
        switch("Bake on GPU", lines, "bake_gpu", tip="gpu")
        y[0] -= GAP
        if hasattr(lines, "bake_size"):
            # the texture size the classic panel offered and the card had lost
            section("BAKE RESOLUTION")
            sizes = ("1024", "2048", "4096")
            cw = (inner - 6.0 * 2) / 3
            for k, code in enumerate(sizes):
                w.append({"kind": "chip",
                          "rect": (left + k * (cw + 6.0), y[0] - 30.0, cw, 30.0),
                          "text": code, "on": lines.bake_size == code,
                          "tip": None, "act": ("enum", (lines, "bake_size", code))})
            y[0] -= 30.0 + GAP
        baking = _bake_state()
        if baking is not None and baking["busy"]:
            put("running", 30.0, text="Baking  %d%%"
                % int(baking["shown"] * 100.0), frac=baking["shown"])
            put("runline", 14.0, text="%s  |  pass %d of %s  |  %ds  |  Esc" % (
                baking["stage"], min(baking["done"] + 1,
                                     max(baking["total"], 1)),
                baking["total"] or "?", int(time.time() - baking["t0"])))
        else:
            row((("Bake", "mesh.quadremesh_bake_from_original", "bake"),
                 ("Unbake", "mesh.quadremesh_unbake", "unbake")))

    # The colour of the card, chosen here rather than by us. Two strips: the
    # hue all the way round, and how much of it there is - all the way down to
    # none, for anyone who would rather the card were grey.
    prefs = _prefs()
    if prefs is not None and hasattr(prefs, "accent_hue"):
        if quiet_fold("uidesign", "UI design"):
            hue = float(prefs.accent_hue)
            sat = float(prefs.accent_sat)
            steps = 34
            put("ramp", 12.0, gap=6.0, value=hue, lo=0.0, hi=1.0, decimals=3,
                tip="accent",
                ramp=[accent_rgb(i / (steps - 1.0), max(sat, 0.25)) + (1.0,)
                      for i in range(steps)],
                act=("slide", (prefs, "accent_hue")))
            put("ramp", 12.0, value=sat, lo=0.0, hi=1.0, decimals=3,
                tip="accent",
                ramp=[accent_rgb(hue, i / (steps - 1.0)) + (1.0,)
                      for i in range(steps)],
                act=("slide", (prefs, "accent_sat")))
            field("Corner rounding", prefs, "corner", 0.0, 16.0, 1,
                  tip="corner", save=True)
            switch("Classic panel", prefs, "classic_panel", tip="classic")
            y[0] -= GAP

    # About is not a section of its own. It is a line of text at the foot of
    # the card with the three links written into it, because that is what it
    # is: a signature, not a place to go.

    rule()

    obj = context.active_object
    faces = len(obj.data.polygons) if obj is not None and obj.type == "MESH" \
        else 0
    try:
        from . import VERSION_TEXT
        stamp = "  ·  v" + VERSION_TEXT
    except Exception:
        stamp = ""
    try:
        from . import ARTSTATION_URL, SUPERHIVE_URL, DISCORD_URL
    except Exception:
        ARTSTATION_URL = SUPERHIVE_URL = DISCORD_URL = ""
    w.append({"kind": "label", "rect": (left, y[0] - 12.0, 0, 0),
              "text": "Milad Kambari - 3DRedbox Studio", "size": 11,
              "color": TEXT_DIM})
    y[0] -= 16.0
    links((("ArtStation", ARTSTATION_URL),
           ("Superhive", SUPERHIVE_URL),
           ("Discord", DISCORD_URL)))

    note = _state.get("note")
    if note is not None and time.time() - note[1] < 6.0:
        for line in _wrap(note[0], inner, 11, scale):
            w.append({"kind": "label", "rect": (left, y[0] - 12.0, 0, 0),
                      "text": line, "size": 11, "color": ACCENT})
            y[0] -= 15.0
        y[0] -= 3.0
    w.append({"kind": "label", "rect": (left, y[0] - 12.0, 0, 0),
              "text": f"{faces:,} faces{stamp}", "size": 11,
              "color": TEXT_DIM})
    y[0] -= 12.0

    bottom = y[0] - PAD
    # The height the contents want, with the scrolling taken back out of it so
    # the number does not move as the card is scrolled.
    full = (top + PAD - bottom) + _state["scroll"]
    room = top + PAD - 6.0                  # what the viewport has
    _state["over"] = max(0.0, full - room)
    shown = min(full, room)
    card = (x, top + PAD - shown, CARD_W, shown)
    return w, card


def _typing_here(it):
    """Is this the number box that is open for typing?"""
    t = _state["typing"]
    if t is None or it.get("kind") != "field":
        return False
    act = it.get("act")
    if not act or act[0] != "type":
        return False
    if act[1][1] != t["prop"]:
        return False
    # Blender hands back a fresh Python wrapper for the same settings block on
    # every access, so `is` says no even when it is the same block. Comparing
    # what they point at is the only test that holds - without it the box drew
    # as if nothing was happening and typing looked dead.
    try:
        return act[1][0].as_pointer() == t["owner"].as_pointer()
    except Exception:
        return False


def _stop_typing(context, apply):
    """Close the box, keeping what was typed or throwing it away."""
    t = _state["typing"]
    _state["typing"] = None
    if t is None:
        return
    if apply and t["text"].strip() not in ("", "-", ".", "-."):
        try:
            val = float(t["text"])
        except ValueError:
            val = None
        if val is not None:
            # The slider is deliberately narrower than the setting allows -
            # Faces runs 20 to 20,000 on the card and 8 to 200,000 in the
            # property - so a typed number is held to what the setting really
            # permits, not to what is comfortable to drag.
            lo, hi = t["lo"], t["hi"]
            try:
                rna = t["owner"].bl_rna.properties[t["prop"]]
                lo, hi = rna.hard_min, rna.hard_max
            except Exception:
                pass
            val = min(max(val, lo), hi)
            try:
                setattr(t["owner"], t["prop"],
                        int(round(val)) if not t["decimals"] else val)
            except Exception:
                pass
            if t.get("save"):
                try:
                    bpy.ops.wm.save_userpref()
                except Exception:
                    pass
    _redraw(context, getattr(context, "area", None))


def _hit(widgets, mx, my):
    for i, it in enumerate(widgets):
        # "field" is the words and the number above a slider. It is not a
        # control - it has nothing to press - but it is the part of the row
        # the pointer actually lands on, so it has to be reachable or the
        # explanation on it can never be seen.
        if it["kind"] in {"label", "logo", "title", "section", "rule"}:
            continue
        x, y, w, h = it["rect"]
        if x <= mx <= x + w and y <= my <= y + h:
            return i
    return None


def _draw():
    context = bpy.context
    region = context.region
    if region is None or not _visible(context):
        return
    # Preferences can be loaded after this module registers - a start-up, a
    # different user file - so the saved colour is picked up here rather than
    # only when it is changed.
    prefs = _prefs()
    if prefs is not None:
        key = (getattr(prefs, "accent_hue", None),
               getattr(prefs, "accent_sat", None),
               getattr(prefs, "corner", None))
        if _state.get("tint") != key:
            _state["tint"] = key
            retint()
    widgets, card = _build(context, region)
    if not widgets:
        return
    if _state["typing"] is not None and not any(_typing_here(w) for w in widgets):
        _state["typing"] = None
    # Every 3D view draws its own card, laid out for its own width. With the
    # viewport split in two, the second one drawn used to overwrite the first
    # one's buttons, and clicks were tested against the wrong card. So each
    # keeps its own, and the shared copy is the one the pointer is over.
    key = region.as_pointer()
    _state.setdefault("regions", {})[key] = (widgets, card)
    if _state.get("hot") in (None, key) or _state.get("hot") not in _state["regions"]:
        _state["hot"] = key
        _state["widgets"] = widgets
        _state["card"] = card
    now = time.time()
    # How long the machine took to answer the last repaint we asked for. On a
    # light scene this is a millisecond or two; on a 200k face garment it is
    # fifteen, and asking twenty times a second for that is what made the
    # pointer feel heavy. Measured rather than guessed, because it is the
    # scene that decides, not us.
    if _state["asked"]:
        _state["cost"] = _state["cost"] * 0.7 + (now - _state["asked"]) * 0.3
        _state["asked"] = 0.0
    _state["drawn"] = now

    scale = context.preferences.system.ui_scale or 1.0
    hover = _state["hover"] if _state.get("hot") == key else None
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    shader.bind()

    def box(rect, r, color):
        x, y, w, h = rect
        _fill(shader, x * scale, y * scale, w * scale, h * scale, r * scale,
              color)

    def ring(rect, r, color, t=1.0, inside=None):
        """A border, drawn as the card colour punched out of a filled rect."""
        x, y, w, h = rect
        _fill(shader, x * scale, y * scale, w * scale, h * scale, r * scale,
              color)
        _fill(shader, (x + t) * scale, (y + t) * scale, (w - t * 2) * scale,
              (h - t * 2) * scale, max(0.0, r - t) * scale,
              inside if inside is not None else CARD)

    cx, cy, cw, ch = card
    _fill(shader, (cx - 1.0) * scale, (cy - 1.0) * scale, (cw + 2.0) * scale,
          (ch + 2.0) * scale, (R_CARD + 1.0) * scale, EDGE)
    _fill(shader, cx * scale, cy * scale, cw * scale, ch * scale,
          R_CARD * scale, CARD)

    # Rows scrolled past the top or the bottom must not paint over the
    # viewport. The scissor is set to the frame for the whole of the contents
    # and put back afterwards, so the tip drawn later is not clipped by it.
    clipped = _state["over"] > 0.0
    if clipped:
        gpu.state.scissor_test_set(True)
        gpu.state.scissor_set(int(cx * scale) - 2, int(cy * scale) - 2,
                              int(cw * scale) + 4, int(ch * scale) + 4)

    for i, it in enumerate(widgets):
        k = it["kind"]
        x, y, w, h = it["rect"]
        lit = (i == hover)
        if k == "logo":
            box(it["rect"], R_LOGO, ACCENT)
            # A grid, not four blocks. The mark has to say what the add-on
            # makes, and four filled squares said "app icon" while the thing
            # under them is a quad mesh - so it is drawn as the wires.
            span = 16.0
            t = 1.6
            ox = x + (w - span) * 0.5
            oy = y + (h - span) * 0.5
            for k2 in range(4):
                at = k2 * (span - t) / 3.0
                _fill(shader, ox * scale, (oy + at) * scale, span * scale,
                      t * scale, 0.0, ON_ACCENT)
                _fill(shader, (ox + at) * scale, oy * scale, t * scale,
                      span * scale, 0.0, ON_ACCENT)
        elif k == "chip":
            if it["on"]:
                ring(it["rect"], R_CTL, ACCENT, 1.0, inside=PICKED)
            else:
                box(it["rect"], R_CTL, CONTROL_HOVER if lit else CONTROL)
        elif k == "playbtn":
            # Quiet at rest. It is a link to a video, not something the card
            # wants pressed, so it only comes up under the pointer.
            if lit:
                box(it["rect"], R_CTL, CONTROL_HOVER)
            bx = (x + 9.5) * scale
            by = (y + 7.5) * scale
            side = 11.0 * scale
            batch = batch_for_shader(shader, "TRIS", {"pos": (
                (bx, by), (bx, by + side),
                (bx + side * 0.88, by + side * 0.5))})
            shader.uniform_float("color", ACCENT if lit else TEXT_DIM)
            batch.draw(shader)
        elif k == "play":
            # Same manners as the one in the header: a link, drawn quietly,
            # that only lights up when the pointer is on it.
            if lit:
                _fill(shader, (x - 4.0) * scale, y * scale,
                      (w + 8.0) * scale, h * scale, R_CTL * scale,
                      CONTROL_HOVER)
            bx = (x + 4.0) * scale
            by = (y + 8.0) * scale
            side = 10.0 * scale
            batch = batch_for_shader(shader, "TRIS", {"pos": (
                (bx, by), (bx, by + side),
                (bx + side * 0.88, by + side * 0.5))})
            shader.uniform_float("color", ACCENT if lit else TEXT_DIM)
            batch.draw(shader)
        elif k == "switch":
            _fill(shader, x * scale, y * scale, w * scale, 1.0 * scale, 0.0,
                  RULE)
            kx = (x + w - 30.0) * scale
            ky = (y + (h - 17.0) * 0.5) * scale
            _fill(shader, kx, ky, 30.0 * scale, 17.0 * scale, 8.5 * scale,
                  ACCENT if it["on"] else TRACK)
            knob = kx + (14.5 if it["on"] else 2.0) * scale
            _fill(shader, knob, ky + 2.0 * scale, 13.0 * scale, 13.0 * scale,
                  6.5 * scale, ON_ACCENT if it["on"] else KNOB)
        elif k == "field":
            if _typing_here(it):
                # a border, not a filled block: the inside has to be opaque or
                # the accent shows straight through it and the whole box reads
                # as one solid orange slab
                ring((x + w - 84.0, y, 84.0, h), R_BOX, ACCENT, 1.5,
                     inside=CARD)
            else:
                box((x + w - 84.0, y, 84.0, h), R_BOX, CONTROL)
        elif k == "bar":
            ty = y + (h - 5.0) * 0.5
            _fill(shader, x * scale, ty * scale, w * scale, 5.0 * scale,
                  2.5 * scale, TRACK)
            span = float(it["hi"] - it["lo"]) or 1.0
            frac = max(0.0, min(1.0, (it["value"] - it["lo"]) / span))
            _fill(shader, x * scale, ty * scale, w * frac * scale,
                  5.0 * scale, 2.5 * scale, ACCENT)
            _fill(shader, (x + w * frac - 7.0) * scale, (ty - 4.5) * scale,
                  14.0 * scale, 14.0 * scale, 7.0 * scale, ACCENT)
        elif k == "ramp":
            ramp = it["ramp"]
            n = len(ramp)
            ty = y + (h - 9.0) * 0.5
            step = w / float(n)
            for i, c in enumerate(ramp):
                _fill(shader, (x + i * step) * scale, ty * scale,
                      (step + 0.8) * scale, 9.0 * scale, 0.0, c)
            frac = max(0.0, min(1.0, (it["value"] - it["lo"])
                                / (float(it["hi"] - it["lo"]) or 1.0)))
            kx = x + w * frac
            _fill(shader, (kx - 6.0) * scale, (ty - 3.0) * scale,
                  12.0 * scale, 15.0 * scale, 6.0 * scale, KNOB)
            _fill(shader, (kx - 4.0) * scale, (ty - 1.0) * scale,
                  8.0 * scale, 11.0 * scale, 4.0 * scale, ACCENT)
        elif k == "rule":
            _fill(shader, x * scale, y * scale, w * scale, 1.0 * scale, 0.0,
                  RULE)
        elif k == "run":
            box(it["rect"], R_CTL, ACCENT_HOVER if lit else ACCENT)
        elif k == "running":
            # the button itself becomes the bar: the track, then the part done
            box(it["rect"], R_CTL, CONTROL)
            done = max(0.0, min(1.0, it["frac"]))
            if done > 0.0:
                box((x, y, max(R_CTL * 2.0, w * done), h), R_CTL, ACCENT)
        elif k == "ghost":
            ring(it["rect"], R_CTL, ACCENT, 1.0,
                 inside=CONTROL_HOVER if lit else CARD)
        elif k in {"btn", "tool", "fold"}:
            box(it["rect"], R_CTL, CONTROL_HOVER if lit else CONTROL)

    for it in widgets:
        k = it["kind"]
        x, y, w, h = it["rect"]
        if k == "title":
            _text(it["text"], x * scale, y * scale, 15, TEXT, scale, bold=True)
        elif k == "label":
            _text(it["text"], x * scale, y * scale, it["size"], it["color"],
                  scale)
        elif k == "section":
            _text(it["text"], x * scale, (y + 3.0) * scale, 10, TEXT_DIM,
                  scale)
        elif k == "chip":
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 12,
                  TEXT if it["on"] else TEXT_DIM, scale,
                  mid=(x + w * 0.5) * scale)
        elif k == "play":
            lit = (widgets.index(it) == hover)
            _text(it["text"], (x + 22.0) * scale, (y + 8.0) * scale, 12,
                  TEXT if lit else TEXT_DIM, scale)
        elif k == "switch":
            _text(it["text"], x * scale, (y + (h - 11.0) * 0.5) * scale, 12,
                  TEXT if it["on"] else TEXT_DIM, scale)
        elif k == "field":
            _text(it["text"], x * scale, (y + 8.0) * scale, 12, TEXT, scale)
            if _typing_here(it):
                caret = "|" if int(time.time() * 2) % 2 else " "
                _text(_state["typing"]["text"] + caret, 0, (y + 8.0) * scale,
                      12, ACCENT, scale, right=(x + w - 12.0) * scale)
            else:
                _text(it["shown"], 0, (y + 8.0) * scale, 12, TEXT, scale,
                      right=(x + w - 12.0) * scale)
        elif k == "fold":
            _text(">" if not it["on"] else "v", (x + 12.0) * scale,
                  (y + 9.0) * scale, 11, TEXT_DIM, scale)
            _text(it["text"], (x + 28.0) * scale, (y + 9.0) * scale, 12,
                  TEXT if it["on"] else TEXT_DIM, scale)
        elif k == "quietfold":
            lit = (widgets.index(it) == hover)
            tint = TEXT if (it["on"] or lit) else TEXT_DIM
            _text(">" if not it["on"] else "v", x * scale,
                  (y + 6.0) * scale, 11, tint, scale)
            _text(it["text"], (x + 14.0) * scale, (y + 6.0) * scale, 11,
                  tint, scale)
        elif k == "run":
            _text(it["text"], 0, (y + (h - 12.0) * 0.5) * scale, 13, ON_ACCENT,
                  scale, mid=(x + w * 0.5) * scale, bold=True)
        elif k == "running":
            _text(it["text"], 0, (y + (h - 12.0) * 0.5) * scale, 13, TEXT,
                  scale, mid=(x + w * 0.5) * scale, bold=True)
        elif k == "runline":
            _text(it["text"], 0, (y + 2.0) * scale, 10, TEXT_DIM, scale,
                  mid=(x + w * 0.5) * scale)
        elif k == "ghost":
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 12, ACCENT,
                  scale, mid=(x + w * 0.5) * scale)
        elif k == "linktext":
            lit = (widgets.index(it) == hover)
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 11,
                  ACCENT if lit else TEXT_DIM, scale,
                  mid=(x + w * 0.5) * scale)
        elif k in {"btn", "tool"}:
            _text(it["text"], 0, (y + (h - 11.0) * 0.5) * scale, 12, TEXT,
                  scale, mid=(x + w * 0.5) * scale)

    if clipped:
        gpu.state.scissor_test_set(False)
        # a hint that there is more, so the foot is not silently lost
        _fill(shader, (cx + cw * 0.5 - 14.0) * scale, (cy + 3.0) * scale,
              28.0 * scale, 3.0 * scale, 1.5 * scale, _ac(0.55))

    _draw_tip(shader, card, scale)
    gpu.state.blend_set("NONE")


# -- the operator that gives it a mouse -------------------------------------

def _redraw(context, area=None):
    """Ask for a repaint - of one area where we know which one.

    A repaint is not cheap: Blender redraws the whole 3D view, model and all,
    to move a highlight by one row. On a 197k face garment that is what the
    pointer felt like it was dragging. So only the area under the pointer is
    asked, and only when something actually changed.
    """
    hot = _state.get("hot_area")
    if hot is not None:
        for win in bpy.context.window_manager.windows:
            for a in win.screen.areas:
                if a.as_pointer() == hot:
                    a.tag_redraw()
                    return
    if area is not None:
        area.tag_redraw()
        return
    for a in context.screen.areas:
        if a.type == "VIEW_3D":
            a.tag_redraw()


def _fire(context, it, mx):
    st = _settings(context)
    kind, arg = it["act"]
    if kind == "group":
        _state["group"] = arg
    elif kind in {"backend", "mode"}:
        setattr(st, kind, arg)
    elif kind == "enum":
        owner, name, code = arg
        setattr(owner, name, code)
    elif kind == "enum_menu":
        try:
            bpy.ops.wm.context_menu_enum("INVOKE_DEFAULT", data_path=arg)
        except Exception as exc:
            _state["note"] = (str(exc)[:44], time.time())
    elif kind == "prop":
        owner, name = arg
        setattr(owner, name, not getattr(owner, name))
    elif kind == "fold":
        if arg in _state["open"]:
            _state["open"].discard(arg)
        else:
            _state["open"].add(arg)
    elif kind == "slide":
        owner, name = arg
        x, y, w, h = it["rect"]
        frac = max(0.0, min(1.0, (mx - x) / max(1.0, w)))
        val = it["lo"] + frac * (it["hi"] - it["lo"])
        setattr(owner, name,
                int(round(val)) if not it.get("decimals") else float(val))
    elif kind == "url":
        if arg:
            try:
                bpy.ops.wm.url_open(url=arg)
            except Exception:
                pass
    elif kind == "op":
        if arg == "__lesson_hard__":
            try:
                from . import LESSON_HARDSURFACE as url
                bpy.ops.wm.url_open(url=url)
            except Exception:
                pass
            return
        if arg == "__lesson__":
            try:
                from . import LESSONS
                found = LESSONS.get("cloth")
            except Exception:
                found = None
            if found:
                try:
                    bpy.ops.wm.url_open(url=found[1])
                except Exception:
                    pass
            return
        mod, _, name = arg.partition(".")
        op = getattr(getattr(bpy.ops, mod, None), name, None)
        if op is None:
            return
        # Most of these want Object Mode, and the card is reachable from
        # Sculpt Mode because Relax puts you there. Pressing Confirm from a
        # brush did nothing at all and said nothing either; now the mode is
        # left first and the action runs, and if it still cannot, the card
        # says why instead of swallowing it.
        try:
            ready = op.poll()
        except Exception:
            ready = False
        obj = context.active_object
        if not ready and obj is not None and obj.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
                ready = op.poll()
            except Exception:
                ready = False
        if not ready:
            _state["note"] = (WHY.get(arg, "that one cannot run here"),
                              time.time())
            return
        try:
            op("INVOKE_DEFAULT")
        except Exception as exc:
            _state["note"] = (str(exc)[:44], time.time())
            print("Smart Remesh card:", exc)


class QUADREMESH_PT_tab(bpy.types.Panel):
    """An empty panel, kept only so the sidebar has a tab to switch to.

    The card is the interface now, and it follows the sidebar's tab. A tab
    with nothing registered under it does not exist, so this holds the name
    open and draws nothing at all - the card fills that space itself.
    """

    bl_label = " "
    bl_idname = "QUADREMESH_PT_tab"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Remesh"
    bl_options = {"HIDE_HEADER"}

    def draw(self, context):
        pass


class QUADREMESH_OT_overlay(bpy.types.Operator):
    """Give the viewport card a mouse. Started on its own, never by hand."""

    bl_idname = "mesh.quadremesh_overlay"
    bl_label = "Viewport Card"
    bl_options = {"INTERNAL"}

    def modal(self, context, event):
        # One card, one modal. The keep-alive below starts a new one when it
        # has heard nothing for a few seconds - which is also what happens
        # when Blender simply sits in the background - and the old one was
        # still there. Found with 76 of them stacked up: every mouse move ran
        # the card's hit test 76 times, the sliders lagged behind the pointer
        # and felt dead. A copy that is not the newest now leaves quietly.
        if getattr(self, "_token", None) != _state.get("token"):
            return {"CANCELLED"}
        _state["beat"] = time.time()
        if _state["quit"]:
            _state["modal"] = False
            return {"CANCELLED"}
        # The pointer's own viewport. The modal belongs to whichever 3D view
        # it was started in, and Blender gives its coordinates relative to
        # that one - so in a split screen every click on the other card
        # landed hundreds of pixels away from where it was aimed. Held while
        # a slider is dragged or a number typed, so the pointer drifting over
        # the border does not swap cards half way.
        hot_area = None
        hot_region = None
        busy = _state["drag"] is not None or _state["typing"] is not None
        for a in context.window.screen.areas:
            if a.type != "VIEW_3D":
                continue
            for r in a.regions:
                if r.type != "WINDOW":
                    continue
                if busy:
                    if r.as_pointer() == _state.get("hot"):
                        hot_area, hot_region = a, r
                elif (r.x <= event.mouse_x < r.x + r.width
                        and r.y <= event.mouse_y < r.y + r.height):
                    hot_area, hot_region = a, r
        if hot_region is not None:
            key = hot_region.as_pointer()
            laid = _state.get("regions", {}).get(key)
            if laid is not None and key != _state.get("hot"):
                _state["hot"] = key
                _state["widgets"], _state["card"] = laid
                _state["hover"] = None
                _state["tip"] = None
            _state["hot_area"] = hot_area.as_pointer()
        if not _visible(context, hot_area):
            if _state["typing"] is not None:
                _stop_typing(context, False)
            if _state["hover"] is not None:
                _state["hover"] = None
                _state["drag"] = None
                _state["tip"] = None
            # Clicking another tab in the sidebar repaints the sidebar and
            # nothing else, so the card's own handler is never called again
            # and the last painting of it just stays on the screen. Blender's
            # panels vanish because they live in the region that was
            # repainted; the card does not, so it has to ask.
            if _state["was_up"]:
                _state["was_up"] = False
                _redraw(context, getattr(context, "area", None))
            return {"PASS_THROUGH"}
        if not _state["was_up"]:
            # Coming back to our tab repaints the sidebar and nothing else, so
            # without this the card waited for the next viewport redraw to
            # appear - a mouse move, or the timer below. That wait is what
            # read as the card opening late, or not at all until the sidebar
            # was closed and opened again.
            _state["was_up"] = True
            _redraw(context, getattr(context, "area", None))

        scale = context.preferences.system.ui_scale or 1.0
        if hot_region is not None:
            mx = (event.mouse_x - hot_region.x) / scale
            my = (event.mouse_y - hot_region.y) / scale
        else:
            mx = event.mouse_region_x / scale
            my = event.mouse_region_y / scale

        # A box open for typing owns the keyboard until it is closed, or a
        # digit would reach Blender as a shortcut and change the mode.
        if _state["typing"] is not None:
            if event.value != "PRESS":
                return {"RUNNING_MODAL"}
            if event.type in {"RET", "NUMPAD_ENTER"}:
                _stop_typing(context, True)
                return {"RUNNING_MODAL"}
            if event.type == "ESC":
                _stop_typing(context, False)
                return {"RUNNING_MODAL"}
            if event.type == "BACK_SPACE":
                t = _state["typing"]
                t["text"] = "" if t.get("fresh") else t["text"][:-1]
                t["fresh"] = False
                _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if event.type == "LEFTMOUSE":
                _stop_typing(context, True)   # clicking away keeps it
                return {"RUNNING_MODAL"}
            ch = event.ascii
            if ch and (ch.isdigit() or ch in "-."):
                # The box opens showing the current value, selected the way
                # Blender's own fields open. The first key replaces it: typing
                # 10000 into a box that read 7262 used to give 726210000,
                # which was then clamped to the maximum and looked like the
                # typing had been ignored.
                t = _state["typing"]
                if t.get("fresh"):
                    t["text"] = ""
                    t["fresh"] = False
                t["text"] += ch
                _redraw(context, context.area)
            return {"RUNNING_MODAL"}
        widgets = _state["widgets"]
        over = _hit(widgets, mx, my)

        if _state["drag"] is not None:
            if event.type == "MOUSEMOVE":
                it = (widgets[_state["drag"]]
                      if _state["drag"] < len(widgets) else None)
                if it is not None:
                    _fire(context, it, mx)
                    _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if event.type == "LEFTMOUSE" and event.value == "RELEASE":
                it = (widgets[_state["drag"]]
                      if _state["drag"] < len(widgets) else None)
                _state["drag"] = None
                # The colour is meant to outlast the session. Blender only
                # writes preferences out by itself when auto-save is on, so
                # the file is written here, once, when the knob is let go.
                if it is not None and (it["kind"] == "ramp"
                                      or it.get("save")):
                    try:
                        bpy.ops.wm.save_userpref()
                    except Exception:
                        pass
                return {"RUNNING_MODAL"}
            return {"RUNNING_MODAL"}

        if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            # Only when the pointer is on the card, and only when there is
            # something to reach. Anywhere else the wheel is the viewport's.
            card = _state.get("card")
            if (_state["over"] > 0.0 and card is not None
                    and card[0] <= mx <= card[0] + card[2]
                    and card[1] <= my <= card[1] + card[3]):
                step = 48.0 if event.type == "WHEELDOWNMOUSE" else -48.0
                was = _state["scroll"]
                _state["scroll"] = min(max(0.0, was + step), _state["over"])
                if _state["scroll"] != was:
                    _redraw(context, getattr(context, "area", None))
                return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}

        if event.type == "MOUSEMOVE":
            if over != _state["hover"]:
                _state["hover"] = over
                key = None
                if over is not None:
                    key = widgets[over].get("tip")
                _state["tip"] = ((over, key, time.time())
                                 if key is not None else None)
                if _state["tip"] is not None and not _state["ticking"]:
                    _state["ticking"] = True
                    if not bpy.app.timers.is_registered(_tick):
                        bpy.app.timers.register(_tick, first_interval=TIP_DELAY)
                # Sweeping across the card crosses a row every few pixels, and
                # a frame for each of those is a frame of the whole viewport.
                # Twenty-five a second is smooth and is a third of the cost.
                now = time.time()
                wait = max(0.04, _state["cost"] * 1.5)
                if now - _state["painted"] > wait:
                    _state["painted"] = now
                    _state["asked"] = now
                    _state["dirty"] = False
                    _redraw(context, context.area)
                else:
                    _state["dirty"] = True
                    if not bpy.app.timers.is_registered(_settle):
                        bpy.app.timers.register(_settle, first_interval=wait)
            return {"PASS_THROUGH"} if over is None else {"RUNNING_MODAL"}

        if over is None:
            return {"PASS_THROUGH"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            it = widgets[over]
            if "act" not in it:
                return {"RUNNING_MODAL"}      # a label, not a button
            kind, arg = it["act"]
            if kind == "type":
                fx, fy, fw, fh = it["rect"]
                if mx < fx + fw - 84.0:
                    return {"RUNNING_MODAL"}  # the words, not the number
                owner, prop, lo, hi, decimals = arg
                val = getattr(owner, prop)
                _state["typing"] = {
                    "owner": owner, "prop": prop, "lo": lo, "hi": hi,
                    "decimals": decimals, "save": bool(it.get("save")),
                    "fresh": True,
                    "text": (str(int(val)) if not decimals
                             else ("%.*f" % (decimals, val))),
                }
                _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if (kind == "prop" and isinstance(arg, tuple)
                    and arg[0] is _prefs()):
                _fire(context, it, mx)
                try:
                    bpy.ops.wm.save_userpref()
                except Exception:
                    pass
                _redraw(context, context.area)
                return {"RUNNING_MODAL"}
            if it["kind"] in {"bar", "ramp"}:
                _state["drag"] = over
            _fire(context, it, mx)
            _redraw(context, context.area)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE":
            return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}

    def cancel(self, context):
        # Blender ends a modal on its own for plenty of reasons - a file load,
        # a window closing, an error anywhere in the chain. Without this the
        # flag stayed set, the keep-alive saw a live modal that was not there,
        # and the card went on drawing while nothing on it could be clicked.
        if getattr(self, "_token", None) == _state.get("token"):
            _state["modal"] = False

    def invoke(self, context, event):
        if _state["modal"]:
            return {"CANCELLED"}
        _state["modal"] = True
        _state["token"] = _state.get("token", 0) + 1
        self._token = _state["token"]
        _state["beat"] = time.time()
        _state["hover"] = None
        _state["drag"] = None
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


def _showing():
    """Is the card up somewhere, without needing a draw to ask?"""
    prefs = _prefs()
    if prefs is not None and getattr(prefs, "classic_panel", False):
        return False
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                space = area.spaces.active
                if not getattr(space, "show_region_ui", False):
                    continue
                for r in area.regions:
                    if (r.type == "UI" and r.width >= 60
                            and getattr(r, "active_panel_category", "") == TAB):
                        return True
    except Exception:
        pass
    return False


def _keep_alive():
    """Start the card's modal, and start it again if it ever drops.

    A modal dies with a file load or a window closing, and the card would go
    quiet with the tab still open. One cheap check a second brings it back
    without anyone noticing it went.
    """
    if _state["quit"]:
        return None
    # A modal that died without saying so. The old test asked whether the card
    # had been painted in the last two seconds, on the reasoning that a fresh
    # paint means the pointer is over it - but a dead modal is exactly what
    # stops anything asking for a paint, so the card that most needed reviving
    # was the one this could never see. An add-on update leaves one behind
    # every time. Now the only question is whether the card is up and whether
    # anything has reached it lately.
    now = time.time()
    if (_state["modal"] and _state["handle"] is not None
            and now - _state["beat"] > 5.0 and _showing()):
        _state["modal"] = False
    # The same check once a second, for the case where the pointer left the
    # viewport before the tab changed and the modal sees no events at all.
    up = _showing()
    if up != _state["was_up"]:
        _state["was_up"] = up
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    if not _state["modal"]:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                region = next((r for r in area.regions if r.type == "WINDOW"),
                              None)
                if region is None:
                    continue
                try:
                    with bpy.context.temp_override(window=win, area=area,
                                                   region=region):
                        bpy.ops.mesh.quadremesh_overlay("INVOKE_DEFAULT")
                except Exception:
                    pass
                break
            if _state["modal"]:
                break
    # Five times a second, not once: this is the only thing watching for a
    # tab change when the pointer is not in the viewport at all, and a whole
    # second of the card being missing is a second of it looking broken. The
    # check itself is a few attribute reads.
    return 0.2


def clear():
    """Take the card down, whoever is asking."""
    if _state["handle"] is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_state["handle"],
                                                      "WINDOW")
        except Exception:
            pass
    _state["handle"] = None
    bpy.app.driver_namespace.pop(_CARD_HANDLE, None)
    _state["widgets"] = []
    _state["hover"] = None
    _state["drag"] = None
    _state["tip"] = None


def is_on():
    return bool(_state["handle"])


CLASSES = (QUADREMESH_OT_overlay, QUADREMESH_PT_tab)


_CARD_HANDLE = "quadremesh_card_draw_handle"


def _drop_stale_card():
    """Remove a card handler left behind by an earlier load of this module."""
    ns = bpy.app.driver_namespace
    old = ns.pop(_CARD_HANDLE, None)
    if old is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(old, "WINDOW")
        except Exception:
            pass


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    retint()
    _state["quit"] = False
    # The only reference to a draw handler used to live in this module, so a
    # reload that lost the module lost the handler with it - and the old card
    # went on painting underneath the new one, two cards deep. The handle is
    # kept somewhere that outlives the module instead, and any handle found
    # there is taken down before a new one goes up.
    _drop_stale_card()
    _state["handle"] = bpy.types.SpaceView3D.draw_handler_add(
        _draw, (), "WINDOW", "POST_PIXEL")
    bpy.app.driver_namespace[_CARD_HANDLE] = _state["handle"]
    if not bpy.app.timers.is_registered(_keep_alive):
        bpy.app.timers.register(_keep_alive, first_interval=0.5,
                                persistent=True)


def unregister():
    # A handler left drawing after the module is gone cannot be reached to
    # switch off, so the card comes down before anything is unregistered.
    _state["quit"] = True
    try:
        if bpy.app.timers.is_registered(_keep_alive):
            bpy.app.timers.unregister(_keep_alive)
    except Exception:
        pass
    try:
        clear()
    except Exception:
        pass
    try:
        forget_posters()
    except Exception:
        pass
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
