"""Live feature-line preview with hand-adjustable thresholds.

The expensive part of detection is cached per mesh, so dragging a slider only
re-applies the thresholds and rebuilds the line object - fast enough to watch
the lines move while you drag.
"""

from __future__ import annotations

import json
import math
from mathutils.geometry import intersect_point_line
import os
from collections import defaultdict

import numpy as np

import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       StringProperty, IntProperty)
from bpy.types import Operator, Panel, PropertyGroup

from .core import hardsurface as HS
from .core import prune as PR
from .core import panelize as PZ

_CACHE: dict = {}
SUFFIX = "_FEATURELINES"

# Live refresh is not a setting, so it is not stored anywhere. It used to be a
# scene property with a checkbox; the checkbox came off because it is never a
# choice, and then the value stuck at False - leaving no way to turn it back on
# and making the add-on look like it had stopped responding to every slider.
# A counter that only exists in memory cannot get stuck: whatever happens, the
# next Blender session starts at zero.
_suspend = 0


class suspend_live:
    """Batch several property writes into one rebuild."""

    def __enter__(self):
        global _suspend
        _suspend += 1
        return self

    def __exit__(self, *exc):
        global _suspend
        _suspend = max(0, _suspend - 1)
        return False


def _straight_loops(bm, tol_world, protect=None):
    """Loops whose removal moves the surface by less than `tol_world`.

    An angle test cannot do this job. On a fillet the segments differ by a
    fixed angle - a 90 degree corner in twelve steps is 7.5 degrees a step -
    so any threshold raised past that eats the fillet itself and the form
    collapses. What the question actually is: if this loop goes, how far does
    the surface move? Dissolving a loop leaves the two rows either side joined
    straight across, so the error is the distance from each removed vertex to
    the segment between its neighbours on the rows either side. That is the
    sagitta of the arc the loop was describing, in millimetres, and comparing
    it to a distance is the only test that answers "does the form change".

    A loop is still one decision: the worst vertex on it decides the whole
    line, so a loop never comes out half removed with the rows staggered.
    """
    def step(e, v):
        """Next edge of the ring across `v`, or (None, None) at a stop."""
        if len(v.link_edges) != 4:
            return None, None
        ef = set(e.link_faces)
        cand = [x for x in v.link_edges
                if x is not e and not (set(x.link_faces) & ef)]
        if len(cand) != 1:
            return None, None
        return cand[0], cand[0].other_vert(v)

    def cost(v, loop_edges):
        """How far `v` moves off the surface once the loop is gone."""
        side = [e for e in v.link_edges if e not in loop_edges]
        if len(side) != 2:
            return None                      # not a clean interior of a ring
        a = side[0].other_vert(v)
        b = side[1].other_vert(v)
        ab = b.co - a.co
        L = ab.length
        if L < 1e-12:
            return None
        t = max(0.0, min(1.0, (v.co - a.co).dot(ab) / (L * L)))
        return (v.co - (a.co + ab * t)).length

    seen, out, blocked = set(), [], set()
    for e0 in bm.edges:
        if e0.index in seen or len(e0.link_faces) != 2:
            continue
        chain, verts = [e0], set(e0.verts)
        seen.add(e0.index)
        closed = False
        for start in (e0.verts[0], e0.verts[1]):
            e, v = e0, start
            while True:
                e, v = step(e, v)
                if e is None:
                    break
                if e is e0:
                    closed = True
                    break
                if e.index in seen:
                    break
                seen.add(e.index)
                chain.append(e)
                verts.update(e.verts)
            if closed:
                break
        eset = set(chain)
        ok = all(v.index not in blocked for v in verts)
        if ok and protect is not None:
            # a line the user marked is never "changing nothing" - on a flat
            # panel the dissolve read 71 of his 549 lines that way and ate them
            if any(e[protect] for e in chain):
                ok = False
            else:
                # the ring crosses a user line at some of its vertices, and
                # dissolving takes those vertices with it. Fine where the
                # line runs straight through - it is simply merged - but at
                # a corner of the line the corner itself would go: the 11
                # long box edges that still vanished were exactly those.
                for v in verts:
                    ue = [x for x in v.link_edges if x[protect]]
                    if not ue:
                        continue
                    if len(ue) == 2:
                        a = ue[0].other_vert(v).co - v.co
                        b = ue[1].other_vert(v).co - v.co
                        if a.length > 1e-12 and b.length > 1e-12                                 and a.angle(b) >= math.radians(179.0):
                            continue
                    ok = False
                    break
        if ok:
            for v in verts:
                c = cost(v, eset)
                if c is None or c >= tol_world:
                    ok = False
                    break
        if ok:
            out.extend(chain)
            # Two neighbouring loops must not go in the same pass. Each was
            # measured against the surface as it stands, so taking both at once
            # adds their errors together - that is what flattened the fillet:
            # every ring qualified on its own and the corner vanished when they
            # all went at once. Block the rows either side and let the next
            # pass re-measure what is left.
            for v in verts:
                blocked.add(v.index)
                for e in v.link_edges:
                    if e not in eset:
                        blocked.add(e.other_vert(v).index)
    return out


def _refit_circles(bm, src_obj):
    """Push the reduced surface back out so a circle keeps its true size.

    Dropping a ring from 24 segments to 8 leaves an octagon *inscribed* in the
    original circle. Every vertex is still exactly on the surface, but every
    chord between them cuts inside it, so the part comes out thinner than it
    is - the whole error sits on one side. Blender's LoopTools "Circle" is the
    manual version of the fix.

    Fitting circles to edge rings was the obvious way and it does not survive
    the dissolve: measured on the espresso machine's largest part, 486 rings
    walked, 3 still closed and 1 still round, because the loops are broken up
    by then. So the compensation is measured against the source surface
    instead, which needs no rings and works on any curved shape rather than
    only on true circles.

    For each face, the distance from its centre to the original surface *is*
    the sagitta it is cutting. Moving the face's vertices out by half of that
    splits the error either side of the true surface instead of leaving all of
    it inside, which halves the worst deviation and costs no geometry.
    """
    from mathutils.bvhtree import BVHTree

    me = source_mesh(src_obj)
    verts = [Vector(v.co) for v in me.vertices]
    tris = []
    for p in me.polygons:
        idx = list(p.vertices)
        for j in range(1, len(idx) - 1):
            tris.append((idx[0], idx[j], idx[j + 1]))
    bvh = BVHTree.FromPolygons(verts, tris, all_triangles=True)

    acc = {}
    for f in bm.faces:
        # Only the small faces that tile a curved region. A flat panel arrives
        # as one big n-gon and its centre is legitimately nowhere near the
        # surface - a ring around a bolt hole has its centre out in the hole -
        # so measuring a sagitta there is meaningless. Left in, it pushed the
        # worst error on one part from 0.7 mm to 8.7 mm.
        if len(f.verts) > 4:
            continue
        c = f.calc_center_median()
        loc, nor, _i, dist = bvh.find_nearest(c)
        if loc is None or dist is None or dist <= 0.0:
            continue
        span = f.calc_perimeter() / max(len(f.verts), 1)
        if span <= 0.0 or dist > 0.25 * span:
            continue          # too far to be this face's own chord error
        off = (loc - c) * 0.5
        for v in f.verts:
            a = acc.get(v.index)
            acc[v.index] = (off.copy(), 1) if a is None else (a[0] + off, a[1] + 1)

    moved = 0
    for v in bm.verts:
        a = acc.get(v.index)
        if a is None:
            continue
        d = a[0] / a[1]
        if d.length > 1e-9:
            v.co = v.co + d
            moved += 1
    return moved


PZ_DROP_KEY = "quadremesh_drop_orig"
PZ_VAL_KEY = "quadremesh_valence_orig"
PZ_FLAT_KEY = "quadremesh_flat_orig"
PZ_AXIS_KEY = "quadremesh_axis_matrix"
PZ_AXIS_MESH = "quadremesh_axis_mesh"
# The very first mesh the drop ever saw on this object. Confirm advances the
# working baseline and deletes it; this one nothing touches, so there is
# always a way back to the true start - without it, one Confirm on an uneven
# result locked the unevenness in for good.
PZ_FIRST_KEY = "quadremesh_drop_first"
PZ_ORIG_KEY = "quadremesh_clean_orig"
# The step stash is dropped on every Confirm, so it cannot answer "put the
# whole thing back". This second snapshot is taken once, the first time the
# object is cleaned at all, and survives every Confirm until it is used.
PZ_BASE_KEY = "quadremesh_clean_base"


def _remember_base(obj, mesh):
    """Snapshot the object as it was before any cleaning, once."""
    if obj.get(PZ_BASE_KEY) and bpy.data.meshes.get(obj[PZ_BASE_KEY]):
        return
    base = mesh.copy()
    base.name = mesh.name + "_cleanbase"
    base.use_fake_user = True
    obj[PZ_BASE_KEY] = base.name


def _clean_apply(obj, st):
    """Restore the pre-clean mesh, then clean it at the current percentage.

    Working from the stash each time is what makes the slider live: dissolving
    the already-dissolved result would compound on every drag and there would
    be no way back to a lower setting.

    Edit Mode has to go through the live bmesh - writing to `obj.data` while
    the mesh is open for editing is thrown away the moment Blender syncs, which
    is why dragging the slider in Edit Mode appeared to do nothing at all.
    """
    stash = bpy.data.meshes.get(obj.get(PZ_ORIG_KEY) or "")
    if stash is None:
        return None

    editing = obj.mode == "EDIT"
    if editing:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.clear()
        bm.from_mesh(stash)
    else:
        bm = bmesh.new()
        bm.from_mesh(stash)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    PZ.tag_marked(bm)
    region_edges = PZ.enclosed_interior(bm, require_selected=True)
    doomed = PZ.thin_out(region_edges, st.pz_amount)
    limit = set(region_edges) if st.pz_confine else None
    before = len(bm.faces)
    if doomed:
        # the vertices of a removed loop go with it: the old angle rule kept
        # every one that sat on a curve, and Milad's cleaned area came back
        # dotted with them
        PZ.dissolve_keeping_rims(bm, doomed, region=PZ.region_faces(bm),
                                 polish=True)
    bm.normal_update()
    PZ.heal_stubs(bm, confine=limit)
    PZ.polish_verts(bm, uv_layers=list(bm.loops.layers.uv.values()))
    if editing:
        after = len(bm.faces)
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    else:
        bm.to_mesh(obj.data)
        after = len(obj.data.polygons)
        bm.free()
        obj.data.update()
    return before, after


def _pz_live(self, context):
    """Re-clean as the percentage slider moves."""
    if _suspend:
        return
    obj = context.active_object
    if obj is None or obj.type != "MESH":
        return
    if not obj.get(PZ_ORIG_KEY):
        # First move of the slider stands in for pressing the button, so the
        # result can be dialled in without a separate step. Only worth doing
        # when there is a selection to bound the area.
        if obj.mode == "EDIT":
            live = bmesh.from_edit_mesh(obj.data)
            if not any(e.select for e in live.edges):
                return
            stash = bpy.data.meshes.new(obj.data.name + "_preclean")
            live.to_mesh(stash)
            _remember_base(obj, stash)
        else:
            if not any(e.select for e in obj.data.edges):
                return
            stash = obj.data.copy()
            stash.name = obj.data.name + "_preclean"
            _remember_base(obj, stash)
        stash.use_fake_user = True
        obj[PZ_ORIG_KEY] = stash.name
    res = _clean_apply(obj, self)
    if res:
        self.build_info = f"{res[0]} -> {res[1]} faces  |  {self.pz_amount:.0f}%"


def _shade_from(obj, base):
    """Give the thinned mesh the shading of the dense one it came from.

    The drop leaves n-gons over a curved surface and their interpolated
    normals band; projecting the dense mesh's corner normals onto the result
    restores the original look. NEAREST_POLYNOR picks the source face whose
    normal agrees with the face the corner sits on, so a corner on a flat top
    never borrows from the bevel one edge over - the nearest-point mapping
    did exactly that and drew radial streaks across every flat.
    The transfer runs in world space, so the
    stand-in source object must sit exactly where the target sits - Milad's
    part is scaled 0.033, and without copying the matrix the source was
    thirty times its size and every borrowed normal came from the wrong
    place, rendering the model near black.
    """
    if base is None or len(base.polygons) == 0:
        return
    src = bpy.data.objects.new("qr_shade_src", base)
    bpy.context.scene.collection.objects.link(src)
    src.matrix_world = obj.matrix_world.copy()
    try:
        with bpy.context.temp_override(
                object=src, active_object=src,
                selected_editable_objects=[src, obj]):
            bpy.ops.object.data_transfer(
                data_type="CUSTOM_NORMAL",
                loop_mapping="NEAREST_POLYNOR",
                use_create=True)
    finally:
        bpy.data.objects.remove(src, do_unlink=True)
    # One normal per vertex, not one per corner. The transfer picks a source
    # face per corner, and two corners of the same vertex can come home with
    # slightly different answers - the mismatch renders as a faint line down
    # every kept edge. Vertices on a sharp crease keep their split, that is
    # what a crease is.
    me = obj.data
    sharp_verts = set()
    for e in me.edges:
        if e.use_edge_sharp:
            sharp_verts.update(e.vertices)
    acc = {}
    for l in me.loops:
        acc.setdefault(l.vertex_index, []).append(l.normal.copy())
    avg = {v: sum(ns, Vector()).normalized() for v, ns in acc.items()}
    me.normals_split_custom_set(
        [l.normal if l.vertex_index in sharp_verts else avg[l.vertex_index]
         for l in me.loops])


def _confine_to_selection(bm):
    """Keep the drop inside whatever is selected, if anything is.

    Select Axis Loops shows exactly which lines are in play; Flat Below and
    Remove Per Kept then decide how many of those to take. Without this the
    two had nothing to do with each other - the selection said one thing and
    the drop went and did another.

    Everything outside the selection is marked, which is what the pool
    already skips, so no other machinery has to know about this. A selection
    covering the whole mesh means "no target", the same rule `tag_marked`
    uses, since Blender leaves a mesh fully selected as a matter of course.
    """
    total = len(bm.edges)
    sel = 0
    for e in bm.edges:
        if e.select:
            sel += 1
    if not (0 < sel < total * 0.9):
        return 0
    for e in bm.edges:
        if not e.select:
            e.tag = True
    return sel


def _drop_apply(obj, st):
    """Redo the loop drop from the stored baseline at the current settings."""
    base = bpy.data.meshes.get(obj.get(PZ_DROP_KEY) or "")
    if base is None:
        return None
    editing = obj.mode == "EDIT"
    if editing:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.clear()
        bm.from_mesh(base)
    else:
        bm = bmesh.new()
        bm.from_mesh(base)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    # With an axis filter on, the selection is what Select Axis Loops
    # just made - the target, not something to spare. Reading it as a
    # mark protected the very lines the drop was aimed at, so it went
    # and took others instead.
    # Protect UV walls the walk off again, at Milad's word. Taking the
    # loops whole across the seams and mending afterwards did give an
    # even pattern, but the mend cannot put the texture back: a face
    # merged across a seam carries only one side's coordinates, and 11
    # faces in 410 came out showing the wrong patch of the map. That
    # was fixable by baking, but the original is gone by then in his
    # pipeline, so the texture has to survive the drop itself.
    PZ.tag_marked(bm, keep_seams=st.pz_keep_seams,
                  uv_layers=list(bm.loops.layers.uv.values()),
                  use_selection=False)
    _confine_to_selection(bm)
    before = len(bm.faces)
    # The two removals are independent tools: Flat Below at 0 is off, so
    # Take 1 in can run alone and its pattern is not eaten first by the
    # flat pass - with both at work, flat had already taken every Y loop
    # and the pattern was left nothing to count.
    # The pattern goes first, while the grid is still whole. After the flat
    # pass every removed ring leaves T-junctions on the lines that cross it,
    # the walk fragments into thousands of partial runs, and whole-or-nothing
    # spares them all - which is how a doubled line outlived every setting.
    dropped = partial = 0
    if st.pz_every >= 1:
        doomed, n2 = PZ.thin_every(
            bm, st.pz_every, keep_marked=st.pz_keep_marked,
            axes=(st.pz_axis_x, st.pz_axis_y, st.pz_axis_z),
            rot=obj.matrix_world.to_3x3())
        if doomed:
            PZ.dissolve_keeping_rims(bm, doomed, polish=True)
            PZ.heal_stubs(bm)
            PZ.polish_verts(
                bm, uv_layers=list(bm.loops.layers.uv.values()))
            dropped += n2
    if st.pz_useless > 0.0:
        n1, partial = PZ.drop_loops(
            bm, tol_deg=st.pz_useless, keep_marked=st.pz_keep_marked,
            sag_pct=0.0,
            axes=(st.pz_axis_x, st.pz_axis_y, st.pz_axis_z),
            rot=obj.matrix_world.to_3x3())
        dropped += n1
    PZ.polish_verts(bm, uv_layers=list(bm.loops.layers.uv.values()))
    if editing:
        after = len(bm.faces)
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    else:
        bm.to_mesh(obj.data)
        after = len(obj.data.polygons)
        bm.free()
        obj.data.update()
        _shade_from(obj, base)
    return before, after, dropped


def _axis_live(self, context):
    """Ticking an axis re-does the selection, and nothing else.

    Nothing is removed - Milad reached for the axis buttons to aim a
    selection and used to lose his loops before he could press anything.

    But leaving it to do nothing at all was its own trap: the drop works on
    what is selected, so changing the axis without pressing Select again
    left Y's lines selected while the panel said X, and the drop reported
    "0 loops dropped" because not one loop in the pool was an X loop. The
    tick and the selection have to agree.
    """
    obj = context.active_object
    if obj is None or obj.type != "MESH" or not len(obj.data.polygons):
        return
    st = context.scene.quadremesh_lines
    if not any((st.pz_axis_x, st.pz_axis_y, st.pz_axis_z)):
        return
    try:
        bpy.ops.mesh.quadremesh_select_axis_loops()
    except Exception as exc:
        print("[quadremesh] axis select skipped:", exc)


def _clean_apply(obj, st, base):
    """Rebuild `obj` from `base` with the cleanup settings as they now stand.

    Always from the baseline, never from the last result - the same thing
    that makes the loop drop live. Sweep and Weld both run here, in that
    order, so moving either slider shows the whole outcome rather than one
    more layer on top of the last.
    """
    bm = bmesh.new()
    bm.from_mesh(base)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    rejoined = 0
    try:
        from .core import uvheal
        for lay in bm.loops.layers.uv.values():
            rejoined += uvheal._rejoin(bm, lay)
    except Exception as exc:
        print("[quadremesh] rejoin skipped:", exc)
    PZ.tag_marked(bm, keep_seams=st.pz_keep_seams,
                  uv_layers=list(bm.loops.layers.uv.values()))
    before = len(bm.faces)
    gone = PZ.sweep_flat(bm, amount=st.pz_sweep_amt,
                         keep_marked=st.pz_keep_marked)
    welded = 0
    if st.pz_weld_dist > 0.0:
        n0 = len(bm.verts)
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=st.pz_weld_dist)
        welded = n0 - len(bm.verts)
    PZ.min_three_edges(bm)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    _heal_uv(obj.data)
    ngon = sum(1 for pg in obj.data.polygons if pg.loop_total > 4)
    return (f"{before} -> {len(obj.data.polygons)} faces  |  "
            f"{gone} swept, {welded} welded, {ngon} n-gons"
            + (f", {rejoined} lone UV faces rejoined" if rejoined else ""))


def _clean_baseline(obj):
    """The mesh the cleanup sliders work from, made on first use."""
    base = bpy.data.meshes.get(obj.get(PZ_VAL_KEY) or "")
    if base is None:
        base = obj.data.copy()
        base.name = obj.data.name + "_prevalence"
        base.use_fake_user = True
        obj[PZ_VAL_KEY] = base.name
    return base


def _clean_live(self, context):
    """Redo the cleanup as its sliders move."""
    if _suspend:
        return
    obj = context.active_object
    if obj is None or obj.type != "MESH" or not len(obj.data.polygons):
        return
    if obj.mode == "EDIT":
        return
    try:
        _clean_apply(obj, context.scene.quadremesh_lines,
                     _clean_baseline(obj))
    except Exception as exc:
        print("[quadremesh] live cleanup skipped:", exc)


def _drop_live(self, context):
    """Redo the drop as its settings move.

    Cheap to do live because the drop always works from the baseline rather
    than from its own last result - the same thing that makes pressing the
    button twice a no-op.
    """
    if _suspend:
        return
    obj = context.active_object
    if obj is None or obj.type != "MESH":
        return
    if not obj.get(PZ_DROP_KEY):
        # first move of a slider stands in for pressing the button
        if obj.mode == "EDIT":
            live = bmesh.from_edit_mesh(obj.data)
            base = bpy.data.meshes.new(obj.data.name + "_predrop")
            live.to_mesh(base)
        else:
            base = obj.data.copy()
            base.name = obj.data.name + "_predrop"
        base.use_fake_user = True
        obj[PZ_DROP_KEY] = base.name
        if not obj.get(PZ_FIRST_KEY):
            first = base.copy()
            first.name = obj.data.name + "_dropstart"
            first.use_fake_user = True
            obj[PZ_FIRST_KEY] = first.name
    res = _drop_apply(obj, self)
    if res:
        self.build_info = (f"{res[2]} loops dropped  |  "
                           f"{res[0]} -> {res[1]} faces")


def marked_mask(obj, cache):
    """Edges the user marked Sharp, as a mask over the analysis edge list.

    The cache indexes the source mesh's own vertices, so a marked edge is
    found by its vertex pair. Feeding these into the same mask the detector
    produces means the user's lines go through the whole Hardsurface pipeline -
    prune, panel building, chamfer - instead of a second dissolve of their own.
    """
    src = source_mesh(obj)
    E = cache["edges"]
    lookup = {}
    for i, (a, b) in enumerate(E.tolist()):
        lookup[(a, b) if a < b else (b, a)] = i
    out = np.zeros(len(E), dtype=bool)
    n = 0
    # Read the selection as well as Mark Sharp. Selecting edges is what people
    # reach for first, and reading only the sharp flag made the feature look
    # broken for anyone who had not also marked them.
    #
    # Unless the whole model is selected. A mesh that has just been imported,
    # separated in Edit Mode or built by script arrives with every edge
    # selected, and that is not a choice anyone made - but read as one it says
    # keep every line, so the rebuild hands back exactly what it was given and
    # the tool looks stone dead. Measured on Milad's train: 244 of 244 edges
    # selected, 244 counted as his own lines, 127 faces in and 127 out.
    total = len(src.edges)
    picked = sum(1 for e in src.edges if e.select)
    read_sel = total == 0 or picked < total * 0.95
    cache["sel_ignored"] = not read_sel and picked > 0
    for e in src.edges:
        if not (e.use_edge_sharp or (read_sel and e.select)):
            continue
        a, b = e.vertices
        i = lookup.get((a, b) if a < b else (b, a))
        if i is not None:
            out[i] = True
            n += 1

    # And the marks made on what the object is actually showing. With Replace
    # Original on that is the previous result, which shares no numbering with
    # the mesh being analysed, so index lookup finds nothing - 14 edges marked
    # Sharp on Milad's train part, 0 counted. A line on the result also spans
    # a whole run of source edges, so this goes by geometry: every analysis
    # edge lying along the marked segment is marked with it.
    shown = obj.data
    if shown is not src and len(shown.edges):
        n += _marks_by_position(shown, cache, lookup, out)
    return out, n


def _marks_by_position(shown, cache, lookup, out):
    from mathutils.kdtree import KDTree
    from mathutils import Vector
    from mathutils.geometry import intersect_point_line

    V = cache["V"]
    E = cache["edges"]
    if not len(E):
        return 0
    nv = len(shown.vertices)
    sco = np.empty(nv * 3, dtype=np.float64)
    shown.vertices.foreach_get("co", sco)
    sco = sco.reshape(nv, 3)
    span = float(np.linalg.norm(V.max(0) - V.min(0))) or 1.0
    tol = span * 2e-4

    total = len(shown.edges)
    picked = sum(1 for e in shown.edges if e.select)
    read_sel = total == 0 or picked < total * 0.95
    wanted = [e for e in shown.edges
              if e.use_edge_sharp or (read_sel and e.select)]
    if not wanted:
        return 0

    mid = (V[E[:, 0]] + V[E[:, 1]]) * 0.5
    tree = KDTree(len(mid))
    for i, c in enumerate(mid.tolist()):
        tree.insert(c, i)
    tree.balance()

    n = 0
    for e in wanted:
        a = Vector(sco[e.vertices[0]].tolist())
        b = Vector(sco[e.vertices[1]].tolist())
        half = (b - a).length * 0.5
        if half <= 0.0:
            continue
        centre = (a + b) * 0.5
        for _co, i, _d in tree.find_range(centre, half + tol):
            if out[i]:
                continue
            m = Vector(((V[E[i, 0]] + V[E[i, 1]]) * 0.5).tolist())
            _q, t = intersect_point_line(m, a, b)
            t = min(max(t, 0.0), 1.0)
            if (m - a.lerp(b, t)).length < tol:
                out[i] = True
                n += 1
    return n


def uv_seam_mask(obj, cache):
    """The UV cuts of the source, as a mask over the analysis edge list.

    An edge is a cut where the two faces either side disagree about a shared
    corner's UV, or where there is only one face. Read from arrays: walking
    the RNA per polygon costs more than the rest of the detection put
    together on a middling model.
    """
    src = source_mesh(obj)
    if not src.uv_layers or not len(src.polygons):
        return None
    layer = next((l for l in src.uv_layers if l.active_render),
                 src.uv_layers[0])
    nl = len(src.loops)
    uv = np.empty(nl * 2, dtype=np.float32)
    layer.data.foreach_get("uv", uv)
    uv = uv.reshape(nl, 2)
    lvert = np.empty(nl, dtype=np.int32)
    src.loops.foreach_get("vertex_index", lvert)
    nf = len(src.polygons)
    lstart = np.empty(nf, dtype=np.int32)
    src.polygons.foreach_get("loop_start", lstart)
    ltotal = np.empty(nf, dtype=np.int32)
    src.polygons.foreach_get("loop_total", ltotal)

    nxt = np.arange(nl, dtype=np.int32) + 1
    nxt[lstart + ltotal - 1] = lstart
    va = lvert
    vb = lvert[nxt]
    lo = np.minimum(va, vb)
    hi = np.maximum(va, vb)
    order = np.lexsort((hi, lo))
    lo_s, hi_s = lo[order], hi[order]
    pair = np.zeros(len(order), dtype=bool)
    same = (lo_s[1:] == lo_s[:-1]) & (hi_s[1:] == hi_s[:-1])
    pair[:-1] |= same
    pair[1:] |= same

    # A cut is where the two sides disagree about the shared corners' UVs.
    # Compared as whole arrays: the per-corner dictionary this used to build
    # held one entry per loop and was slower than the entire detection.
    ia = order[:-1][same]
    ib = order[1:][same]
    ua0, ub0 = uv[ia], uv[ib]
    na = uv[nxt[ia]]
    nb = uv[nxt[ib]]
    # the two loops of a shared edge run opposite ways round their faces, so
    # this face's corner pairs with the other's *next* corner and vice versa
    d1 = np.abs(ua0 - nb).max(axis=1)
    d2 = np.abs(na - ub0).max(axis=1)
    cut = (d1 > 1e-5) | (d2 > 1e-5)
    pairs_lo = np.concatenate([lo[ia][cut], lo[~pair[np.argsort(order)]]])
    pairs_hi = np.concatenate([hi[ia][cut], hi[~pair[np.argsort(order)]]])
    if not len(pairs_lo):
        return None
    seam_pairs = set(zip(pairs_lo.tolist(), pairs_hi.tolist()))

    E = cache["edges"]
    ea = np.minimum(E[:, 0], E[:, 1])
    eb = np.maximum(E[:, 0], E[:, 1])
    out = np.zeros(len(E), dtype=bool)
    for i in range(len(E)):
        if (int(ea[i]), int(eb[i])) in seam_pairs:
            out[i] = True
    return out


def detect(context, cache, st):
    """Thresholds, then the automatic prune. One place, so preview and build
    can never disagree about which lines the mesh is made from."""
    auto_c, auto_f = HS.auto_thresholds(cache)
    crease = auto_c if st.auto_thresholds else st.crease_deg
    flat = auto_f if st.auto_thresholds else st.flat_deg
    mask, info = HS.classify(cache, crease, flat, min_chain=st.min_chain,
                             use_type=st.use_type, close_gaps=st.close_gaps,
                             gap_span=st.gap_span)
    # The mesh's own border is a feature by definition, and `classify` never
    # sees it: it only walks manifold edges. Without this a plain flat sheet
    # detects zero lines, leaves the rebuild with no panel boundary at all, and
    # comes back empty - measured on three panels of the espresso machine,
    # which went in at 140/356/765 faces and came out at 0.
    mask = mask | ~cache["man"]

    obj = bpy.data.objects.get(st.source)
    seam_mask = None
    n_marked = 0
    marked = None
    if obj is not None and (st.hs_use_marked or st.hs_only_marked):
        marked, n_marked = marked_mask(obj, cache)
        if n_marked:
            if st.hs_only_marked:
                mask = marked | ~cache["man"]
                if seam_mask is not None:
                    mask = mask | seam_mask
            else:
                mask = mask | marked
    info = dict(info)
    info["n_marked"] = n_marked
    info["sel_ignored"] = bool(cache.get("sel_ignored"))
    info["final"] = int(mask.sum())
    plog = None
    if st.auto_prune:
        mask, plog = PR.prune(cache, mask, planar_tol=st.planar_tol,
                              merge=True)
        # A line the user marked by hand is not a candidate for pruning. The
        # prune decides a line carries no shape and drops it, which is right
        # for a line the detector guessed at and wrong for one that was asked
        # for - it made the marked edges look like they had no effect at all.
        if n_marked:
            mask = mask | marked
        # Same for a UV seam: across a flat panel the prune rightly judges it
        # to carry no shape, so every seam line was thrown away the moment it
        # was added and Keep UV Islands looked like it did nothing.
        if seam_mask is not None:
            mask = mask | seam_mask
        info = dict(info)
        info["final"] = int(mask.sum())
    return mask, info, plog, crease, flat, auto_c, auto_f


def _info_line(info, plog, crease, flat, auto_c, auto_f):
    txt = (f"{info['final']} edges  |  {info['n_crease']} crease + "
           f"{info['n_type']} type  |  {info['open_ends']} open ends  |  "
           f"{100 * info['panel_pct']:.0f}% of area is flat panel  |  "
           f"using {crease:.1f} / {flat:.2f}  (auto {auto_c:.1f} / {auto_f:.1f})")
    if info.get("n_marked"):
        txt += f"  |  {info['n_marked']} of your own lines"
    if info.get("sel_ignored"):
        txt += ("  |  the whole mesh is selected, so the selection was not "
                "read as lines")
    if plog:
        txt += (f"  |  pruned {plog['removed']} lines that change nothing "
                f"({plog['regions_before']}->{plog['regions_after']} regions)")
        if plog.get("sliver_merges"):
            txt += f"  |  welded {plog['sliver_merges']} strips too thin to keep"
    return txt


ORIG_KEY = "quadremesh_orig_mesh"


def source_mesh(obj):
    """The geometry to analyse, which is not always what the object shows.

    With Replace Original the result is written straight into the object, so
    on the next rebuild `obj.data` is the previous *output*. Reading that would
    remesh a remesh and the reduction would compound on every slider move.
    The mesh the result displaced is kept alive by a fake user precisely so
    there is still something true to read.
    """
    orig = obj.get(ORIG_KEY)
    if orig:
        me = bpy.data.meshes.get(orig)
        if me is not None:
            return me
    return obj.data


def _mesh_arrays(obj):
    me = source_mesh(obj)
    nv = len(me.vertices)
    V = np.empty(nv * 3)
    me.vertices.foreach_get("co", V)
    V = V.reshape(nv, 3)
    fs = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", fs)
    fv = np.empty(int(fs.sum()), dtype=np.int64)
    me.loops.foreach_get("vertex_index", fv)
    return V, fv, fs


def forget_cache(obj):
    """Drop the stored analysis for this object.

    Handing a mesh from Organic to Hardsurface changes what the loop tools
    are looking at, and a cache keyed only by the object's name would answer
    with the previous subject's lines.
    """
    _CACHE.pop(obj.name, None)
    _AXIS_COUNTS.pop(obj.name, None)


def get_cache(obj):
    """Analysis for this object, rebuilt only when the mesh actually changes."""
    key = obj.name
    src = source_mesh(obj)
    stamp = (len(src.vertices), len(src.polygons), src.name)
    hit = _CACHE.get(key)
    if hit is not None and hit[0] == stamp:
        return hit[1]
    V, fv, fs = _mesh_arrays(obj)
    starts, edges, pair = HS._topology(V, fv, fs)
    fn, fa = HS._face_normals_areas(V, fv, fs, starts)
    cache = HS.analyse(V, fv, fs, starts, edges, pair, fn, fa)
    _CACHE[key] = (stamp, cache)
    return cache


def rebuild_preview(context, source=None):
    st = context.scene.quadremesh_lines
    obj = source or bpy.data.objects.get(st.source)
    if obj is None or obj.type != "MESH" or not len(obj.data.polygons):
        return None
    cache = get_cache(obj)
    mask, info, plog, crease, flat, auto_c, auto_f = detect(context, cache, st)
    st.info = _info_line(info, plog, crease, flat, auto_c, auto_f)

    V = cache["V"]
    E = cache["edges"][mask]
    name = obj.name + SUFFIX
    old = bpy.data.objects.get(name)
    if old is not None:
        data = old.data
        bpy.data.objects.remove(old)
        if data.users == 0:
            bpy.data.meshes.remove(data)
    if not len(E):
        return None
    used = np.unique(E)
    remap = np.full(len(V), -1, dtype=np.int64)
    remap[used] = np.arange(len(used))
    me = bpy.data.meshes.new(name + "_mesh")
    me.from_pydata([tuple(v) for v in V[used].tolist()],
                   [tuple(e) for e in remap[E].tolist()], [])
    me.update()
    out = bpy.data.objects.new(name, me)
    out.matrix_world = obj.matrix_world.copy()
    for coll in obj.users_collection:
        coll.objects.link(out)
    out.show_in_front = True
    out.color = (1.0, 0.45, 0.05, 1.0)
    return out


PANEL_SUFFIX = "_PANELS"
BUILD_SUFFIX = "_S-Remesh"


def rebuild_panels(context, source=None):
    """Colour every panel the lines carve out, so the partition is visible.

    Same region growing the rebuild uses: faces join across any edge that is
    not a feature edge. If a panel here looks wrong, the mesh built from it
    will be wrong in the same place.
    """
    st = context.scene.quadremesh_lines
    obj = source or bpy.data.objects.get(st.source)
    if obj is None or obj.type != "MESH" or not len(obj.data.polygons):
        return None
    cache = get_cache(obj)
    mask, _info, _plog, crease, flat, auto_c, auto_f = detect(context, cache, st)

    A, B, idx = cache["A"], cache["B"], cache["idx"]
    nf, fa = cache["nf"], cache["fa"]
    ds = HS.DisjointSet(nf)
    for e, x, y in zip(idx.tolist(), A.tolist(), B.tolist()):
        if not mask[e]:
            ds.union(x, y)
    root = np.fromiter((ds.find(i) for i in range(nf)), dtype=np.int64, count=nf)
    _, lab = np.unique(root, return_inverse=True)
    nreg = int(lab.max()) + 1
    area = np.bincount(lab, weights=fa)
    total = max(area.sum(), 1e-20)

    rng = np.random.default_rng(11)
    pal = rng.random((nreg, 3)) * 0.65 + 0.35
    # tiny regions read as noise; grey them so real panels stand out
    tiny = area < 0.002 * total
    pal[tiny] = (0.16, 0.16, 0.18)

    me = obj.data
    sizes = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", sizes)
    # `analyse` works on the original polygons, not a triangulation, so the
    # labels already line up one-to-one with the mesh faces.
    poly_lab = lab

    name = obj.name + PANEL_SUFFIX
    old = bpy.data.objects.get(name)
    if old is not None:
        d = old.data
        bpy.data.objects.remove(old)
        if d.users == 0:
            bpy.data.meshes.remove(d)
    nm = me.copy()
    nm.name = name + "_mesh"
    for a in list(nm.color_attributes):
        nm.color_attributes.remove(a)
    at = nm.color_attributes.new(name="panels", type="FLOAT_COLOR",
                                 domain="CORNER")
    cols = np.ones((int(sizes.sum()), 4), dtype=np.float32)
    cols[:, :3] = np.repeat(pal[poly_lab], sizes, axis=0)
    at.data.foreach_set("color", cols.ravel())
    nm.attributes.active_color_name = "panels"
    nm.attributes.default_color_name = "panels"
    nm.update()
    out = bpy.data.objects.new(name, nm)
    out.matrix_world = obj.matrix_world.copy()
    for coll in obj.users_collection:
        coll.objects.link(out)
    st.panel_info = (f"{nreg} panels  |  {int(tiny.sum())} tiny  |  "
                     f"largest {100 * float(area.max() / total):.1f}% of area")
    return out


def fresh_shading(me, angle_deg=35.0, mark_sharp=True):
    """Give a rebuilt mesh its own shading back.

    A scan carries custom split normals, and they follow the mesh through
    every rebuild. They also override everything: with them in place Shade
    Smooth and Shade Auto Smooth do nothing at all, which is exactly what
    Milad hit - every face still flat, no sharp edges, and no setting that
    would move it. The normals belonged to the triangles that are gone, so
    they are cleared here and the new surface is shaded from its own angles:
    smooth across the panels, sharp where the model really turns.
    """
    try:
        if me.has_custom_normals:
            me.free_normals_split()
            me.attributes.remove(me.attributes["custom_normal"])
    except Exception:
        pass
    try:
        for f in me.polygons:
            f.use_smooth = True
        lim = math.radians(angle_deg)
        for e in me.edges:
            e.use_edge_sharp = False
        me.update()
        if not mark_sharp:
            # Asked for nothing sharp at all: the flags are already cleared
            # above, so only the creases are left to go. A garment has no hard
            # corners to keep, and a sharp edge through a panel shows up as a
            # crease line in the shading.
            try:
                for e in me.edges:
                    e.crease = 0.0
            except Exception:
                pass
            for f in me.polygons:
                f.use_smooth = True
            me.update()
            return
        # mark the real corners, the same test Shade Auto Smooth uses
        bm = bmesh.new()
        bm.from_mesh(me)
        for e in bm.edges:
            if len(e.link_faces) == 2:
                a = e.link_faces[0].normal.angle(e.link_faces[1].normal, 0.0)
                if a >= lim:
                    e.smooth = False
        bm.to_mesh(me)
        bm.free()
        me.update()
    except Exception:
        pass


def keep_materials(src_me, dst_me):
    """Carry the source's materials onto a rebuilt mesh.

    A remesh builds its mesh from raw coordinates, so the material slots the
    original carried simply were not there afterwards. The slots come across
    whole; with more than one material each new face takes its index from the
    nearest face of the original, which is as close as a rebuilt surface can
    get to the old assignment.
    """
    if src_me is None or not src_me.materials:
        return
    dst_me.materials.clear()
    for m in src_me.materials:
        dst_me.materials.append(m)
    if len(src_me.materials) < 2 or not len(src_me.polygons):
        return
    from mathutils.bvhtree import BVHTree
    tree = BVHTree.FromPolygons(
        [v.co[:] for v in src_me.vertices],
        [p.vertices[:] for p in src_me.polygons])
    for p in dst_me.polygons:
        hit = tree.find_nearest(p.center)
        if hit and hit[2] is not None:
            p.material_index = src_me.polygons[hit[2]].material_index


def _split_on_seams(dst_me, src_me):
    """Cut any rebuilt face that a UV seam runs through.

    A face cannot hold two islands, so the six panels of Milad's radio that
    straddled a seam could only ever smear the texture between them. Each
    seam edge of the source that lies inside a rebuilt face - not along its
    border - slices that face along the seam's own line, and from then on
    every face sits on one island.
    """
    # Bail before building anything. The seam list alone walks every source
    # polygon and its corners - 4 of the 6 seconds the remesh spends in
    # Python on Milad's part - and _fix_uv_slivers already covers what this
    # pass is for. Only a small source is worth the extra precision.
    if len(src_me.polygons) > 5000:
        return 0
    uv = src_me.uv_layers[0].data
    cuv = {}
    ef = {}
    for poly in src_me.polygons:
        for k in range(poly.loop_start, poly.loop_start + poly.loop_total):
            cuv[(poly.index, src_me.loops[k].vertex_index)] = uv[k].uv
        for ek in poly.edge_keys:
            ef.setdefault(ek, []).append(poly.index)
    segs = []
    for ek, fs in ef.items():
        seam = len(fs) == 1 or (
            len(fs) == 2 and any((cuv[(fs[0], v)] - cuv[(fs[1], v)]).length
                                 > 1e-5 for v in ek))
        if seam:
            segs.append((src_me.vertices[ek[0]].co.copy(),
                         src_me.vertices[ek[1]].co.copy()))
    if not segs:
        return 0
    from mathutils.bvhtree import BVHTree
    ext = [max(v.co[i] for v in src_me.vertices) -
           min(v.co[i] for v in src_me.vertices) for i in range(3)]
    diag = max(ext) or 1.0
    bm = bmesh.new()
    bm.from_mesh(dst_me)
    bm.faces.ensure_lookup_table()
    cuts = 0
    # Each cut re-indexes the mesh and rebuilds the search tree, and every
    # seam segment is tested against the whole result first. Measured on
    # Milad's part that was 4.8 of the 8 seconds the whole remesh spends in
    # Python, for a tidy-up that _fix_uv_slivers already covers. Anything
    # but a lightly seamed model skips it.
    if len(segs) > 1200:
        bm.free()
        return 0
    CUT_CAP = 300
    tree = BVHTree.FromBMesh(bm)
    for a, b in segs:
        d = b - a
        if d.length < 1e-12:
            continue
        mid = (a + b) / 2
        hit = tree.find_nearest(mid)
        if hit is None or hit[2] is None or hit[3] > diag * 0.005:
            continue
        face = bm.faces[hit[2]]
        if len(face.verts) < 4:
            continue
        on_edge = False
        for e in face.edges:
            _q, t = intersect_point_line(mid, e.verts[0].co, e.verts[1].co)
            t = min(max(t, 0.0), 1.0)
            if (mid - e.verts[0].co.lerp(e.verts[1].co, t)).length                     < diag * 2e-3:
                on_edge = True
                break
        if on_edge:
            continue
        # the seam has to lie in the face, not cross it
        if abs(d.normalized().dot(face.normal)) > 0.3:
            continue
        no = face.normal.cross(d.normalized())
        if no.length < 1e-9:
            continue
        no.normalize()
        side = [(v.co - mid).dot(no) for v in face.verts]
        thin = diag * 0.01
        if max(side) < thin or min(side) > -thin:
            continue                      # would only shave off a sliver
        geom = [face] + list(face.edges) + list(face.verts)
        res = bmesh.ops.bisect_plane(bm, geom=geom, plane_co=mid,
                                     plane_no=no)
        if res["geom_cut"]:
            cuts += 1
            if cuts >= CUT_CAP:
                break
            bm.faces.ensure_lookup_table()
            tree = BVHTree.FromBMesh(bm)
    if cuts:
        bm.to_mesh(dst_me)
        dst_me.update()
    bm.free()
    return cuts


def _fast_uv_transfer(dst_obj, src_me):
    """Blender's own UV transfer, for meshes too big for the exact path.

    Returns True only if UVs really arrived. It used to swallow every error
    and say nothing, so a transfer that failed looked exactly like a model
    with no UVs - the caller can now fall back instead.
    """
    src = bpy.data.objects.new("qr_uv_src", src_me)
    bpy.context.scene.collection.objects.link(src)
    src.matrix_world = dst_obj.matrix_world.copy()
    # The transfer compares the *evaluated* meshes. The target carries the
    # user's modifiers - an Armature above all - so it was being matched in
    # its posed shape against a stand-in source in rest pose, and a third of
    # the corners found the wrong face. Everything is switched off for the
    # length of the transfer and put back exactly as it was.
    was = [(m, m.show_viewport) for m in dst_obj.modifiers]
    for m, _ in was:
        m.show_viewport = False
    try:
        with bpy.context.temp_override(
                object=src, active_object=src,
                selected_editable_objects=[src, dst_obj]):
            bpy.ops.object.data_transfer(
                data_type="UV", loop_mapping="POLYINTERP_NEAREST",
                layers_select_src="ALL", layers_select_dst="NAME",
                use_create=True)
    except Exception:
        pass
    finally:
        for m, on in was:
            m.show_viewport = on
        bpy.data.objects.remove(src, do_unlink=True)

    dst_me = dst_obj.data
    for want in src_me.uv_layers:
        got = dst_me.uv_layers.get(want.name)
        if got is None or len(got.data) != len(dst_me.loops):
            return False
        if not any(got.data[i].uv.length > 1e-9
                   for i in range(0, len(got.data), 29)):
            return False
    # keep whichever layer the original rendered with
    for want in src_me.uv_layers:
        got = dst_me.uv_layers.get(want.name)
        if got is not None and want.active_render:
            got.active_render = True
            dst_me.uv_layers.active = got
    return bool(len(src_me.uv_layers))


def _fix_uv_slivers(dst_obj, src_me=None, layer_name=None):
    """Not called any more, and kept only as a record of what not to do.

    Pulling a stray corner onto its neighbour left the face with no UV area
    at all - 231 of them on Milad's revolver - so the texture came out as
    one colour smeared along a line. Measured, the transfer is better left
    alone: 0.85% of faces poorly mapped without this, 5.27% with it, against
    1.02% on the original model.

    Pull back the few faces whose corners landed on different UV islands.

    Blender's own transfer maps each corner to the nearest bit of the
    original on its own, so a face lying across a seam gets one corner from
    each side - the long slivers stretched across the UV sheet. Each stray
    corner is moved onto the nearest corner of the face that is on the
    island the rest of the face is on. The face ends up small and tight
    against the seam instead of spanning the sheet, and the texture error is
    bounded by that one face. Nothing else is touched, and it needs no look
    at the source mesh at all - the earlier version searched all 260000
    source loops and took minutes.
    """
    dst_me = dst_obj.data
    if not dst_me.uv_layers:
        return 0
    fixed = 0
    for layer in dst_me.uv_layers:
        if layer_name is not None and layer.name != layer_name:
            continue
        nl = len(dst_me.loops)
        arr = np.empty(nl * 2, dtype=np.float32)
        layer.data.foreach_get("uv", arr)
        uv = arr.reshape(nl, 2)
        changed = False
        for face in dst_me.polygons:
            a = face.loop_start
            b = a + face.loop_total
            block = uv[a:b]
            d = np.linalg.norm(block[:, None, :] - block[None, :, :], axis=2)
            if d.max() <= 0.2:
                continue
            # the island most of the face is on: the corner with the most
            # neighbours within reach of it
            counts = (d <= 0.2).sum(axis=1)
            home = int(counts.argmax())
            stray = np.flatnonzero(d[home] > 0.2)
            if not len(stray):
                continue
            for k in stray:
                good = np.flatnonzero(d[home] <= 0.2)
                near = good[np.argmin(np.linalg.norm(
                    block[good] - block[k], axis=1))]
                uv[a + k] = block[near]
            changed = True
            fixed += 1
        if changed:
            layer.data.foreach_set("uv", uv.reshape(-1))
    if fixed:
        dst_me.update()
    return fixed


def _mend_seam_faces(dst_obj, src_me):
    """Give the faces that straddle a UV seam a real UV instead of a blend.

    Blender's transfer maps each corner to the nearest bit of the original
    on its own, so a face lying across a seam gets one corner from each
    side and the texture tears along it - the cracks down the arms of
    Milad's character. Every corner of such a face is moved onto the island
    the rest of the face is on, taking a UV the source really carries at
    that vertex rather than an average of two.

    An earlier version snapped the stray corner onto its neighbour instead.
    That left the face with no UV area at all, which reads as a smear of
    one colour, so the corner has to come from the source, not the face.
    """
    dst_me = dst_obj.data
    if not (src_me.uv_layers and dst_me.uv_layers):
        return 0
    if len(src_me.uv_layers[0].data) != len(src_me.loops):
        return 0

    from mathutils.kdtree import KDTree
    nv = len(src_me.vertices)
    sco = np.empty(nv * 3, dtype=np.float32)
    src_me.vertices.foreach_get("co", sco)
    sco = sco.reshape(nv, 3)
    kd = KDTree(nv)
    for i in range(nv):
        kd.insert(Vector(sco[i]), i)
    kd.balance()
    # A rebuilt corner does not sit exactly on a source vertex - measured on
    # Milad's character, half a percent of the model away at worst - and
    # anything the search misses keeps its torn UV. 1% covers every case
    # there and is still far too small to reach another island.
    reach = float(max(sco.max(axis=0) - sco.min(axis=0))) * 1e-2

    nl = len(src_me.loops)
    slv = np.empty(nl, dtype=np.int32)
    src_me.loops.foreach_get("vertex_index", slv)
    kd_find_range = kd.find_range
    kd_find_n = kd.find_n

    dn = len(dst_me.loops)
    dvi = np.empty(dn, dtype=np.int32)
    dst_me.loops.foreach_get("vertex_index", dvi)
    dnv = len(dst_me.vertices)
    dco = np.empty(dnv * 3, dtype=np.float32)
    dst_me.vertices.foreach_get("co", dco)
    dco = dco.reshape(dnv, 3)
    ls = np.empty(len(dst_me.polygons), dtype=np.int32)
    dst_me.polygons.foreach_get("loop_start", ls)
    lt = np.empty(len(dst_me.polygons), dtype=np.int32)
    dst_me.polygons.foreach_get("loop_total", lt)

    fixed = 0
    for layer in dst_me.uv_layers:
        src_layer = src_me.uv_layers.get(layer.name) or src_me.uv_layers[0]
        sn = len(src_layer.data)
        sarr = np.empty(sn * 2, dtype=np.float32)
        src_layer.data.foreach_get("uv", sarr)
        sarr = sarr.reshape(sn, 2)
        out = np.empty(dn * 2, dtype=np.float32)
        layer.data.foreach_get("uv", out)
        out = out.reshape(dn, 2)

        # Which source vertices any torn corner might ask about. Indexing
        # all 470000 of a scan's vertices took 34 seconds, nearly all of the
        # run, for a few thousand corners that actually need one.
        want = set()
        for f in range(len(dst_me.polygons)):
            a0, k0 = int(ls[f]), int(lt[f])
            b0 = out[a0:a0 + k0]
            if float(np.linalg.norm(
                    b0[:, None, :] - b0[None, :, :], axis=2).max()) <= 0.03:
                continue
            for j in range(k0):
                for _c, vi, _d in kd_find_n(Vector(dco[dvi[a0 + j]]), 64):
                    want.add(vi)
        if not want:
            continue
        choices = {}
        for i in range(nl):
            vi = int(slv[i])
            if vi in want:
                choices.setdefault(vi, []).append(sarr[i])
        # Repeated: mending one corner changes which cluster is the biggest,
        # so a face with corners on three islands needs another look. Two
        # passes took Milad's character from 12.7% torn faces to 5.2%, and
        # settling it needs a few more.
        # Only the faces that are actually torn, found once. Rescanning all
        # 39505 of them on each of six rounds was most of the 35 seconds.
        torn = []
        for f in range(len(dst_me.polygons)):
            a, k = int(ls[f]), int(lt[f])
            blk = out[a:a + k]
            if float(np.abs(blk - blk[0]).max()) > 0.03 or                     float(np.linalg.norm(
                        blk[:, None, :] - blk[None, :, :], axis=2).max()) > 0.03:
                torn.append(f)
        changed = False
        pools = {}
        for _round in range(6):
            round_fixed = 0
            for f in torn:
                a, k = int(ls[f]), int(lt[f])
                blk = out[a:a + k]
                d = np.linalg.norm(blk[:, None, :] - blk[None, :, :], axis=2)
                if d.max() <= 0.03:
                    continue
                home = int((d <= 0.03).sum(axis=1).argmax())
                anchor = blk[home].copy()
                moved = False
                for j in range(k):
                    if np.linalg.norm(blk[j] - anchor) <= 0.03:
                        continue
                    li = a + j
                    pool = pools.get(li)
                    if pool is None:
                        co = Vector(dco[dvi[li]])
                        # nearest first, and stop as soon as a vertex with
                        # more than one UV turns up: that is the seam vertex
                        # this corner belongs to. Sweeping the whole radius
                        # for every corner, every round, was 33 seconds.
                        # Every UV within reach, gathered once and kept.
                        # Stopping at the first seam vertex was five times
                        # faster and left a quarter of the tears in place -
                        # the right UV often belongs to a vertex further out.
                        # The nearest few dozen vertices, not everything
                        # inside a radius: on a 470000-vertex scan a one
                        # percent sphere holds thousands, and gathering them
                        # for every corner on every round was 37 seconds.
                        # 24 was too few - it left a quarter of the tears -
                        # and 64 costs almost nothing more.
                        pool = []
                        for _c, vi, _d in kd_find_n(co, 64):
                            pool.extend(choices.get(vi, ()))
                        # as one array: picking the closest of a few hundred
                        # UVs one numpy call at a time was 3 million calls and
                        # 16 of the 20 seconds on a 1.9 million face lantern
                        pool = (np.asarray(pool, dtype=np.float32)
                                if pool else None)
                        pools[li] = pool
                    if pool is None:
                        continue
                    diff = pool - anchor
                    best = pool[int(np.argmin(
                        diff[:, 0] * diff[:, 0] + diff[:, 1] * diff[:, 1]))]
                    if not np.allclose(best, out[a + j]):
                        out[a + j] = best
                        moved = True
                if moved:
                    round_fixed += 1
            if not round_fixed:
                break
            changed = True
            fixed += round_fixed
        if changed:
            layer.data.foreach_set("uv", out.reshape(-1))
    if fixed:
        dst_me.update()
    return fixed


# -- UV transfer for very large sources, off the main thread ----------------
#
# On a 1.9 million face scan the transfer was the longest part of a remesh:
# Blender's own data transfer builds its search tree over the whole source on
# the main thread, 4.4 seconds with the window frozen, and the seam mending
# after it another 4.6 - while the engine itself had taken 6.6. Everything
# here works on arrays read out once, so it can run on a worker thread and
# the progress bar goes on moving through it.

BIG_UV_FACES = 200000


def big_uv_wanted(dst_me, src_me):
    """Is the source big enough for the threaded transfer to be worth it?"""
    return (src_me is not None and src_me.uv_layers
            and len(src_me.polygons) >= BIG_UV_FACES
            and len(dst_me.polygons) > 0
            and len(src_me.uv_layers[0].data) == len(src_me.loops))


def big_uv_prepare(dst_me, src_me):
    """Read off Blender everything the transfer needs. Main thread."""
    nv = len(src_me.vertices)
    sco = np.empty(nv * 3, dtype=np.float64)
    src_me.vertices.foreach_get("co", sco)
    nl = len(src_me.loops)
    slv = np.empty(nl, dtype=np.int32)
    src_me.loops.foreach_get("vertex_index", slv)
    nf = len(src_me.polygons)
    sls = np.empty(nf, dtype=np.int32)
    src_me.polygons.foreach_get("loop_start", sls)
    slt = np.empty(nf, dtype=np.int32)
    src_me.polygons.foreach_get("loop_total", slt)
    layers = []
    for layer in src_me.uv_layers:
        a = np.empty(nl * 2, dtype=np.float32)
        layer.data.foreach_get("uv", a)
        layers.append((layer.name, a.reshape(nl, 2), bool(layer.active_render)))
    dnv = len(dst_me.vertices)
    dco = np.empty(dnv * 3, dtype=np.float64)
    dst_me.vertices.foreach_get("co", dco)
    dn = len(dst_me.loops)
    dvi = np.empty(dn, dtype=np.int32)
    dst_me.loops.foreach_get("vertex_index", dvi)
    dnf = len(dst_me.polygons)
    dls = np.empty(dnf, dtype=np.int32)
    dst_me.polygons.foreach_get("loop_start", dls)
    dlt = np.empty(dnf, dtype=np.int32)
    dst_me.polygons.foreach_get("loop_total", dlt)
    return {"sco": sco.reshape(nv, 3), "slv": slv, "sls": sls, "slt": slt,
            "layers": layers, "dco": dco.reshape(dnv, 3), "dvi": dvi,
            "dls": dls, "dlt": dlt}


def _closest_on_tris(p, a, b, c):
    """Closest point on each triangle to p, as barycentric weights.

    p is (n, 1, 3), a b c are (n, k, 3). Returns (w0, w1, w2, dist2), each
    (n, k). The region test of Ericson's Real-Time Collision Detection, done
    for every pair at once.
    """
    ab = b - a
    ac = c - a
    ap = p - a
    d1 = np.einsum("nki,nki->nk", ab, ap)
    d2 = np.einsum("nki,nki->nk", ac, ap)
    bp = p - b
    d3 = np.einsum("nki,nki->nk", ab, bp)
    d4 = np.einsum("nki,nki->nk", ac, bp)
    cp = p - c
    d5 = np.einsum("nki,nki->nk", ab, cp)
    d6 = np.einsum("nki,nki->nk", ac, cp)
    va = d3 * d6 - d5 * d4
    vb = d5 * d2 - d1 * d6
    vc = d1 * d4 - d3 * d2

    with np.errstate(divide="ignore", invalid="ignore"):
        denom = va + vb + vc
        v_in = np.where(denom != 0.0, vb / denom, 0.0)
        w_in = np.where(denom != 0.0, vc / denom, 0.0)
        t_ab = np.where(d1 - d3 != 0.0, d1 / (d1 - d3), 0.0)
        t_ac = np.where(d2 - d6 != 0.0, d2 / (d2 - d6), 0.0)
        e_bc = (d4 - d3) + (d5 - d6)
        t_bc = np.where(e_bc != 0.0, (d4 - d3) / e_bc, 0.0)

    # start inside, then overwrite region by region, most specific last
    w1 = v_in.copy()
    w2 = w_in.copy()
    r = (va <= 0.0) & ((d4 - d3) >= 0.0) & ((d5 - d6) >= 0.0)     # edge BC
    w1 = np.where(r, 1.0 - t_bc, w1)
    w2 = np.where(r, t_bc, w2)
    r = (vb <= 0.0) & (d2 >= 0.0) & (d6 <= 0.0)                   # edge AC
    w1 = np.where(r, 0.0, w1)
    w2 = np.where(r, t_ac, w2)
    r = (d6 >= 0.0) & (d5 <= d6)                                  # vertex C
    w1 = np.where(r, 0.0, w1)
    w2 = np.where(r, 1.0, w2)
    r = (vc <= 0.0) & (d1 >= 0.0) & (d3 <= 0.0)                   # edge AB
    w1 = np.where(r, t_ab, w1)
    w2 = np.where(r, 0.0, w2)
    r = (d3 >= 0.0) & (d4 <= d3)                                  # vertex B
    w1 = np.where(r, 1.0, w1)
    w2 = np.where(r, 0.0, w2)
    r = (d1 <= 0.0) & (d2 <= 0.0)                                 # vertex A
    w1 = np.where(r, 0.0, w1)
    w2 = np.where(r, 0.0, w2)
    w0 = 1.0 - w1 - w2
    q = a * w0[..., None] + b * w1[..., None] + c * w2[..., None]
    diff = p - q
    return w0, w1, w2, np.einsum("nki,nki->nk", diff, diff)


def big_uv_compute(d, cancelled=lambda: False, trace=None):
    """The transfer and the seam mending, on arrays only. Any thread.

    Each corner of the result takes its UV from the nearest point on the
    source surface, interpolated across that source triangle - the same rule
    as Blender's Nearest Face Interpolated. The nearest point is searched
    among the triangles around the source vertices closest to the corner.
    """
    from mathutils.kdtree import KDTree

    sco, slv, sls, slt = d["sco"], d["slv"], d["sls"], d["slt"]
    dco, dvi, dls, dlt = d["dco"], d["dvi"], d["dls"], d["dlt"]
    nv = len(sco)
    nf = len(sls)

    # the source as triangles, fanned the way Blender fans them, by corner
    per = np.maximum(slt - 2, 0).astype(np.int64)
    owner = np.repeat(np.arange(nf, dtype=np.int64), per)
    tstart = np.zeros(nf, dtype=np.int64)
    if nf > 1:
        tstart[1:] = np.cumsum(per)[:-1]
    kk = np.arange(len(owner), dtype=np.int64) - tstart[owner] + 1
    L0 = sls[owner].astype(np.int64)
    L1 = L0 + kk
    L2 = L1 + 1
    V0, V1, V2 = slv[L0], slv[L1], slv[L2]
    nt = len(L0)

    # which triangles touch each vertex
    tv = np.concatenate([V0, V1, V2])
    ti = np.concatenate([np.arange(nt, dtype=np.int64)] * 3)
    order = np.argsort(tv, kind="stable")
    ti_s = ti[order]
    vcount = np.bincount(tv, minlength=nv)
    vstart = np.zeros(nv, dtype=np.int64)
    vstart[1:] = np.cumsum(vcount)[:-1]
    del tv, ti, order
    if trace:
        trace("adjacency")

    if cancelled():
        return None
    kd = KDTree(nv)
    for i, c in enumerate(sco.tolist()):
        kd.insert(c, i)
    kd.balance()
    if trace:
        trace("kd tree")
    if cancelled():
        return None

    K = 8           # nearest source vertices per corner
    M = 12          # triangles kept around each of them
    dnv = len(dco)
    near = np.zeros((dnv, K), dtype=np.int64)
    for i, c in enumerate(dco.tolist()):
        hits = kd.find_n(c, K)
        ids = [h[1] for h in hits] or [0]
        while len(ids) < K:
            ids.append(ids[0])
        near[i] = ids

    if trace:
        trace("nearest vertices")
    best_tri = np.zeros(dnv, dtype=np.int64)
    bw = np.zeros((dnv, 3), dtype=np.float64)
    offs = np.arange(M, dtype=np.int64)
    for s0 in range(0, dnv, 2048):
        if cancelled():
            return None
        nb = near[s0:s0 + 2048]
        idx = vstart[nb][..., None] + offs
        ok = offs < vcount[nb][..., None]
        cand = np.where(ok, ti_s[np.minimum(idx, len(ti_s) - 1)], -1)
        cand = cand.reshape(len(nb), K * M)
        safe = np.maximum(cand, 0)
        p = dco[s0:s0 + 2048][:, None, :]
        w0, w1, w2, dist = _closest_on_tris(p, sco[V0[safe]], sco[V1[safe]],
                                            sco[V2[safe]])
        dist = np.where(cand >= 0, dist, np.inf)
        j = np.argmin(dist, axis=1)
        rows = np.arange(len(nb))
        best_tri[s0:s0 + 2048] = safe[rows, j]
        bw[s0:s0 + 2048, 0] = w0[rows, j]
        bw[s0:s0 + 2048, 1] = w1[rows, j]
        bw[s0:s0 + 2048, 2] = w2[rows, j]

    if trace:
        trace("closest triangles")
    out = []
    for name, suv, render in d["layers"]:
        uvv = (suv[L0[best_tri]] * bw[:, 0:1] + suv[L1[best_tri]] * bw[:, 1:2]
               + suv[L2[best_tri]] * bw[:, 2:3]).astype(np.float32)
        arr = uvv[dvi]
        if trace:
            trace("uv interpolated")
        _mend_arrays(arr, dls, dlt, dco, dvi, suv, slv, kd, trace)
        if trace:
            trace("mended")
        out.append((name, arr, render))
        if cancelled():
            return None
    return out


def _mend_arrays(out, ls, lt, dco, dvi, sarr, slv, kd, trace=None):
    """_mend_seam_faces on arrays, so it can run off the main thread."""
    kd_find_n = kd.find_n
    nfaces = len(ls)
    want = set()
    for f in range(nfaces):
        a0, k0 = int(ls[f]), int(lt[f])
        b0 = out[a0:a0 + k0]
        if float(np.linalg.norm(
                b0[:, None, :] - b0[None, :, :], axis=2).max()) <= 0.03:
            continue
        for j in range(k0):
            for _c, vi, _d in kd_find_n(dco[dvi[a0 + j]].tolist(), 64):
                want.add(vi)
    if trace:
        trace("mend want %d" % len(want))
    if not want:
        return 0
    wanted = np.fromiter(want, dtype=np.int64, count=len(want))
    hit = np.flatnonzero(np.isin(slv, wanted))
    hit = hit[np.argsort(slv[hit], kind="stable")]
    verts = slv[hit]
    cuts = np.flatnonzero(np.diff(verts)) + 1
    choices = {}
    for grp in np.split(hit, cuts):
        if len(grp):
            choices[int(slv[grp[0]])] = sarr[grp]
    if trace:
        trace("mend choices %d" % len(choices))
    torn = []
    for f in range(nfaces):
        a, k = int(ls[f]), int(lt[f])
        blk = out[a:a + k]
        if float(np.abs(blk - blk[0]).max()) > 0.03 or float(np.linalg.norm(
                blk[:, None, :] - blk[None, :, :], axis=2).max()) > 0.03:
            torn.append(f)
    if trace:
        trace("mend torn %d" % len(torn))
    fixed = 0
    pools = {}
    for _round in range(6):
        round_fixed = 0
        for f in torn:
            a, k = int(ls[f]), int(lt[f])
            blk = out[a:a + k]
            dd = np.linalg.norm(blk[:, None, :] - blk[None, :, :], axis=2)
            if dd.max() <= 0.03:
                continue
            home = int((dd <= 0.03).sum(axis=1).argmax())
            anchor = blk[home].copy()
            moved = False
            for j in range(k):
                if np.linalg.norm(blk[j] - anchor) <= 0.03:
                    continue
                li = a + j
                pool = pools.get(li, False)
                if pool is False:
                    parts = [choices[vi] for _c, vi, _d
                             in kd_find_n(dco[dvi[li]].tolist(), 64)
                             if vi in choices]
                    pool = np.concatenate(parts) if parts else None
                    pools[li] = pool
                if pool is None:
                    continue
                diff = pool - anchor
                best = pool[int(np.argmin(
                    diff[:, 0] * diff[:, 0] + diff[:, 1] * diff[:, 1]))]
                if not np.allclose(best, out[a + j]):
                    out[a + j] = best
                    moved = True
            if moved:
                round_fixed += 1
        if not round_fixed:
            break
        fixed += round_fixed
    return fixed


def big_uv_apply(dst_obj, layers):
    """Write the transferred UVs into the result. Main thread."""
    dst_me = dst_obj.data
    dn = len(dst_me.loops)
    for name, arr, render in layers:
        lay = dst_me.uv_layers.get(name) or dst_me.uv_layers.new(name=name)
        if len(lay.data) != dn:
            continue
        lay.data.foreach_set("uv", arr.reshape(-1))
        if render:
            lay.active_render = True
            dst_me.uv_layers.active = lay
    dst_me.update()


def keep_uvs_steps(dst_obj, src_me):
    """keep_uvs, yielding while the heavy part runs on a worker thread.

    Small sources go through keep_uvs as they always have. A big one is read
    out, handed to a thread, and the caller is given a chance to draw every
    time it asks for the next step; then the result is written back and the
    UV healing runs as before.
    """
    import threading
    if not big_uv_wanted(dst_obj.data, src_me):
        keep_uvs(dst_obj, src_me)
        return
    data = big_uv_prepare(dst_obj.data, src_me)
    box = {}

    def work():
        try:
            box["out"] = big_uv_compute(data)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            box["error"] = exc

    th = threading.Thread(target=work, daemon=True, name="SmartRemeshUV")
    th.start()
    while th.is_alive():
        # Wait on the thread itself, briefly, before handing back. A caller
        # that asks for the next step straight away - a script running the
        # remesh to the end - otherwise keeps the interpreter so busy that
        # the worker never gets a turn: measured, 192 million empty steps in
        # a minute and the transfer not started. Joining lets it run.
        th.join(0.02)
        if th.is_alive():
            yield "carrying the UVs"
    if box.get("error") is not None or not box.get("out"):
        keep_uvs(dst_obj, src_me)       # the proven path, if this one failed
        return
    big_uv_apply(dst_obj, box["out"])
    yield "mending the UVs"
    _heal_uv(dst_obj.data)


def keep_uvs(dst_obj, src_me):
    """Carry the source's UV layers onto a rebuilt mesh, island by island.

    The rebuilt corners sit on the feature lines, and on a hard-surface
    model those are exactly where the UV seams run - so a corner's nearest
    source face is a coin toss between two islands, and 164 of the 289
    faces of Milad's radio came out torn between them. Extending one source
    face's mapping across the whole panel fixed the tearing and broke the
    accuracy instead: a real unwrap is only affine face by face.

    So: each rebuilt face chooses its island from the source face under its
    centre, which is never on a seam. Each corner is then mapped from its
    nearest source face *on that island* - local, so accurate - and every
    corner of the face lands on the same island, so nothing tears.
    """
    if src_me is None or not src_me.uv_layers or not len(src_me.polygons):
        return
    if len(src_me.uv_layers[0].data) != len(src_me.loops):
        return          # mesh is in Edit Mode; its UV arrays are not readable
    dst_me = dst_obj.data
    if not len(dst_me.polygons):
        return
    # The island-aware transfer below is per corner in Python: on the car,
    # 200000 corners each doing a tree query, which is minutes. Past this
    # size Blender's own transfer does the job in C - less exact at the
    # island borders, but the alternative is a remesh that never returns.
    # The exact path keeps every corner on its face's own UV island, which
    # the C transfer cannot do - on a UDIM model it put a third of the
    # corners in the wrong tile. It is worth its cost now that the cost is
    # a few seconds: the per-island BVH trees it used to build are gone,
    # replaced by one index over the source faces. Only genuinely huge
    # meshes fall back.
    if len(dst_me.polygons) > 20000 or len(src_me.polygons) > 40000:
        if _fast_uv_transfer(dst_obj, src_me):
            _mend_seam_faces(dst_obj, src_me)
            _heal_uv(dst_me)
            return
        # it did not take. Better slow than a model with no UVs at all.
    from mathutils.bvhtree import BVHTree
    # 200000 was no guard at all: the car is 54000 and still took hours,
    # because _split_on_seams re-indexes the whole mesh after every cut.
    if len(dst_me.polygons) <= 20000 and len(src_me.polygons) <= 20000:
        _split_on_seams(dst_me, src_me)
    verts = [v.co.copy() for v in src_me.vertices]
    polys = [p.vertices[:] for p in src_me.polygons]
    vtuples = [v[:] for v in verts]
    tree = BVHTree.FromPolygons(vtuples, polys)
    layer0 = src_me.uv_layers[0].data

    # islands: faces joined across an edge whose UVs agree on both sides
    parent = list(range(len(src_me.polygons)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    # Read the arrays in one go. Walking them through RNA - 216000
    # `.uv.copy()` calls on the car - took longer than the whole rest of
    # the remesh put together.
    nl = len(src_me.loops)
    uvs = np.empty(nl * 2, dtype=np.float32)
    layer0.foreach_get("uv", uvs)
    uvs = uvs.reshape(nl, 2)
    lvert = np.empty(nl, dtype=np.int32)
    src_me.loops.foreach_get("vertex_index", lvert)
    # Everything here used to walk Blender's RNA polygon by polygon and
    # corner by corner. Read as arrays instead: on Milad's part this is the
    # difference between five seconds and a fraction of one.
    nf = len(src_me.polygons)
    lstart = np.empty(nf, dtype=np.int32)
    src_me.polygons.foreach_get("loop_start", lstart)
    ltotal = np.empty(nf, dtype=np.int32)
    src_me.polygons.foreach_get("loop_total", ltotal)
    face_of_loop = np.repeat(np.arange(nf, dtype=np.int32), ltotal)
    corner_uv = {}
    for i in range(nl):
        corner_uv[(int(face_of_loop[i]), int(lvert[i]))] = uvs[i]
    # the next corner around each face, so an edge is (loop, next loop)
    nxt = np.arange(nl, dtype=np.int32) + 1
    ends = lstart + ltotal - 1
    nxt[ends] = lstart
    va = lvert
    vb = lvert[nxt]
    lo = np.minimum(va, vb)
    hi = np.maximum(va, vb)
    order = np.lexsort((hi, lo))
    lo_s = lo[order]
    hi_s = hi[order]
    f_s = face_of_loop[order]
    same = (lo_s[1:] == lo_s[:-1]) & (hi_s[1:] == hi_s[:-1])
    for i in np.flatnonzero(same):
        a = int(f_s[i])
        b = int(f_s[i + 1])
        v0 = int(lo_s[i])
        v1 = int(hi_s[i])
        ua0 = corner_uv.get((a, v0))
        ub0 = corner_uv.get((b, v0))
        ua1 = corner_uv.get((a, v1))
        ub1 = corner_uv.get((b, v1))
        if ua0 is None or ub0 is None or ua1 is None or ub1 is None:
            continue
        if (abs(ua0[0] - ub0[0]) < 1e-5 and abs(ua0[1] - ub0[1]) < 1e-5
                and abs(ua1[0] - ub1[0]) < 1e-5
                and abs(ua1[1] - ub1[1]) < 1e-5):
            parent[find(a)] = find(b)
    island_of = [find(i) for i in range(len(src_me.polygons))]
    members = {}
    for i, isl in enumerate(island_of):
        members.setdefault(isl, []).append(i)
    # One index for the whole mesh instead of a BVH tree per island. Each
    # island tree copied all of the model's vertices, and a mesh with a few
    # thousand islands spent nearly a minute doing nothing else - the freeze
    # Milad kept hitting. A KD tree over face centres answers the same
    # question, "the nearest face on this island", in one build.
    from mathutils.kdtree import KDTree
    fkd = KDTree(nf)
    centres = np.empty(nf * 3, dtype=np.float32)
    src_me.polygons.foreach_get("center", centres)
    centres = centres.reshape(nf, 3)
    areas = np.empty(nf, dtype=np.float32)
    src_me.polygons.foreach_get("area", areas)
    for i in range(nf):
        fkd.insert(centres[i], i)
    fkd.balance()
    edge_hint = math.sqrt(float(areas.mean())) or 1e-6

    def nearest_on(isl, co):
        """Index of the nearest source face that belongs to island `isl`."""
        r = edge_hint * 4.0
        for _try in range(5):
            best = None
            best_d = None
            for _c, fi, d in fkd.find_range(co, r):
                if island_of[fi] != isl:
                    continue
                if best_d is None or d < best_d:
                    best_d = d
                    best = fi
            if best is not None:
                return best, best_d
            r *= 3.0
        return None, None

    def frame(poly):
        idx = list(range(poly.loop_start, poly.loop_start + poly.loop_total))
        cos = [verts[src_me.loops[k].vertex_index] for k in idx]
        best = None
        area = 0.0
        for b in range(1, len(idx)):
            for c in range(b + 1, len(idx)):
                ar = (cos[b] - cos[0]).cross(cos[c] - cos[0]).length
                if ar > area:
                    area = ar
                    best = (idx[0], idx[b], idx[c])
        return best

    frames = {}
    from mathutils.kdtree import KDTree
    vkd = KDTree(len(verts))
    for i, v in enumerate(verts):
        vkd.insert(v, i)
    vkd.balance()
    # A vertex on a seam carries one UV per island it belongs to.
    # Indexed that way, a corner sitting exactly on such a vertex takes
    # the right one outright instead of having its island's mapping
    # extrapolated across the seam - which stretched every face along
    # one, however the face had been split.
    vert_islands = {}
    vert_uv_by_island = {}
    for i in range(nl):
        vi = int(lvert[i])
        isl = island_of[int(face_of_loop[i])]
        vert_islands.setdefault(vi, set()).add(isl)
        vert_uv_by_island.setdefault((vi, isl), uvs[i])
    dst_me.calc_loop_triangles()
    tris_of = {}
    for tri in dst_me.loop_triangles:
        tris_of.setdefault(tri.polygon_index, []).append(tri)
    ext = [max(v[i] for v in verts) - min(v[i] for v in verts)
           for i in range(3)]
    vtol = max(ext) * 1e-5 if verts else 0.0
    # "on the island" means on it, not near it: islands touch each other
    # in 3D, so a corner one island over is still within a percent of this
    # one. Only a corner sitting exactly on a face of the chosen island keeps
    # that island; anything else takes the nearest face of all, whichever
    # island that is - its own.
    # The result's geometry, read once. Reaching through RNA for every
    # corner - 22440 of them, each a Vector built on the fly - was most of
    # what the transfer spent its time on.
    dn = len(dst_me.loops)
    dvi = np.empty(dn, dtype=np.int32)
    dst_me.loops.foreach_get("vertex_index", dvi)
    dnv = len(dst_me.vertices)
    dco = np.empty(dnv * 3, dtype=np.float32)
    dst_me.vertices.foreach_get("co", dco)
    dco = dco.reshape(dnv, 3)
    for layer in src_me.uv_layers:
        dst_layer = (dst_me.uv_layers.get(layer.name)
                     or dst_me.uv_layers.new(name=layer.name))
        sn = len(layer.data)
        sarr = np.empty(sn * 2, dtype=np.float32)
        layer.data.foreach_get("uv", sarr)
        sarr = sarr.reshape(sn, 2)
        # A layer that was just created on a mesh whose loops have been
        # rewritten reports zero entries until Blender fills it in, and
        # foreach_get then refuses the buffer outright - "sequence length
        # mismatch given 43104, needed 0" - which aborted the whole rebuild
        # and left the result half made. An empty layer simply starts at
        # zero here instead.
        if len(dst_layer.data) != dn:
            out = np.zeros(dn * 2, dtype=np.float32)
        else:
            out = np.empty(dn * 2, dtype=np.float32)
            dst_layer.data.foreach_get("uv", out)
        out = out.reshape(dn, 2)
        for face in dst_me.polygons:
            # The face's island is decided by vote, not by its centre. A
            # panel with a hole cut through it has its centre over the hole,
            # and the nearest surface there is the wall inside - an island
            # none of the panel's corners are on. Every corner, pulled a
            # little inward so it is off the seam, names the island under
            # it; the island with the most names wins.
            # Sample points come from the face's own triangulation - the
            # centroid of each triangle, weighted by its area. A corner
            # nudged toward the centre leaves a concave or holed face and
            # lands on the neighbour's island, which is how a 12-gon bordered
            # by seams on every side still voted for the island next door.
            # First word goes to the corners: a rebuilt corner sits on a
            # source vertex, and the islands that vertex belongs to are
            # known exactly. Where two shells lie on top of each other - the
            # label plate on the radio's front, coplanar with the panel
            # under it - the area vote is a coin toss, but the corners are
            # the panel's own vertices and never the plate's.
            cvotes = {}
            votes = {}
            dist = {}
            for tri in tris_of.get(face.index, ()):
                pts = [dst_me.vertices[i].co for i in tri.vertices]
                cen = (pts[0] + pts[1] + pts[2]) / 3
                h = tree.find_nearest(cen)
                if not h or h[2] is None:
                    continue
                isl = island_of[h[2]]
                votes[isl] = votes.get(isl, 0.0) + tri.area
                dist[isl] = min(dist.get(isl, 1e30), h[3])
            for k2 in range(face.loop_start,
                            face.loop_start + face.loop_total):
                co2 = Vector(dco[dvi[k2]])
                for _c, vi, _d in vkd.find_range(co2, vtol):
                    for isl in vert_islands.get(vi, ()):
                        cvotes[isl] = cvotes.get(isl, 0) + 1
            if not votes and not cvotes:
                continue
            pool = set(votes) | set(cvotes)
            best = max(pool, key=lambda i: (cvotes.get(i, 0),
                                           votes.get(i, 0.0),
                                           -dist.get(i, 1e30)))
            for k in range(face.loop_start,
                           face.loop_start + face.loop_total):
                co = Vector(dco[dvi[k]])
                # A corner sitting exactly on a source vertex takes
                # that vertex's UV for this island outright. A vertex
                # on a seam carries one per island, and picking the
                # right one is what stops every face along a seam
                # being stretched across to the other island.
                exact = None
                for _c, svi, _d in vkd.find_range(co, vtol):
                    exact = vert_uv_by_island.get((svi, best))
                    if exact is not None:
                        break
                if exact is not None:
                    out[k] = exact
                    continue
                pi, pd = nearest_on(best, co)
                if pi is None:
                    h3 = tree.find_nearest(co)
                    if not h3 or h3[2] is None:
                        continue
                    pi = h3[2]
                # A corner well off its face's island keeps that island's
                # mapping anyway. Handing it to whichever island it happens
                # to be nearest drew long slivers across the sheet.
                # Every corner maps from the face's own island, even one that
                # sits off it. Handing such a corner to the island it is
                # nearest drew a line across the whole UV sheet; extending
                # the main island's mapping out to it keeps the face compact
                # and the texture merely approximate on that strip - which is
                # all a face spanning two islands can ever be.
                fr = frames.get(pi)
                if fr is None:
                    fr = frames[pi] = frame(src_me.polygons[pi])
                if fr is None:
                    continue
                l0, l1, l2 = fr
                p0 = verts[src_me.loops[l0].vertex_index]
                e1 = verts[src_me.loops[l1].vertex_index] - p0
                e2 = verts[src_me.loops[l2].vertex_index] - p0
                a11 = e1.dot(e1); a12 = e1.dot(e2); a22 = e2.dot(e2)
                det = a11 * a22 - a12 * a12
                if abs(det) < 1e-18:
                    continue
                q = co - p0
                b1 = q.dot(e1); b2 = q.dot(e2)
                sgm = (b1 * a22 - b2 * a12) / det
                tau = (a11 * b2 - a12 * b1) / det
                # Not clamped into the source triangle: doing that
                # pinned every off-island corner onto the island's
                # edge, and 229 faces came out with no UV area at all
                # - a single colour smeared over each of them.
                u0 = sarr[l0]
                out[k] = u0 + (sarr[l1] - u0) * sgm + (sarr[l2] - u0) * tau
        dst_layer.data.foreach_set("uv", out.reshape(-1))
    dst_me.update()
    _heal_uv(dst_me)


def _heal_uv(me):
    """Mend the faces the transfer left reaching across the UV map.

    Whichever path carried the UVs over, a face that landed on a seam took
    corners from two islands and is drawn as a line clean across the map.
    On Milad's `part_07` that was 154 faces of 4206 in `DiffuseUV` and 157
    in `BakeUV`; afterwards, none in either.
    """
    try:
        from .core import uvheal
        return uvheal.heal(me)
    except Exception as exc:      # a mended UV is a bonus, never the job
        print("[quadremesh] UV heal skipped:", exc)
        return 0


# Modifiers that rebuild topology. With Replace Original the fresh quad mesh
# goes into the object and the stack runs on top of it, so a Triangulate left
# on turns every new quad straight back into triangles - the result looked
# nothing like the one Replace Original off produces, from the same remesh.
TOPO_MODS = {"TRIANGULATE", "DECIMATE", "REMESH", "SUBSURF", "MULTIRES"}


def mute_topology_mods(obj):
    """Switch off the modifiers that would undo the remesh. Returns names."""
    off = []
    for m in obj.modifiers:
        if m.type in TOPO_MODS and (m.show_viewport or m.show_render):
            m.show_viewport = False
            m.show_render = False
            off.append(m.name)
    return off


def at_same_place(a, b):
    """Has `a` been moved away from `b`'s transform?"""
    return max((abs(x - y) for ra, rb in zip(a.matrix_world, b.matrix_world)
                for x, y in zip(ra, rb)), default=0.0) <= 1e-6


def _cut_faces_across_seams(dst_obj, src_me, rounds=3, tol=0.05):
    """Cut every rebuilt face that lies across a UV seam, then re-map it.

    A face with corners on two islands has to stretch from one to the other
    however its UVs are worked out - that is the smear left on Milad's grip.
    A face cannot hold two islands, so the face is split in two along the
    line between them and each half maps from one island alone.

    Driven by the transferred UVs themselves, so it needs no seam geometry:
    if a face's corner UVs fall into two clusters, that face straddles.
    """
    total = 0
    for _round in range(rounds):
        me = dst_obj.data
        nl = len(me.loops)
        if not me.uv_layers or not nl:
            return total
        uv = np.empty(nl * 2, dtype=np.float32)
        me.uv_layers[0].data.foreach_get("uv", uv)
        uv = uv.reshape(nl, 2)
        ls = np.empty(len(me.polygons), dtype=np.int32)
        me.polygons.foreach_get("loop_start", ls)
        lt = np.empty(len(me.polygons), dtype=np.int32)
        me.polygons.foreach_get("loop_total", lt)

        jobs = []
        for i in range(len(me.polygons)):
            a, k = int(ls[i]), int(lt[i])
            blk = uv[a:a + k]
            d = np.linalg.norm(blk[:, None, :] - blk[None, :, :], axis=2)
            if d.max() <= tol:
                continue
            # the two groups: the corner with most neighbours, and the rest
            home = int((d <= tol).sum(axis=1).argmax())
            near = d[home] <= tol
            if near.all():
                continue
            jobs.append((i, near))
        if not jobs:
            return total

        bm = bmesh.new()
        bm.from_mesh(me)
        bm.faces.ensure_lookup_table()
        # Collect the faces up front. bisect_plane invalidates the index
        # table, so looking the next one up by number after a cut fails.
        picked = []
        for i, near in jobs:
            picked.append((bm.faces[i], near))
        cut = 0
        for face, near in picked:
            if not face.is_valid or len(face.verts) < 3:
                continue
            vs = list(face.verts)
            if len(vs) != len(near):
                continue
            a_pts = [v.co for v, n in zip(vs, near) if n]
            b_pts = [v.co for v, n in zip(vs, near) if not n]
            if not a_pts or not b_pts:
                continue
            ca = sum(a_pts, Vector()) / len(a_pts)
            cb = sum(b_pts, Vector()) / len(b_pts)
            no = cb - ca
            no -= face.normal * no.dot(face.normal)
            if no.length < 1e-12:
                continue
            geom = [face] + list(face.edges) + list(face.verts)
            try:
                bmesh.ops.bisect_plane(bm, geom=geom, plane_co=(ca + cb) / 2,
                                       plane_no=no.normalized())
                cut += 1
            except Exception:
                pass
        if not cut:
            bm.free()
            return total
        bm.to_mesh(me)
        bm.free()
        me.update()
        total += cut
        keep_uvs(dst_obj, src_me)
    return total


MIRROR_AXIS = {"X": 0, "Y": 1, "Z": 2}


def detect_symmetry(obj, tol_ratio=0.01):
    """Which local axis this mesh is mirror-symmetric across, or None.

    Mirror-modelled hard-surface parts are the common case and remeshing them
    whole wastes the symmetry: the two halves come back with different edge
    flow, and the seam down the middle is where it shows worst. Finding the
    plane lets the build happen once on one half.

    A sample of vertices is reflected through the object's own origin - the
    same plane a Mirror modifier would use - and each reflection is asked for
    its nearest real vertex. If they all land on the surface within a fraction
    of the model's size, the mesh is symmetric across that axis.
    """
    from mathutils.kdtree import KDTree

    me = obj.data
    n = len(me.vertices)
    if n < 8:
        return None
    co = np.empty(n * 3, dtype=np.float64)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3)

    size = float(max(co.max(axis=0) - co.min(axis=0)))
    if size <= 0:
        return None
    tol = size * tol_ratio

    tree = KDTree(n)
    for i, p in enumerate(co):
        tree.insert(p, i)
    tree.balance()

    step = max(1, n // 2000)
    sample = co[::step]
    best = None
    for name, axis in MIRROR_AXIS.items():
        # A mesh that is flat in this axis is not symmetric across it, it is
        # simply degenerate there, and would score perfectly.
        spread = float(sample[:, axis].max() - sample[:, axis].min())
        if spread < size * 0.05:
            continue
        worst = 0.0
        for p in sample:
            q = p.copy()
            q[axis] = -q[axis]
            hit = tree.find(Vector(q))
            if hit is None or hit[0] is None:
                worst = float("inf")
                break
            d = (Vector(q) - hit[0]).length
            if d > worst:
                worst = d
            if worst > tol:
                break
        if worst <= tol and (best is None or worst < best[1]):
            best = (name, worst)
    return best[0] if best else None


def cut_half(obj, axis_name, gap=1e-6):
    """A temporary object holding the positive half of `obj`.

    Vertices that land on the plane are snapped exactly onto it, so the mirror
    afterwards welds instead of leaving a hairline crack.
    """
    import bmesh
    from mathutils import Vector as V3

    axis = MIRROR_AXIS[axis_name]
    me = obj.data.copy()
    me.name = obj.data.name + "_half"
    bm = bmesh.new()
    bm.from_mesh(me)
    no = V3((0.0, 0.0, 0.0))
    no[axis] = 1.0
    bmesh.ops.bisect_plane(bm, geom=list(bm.verts) + list(bm.edges) +
                           list(bm.faces), plane_co=V3((0.0, 0.0, 0.0)),
                           plane_no=no, clear_inner=True, clear_outer=False)
    size = max(obj.dimensions) or 1.0
    for v in bm.verts:
        if abs(v.co[axis]) < size * 1e-4:
            v.co[axis] = 0.0
    bm.to_mesh(me)
    bm.free()
    me.update()

    half = bpy.data.objects.new(obj.name + "_SR_half", me)
    for coll in obj.users_collection:
        coll.objects.link(half)
    half.matrix_world = obj.matrix_world.copy()
    return half


def weld_mirror(obj, axis_name):
    """Reflect the mesh through the plane and weld the seam.

    Only the geometry is mirrored; the object keeps its own transform, so this
    survives being moved afterwards where a Mirror modifier plus an origin
    change would not.
    """
    import bmesh

    axis = MIRROR_AXIS[axis_name]
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)

    size = max(obj.dimensions) or 1.0
    for v in bm.verts:
        if abs(v.co[axis]) < size * 1e-4:
            v.co[axis] = 0.0

    src = list(bm.verts) + list(bm.edges) + list(bm.faces)
    dup = bmesh.ops.duplicate(bm, geom=src)["geom"]
    verts = [g for g in dup if isinstance(g, bmesh.types.BMVert)]
    faces = [g for g in dup if isinstance(g, bmesh.types.BMFace)]
    for v in verts:
        v.co[axis] = -v.co[axis]
    # reflecting turns every face inside out
    bmesh.ops.reverse_faces(bm, faces=faces)

    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=size * 1e-4)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    me.update()
    return len(me.polygons)


def fold_result(obj, axis_name):
    """Keep one half of a finished mesh and reflect it onto the other.

    The first attempt cut the *source* in half and built that. It gave clean
    quads but a different mesh: the cut is an open border, the detector reads
    it as a real edge of the model, and the result came back with 8 boundary
    edges and a quarter of the straight runs the whole build found. Turning
    the mirror on changed far more than the symmetry.

    Folding the finished result instead means the detection never sees a cut
    at all - it is the same build, with one half replaced by the other. The
    seam costs a little: vertices near the plane are pulled onto it first, so
    the cut lands on existing edges wherever it can rather than slicing quads
    in half.
    """
    import bmesh

    axis = MIRROR_AXIS[axis_name]
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    if not bm.faces:
        bm.free()
        return len(me.polygons)

    span = 0.0
    for e in bm.edges:
        span += (e.verts[0].co - e.verts[1].co).length
    span /= max(len(bm.edges), 1)
    snap = span * 0.35

    for v in bm.verts:
        if abs(v.co[axis]) < snap:
            v.co[axis] = 0.0

    no = Vector((0.0, 0.0, 0.0))
    no[axis] = 1.0
    bmesh.ops.bisect_plane(bm, geom=list(bm.verts) + list(bm.edges) +
                           list(bm.faces), plane_co=Vector((0.0, 0.0, 0.0)),
                           plane_no=no, clear_inner=True, clear_outer=False)
    bm.verts.ensure_lookup_table()
    for v in bm.verts:
        if abs(v.co[axis]) < snap * 0.5:
            v.co[axis] = 0.0

    src = list(bm.verts) + list(bm.edges) + list(bm.faces)
    dup = bmesh.ops.duplicate(bm, geom=src)["geom"]
    verts = [g for g in dup if isinstance(g, bmesh.types.BMVert)]
    faces = [g for g in dup if isinstance(g, bmesh.types.BMFace)]
    for v in verts:
        v.co[axis] = -v.co[axis]
    bmesh.ops.reverse_faces(bm, faces=faces)
    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=span * 1e-3)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    me.update()
    return len(me.polygons)


def build_panel_mesh(context, source=None, reuse=None):
    """Emit the panels as real geometry, sitting exactly on the lines.

    Nothing here is simplified or inset - a boundary vertex of the result is a
    boundary vertex of the detected network, so the two cannot drift apart.
    """
    import bmesh

    st = context.scene.quadremesh_lines
    obj = source or bpy.data.objects.get(st.source)
    if obj is None or obj.type != "MESH" or not len(obj.data.polygons):
        return None
    cache = get_cache(obj)
    mask, info, plog, crease, flat, auto_c, auto_f = detect(context, cache, st)
    # Keep the line readout in step with what was actually built. It used to be
    # written only by the preview, so it could still be describing a different
    # object from a previous run while the build below said something else.
    st.info = _info_line(info, plog, crease, flat, auto_c, auto_f)
    # Vertices that must survive the straightening. A UV seam counts for the
    # same reason a hand-marked line does: the seam is only kept if the
    # vertices along it stay where they are, and the straightening judged
    # them redundant and merged them - which is why Keep UV Islands still
    # let the islands drift.
    pinned = None
    keep_edges = None
    if st.hs_use_marked or st.hs_only_marked:
        marked, n_marked = marked_mask(obj, cache)
        if n_marked:
            keep_edges = marked
    if keep_edges is not None and keep_edges.any():
        pinned = np.zeros(len(cache["V"]), dtype=bool)
        pinned[cache["edges"][keep_edges].ravel()] = True
        marked = keep_edges
    V, faces, rep, lines = HS.panels_to_mesh(cache, mask,
                                             straighten=st.straighten,
                                             planar_tol=st.planar_tol,
                                             pinned=pinned)
    if not len(faces):
        st.build_info = "no closed panel found"
        return None
    diag = float(np.linalg.norm(V.max(0) - V.min(0))) or 1.0
    muted = []

    # One result per model, so dragging a slider does not leave a pile of old
    # results stacked at the same spot. Which object that is depends on how we
    # got here: a live refresh updates the one it is already driving, wherever
    # the user has put it, while a fresh button press may need a new one.
    name = obj.name + BUILD_SUFFIX
    target = bpy.data.objects.get(reuse) if reuse else None
    if target is None:
        existing = bpy.data.objects.get(name)
        if existing is not None:
            # The moment a result is dragged somewhere to compare it, it stops
            # being scratch and becomes the user's. Overwriting it then throws
            # their work away, so a moved one is left alone and the new result
            # takes a free name instead.
            if not at_same_place(existing, obj):
                n = 1
                while bpy.data.objects.get(f"{name}.{n:03d}") is not None:
                    n += 1
                name = f"{name}.{n:03d}"
            else:
                target = existing
    me = bpy.data.meshes.new(name + "_mesh")
    me.from_pydata([tuple(p) for p in V], [], [list(f) for f in faces])
    me.validate(verbose=False)
    keep_materials(obj.data, me)
    bm = bmesh.new()
    bm.from_mesh(me)
    # Loop chaining picks a direction per panel independently, so the windings
    # disagree between neighbours until they are made to agree.
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    # Tag the bore walls in a face layer rather than holding references: the
    # bevel destroys every original face and builds replacements, so a Python
    # handle taken before it is dead afterwards and the support pass found
    # nothing to work on. Custom layers are carried over to the replacements.
    bm.faces.ensure_lookup_table()
    kind = bm.faces.layers.int.new("qr_kind")
    group = bm.faces.layers.int.new("qr_panel")
    for f, g in zip(bm.faces, rep["face_panel"]):
        f[group] = g
    for i in rep["bore_faces"]:
        bm.faces[i][kind] = 1

    # Mark the detected lines on the edges themselves, now, while the vertex
    # numbering still matches what `panels_to_mesh` handed back. The chamfer
    # used to look them up by vertex-index pair at the end, but the loop
    # dissolve in between deletes vertices and renumbers the rest, so the pairs
    # pointed at the wrong edges by then: measured on a bevelled test cube, 312
    # of 312 lines were found with the dissolve off and 49 of 312 with it on.
    # That is the "some edges chamfer and some do not" - the selection was a
    # near-random sixth of what was asked for. A layer travels with the edge.
    is_line = bm.edges.layers.int.new("qr_line")
    is_user = bm.edges.layers.int.new("qr_user")
    bm.edges.ensure_lookup_table()
    for e in bm.edges:
        a, b = e.verts[0].index, e.verts[1].index
        if (min(a, b), max(a, b)) in lines:
            e[is_line] = 1
    # Which of those lines are the user's own. The panel build renumbers
    # every vertex, so the marked edges are found again by position: an
    # edge whose midpoint sits on a marked source edge's midpoint.
    segs = []
    if pinned is not None:
        from mathutils.kdtree import KDTree
        src_V = cache["V"]
        mids = [((src_V[a] + src_V[b]) / 2.0) for a, b in
                cache["edges"][marked].tolist()]
        if mids:
            from mathutils import Vector
            segs = [(Vector(src_V[a].tolist()), Vector(src_V[b].tolist()))
                    for a, b in cache["edges"][marked].tolist()]
            kd = KDTree(len(mids))
            for i, m in enumerate(mids):
                kd.insert(m.tolist(), i)
            kd.balance()
            # by distance to the marked segment, not midpoint to midpoint:
            # the straight-run pass merges a run of source edges into one
            # built edge, whose midpoint matches none of theirs
            tol = diag * 1e-4
            for e in bm.edges:
                # every edge, not just the detected lines: inside a curved
                # region kept as-is the user's line is ordinary geometry
                m = (e.verts[0].co + e.verts[1].co) / 2
                for _co, i, _d in kd.find_n(m, 6):
                    a, b = segs[i]
                    _q, t = intersect_point_line(m, a, b)
                    t = min(max(t, 0.0), 1.0)
                    if (m - a.lerp(b, t)).length < tol:
                        e[is_user] = 1
                        break

    # Panels are emitted one at a time, so where two of them share a border
    # each writes its own copy of the vertices along it. They land on exactly
    # the same coordinates, which is why nothing looked wrong - no open edge,
    # no hole - but the mesh is split there, and a bevel or a subdivision opens
    # the seam. Measured on the barrier: 18 pairs sitting under two microns
    # apart. The next real spacing is a hundred times that, so a weld a
    # hundred-thousandth of the model wide takes the duplicates and can reach
    # nothing else. This has to run after the line tagging above, which is
    # written by vertex index, and before anything that reads the tag.
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=diag * 1e-5)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    # A marked line that does not separate two panels - a seam that stops
    # in the middle of a flat, say - has no face border to live on, and the
    # panel build simply had nowhere to put it: 7 of the 549 lines on
    # Milad's radio went that way. A face cannot carry an edge inside it,
    # so the panel is cut right through along the line instead. The line is
    # then there, exactly where it was drawn, as the border between the two
    # halves.
    # Both of the tidying passes below walk every marked line against the
    # whole mesh. On Milad's car - 54000 faces, 9902 lines - that is hours,
    # which read as a crash. Above this size they are skipped: the result is
    # the same mesh, only without the last per-line refinement.
    HEAVY = 20000
    heavy = len(bm.faces) > HEAVY or len(segs) > 4000
    cut_in = 0
    if pinned is not None and segs and not heavy:
        from mathutils.bvhtree import BVHTree
        # one tree, rebuilt only after a cut. Building it afresh for every
        # segment - 9902 of them on the car, over 50k faces - is what made
        # the remesh look like a crash
        tree = BVHTree.FromBMesh(bm)
        for a, b in segs:
            mid = (a + b) / 2
            hit = tree.find_nearest(mid)
            # the line may sit a little off the panel: a small step the
            # Coplanar tolerance flattened into its neighbour is exactly the
            # case here, 0.3% of the model above the face on the radio
            if hit is None or hit[2] is None or hit[3] > diag * 0.02:
                continue
            face = bm.faces[hit[2]]
            # already on a border of this face? then nothing to do
            on_edge = False
            for e in face.edges:
                _q, t = intersect_point_line(mid, e.verts[0].co, e.verts[1].co)
                t = min(max(t, 0.0), 1.0)
                if (mid - e.verts[0].co.lerp(e.verts[1].co, t)).length                         < diag * 1e-4:
                    on_edge = True
                    break
            if on_edge:
                continue
            d = (b - a)
            if d.length < 1e-12:
                continue
            no = face.normal.cross(d.normalized())
            if no.length < 1e-9:
                continue
            no.normalize()
            # only a cut that leaves something on both sides. A line a hair
            # inside a panel's border would shave off a sliver - a face two
            # millionths of the model in area with corners on no vertex at
            # all - and that sliver is what smeared the texture at the UV
            # sheet's corners. The line is then left to the border it hugs.
            side = [(v.co - mid).dot(no) for v in face.verts]
            thin = diag * 0.01
            if max(side) < thin or min(side) > -thin:
                continue
            geom = [face] + list(face.edges) + list(face.verts)
            res = bmesh.ops.bisect_plane(bm, geom=geom, plane_co=mid,
                                         plane_no=no)
            for g in res["geom_cut"]:
                if isinstance(g, bmesh.types.BMEdge):
                    g[is_user] = 1
                    g[is_line] = 1
            cut_in += 1
            bm.faces.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            tree = BVHTree.FromBMesh(bm)

    # Regions handed back whole arrive as the source triangles. Pairing them up
    # moves no vertex, so the shape is untouched, but it stops the result being
    # mostly triangles wherever the model is curved.
    tri = [f for f in bm.faces if len(f.verts) == 3]
    if tri:
        # Never pair two triangles across a line: a quad straddling a UV
        # seam carries two islands in one face and the texture smears across
        # it. The built mesh has no UVs yet to compare, so the lines are
        # lent the sharp flag for the duration of the join and handed back.
        lent = [e for e in bm.edges if (e[is_line] or e[is_user]) and e.smooth]
        for e in lent:
            e.smooth = False
        bmesh.ops.join_triangles(
            bm, faces=tri, angle_face_threshold=0.9, angle_shape_threshold=1.4,
            cmp_seam=False, cmp_sharp=True, cmp_uvs=False, cmp_vcols=False,
            cmp_materials=False)
        for e in lent:
            if e.is_valid:
                e.smooth = True
        bm.faces.ensure_lookup_table()

    dissolved = 0
    if st.dissolve_straight > 0.0:
        before_f = len(bm.faces)
        for _pass in range(40):
            here = len(bm.faces)
            sel = _straight_loops(bm, st.dissolve_straight * diag,
                                  protect=is_user)
            if not sel:
                break
            bmesh.ops.dissolve_edges(bm, edges=sel, use_verts=True,
                                     use_face_split=False)
            bm.faces.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            # A pass that changes nothing will change nothing next time
            # either - the same edges come back and the dissolve refuses them
            # again. It only ever stopped because the counter ran out.
            # Measured on a 159,806 face cabinet: two passes did the work,
            # then thirty eight identical passes found the same two edges,
            # removed no face at all, and cost 26.6 of the build's 34.4
            # seconds.
            if len(bm.faces) >= here:
                break
        dissolved = before_f - len(bm.faces)

    circles = 0
    if st.refit_circles and dissolved:
        circles = _refit_circles(bm, obj)
        bm.normal_update()

    cham = 0
    got_width = 0.0
    beveled = set()
    if st.chamfer > 0.0:
        bm.edges.ensure_lookup_table()
        # Only the detected lines. The cuts that open a hole and the rungs of a
        # bore wall are construction edges - chamfering those would round off
        # the inside of the cylinder instead of its rim.
        sel = [e for e in bm.edges if e[is_line]]
        if sel:
            # Total length of what is about to be chamfered, so the width the
            # bevel actually managed can be read back off the band area
            # afterwards. Guessing at Blender's clamp from edge lengths was
            # tried and is not reliable - a flat panel arrives as one n-gon
            # whose shortest edge is some tiny boundary segment, which made
            # every band look clamped even when none was. Measuring the result
            # cannot be wrong in that way.
            line_len = sum(e.calc_length() for e in sel)
            res = bmesh.ops.bevel(
                bm, geom=sel, offset=st.chamfer * diag,
                offset_type="OFFSET", segments=st.chamfer_segments,
                profile=st.chamfer_profile, affect="EDGES",
                clamp_overlap=st.chamfer_clamp,
                miter_outer="ARC", miter_inner="SHARP",
                loop_slide=True, material=-1)
            beveled = set(res["faces"])
            cham = len(sel)
            band_area = sum(f.calc_area() for f in res["faces"] if f.is_valid)
            if line_len > 0.0:
                got_width = band_area / line_len
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    sup, clamped = 0, 0
    if st.support > 0.0 and st.support_loops > 0:
        # What is left once the chamfer bands and the bore walls are taken out
        # is exactly the flat panels, and the pieces one panel was cut into
        # carry the same group so they inset as a unit.
        live = defaultdict(list)
        for f in bm.faces:
            if f not in beveled and f[kind] == 0:
                live[f[group]].append(f)
        live = list(live.values())
        for _ in range(st.support_loops):
            nxt = []
            for grp in live:
                grp = [f for f in grp if f.is_valid]
                if not grp:
                    continue
                # Hydraulic radius: twice the area over the perimeter. A width
                # near that collapses the panel, so hold well under it. Without
                # this a support wider than a narrow panel folds it inside out.
                inner_e = {e for f in grp for e in f.edges
                           if sum(1 for g in e.link_faces if g in grp) > 1}
                per = sum(e.calc_length() for f in grp for e in f.edges
                          if e not in inner_e) or 1e-12
                area = sum(f.calc_area() for f in grp)
                w = st.support * diag
                cap = 0.4 * (2.0 * area / per)
                if w > cap:
                    w = cap
                    clamped += 1
                if w <= 1e-9:
                    continue
                res = bmesh.ops.inset_region(
                    bm, faces=grp, use_boundary=True, use_even_offset=True,
                    thickness=w, depth=0.0, use_interpolate=True)
                sup += 1
                band = set(res["faces"])
                keep = [f for f in bm.faces
                        if f.is_valid and f not in band and f[group] == grp[0][group]
                        and f[kind] == 0 and f not in beveled]
                if keep:
                    nxt.append(keep)
            live = nxt
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=diag * 1e-5)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    # Where two detected lines run a hair apart the chamfer has no room between
    # them, and the bevel comes out as edges a fraction of a millimetre long -
    # in the viewport that reads as loose vertices sitting on top of each
    # other. Measured on the barrier: 133 edges under 0.3 mm where the median
    # is 0.63 mm. Collapsing them is the weld; dropping one of the two lines
    # instead was tried and breaks the panel loop, so the build returns
    # nothing at all.
    welded = 0
    if st.weld_close > 0.0:
        before_v = len(bm.verts)
        # Never wider than a fraction of the chamfer it is cleaning up. As a
        # plain fraction of the model this ate the chamfer itself once the
        # band got small: at chamfer 0.002 the band is 0.81 mm and the weld
        # was 0.32 mm of it, so lowering the chamfer one step went from a
        # clean result to a wrecked one. The band is what these collapsed
        # edges belong to, so the band is what the limit has to follow.
        limit = st.weld_close * diag
        if got_width > 0.0:
            limit = min(limit, got_width * 0.25)
        # Two lines that end near each other without touching. Where a
        # reference model has a panel line that jogs sideways as it crosses
        # another - the line above ends a hair to one side of the line below -
        # the two ends are separate vertices with no edge between them, so
        # collapsing short edges never reaches them and the kink survives
        # every rebuild. Measured on Milad's train: the two ends sit 0.018
        # apart on a part 32 across, and they are that far apart in the
        # reference itself. Pulling them together is the same job the slider
        # already names, so it is done under the same number.
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=limit)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bmesh.ops.dissolve_degenerate(bm, dist=limit, edges=bm.edges[:])
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        welded = before_v - len(bm.verts)

    bnd = sum(1 for e in bm.edges if len(e.link_faces) == 1)
    tris = sum(1 for f in bm.faces if len(f.verts) == 3)
    bm.to_mesh(me)
    bm.free()
    me.update()
    if st.hs_replace:
        # Straight into the object. The mesh it displaces is kept the first
        # time only - after that `obj.data` is our own previous output and
        # stashing it would lose the real original for good.
        if ORIG_KEY not in obj:
            obj.data.use_fake_user = True
            obj[ORIG_KEY] = obj.data.name
        obj.data = me
        out = obj
        muted = mute_topology_mods(obj)
    else:
        # The checkbox has to work both ways. Once Replace has written into the
        # object, switching it off has to hand the model back - otherwise the
        # object keeps showing the replaced mesh and the checkbox reads as
        # stuck on, which is exactly how it was reported.
        if ORIG_KEY in obj:
            back = bpy.data.meshes.get(obj[ORIG_KEY])
            if back is not None:
                spent = obj.data
                obj.data = back
                back.use_fake_user = False
                del obj[ORIG_KEY]
                if spent.users == 0 and not spent.use_fake_user:
                    try:
                        bpy.data.meshes.remove(spent)
                    except Exception:
                        pass
        if target is not None:
            # swap the geometry, keep the object - so the transform the user
            # gave it survives every rebuild
            spent = target.data
            target.data = me
            if spent.users == 0 and not spent.use_fake_user:
                try:
                    bpy.data.meshes.remove(spent)
                except Exception:
                    pass
            out = target
        else:
            out = bpy.data.objects.new(name, me)
            out.matrix_world = obj.matrix_world.copy()
            for coll in obj.users_collection:
                coll.objects.link(out)
        # Restore Original reads this to know what to put back and what to
        # unhide; the kind keeps the two halves from adopting each other's
        # results, which they did - Organic overwrote a Hardsurface result
        # because both only wrote the source name.
        out["quadremesh_source"] = obj.name
        out["quadremesh_kind"] = "hardsurface"
    src_data = (bpy.data.meshes.get(obj[ORIG_KEY]) if ORIG_KEY in obj
                else obj.data) if out is obj else obj.data
    keep_uvs(out, src_data)
    st.result = out.name
    st.build_info = (
        f"{len(me.polygons)} faces  |  {len(me.vertices)} verts  |  "
        f"{rep['holes']} holes cut, {rep['bores']} bores walled  |  "
        f"{rep['kept_curved']} curved regions kept as-is "
        f"({100 * rep['curved_area_pct']:.0f}% of area)  |  "
        f"{rep['dropped']} straight-run verts dropped  |  "
        f"chamfer on {cham} lines"
        + (f" - asked {st.chamfer:.4f}, got {got_width / diag:.4f}"
           + (" (Clamp Overlap)" if st.chamfer_clamp
              and got_width / diag < st.chamfer * 0.9 else "")
           if cham and st.chamfer > 0.0 else "") + "  |  "
        f"{sup} support rings ({clamped} narrowed to fit)  |  "
        f"{bnd} boundary edges  |  {tris} tris"
        + (f"  |  welded {welded} verts where lines ran together" if welded else "")
        + (f"  |  switched off {', '.join(muted)}" if muted else ""))
    return out


def build_maybe_mirrored(context, source=None, reuse=None, report=None):
    """`build_panel_mesh`, folded across the symmetry plane when asked.

    This lives here rather than in the Remesh button because every rebuild
    goes through it: changing a preset refreshes the result live, and when
    only the button knew about mirroring that refresh quietly produced an
    unmirrored mesh - the tick stayed on while the model stopped matching it,
    and it took another press of Remesh to get the mirror back.
    """
    st = context.scene.quadremesh_lines
    obj = source or bpy.data.objects.get(st.source)
    if obj is None:
        return None

    axis = None
    if st.hs_mirror:
        axis = (st.hs_mirror_axis if st.hs_mirror_axis != "AUTO"
                else detect_symmetry(obj))
        if axis is None and report:
            report({"WARNING"},
                   "Mirror Retopology: this model is not symmetric across any "
                   "axis - built whole instead")

    out = build_panel_mesh(context, obj, reuse=reuse)
    if out is None:
        return None
    st.result = out.name

    fresh_shading(out.data)
    if axis is not None:
        n = fold_result(out, axis)
        st.build_info = (f"{st.build_info}  |  mirrored across {axis}, "
                         f"{n:,} faces")
    return out


def _rebuild(self, context):
    """Chamfer settings only need the built mesh redone, not the detection."""
    st = context.scene.quadremesh_lines
    if _suspend or not st.source or not session_owns(context, st):
        return
    src = bpy.data.objects.get(st.source)
    built = (bpy.data.objects.get(st.result) is not None
             or (src is not None and ORIG_KEY in src))
    if not built:
        return
    # Hold the name, not the object: build_panel_mesh deletes the previous
    # result, and a Python handle to a removed object raises on any attribute
    # access - which killed the whole slider drag.
    prev = context.view_layer.objects.active
    was_result = prev is not None and prev.name.endswith(BUILD_SUFFIX)
    out = build_maybe_mirrored(context, reuse=st.result)
    if out is not None and was_result:
        for o in list(context.selected_objects):
            o.select_set(False)
        out.select_set(True)
        context.view_layer.objects.active = out


def session_owns(context, st):
    """Is the user still working on the object this session is bound to?

    `st.source` remembers the last model remeshed and used to be the only test,
    so selecting a different model and touching any setting rebuilt the
    *previous* one - the new selection was ignored and the old result silently
    changed under you. The live rebuild only belongs to whoever is looking at
    that object or at something it produced.
    """
    act = context.view_layer.objects.active
    if act is None or not st.source:
        return False
    return act.name in (st.source, st.result, st.source + SUFFIX,
                        st.source + PANEL_SUFFIX)


def _live(self, context):
    """Refresh whatever the user already has on screen.

    It used to build the line preview unconditionally, which was fine while
    there was a Lines button to ask for it. With only Remesh left, dragging a
    slider would have spawned a line object nobody asked for, so each preview
    is refreshed only when it already exists.
    """
    st = context.scene.quadremesh_lines
    if _suspend or not st.source or not session_owns(context, st):
        return
    if bpy.data.objects.get(st.source + SUFFIX) is not None:
        rebuild_preview(context)
    if bpy.data.objects.get(st.source + PANEL_SUFFIX) is not None:
        rebuild_panels(context)
    src = bpy.data.objects.get(st.source)
    if (bpy.data.objects.get(st.result) is not None
            or (src is not None and ORIG_KEY in src)):
        _rebuild(self, context)


# Read off eight prototype recordings. Everything in PRESET_COMMON was
# identical in all eight, so it is not a choice anyone was making - it is what
# the tool wants. Only four values ever moved, and they moved together in three
# recognisable ways, which is what the three presets are.
PRESET_COMMON = {
    "planar_tol": 0.01,       # Flatten Below  - 0.0100 in all eight
    "straighten": 0.0002,     # Straighten     - 0.00020 in all eight
    "chamfer": 0.0,           # never used
    "support": 0.0,           # never used
    "use_type": True,
    "close_gaps": True,
    "gap_span": 0.0,          # 0.000 in every modern run
    "refit_circles": True,
    "auto_thresholds": False,
    "weld_close": 0.0002,
}

PRESETS = {
    # coffee_p03 (93% flat) and futuristic mech (15% flat) - flat area does not
    # predict this one. Crease 0 takes every line and leaves the sorting to the
    # coplanar test and the prune, which is what you reach for when the crease
    # detector is not finding the right lines.
    "DETAIL": {
        "crease_deg": 0.0, "flat_deg": 4.90,
        "min_chain": 0.0, "dissolve_straight": 0.0015,
        "auto_prune": True,
    },
    # The mainstream setting: car body, back seats, stone lantern, trigger.
    # Crease ran 19.5-27 across those four, so 23 is the middle of it.
    "BALANCED": {
        "crease_deg": 23.0, "flat_deg": 2.00,
        "min_chain": 1.0, "dissolve_straight": 0.0020,
        "auto_prune": True,
    },
    # Body, 98% flat panel, 8960 faces in and 137 out. Only the strongest
    # creases, and the prune switched off because at crease 40 there is nothing
    # spurious left for it to remove.
    "FLAT": {
        "crease_deg": 40.0, "flat_deg": 2.00,
        "min_chain": 0.1, "dissolve_straight": 0.0010,
        "auto_prune": False,
    },
}


# Everything a preset captures. Anything not on this list stays as the user
# left it when a preset is applied - Chamfer and Support are on it precisely
# so a preset cannot leave a stale chamfer behind.
PRESET_FIELDS = sorted(set(PRESET_COMMON) | set(PRESETS["BALANCED"]))

# Saved presets live in Blender's config directory rather than in the .blend,
# so they follow the user between files the way the built-in three do.
_USER: dict = {}
_ENUM_ITEMS: list = []          # held to stop Blender collecting the strings


def _user_path():
    d = bpy.utils.user_resource("CONFIG", path="smart_remesh", create=True)
    return os.path.join(d, "presets.json")


def load_user_presets():
    global _USER
    try:
        with open(_user_path(), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        _USER = {k: v for k, v in data.items() if isinstance(v, dict)}
    except Exception:
        _USER = {}


def save_user_presets():
    try:
        with open(_user_path(), "w", encoding="utf-8") as fh:
            json.dump(_USER, fh, indent=1, sort_keys=True)
        return True
    except Exception as exc:
        print("Smart Remesh: could not write presets:", exc)
        return False


def _preset_items(self, context):
    global _ENUM_ITEMS
    items = [
        ("BALANCED", "Balanced",
         "Crease 23, Coplanar 2.00, Min Length 1.0, Loops 0.0020. The setting "
         "four of the eight prototypes converged on"),
        ("DETAIL", "Detail",
         "Crease 0, Coplanar 4.90, Min Length 0, Loops 0.0015. Takes every "
         "line and lets the coplanar test and the prune sort them out"),
        ("FLAT", "Flat Panels",
         "Crease 40, Coplanar 2.00, Min Length 0.1, Loops 0.0010, prune off. "
         "For a model that is nearly all flat panel"),
    ]
    if _USER:
        items.append(None)
        for name in sorted(_USER):
            items.append(("USER:" + name, name, "Saved preset"))
    items.append(None)
    items.append(("CUSTOM", "Custom", "Values set by hand"))
    _ENUM_ITEMS = items
    return _ENUM_ITEMS


def _apply_preset(self, context):
    st = context.scene.quadremesh_lines
    key = st.preset
    if key == "CUSTOM":
        return
    if key.startswith("USER:"):
        values = _USER.get(key[5:])
        if not values:
            return
    else:
        values = dict(PRESET_COMMON)
        values.update(PRESETS[key])
    with suspend_live():                 # one rebuild at the end, not fifteen
        for k, v in values.items():
            try:
                setattr(st, k, v)
            except Exception:
                pass                     # a preset from an older version
    _live(self, context)


class QUADREMESH_OT_preset_save(Operator):
    bl_idname = "mesh.quadremesh_preset_save"
    bl_label = "Save Preset"
    bl_description = ("Store the current settings under a name. Saved presets "
                      "live in Blender's config folder, so they follow you "
                      "between files")
    bl_options = {"REGISTER"}

    name: StringProperty(name="Name", default="My Preset")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=260)

    def draw(self, context):
        self.layout.prop(self, "name")

    def execute(self, context):
        st = context.scene.quadremesh_lines
        nm = self.name.strip()
        if not nm:
            self.report({"WARNING"}, "give it a name")
            return {"CANCELLED"}
        _USER[nm] = {k: getattr(st, k) for k in PRESET_FIELDS
                     if k in st.bl_rna.properties}
        if not save_user_presets():
            self.report({"ERROR"}, "could not write the preset file")
            return {"CANCELLED"}
        st.preset = "USER:" + nm
        self.report({"INFO"}, f"saved '{nm}'")
        return {"FINISHED"}


class QUADREMESH_OT_preset_delete(Operator):
    bl_idname = "mesh.quadremesh_preset_delete"
    bl_label = "Delete Preset"
    bl_description = "Remove the saved preset that is currently selected"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.scene.quadremesh_lines.preset.startswith("USER:")

    def execute(self, context):
        st = context.scene.quadremesh_lines
        nm = st.preset[5:]
        if nm not in _USER:
            return {"CANCELLED"}
        del _USER[nm]
        save_user_presets()
        st.preset = "CUSTOM"
        self.report({"INFO"}, f"deleted '{nm}'")
        return {"FINISHED"}


class _Folded:
    """A layout that quietly swallows everything drawn into it.

    A folded box still has its whole body written out below it, and rewriting
    every one of those calls to sit behind a test would be a long edit with a
    lot of room to slip. Handing the body this instead costs one line per
    section: every call on it does nothing and hands itself back, so the block
    below draws into nowhere.
    """

    def _nothing(self, *args, **kwargs):
        return self

    def __getattr__(self, name):
        return self._nothing


FOLDED = _Folded()


def fold_head(layout, st, flag, title, icon):
    """Draw a section header that folds, and give back the body to draw into.

    The body is the box itself when the section is open and a sink when it is
    shut, so the code under it never has to know which it got.
    """
    box = layout.box()
    head = box.row(align=True)
    head.prop(st, flag, text="", emboss=False,
              icon="TRIA_DOWN" if getattr(st, flag) else "TRIA_RIGHT")
    head.label(text=title, icon=icon)
    return box if getattr(st, flag) else FOLDED


class QuadRemeshLines(PropertyGroup):
    show_cleanup: BoolProperty(
        name="Smart Cleanup", default=False,
        description="Open the Smart Cleanup tools")
    show_uv: BoolProperty(
        name="UV", default=False,
        description="Open the UV and bake tools")
    show_loops: BoolProperty(
        name="Erase Useless Loops", default=False,
        description="Open the loop dropping tools")
    show_chamfer: BoolProperty(
        name="Chamfer", default=False,
        description="Open the chamfer and support settings")
    preset: EnumProperty(
        name="Preset", items=_preset_items, update=_apply_preset,
        description="Built-in presets, then anything you have saved")
    source: StringProperty(name="Source")
    result: StringProperty(name="Result")
    info: StringProperty(name="Info")
    panel_info: StringProperty(name="Panel Info")
    build_info: StringProperty(name="Build Info")
    panelize_info: StringProperty(name="Panelize Info")
    hs_use_marked: BoolProperty(
        name="Include My Lines", default=True, update=_live,
        description="Add the edges you marked Sharp to the lines the detector "
                    "found. They then go through the same rebuild as every "
                    "other line")
    pz_amount: FloatProperty(
        name="Remove", default=100.0, min=0.0, max=100.0, subtype="PERCENTAGE",
        update=_pz_live,
        description="How much of the geometry inside your lines to remove. "
                    "100 leaves one face per region; lower keeps some of the "
                    "grid, the loops holding least shape going first")
    pz_merge: FloatProperty(
        name="Second Pass", default=0.0, min=0.0, max=100.0,
        subtype="PERCENTAGE", update=_pz_live,
        description="Go over what is left again and take every other line. "
                    "Plain and predictable, unlike the angle-based merge this "
                    "replaced, which wandered across the grid and broke round "
                    "forms. 0 is off, 100 takes every alternate line")
    pz_confine: BoolProperty(
        name="Stay Inside Lines", default=True, update=_pz_live,
        description="Keep every change inside the area you marked. Off lets a "
                    "loop be followed wherever it runs, which tidies the ends "
                    "but can reach into another part of the model that the "
                    "same loop was shaping and take that apart too")
    pz_pole_rounds: IntProperty(
        name="Rounds", default=8, min=1, max=60,
        description=("How many passes Tidy Poles makes. Each one walks the "
                     "poles a step further from the creases"))
    pz_pole_budget: FloatProperty(
        name="Seconds", default=0.0, min=0.0, max=600.0, soft_max=60.0,
        description=("Stop after this long, whatever is left. 0 runs to the "
                     "end - on a 10000 face part the passes settle in about "
                     "eight seconds"))
    pz_sel_whole_loops: BoolProperty(
        name="Whole Loops", default=True,
        description=("Follow each edge to the end of its loop, so a line is "
                     "selected all the way round however it turns. Off "
                     "selects only the edges actually pointing along the "
                     "ticked axis, stopping where they turn"))
    pz_weld_dist: FloatProperty(
        name="Weld Range", default=0.0, min=0.0, max=1000.0,
        soft_max=1000.0, precision=4, step=1, subtype="DISTANCE",
        update=_clean_live,
        description=("How close two vertices have to be before Weld merges "
                     "them, in the object's own units"))
    pz_absorb: FloatProperty(
        name="Absorb Below", default=0.25, min=0.0, max=1.0,
        subtype="FACTOR",
        description=("A face smaller than this share of the mesh's average "
                     "is a leftover, and is collapsed. 0.25 took Milad's "
                     "beam from 251 faces to 192 and moved the surface by "
                     "eight hundredths of one percent"))
    pz_sweep_amt: FloatProperty(
        name="Sweep Amount", default=0.3, min=0.0, max=1.0, subtype="FACTOR",
        update=_clean_live,
        description=("What share of the leftover edges Sweep Flat takes, "
                     "flattest first. An angle in degrees was useless here: "
                     "the middle dihedral on a scan is around 20 degrees, so "
                     "anything under 10 swept nothing at all and anything "
                     "over 25 swept exactly the same lot"))
    pz_useless: FloatProperty(
        name="Flat Below", default=1.0, min=0.0, max=180.0, soft_max=45.0,
        update=_drop_live,
        description="A loop is carrying no shape when the surface turns less "
                    "than this many degrees across it. A loop is always taken "
                    "whole or not at all - one that would stop mid-surface is "
                    "left alone. The ceiling is 180, which is every angle "
                    "there is: past the sharpest turn on the model nothing "
                    "further qualifies and the result stops changing")
    pz_every: IntProperty(
        name="Remove Per Kept", default=0, min=0, max=200, soft_max=20,
        update=_drop_live,
        description="For every loop kept, remove this many: 1 takes every "
                    "other loop, 2 leaves one in three, 3 one in four. 0 is "
                    "off. Respects the axis ticks and never touches marked "
                    "lines. The ceiling is 200 - past the number of loops "
                    "an axis actually has, only one loop in that direction "
                    "survives and raising it further changes nothing")
    uv_keep_islands: BoolProperty(
        name="Bake Into Existing UV", default=False,
        description="Bake onto the UV layout the model already has, UDIM "
                    "tiles and all, instead of unwrapping it afresh. Only "
                    "affects Bake From Original - the remesh itself is "
                    "untouched")
    uv_show_seams: BoolProperty(
        name="Show UV Seams", default=False, update=_uv_show_update,
        description="Show the edges where the UV map is cut as red seam lines")
    uv_seams_sharp: BoolProperty(
        name="Seams As Sharp", default=False, update=_uv_sharp_update,
        description="Mark the UV seams Sharp - the blue lines the remesh keeps "
                    "- so the texture lands on the rebuilt faces unbroken")
    bake_gpu: BoolProperty(
        name="Bake On GPU", default=False,
        description="Use the graphics card for the bake instead of the "
                    "processor. Much faster at 4096, and on some drivers "
                    "Cycles crashes Blender outright - which is why this is "
                    "off by default. If a bake dies, turn it off again. Needs "
                    "a GPU device picked in Preferences > System")
    bake_size: EnumProperty(
        name="Size", default="2048",
        items=[("1024", "1024", ""), ("2048", "2048", ""), ("4096", "4096", "")],
        description="Texture size for Bake From Original")
    bake_pbr: BoolProperty(
        name="All Maps", default=True,
        description="Bake every channel the original's material drives with "
                    "a texture - roughness, metallic, height, alpha, emission, "
                    "whatever is there - so nothing of the old material is "
                    "left behind")
    pz_loop_axis: EnumProperty(
        name="Cut Along", default="AUTO",
        items=[("AUTO", "Auto", "Follow the surface from the clicked edge"),
               ("X", "X", "A straight cut in the world YZ plane"),
               ("Y", "Y", "A straight cut in the world XZ plane"),
               ("Z", "Z", "A straight cut in the world XY plane")],
        description="Force Edge Loop direction: Auto walks the grid from the "
                    "clicked edge; X, Y or Z slices dead straight through the "
                    "whole model at the clicked point")
    pz_axis_x: BoolProperty(
        name="X", default=True, update=_axis_live,
        description="Allow dropping the loops that run along world X")
    pz_axis_y: BoolProperty(
        name="Y", default=True, update=_axis_live,
        description="Allow dropping the loops that run along world Y")
    pz_axis_z: BoolProperty(
        name="Z", default=True, update=_axis_live,
        description="Allow dropping the loops that run along world Z")
    pz_keep_marked: BoolProperty(
        name="Spare My Lines", default=True, update=_drop_live,
        description="Never drop a loop you marked Sharp or have selected")
    hs_only_marked: BoolProperty(
        name="Only My Lines", default=False, update=_live,
        description="Ignore the detector entirely and build from your marked "
                    "edges alone. The mesh border is still kept, or the "
                    "rebuild would have no outline to work from")
    pz_use_sharp: BoolProperty(
        name="Marked Sharp", default=True,
        description="Treat edges marked Sharp as panel borders. Mark them in "
                    "Edit Mode with Edge ▸ Mark Sharp; they show up cyan "
                    "and are saved with the mesh")
    pz_use_selection: BoolProperty(
        name="Selected Edges", default=True,
        description="Also treat the current edge selection as panel borders. "
                    "Useful for a one-off without marking anything")
    pz_keep_boundary: BoolProperty(
        name="Keep Outline", default=True,
        description="Never dissolve the mesh's own border. Turning this off "
                    "lets the silhouette collapse")
    pz_keep_creased: BoolProperty(
        name="Keep Creased", default=True,
        description="Also keep edges carrying a subdivision crease")
    pz_keep_seams: BoolProperty(
        name="Protect UV", default=True, update=_drop_live,
        description="Never drop a loop that lies on a UV seam. Merging "
                    "the two faces beside a seam leaves one face that can "
                    "only carry one side's coordinates, which loses the "
                    "texture on the other side - 11 faces in 410 came out "
                    "showing the wrong patch of the map when this was off. "
                    "The cost is that a line is held back at every seam, so "
                    "it comes away in pieces rather than evenly")
    pz_protect: FloatProperty(
        name="Protect Above", default=0.0, min=0.0, max=180.0,
        description="Keep an unmarked edge when its two faces bend by more "
                    "than this many degrees, so curvature is not flattened by "
                    "accident. 0 removes everything between your lines, which "
                    "is the literal behaviour")
    pz_dissolve_verts: BoolProperty(
        name="Clean Stray Vertices", default=True,
        description="Also drop vertices left mid-run with nothing attached. "
                    "Without this the panel keeps a fringe of vertices that "
                    "do nothing")
    auto_thresholds: BoolProperty(
        name="Automatic", default=True, update=_live,
        description="Pick both thresholds from the model with Otsu. Turn off "
                    "to set them by hand and watch the lines move")
    cage_faces: IntProperty(
        name="Cage Faces", default=600, min=20, max=20000,
        description="How many faces the cage is built with. The hand made "
                    "ones in the tutorials sit between a few hundred and a "
                    "thousand",
    )
    cage_crease: FloatProperty(
        name="Crease Over", default=30.0, min=1.0, max=180.0,
        description="A fold in the model sharper than this is creased into "
                    "the cage, so subdivision keeps it sharp",
    )
    cage_levels: IntProperty(
        name="Subdiv Levels", default=2, min=0, max=4,
        description="Levels on the Subdivision Surface the cage is given",
    )

    flat_keep_marked: BoolProperty(
        name="Keep My Lines", default=True,
        description="Never dissolve across an edge you marked Sharp, marked "
                    "as a seam, or selected. A line drawn on a flat panel "
                    "survives instead of going with the fan around it",
    )

    flat_fan_angle: FloatProperty(
        name="Flat Within", default=1.0, min=0.01, max=30.0, precision=2,
        description="How far two neighbouring faces may differ and still "
                    "count as the same flat area. Raise it to sweep up a "
                    "surface that is very slightly curved",
    )

    crease_deg: FloatProperty(
        name="Crease", default=20.0, min=0.0, max=90.0,
        soft_min=0.0, soft_max=90.0, step=100, precision=1,
        update=_live,
        description="How much sharper than its neighbours a bend has to be to "
                    "count as a crease. Low values start marking the facets of "
                    "curved surfaces. The measure is relative, so it can go "
                    "negative in principle - but 0 already takes 74k of the "
                    "espresso machine's 187k edges and -5 takes 157k, so the "
                    "floor is kept at 0 to stop a slider drag landing there")
    flat_deg: FloatProperty(
        name="Coplanar", default=2.0, min=0.1, max=15.0, step=10,
        precision=2, update=_live,
        description="How far two faces may disagree and still count as the "
                    "same flat panel. The line where a flat panel meets a "
                    "curved shell is found by asking which side is flat, not "
                    "by any angle across the line itself - that line often has "
                    "almost no dihedral angle at all")
    planar_tol: FloatProperty(
        name="Flatten Below", default=0.01, min=0.0, max=0.1, step=1,
        precision=4, update=_rebuild,
        description="A region flatter than this becomes one n-gon; anything "
                    "curved keeps its own faces instead. Flattening a curved "
                    "region is not a simplification, it is a dent - measured "
                    "at 5.5% of the model on the grenade fuze")
    min_chain: FloatProperty(
        name="Min Length", default=0.02, min=0.0, max=1.0, soft_max=1.0,
        step=1, precision=4, update=_live,
        description="Drop line chains shorter than this fraction of the model")
    dissolve_straight: FloatProperty(
        name="Remove Straight Loops", default=0.0005, min=0.0, max=5.0,
        soft_min=0.0, soft_max=0.02, step=1, precision=5, update=_rebuild,
        description="How far the surface may move when a loop is dropped, as a "
                    "fraction of the model. A loop is removed only when every "
                    "vertex on it is within this of the line its neighbours "
                    "make without it, so the form cannot collapse however far "
                    "this is raised - the fillets simply stop qualifying. "
                    "0 turns it off. The ceiling is 5, which is far past the "
                    "size of the model itself; the slider still steps in the "
                    "useful range and anything above about 0.02 rarely finds "
                    "another loop to take")
    refit_circles: BoolProperty(
        name="Keep Circles Round", default=True, update=_rebuild,
        description="After loops are dropped, put the vertices of a circular "
                    "ring back on the circle they came from. Fewer segments "
                    "leave a polygon inscribed inside the original circle, so "
                    "the part reads thinner than it is; this splits the error "
                    "either side of the true radius instead of all inside. "
                    "Same idea as LoopTools 'Circle'. Rings that are not "
                    "actually round are left untouched")
    hs_mirror: BoolProperty(
        name="Mirror Retopology", default=False,
        description="Build one half and reflect it, for a model that is "
                    "already symmetric. Remeshing the whole thing gives the "
                    "two halves different edge flow, and the seam down the "
                    "middle is where that shows worst")
    hs_mirror_axis: EnumProperty(
        name="Axis", default="AUTO",
        items=[("AUTO", "Auto", "Find the plane the model is symmetric across"),
               ("X", "X", "Mirror across the local YZ plane"),
               ("Y", "Y", "Mirror across the local XZ plane"),
               ("Z", "Z", "Mirror across the local XY plane")],
        description="Which plane to fold across. Auto tests all three and "
                    "picks the one the model actually matches")
    hs_replace: BoolProperty(
        name="Replace Original", default=False,
        description="Write the result into the original object instead of "
                    "leaving it beside it. The mesh it displaces is kept, so "
                    "Restore Original can still undo it, and every rebuild is "
                    "measured from that kept mesh rather than from the last "
                    "result - so the reduction cannot compound as you drag")
    weld_close: FloatProperty(
        name="Weld Close Lines", default=0.0002, min=0.0, max=0.02,
        soft_min=0.0, soft_max=0.01, step=1, precision=5, update=_rebuild,
        description="Merge two lines that run closer together than this "
                    "fraction of the model. The strip between them is all "
                    "border and no surface - a chamfer has no room to fit "
                    "there, so the bevel collapses into edges a fraction of a "
                    "millimetre long that read as loose vertices. Measured on "
                    "the barrier, 38 such lines held the chamfer of the whole "
                    "model to 1.2 mm. It also closes a line that jogs sideways "
                    "where it crosses another, by pulling the two ends onto "
                    "each other. 0 turns it off")
    auto_prune: BoolProperty(
        name="Drop Lines That Change Nothing", default=True, update=_live,
        description="After the thresholds run, test every line by what the "
                    "rebuild does with it rather than by how sharp it is. A "
                    "line separates two regions, so deleting it merges them, "
                    "and it is only worth keeping when the merged region would "
                    "rebuild differently. Measured on the espresso machine, "
                    "this took 3073 lines down to 506 with the result still "
                    "sitting exactly on the original surface")
    use_type: BoolProperty(
        name="Flat/Curved Boundaries", default=True, update=_live,
        description="Include the boundary between flat and curved areas. These "
                    "have almost no dihedral angle, so the crease test alone "
                    "never finds them")
    gap_span: FloatProperty(
        name="Gap Reach", default=0.35, min=0.0, max=4.0,
        soft_min=0.0, soft_max=4.0, step=1, precision=3,
        update=_live,
        description="How far a dangling end may reach to find another one, as "
                    "a fraction of the model. Raise it while 'open ends' is "
                    "not zero - an open line leaves a hole in the rebuild. "
                    "Above 1.0 the march is allowed to wander further than the "
                    "model is wide, which a line that curves round the form "
                    "needs. The other gate is the turn limit: a continuation "
                    "more than about 56 degrees off course is never taken")
    straighten: FloatProperty(
        name="Straighten", default=0.0002, min=0.0, max=0.005, step=1,
        precision=5, update=_rebuild,
        description="Drop line vertices that lie on a straight run, as a "
                    "fraction of the model. A detected line carries every "
                    "vertex of the mesh it crossed, and each one becomes a rung "
                    "across the chamfer with nothing to justify it. Raise it "
                    "too far and hole rims start losing roundness")
    chamfer: FloatProperty(
        name="Chamfer", default=0.0, min=0.0, max=1.0,
        soft_min=0.0, soft_max=1.0, step=1, precision=4,
        update=_rebuild,
        description="Chamfer width as a fraction of the model, applied only to "
                    "the detected lines. 0 leaves the edges sharp. Past a few "
                    "hundredths the bands from neighbouring lines start "
                    "meeting; Clamp Overlap keeps them from cutting through "
                    "each other, which is what makes a wide setting usable")
    chamfer_segments: bpy.props.IntProperty(
        name="Segments", default=2, min=1, max=8, update=_rebuild,
        description="Rows across the chamfer. Keep it even: an odd count "
                    "leaves a triangle in the middle of every three-way corner, "
                    "measured at 36 of them on the reference body")
    chamfer_profile: FloatProperty(
        name="Profile", default=0.5, min=0.0, max=1.0, step=10, precision=2,
        update=_rebuild,
        description="0.5 is a circular arc, lower is flatter, higher bulges out")
    chamfer_clamp: BoolProperty(
        name="Clamp Overlap", default=True, update=_rebuild,
        description="Hold the width back where a panel is too narrow to carry "
                    "it, instead of letting the chamfer fold through itself")
    support: FloatProperty(
        name="Support", default=0.0, min=0.0, max=0.05, step=1, precision=4,
        update=_rebuild,
        description="Distance from the chamfer to the holding loop, as a "
                    "fraction of the model. The loop runs parallel to the "
                    "lines all the way round the panel, so a subdivision "
                    "cannot pull the edge open. 0 adds none")
    support_loops: bpy.props.IntProperty(
        name="Loops", default=1, min=1, max=3, update=_rebuild,
        description="How many holding loops to lay inside each panel. Each one "
                    "sits the same distance in from the one before it")
    close_gaps: BoolProperty(
        name="Close Gaps", default=True, update=_live,
        description="Bridge dangling ends along existing mesh edges. A line "
                    "with a gap stops its region closing, and that region is "
                    "then skipped and leaves a hole")


def _boundary_loops(bm):
    """The rims of the mesh, each as its list of boundary edges."""
    seen = set()
    loops = []
    for e in bm.edges:
        if len(e.link_faces) != 1 or e.index in seen:
            continue
        loop = []
        stack = [e]
        seen.add(e.index)
        while stack:
            cur = stack.pop()
            loop.append(cur)
            for v in cur.verts:
                for e2 in v.link_edges:
                    if len(e2.link_faces) == 1 and e2.index not in seen:
                        seen.add(e2.index)
                        stack.append(e2)
        loops.append(loop)
    return loops


def _stitch_t_junctions(bm, tol):
    """Land a line that stops against another line onto it.

    A line that runs up to a longer one often ends at a vertex of its own
    sitting a hair off that line, with no edge joining the two - the long line
    was never split there. On screen the line simply stops short of the one it
    was heading for, and no amount of welding reaches it, because welding pairs
    vertices and there is no vertex on the other side to pair with. So the long
    edge is cut at the point nearest the loose end and the two are merged.

    Measured on Milad's train: ten such ends on one part, down to two.
    """
    import bmesh
    from mathutils.kdtree import KDTree

    made = 0
    for _round in range(5):
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        kd = KDTree(len(bm.verts))
        for i, v in enumerate(bm.verts):
            kd.insert(v.co, i)
        kd.balance()

        # Which rim each open edge and each open vertex belongs to. A landing
        # that reaches from one rim to another is not a line meeting a line -
        # it is two separate holes being pinched together, and it closed the
        # gap between two panels on Milad's train and pulled their corners into
        # one. Whatever the reach says, those two are left apart.
        rim_of_edge = {}
        rim_of_vert = {}
        for r, L in enumerate(_boundary_loops(bm)):
            for e in L:
                rim_of_edge[e.index] = r
                for v in e.verts:
                    rim_of_vert[v.index] = r

        jobs = []
        for e in bm.edges:
            a, b = e.verts[0].co, e.verts[1].co
            ab = b - a
            L = ab.length
            if L < 1e-9:
                continue
            for _pt, i, _d in kd.find_range((a + b) * 0.5, L * 0.5 + tol):
                v = bm.verts[i]
                if v in e.verts:
                    continue
                t = (v.co - a).dot(ab) / (L * L)
                if t <= 0.02 or t >= 0.98:
                    continue      # that is an end of the edge, not its middle
                ra = rim_of_edge.get(e.index)
                rb = rim_of_vert.get(v.index)
                if ra is not None and rb is not None and ra != rb:
                    continue      # two different holes, not a line and its end
                d = (v.co - (a + ab * t)).length
                if d < tol:
                    jobs.append((d, e, v, t))
        if not jobs:
            break
        jobs.sort(key=lambda j: j[0])
        used = set()
        did = 0
        for _d, e, v, t in jobs:
            if not e.is_valid or not v.is_valid or e.index in used:
                continue
            used.add(e.index)
            try:
                _ne, nv = bmesh.utils.edge_split(e, e.verts[0], t)
                nv.co = v.co
                bmesh.ops.pointmerge(bm, verts=[nv, v], merge_co=v.co)
            except Exception:
                continue
            did += 1
            made += 1
        if not did:
            break
    return made


def _carry_lines_across(bm, straight=0.9, rounds=4):
    """Take a line that arrives at a panel straight out the other side.

    A line that runs down the side of a model and crosses a narrow band often
    comes out of the rebuild in two halves with nothing across the band itself:
    it arrives at the band's edge, the band is one face, and the line picks up
    again below. Nothing is missing from the surface, so filling finds nothing
    to fill - what is missing is the cut across that one face.

    Both ends have to agree before a cut is made. The line arrives heading one
    way, the far end leaves heading the same way, and the join between them has
    to sit along that same line to within about 25 degrees at both ends. On
    Milad's train that gate passed the band crossing at 0.999 and 0.993 and
    turned down every other pairing on the part, the nearest of which was 0.80.
    """
    import bmesh

    joined = 0
    for _round in range(rounds):
        did = 0
        for f in list(bm.faces):
            if not f.is_valid:
                continue
            ends = []
            for v in f.verts:
                out = [e for e in v.link_edges if f not in e.link_faces]
                if len(out) != 1:
                    continue
                d = v.co - out[0].other_vert(v).co
                if d.length < 1e-9:
                    continue
                ends.append((v, d.normalized()))
            best = None
            for i in range(len(ends)):
                for j in range(i + 1, len(ends)):
                    a, da = ends[i]
                    b, db = ends[j]
                    if any(b in e.verts for e in a.link_edges):
                        continue        # already joined
                    ab = b.co - a.co
                    if ab.length < 1e-9:
                        continue
                    u = ab.normalized()
                    sa = u.dot(da)
                    sb = (-u).dot(db)
                    if sa < straight or sb < straight:
                        continue
                    score = min(sa, sb)
                    if best is None or score > best[0]:
                        best = (score, a, b)
            if best is None:
                continue
            try:
                res = bmesh.ops.connect_verts(bm, verts=[best[1], best[2]])
            except Exception:
                continue
            if res.get("edges"):
                joined += 1
                did += 1
        if not did:
            break
    return joined


def _rim_ring(edges):
    """A rim's vertices in the order they run round it."""
    nb = {}
    for e in edges:
        a, b = e.verts
        nb.setdefault(a, []).append(b)
        nb.setdefault(b, []).append(a)
    if not nb:
        return []
    start = next(iter(nb))
    ring = [start]
    prev, cur = None, start
    while True:
        nxt = [w for w in nb[cur] if w is not prev]
        if not nxt:
            break
        w = nxt[0]
        if w is start:
            break
        ring.append(w)
        prev, cur = cur, w
        if len(ring) > len(edges) + 2:
            break
    return ring


def _continue_straight(bm, straight=0.9995, min_frac=0.25, rounds=3):
    """Carry a line from the panel next door on across this one.

    A line that runs along a row of panels stops wherever the rebuild happened
    to end a face and picks up again on the far side, leaving one panel in the
    row with nothing across it. The two-ended pass will not touch it, because
    there is nothing coming the other way to agree with - the line simply
    arrives and has to keep going.

    So one end is enough here, but only when the continuation is dead straight:
    within a fortieth of a degree of the line coming in, at least a quarter of
    the way across the face, and with nothing already leaving that vertex the
    same way. Measured on Milad's train, that gate drew the three lines that
    were missing and left everything else alone, where a looser one at three
    degrees drew thirty-four.
    """
    import bmesh

    made = 0
    for _round in range(rounds):
        did = 0
        for f in list(bm.faces):
            if not f.is_valid:
                continue
            pts = np.array([v.co[:] for v in f.verts])
            size = float(np.linalg.norm(pts.max(0) - pts.min(0)))
            best = None
            for v in f.verts:
                for e in [x for x in v.link_edges if f not in x.link_faces]:
                    d = v.co - e.other_vert(v).co
                    if d.length < 1e-9:
                        continue
                    d = d.normalized()
                    for t in f.verts:
                        if t is v or any(t in ee.verts for ee in v.link_edges):
                            continue
                        q = t.co - v.co
                        if q.length < size * min_frac:
                            continue
                        u = q.normalized()
                        sc = u.dot(d)
                        if sc < straight:
                            continue
                        if any((ee.other_vert(v).co - v.co).normalized().dot(u)
                               > 0.97 for ee in v.link_edges
                               if (ee.other_vert(v).co - v.co).length > 1e-9):
                            continue       # that line is already there
                        if best is None or sc > best[0]:
                            best = (sc, v, t)
            if best is None:
                continue
            try:
                res = bmesh.ops.connect_verts(bm, verts=[best[1], best[2]])
            except Exception:
                continue
            if res.get("edges"):
                made += 1
                did += 1
        if not did:
            break
    return made


def _link_opening_corners(bm, turn_deg=40.0, span=3, cone=0.4):
    """Run a line out of each corner of an opening to the corner it points at.

    A door or a window cut into a panel leaves the surface around it as one
    long n-gon wrapping most of the way round the hole, tied to the outer rim
    at a single place. It holds together, but it is not what a modeller would
    leave: the corners of the opening should carry on outwards, which is what
    turns the wrap into ordinary four-sided pieces.

    The line has to finish on a corner. Cutting into whichever edge it happened
    to reach was tried first and is wrong - Milad's words, a support must not be
    left in the middle of a line - so nothing new is created: the far end is
    picked from the corners already there, whichever one the opening corner is
    pointing most nearly at. Every one of the eight corners on his train door
    and window found one, between 0.75 and 0.99 along its own direction.

    A corner is read over a window of a few vertices rather than at one, since
    an opening is filleted and each single step round the fillet turns only a
    little - the same reason the cloth side had to pin panel corners over a
    span.
    """
    import bmesh

    loops = _boundary_loops(bm)
    if len(loops) < 2:
        return 0
    spans = []
    for L in loops:
        pts = np.array([v.co[:] for e in L for v in e.verts])
        spans.append(float(np.linalg.norm(pts.max(0) - pts.min(0))))
    outer = int(np.argmax(spans))

    jobs = []
    for i, L in enumerate(loops):
        if i == outer:
            continue
        ring = _rim_ring(L)
        n = len(ring)
        if n < 4:
            continue
        # A four-sided strip has no room for a window of three either side, and
        # it was skipped for that alone - which left the two ends of every thin
        # strip with no support at all. The window shrinks to fit the rim.
        span = max(1, min(3, n // 4))
        own = set(ring)
        pts = np.array([v.co[:] for v in ring])
        reach = float(np.linalg.norm(pts.max(0) - pts.min(0))) * 0.35
        # what already leaves this opening, so the same line is not drawn twice
        here = []
        for v in ring:
            for e in v.link_edges:
                t = e.other_vert(v)
                if t in own:
                    continue
                d = t.co - v.co
                if d.length > 1e-9:
                    here.append((v.co.copy(), d.normalized()))
        turns = []
        for k in range(n):
            a = ring[(k - span) % n].co - ring[k].co
            b = ring[(k + span) % n].co - ring[k].co
            if a.length < 1e-9 or b.length < 1e-9:
                turns.append(0.0)
            else:
                turns.append(180.0 - math.degrees(a.normalized().angle(
                    b.normalized())))
        for k in range(n):
            if turns[k] < turn_deg:
                continue
            if turns[k] < max(turns[(k + d) % n]
                              for d in range(-span, span + 1) if d):
                continue          # the peak of the corner, not its shoulder
            v = ring[k]
            a = ring[(k - span) % n].co - v.co
            b = ring[(k + span) % n].co - v.co
            w = -(a.normalized() + b.normalized())
            if w.length < 1e-9:
                continue
            jobs.append((v, w.normalized(), own, here, reach))

    made = 0
    for v, w, own, here, reach in jobs:
        if not v.is_valid:
            continue
        best = None
        for f in v.link_faces:
            for t in f.verts:
                if t is v or t in own:
                    continue      # the opening's own rim is not a way out
                if any(t in e.verts for e in v.link_edges):
                    continue      # already joined
                d = t.co - v.co
                if d.length < 1e-9:
                    continue
                dot = d.normalized().dot(w)
                if dot < cone:
                    continue
                if best is None or dot > best[0]:
                    best = (dot, t)
        if best is None:
            continue              # nothing to aim at, so nothing is drawn
        # A line the rebuild already ran out of this opening covers the same
        # ground, and a second one beside it is the extra line that reads as a
        # doubled support. Measured on Milad's window: two of the four corners
        # pointed within 0.03 of a line already there, a third of the way round
        # the rim from it.
        d = (best[1].co - v.co)
        if d.length > 1e-9:
            d = d.normalized()
            if any(d.dot(hd) > 0.97 and (hc - v.co).length < reach
                   for hc, hd in here):
                continue
        try:
            res = bmesh.ops.connect_verts(bm, verts=[v, best[1]])
        except Exception:
            continue
        if res.get("edges"):
            made += 1
    return made


def fill_missed_gaps(obj, tol=0.01, snap=0.002, corners=True,
                     close_holes=False):
    """Put a face back where the rebuild left the surface open.

    Two lines running close and parallel leave a strip between them that the
    region pass sometimes fails to close, and what is left is a long thin hole
    straight through the model. It reads as a line that stops and a band of
    nothing beside it. Measured on Milad's train: a strip 7.6 long and 0.5 wide
    with no face on it, on a part 32 across.

    A hole that belongs there and a hole that does not look the same from
    inside the result, so the reference is asked instead: sample the inside of
    each rim and see whether the model it was built from has surface there. A
    door opening has none - that is what makes it an opening - while a strip
    the rebuild dropped is covered by cloth on every sample. The outer rim is
    left alone by area; it is the one every other rim sits inside.

    A line that stopped against another without joining it is landed on it in
    the same pass, since both leave the same thing behind: a rebuild that is
    open where the model is not.

    Returns (holes filled, rims looked at, line ends landed, lines carried on,
    opening corners linked out).
    """
    import bmesh
    from mathutils import Vector
    from mathutils.bvhtree import BVHTree

    src = source_mesh(obj)
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    co0 = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
    diag0 = float(np.linalg.norm(co0.max(0) - co0.min(0))) or 1.0
    landed = _stitch_t_junctions(bm, snap * diag0)
    if landed:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

    loops = _boundary_loops(bm)
    if len(loops) < 2:
        carried = _carry_lines_across(bm) + _continue_straight(bm)
        if landed or carried:
            bm.normal_update()
            bm.to_mesh(obj.data)
            obj.data.update()
        bm.free()
        return 0, len(loops), landed, carried, 0

    co = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
    diag = float(np.linalg.norm(co.max(0) - co.min(0))) or 1.0
    reach = tol * diag

    sm = bmesh.new()
    sm.from_mesh(src)
    tree = BVHTree.FromBMesh(sm)

    # the outer rim is the widest one; everything else is a hole in the sheet
    spans = []
    for L in loops:
        pts = np.array([v.co[:] for e in L for v in e.verts])
        spans.append(float(np.linalg.norm(pts.max(0) - pts.min(0))))
    outer = int(np.argmax(spans))

    filled = 0
    for i, L in enumerate(loops):
        if i == outer or not close_holes:
            # Closing a hole changes what the model is, and every other repair
            # here only adds lines. Milad's words: whatever setting I change it
            # alters the structure, and it should not. So a hole is left alone
            # unless it is asked for by name.
            continue
        verts = []
        for e in L:
            verts.extend(e.verts)
        mid = Vector((0.0, 0.0, 0.0))
        for v in verts:
            mid += v.co
        mid /= len(verts)
        # points a little way in from the rim, which stay inside a thin strip
        # where the plain middle of a bent rim would not
        gaps = []
        for e in L:
            q = mid.lerp((e.verts[0].co + e.verts[1].co) * 0.5, 0.6)
            hit = tree.find_nearest(q)
            if hit[0] is not None:
                gaps.append(hit[3])
        # the middle sample, not a count of how many passed. A rim that bends
        # has a few samples wandering off the surface whatever it sits over,
        # and they drowned the answer; measured on the train the two cases sit
        # a factor of five apart on the median - 0.18 under a dropped strip
        # against 0.88 under the door opening.
        if not gaps or float(np.median(gaps)) > reach:
            continue           # the reference is open here too, so leave it
        try:
            res = bmesh.ops.contextual_create(bm, geom=list(L))
            if res.get("faces"):
                filled += 1
        except Exception:
            pass

    sm.free()
    carried = _carry_lines_across(bm) + _continue_straight(bm)
    linked = _link_opening_corners(bm) if corners else 0
    if filled or landed or carried or linked:
        bm.normal_update()
        bm.to_mesh(obj.data)
        obj.data.update()
    bm.free()
    return filled, len(loops), landed, carried, linked


class QUADREMESH_OT_join_points(Operator):
    """Run a line from one point to the point across from it.

    Two clicks: the first picks the point the line starts at, the second the
    one it ends at, and the faces in between are cut so the line goes right
    through, the way a modeller reaches for J. Escape or a right click stops
    without changing anything.

    This is what is left of a long detour. Reading the crumpled spots by rule
    and reweaving them was tried three ways on Milad's part and measured every
    time: Grid Fill on a five-sided opening handed back the same n-gon;
    carrying each stopped line to the next edge along added 36 lines and left
    the mesh worse, 41 triangles becoming 54 and 39 poles becoming 46; and
    carrying a line the whole way across found nowhere to start, because the
    grid around the gap is not a grid either. Pointing at the two ends says
    what no measure of that mesh can.
    """

    bl_idname = "mesh.quadremesh_join_points"
    bl_label = "Join Two Points"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH" and o.mode == "OBJECT"
                and len(o.data.polygons))

    def _vert_under(self, context, event):
        """The vertex nearest to where the mouse is pointing, or -1."""
        from bpy_extras import view3d_utils
        region = context.region
        rv3d = context.region_data
        if region is None or rv3d is None:
            return -1
        xy = (event.mouse_region_x, event.mouse_region_y)
        if not (0 <= xy[0] <= region.width and 0 <= xy[1] <= region.height):
            return -1
        obj = context.active_object
        inv = obj.matrix_world.inverted()
        org = inv @ view3d_utils.region_2d_to_origin_3d(region, rv3d, xy)
        dr = (inv.to_3x3()
              @ view3d_utils.region_2d_to_vector_3d(region, rv3d, xy))
        ok, loc, _nor, face = obj.ray_cast(org, dr.normalized())
        if not ok or face < 0:
            return -1
        poly = obj.data.polygons[face]
        best = -1
        near = None
        for vi in poly.vertices:
            d = (obj.data.vertices[vi].co - loc).length
            if near is None or d < near:
                near, best = d, vi
        return best

    def _mark(self, context):
        if context.area:
            if self.first < 0:
                context.area.header_text_set(
                    "Click the point the line starts at, Esc to stop")
            else:
                context.area.header_text_set(
                    "Now click the point it runs to, Esc to stop")

    def modal(self, context, event):
        if event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            return {"PASS_THROUGH"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            hit = self._vert_under(context, event)
            if hit < 0:
                return {"RUNNING_MODAL"}
            if self.first < 0:
                self.first = hit
                self._mark(context)
                return {"RUNNING_MODAL"}
            if hit == self.first:
                return {"RUNNING_MODAL"}
            if context.area:
                context.area.header_text_set(None)
            return self._join(context, self.first, hit)
        if event.type in {"RIGHTMOUSE", "ESC"}:
            if context.area:
                context.area.header_text_set(None)
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def _join(self, context, a, b):
        import bmesh
        obj = context.active_object
        me = obj.data
        before = len(me.polygons)
        bpy.ops.object.mode_set(mode="EDIT")
        try:
            bpy.context.tool_settings.mesh_select_mode = (True, False, False)
            bm = bmesh.from_edit_mesh(me)
            bm.verts.ensure_lookup_table()
            for v in bm.verts:
                v.select_set(False)
            for e in bm.edges:
                e.select_set(False)
            for f in bm.faces:
                f.select_set(False)
            bm.verts[a].select_set(True)
            bm.verts[b].select_set(True)
            bm.select_history.clear()
            bm.select_history.add(bm.verts[a])
            bm.select_history.add(bm.verts[b])
            bmesh.update_edit_mesh(me)
            try:
                bpy.ops.mesh.vert_connect_path()
            except Exception:
                try:
                    bpy.ops.mesh.vert_connect()
                except Exception:
                    pass
        finally:
            bpy.ops.object.mode_set(mode="OBJECT")
        made = len(me.polygons) - before
        if made > 0:
            self.report({"INFO"}, f"joined - {made} more faces")
        else:
            self.report({"WARNING"},
                        "those two would not join - they have to sit on the "
                        "same piece of surface")
        return {"FINISHED"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"ERROR"}, "run this from the 3D viewport")
            return {"CANCELLED"}
        self.first = -1
        self._mark(context)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class QUADREMESH_OT_fill_gaps(Operator):
    """Put a face back where the rebuild left the surface open.

    Where two lines run close and parallel the strip between them sometimes
    fails to close and is left as a hole straight through the model. This finds
    those and fills them, and leaves the real openings alone by checking the
    reference: a door opening is open in the reference too, a dropped strip is
    covered.
    """

    bl_idname = "mesh.quadremesh_fill_gaps"
    bl_label = "Fill Missed Gaps"
    bl_options = {"REGISTER", "UNDO"}

    tol: FloatProperty(
        name="Reach", default=0.01, min=0.0001, max=0.1, precision=4,
        description="How close the reference has to be under a rim before it "
                    "counts as covered, as a fraction of the model",
    )
    close_holes: BoolProperty(
        name="Close Open Strips", default=False,
        description="Put a face back over a strip the rebuild left open, when "
                    "the reference has surface under it. Off by default: it is "
                    "the one repair here that changes which holes the model "
                    "has, and a gap between two panels reads the same from "
                    "inside the result as a strip that was dropped",
    )
    corners: BoolProperty(
        name="Link Opening Corners", default=True,
        description="Carry each corner of a door or window out to the panel "
                    "around it, so the surface there is ordinary four-sided "
                    "pieces instead of one long shape wrapped round the hole",
    )
    snap: FloatProperty(
        name="Land Ends", default=0.002, min=0.0, max=0.05, precision=4,
        description="How far a line that stops short may be from the line it "
                    "was heading for and still be landed on it, as a fraction "
                    "of the model. 0 leaves those alone",
    )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH" and o.mode == "OBJECT"
                and len(o.data.polygons))

    def execute(self, context):
        obj = context.active_object
        try:
            filled, rims, landed, carried, linked = fill_missed_gaps(
                obj, self.tol, self.snap, self.corners, self.close_holes)
        except Exception as exc:
            traceback.print_exc()
            self.report({"ERROR"}, f"could not fill: {exc}")
            return {"CANCELLED"}
        bits = []
        if filled:
            bits.append(f"{filled} of {rims} open rims filled")
        elif self.close_holes:
            bits.append(f"nothing to fill, {rims} rims all belong")
        else:
            bits.append(f"{rims} rims left as they are")
        if landed:
            bits.append(f"{landed} line ends landed on the line they met")
        if carried:
            bits.append(f"{carried} lines carried on across the panel")
        if linked:
            bits.append(f"{linked} opening corners run out to the panel")
        self.report({"INFO"}, "  |  ".join(bits))
        return {"FINISHED"}


class QUADREMESH_OT_lines_preview(Operator):
    bl_idname = "mesh.quadremesh_lines_preview"
    bl_label = "Show Feature Lines"
    bl_description = "Build a line object from the current thresholds"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        obj = context.active_object
        # The build operator leaves its own result active, so without
        # BUILD_SUFFIX here a second click would analyse the chamfered output
        # instead of the source and quietly re-point everything at it.
        if obj.name.endswith((SUFFIX, PANEL_SUFFIX, BUILD_SUFFIX)):
            src = bpy.data.objects.get(context.scene.quadremesh_lines.source)
            if src is None:
                self.report({"WARNING"}, "select the source mesh, not the lines")
                return {"CANCELLED"}
            obj = src
        st = context.scene.quadremesh_lines
        st.source = obj.name
        cache = get_cache(obj)
        auto_c, auto_f = HS.auto_thresholds(cache)
        if st.auto_thresholds:
            # Writing these fires their update, and their update is a full
            # rebuild. Two writes, two rebuilds, and then the real build
            # below: one press did the whole job three times over. Measured
            # on a 200,000 face door, 42.2 seconds, two thirds of it here.
            with suspend_live():
                st.crease_deg = round(auto_c, 1)
                st.flat_deg = round(auto_f, 2)
        out = rebuild_preview(context, obj)
        if out is None:
            self.report({"WARNING"}, "no lines at these thresholds")
            return {"CANCELLED"}
        self.report({"INFO"}, st.info)
        return {"FINISHED"}


class QUADREMESH_OT_panels_preview(Operator):
    bl_idname = "mesh.quadremesh_panels_preview"
    bl_label = "Show Panels"
    bl_description = ("Colour the panels the current lines carve out. Each "
                      "colour is one region the rebuild will treat as a single "
                      "flat face")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        obj = context.active_object
        if obj.name.endswith((SUFFIX, PANEL_SUFFIX, BUILD_SUFFIX)):
            src = bpy.data.objects.get(context.scene.quadremesh_lines.source)
            if src is None:
                self.report({"WARNING"}, "select the source mesh")
                return {"CANCELLED"}
            obj = src
        st = context.scene.quadremesh_lines
        st.source = obj.name
        cache = get_cache(obj)
        auto_c, auto_f = HS.auto_thresholds(cache)
        if st.auto_thresholds:
            # Writing these fires their update, and their update is a full
            # rebuild. Two writes, two rebuilds, and then the real build
            # below: one press did the whole job three times over. Measured
            # on a 200,000 face door, 42.2 seconds, two thirds of it here.
            with suspend_live():
                st.crease_deg = round(auto_c, 1)
                st.flat_deg = round(auto_f, 2)
        out = rebuild_panels(context, obj)
        if out is None:
            return {"CANCELLED"}
        # panels are easier to read with vertex colours on and flat lighting
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                sp = area.spaces.active
                sp.shading.type = "SOLID"
                sp.shading.color_type = "VERTEX"
                sp.shading.light = "FLAT"
        obj.hide_set(True)
        # Deselecting through `bpy.ops` needs a context this operator is not
        # guaranteed to have. Reported from a sidebar click on macOS:
        # "bpy.ops.object.select_all.poll() failed, context is incorrect".
        # Setting the flag per object has no context requirement at all.
        for o in list(context.selected_objects):
            o.select_set(False)
        out.select_set(True)
        context.view_layer.objects.active = out
        self.report({"INFO"}, st.panel_info)
        return {"FINISHED"}


class QUADREMESH_OT_panels_build(Operator):
    bl_idname = "mesh.quadremesh_panels_build"
    bl_label = "Remesh Hardsurface"
    bl_description = ("Turn the panels into geometry. Every edge of the result "
                      "is a detected line - holes are cut open and bores get a "
                      "quad wall instead of being capped shut")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        obj = context.active_object
        for suffix in (SUFFIX, PANEL_SUFFIX, BUILD_SUFFIX):
            if obj.name.endswith(suffix):
                src = bpy.data.objects.get(context.scene.quadremesh_lines.source)
                if src is None:
                    self.report({"WARNING"}, "select the source mesh")
                    return {"CANCELLED"}
                obj = src
                break
        st = context.scene.quadremesh_lines
        st.source = obj.name
        # Edit Mode keeps the mesh data in bmesh, and from Python the UV
        # layer arrays read as empty until it is flushed - the UV transfer
        # crashed on exactly that after Seams To Sharp left the user in
        # Edit Mode. Build from Object Mode and hand the mode back after.
        if obj.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
        cache = get_cache(obj)
        auto_c, auto_f = HS.auto_thresholds(cache)
        if st.auto_thresholds:
            # Writing these fires their update, and their update is a full
            # rebuild. Two writes, two rebuilds, and then the real build
            # below: one press did the whole job three times over. Measured
            # on a 200,000 face door, 42.2 seconds, two thirds of it here.
            with suspend_live():
                st.crease_deg = round(auto_c, 1)
                st.flat_deg = round(auto_f, 2)
        # Reuse whatever this session is already driving, so pressing the
        # button again refreshes that result instead of stacking another one.
        # A result the user has dragged aside is theirs now, and is skipped -
        # which is what makes the next press produce a fresh object rather
        # than overwrite their comparison.
        cur = bpy.data.objects.get(st.result)
        reuse = None
        if (cur is not None and cur.get("quadremesh_source") == obj.name
                and cur.get("quadremesh_kind") == "hardsurface"
                and at_same_place(cur, obj)):
            reuse = cur.name
        out = build_maybe_mirrored(context, obj, reuse=reuse,
                                   report=self.report)
        if out is None:
            self.report({"WARNING"}, st.build_info or "nothing built")
            return {"CANCELLED"}
        # The viewport is left exactly as it was found. This used to force
        # every viewport to solid, which threw whoever was working in material
        # or rendered view back out of it on every remesh; then the wireframe
        # overlay went behind a toggle, and now not even that - the overlay is
        # one keystroke away in Blender's own menu and does not belong here.
        # The source used to be hidden here. With Replace Original off that
        # reads as the add-on having replaced the model - the original vanishes
        # and the result appears in the same place, which is indistinguishable
        # from a replacement and was reported as one. With Replace Original on
        # it was worse: `out` *is* the object, so this hid the result itself.
        # Nothing of the user's is hidden now; only our own scaffolding is.
        for suffix in (SUFFIX, PANEL_SUFFIX):
            o = bpy.data.objects.get(st.source + suffix)
            if o is not None:
                o.hide_set(True)
        # Deselecting through `bpy.ops` needs a context this operator is not
        # guaranteed to have. Reported from a sidebar click on macOS:
        # "bpy.ops.object.select_all.poll() failed, context is incorrect".
        # Setting the flag per object has no context requirement at all.
        for o in list(context.selected_objects):
            o.select_set(False)
        out.select_set(True)
        context.view_layer.objects.active = out
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_lines_clear(Operator):
    bl_idname = "mesh.quadremesh_lines_clear"
    bl_label = "Clear"
    bl_description = "Remove the line preview object"

    def execute(self, context):
        st = context.scene.quadremesh_lines
        for suffix in (SUFFIX, PANEL_SUFFIX, BUILD_SUFFIX):
            o = bpy.data.objects.get((st.source or "") + suffix)
            if o is not None:
                d = o.data
                bpy.data.objects.remove(o)
                if d.users == 0:
                    bpy.data.meshes.remove(d)
        src = bpy.data.objects.get(st.source)
        if src is not None:
            src.hide_set(False)
        st.source = ""
        st.info = ""
        st.panel_info = ""
        st.build_info = ""
        return {"FINISHED"}



class QUADREMESH_OT_tris_to_quads(Operator):
    """Join the triangles of the model back into quads (Blender's Alt+J).

    Many models need no remesh at all - only the triangulation lines an export
    or a game engine added taken out again. This does exactly that on the
    selected mesh objects and leaves every other edge where it is."""
    bl_idname = "mesh.quadremesh_tris_to_quads"
    bl_label = "Mesh cleanup"
    bl_description = ("Remove the triangulation lines: join triangles back "
                      "into quads (Alt+J), without remeshing")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.mesh.quadremesh_lines_clear()          # the line preview, as before
        objs = [o for o in context.selected_objects if o.type == "MESH"]
        act = context.active_object
        if act is not None and act.type == "MESH" and act not in objs:
            objs.append(act)
        if not objs:
            self.report({"WARNING"}, "Select a mesh object first")
            return {"CANCELLED"}
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        before = sum(len(o.data.polygons) for o in objs)
        for o in context.selected_objects:
            o.select_set(False)
        for o in objs:
            o.select_set(True)
        context.view_layer.objects.active = objs[0]
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.tris_convert_to_quads()
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        after = sum(len(o.data.polygons) for o in objs)
        self.report({"INFO"}, f"Mesh cleanup: {before:,} faces -> {after:,}")
        return {"FINISHED"}


class QUADREMESH_OT_panelize(Operator):
    """Dissolve every edge that is not one of the lines you marked.

    Works in place on the active object, in Object Mode or Edit Mode. It is an
    edit like Blender's own Dissolve, so Ctrl+Z is the way back - it does not
    build a result object beside the original the way Remesh Hardsurface does,
    because the input here is a mesh the user has already marked up by hand
    and duplicating it would strand those marks on the copy.
    """

    bl_idname = "mesh.quadremesh_panelize"
    bl_label = "Dissolve Between Lines"
    bl_description = ("Keep the lines you marked and dissolve everything "
                      "between them, leaving one n-gon per panel. Mark lines "
                      "with Edge ▸ Mark Sharp, or just select them")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == "MESH"

    def execute(self, context):
        st = context.scene.quadremesh_lines
        ob = context.active_object
        editing = ob.mode == "EDIT"

        # Always dissolve on a copy first. The operation can annihilate a
        # region outright - a sphere with only its equator marked collapsed
        # 288 faces to zero in testing - and there is no clean way to take
        # that back once it has been applied to a live edit-mode mesh.
        live = bmesh.from_edit_mesh(ob.data) if editing else None
        if editing:
            bm = live.copy()
        else:
            bm = bmesh.new()
            bm.from_mesh(ob.data)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        marks = PZ.count_marked(bm, use_sharp=st.pz_use_sharp,
                                use_selection=st.pz_use_selection)
        if marks["usable"] == 0:
            if not editing:
                bm.free()
            self.report({"ERROR"},
                        "No lines marked. Mark edges Sharp in Edit Mode, or "
                        "select them, then press again")
            return {"CANCELLED"}

        # Only the pockets the user actually enclosed get flattened; anything
        # their lines do not close off is left exactly as it was.
        doomed, n_regions = PZ.inside_marked_loops(
            bm, use_sharp=st.pz_use_sharp, use_selection=st.pz_use_selection)
        if not doomed:
            if editing:
                bm.free()
            else:
                bm.free()
            self.report({"ERROR"},
                        "Your lines do not close off any area. Make the marked "
                        "edges form a complete loop around what you want "
                        "flattened.")
            return {"CANCELLED"}
        keep = {e.index for e in bm.edges} - doomed
        box_before = PZ.bounds(bm)
        try:
            res = PZ.panelize(bm, keep,
                              dissolve_verts=st.pz_dissolve_verts)
        except Exception as exc:
            bm.free()
            self.report({"ERROR"}, f"Dissolve failed: {exc}")
            return {"CANCELLED"}

        # This used to refuse the operation when the numbers looked like a
        # collapse. Milad asked for that gone: it blocked results he wanted,
        # and Ctrl+Z is a perfectly good way back. The measurement is still
        # taken and still reported, it just no longer stops anything.
        note = PZ.check(bm, box_before, res)

        if editing:
            PZ.panelize(live, keep, dissolve_verts=st.pz_dissolve_verts)
            bm.free()
            bmesh.update_edit_mesh(ob.data, loop_triangles=True,
                                   destructive=True)
        else:
            bm.to_mesh(ob.data)
            bm.free()
            ob.data.update()

        st.panelize_info = (
            f"{res['faces_before']} -> {res['faces_after']} faces, "
            f"{res['edges_removed']} edges and {res['verts_removed']} vertices "
            f"removed, {res['lines_kept']} lines kept"
        )
        if note:
            st.panelize_info += "  |  " + note
            self.report({"WARNING"}, note)
        else:
            self.report({"INFO"}, st.panelize_info)
        return {"FINISHED"}


class QUADREMESH_OT_panelize_mark(Operator):
    """Mark the selected edges Sharp so they survive a later dissolve."""

    bl_idname = "mesh.quadremesh_panelize_mark"
    bl_label = "Mark Selected as Lines"
    bl_description = ("Mark the selected edges Sharp. They turn cyan, are "
                      "saved with the mesh, and are what Dissolve Between "
                      "Lines keeps")
    bl_options = {"REGISTER", "UNDO"}

    clear: BoolProperty(name="Clear Instead", default=False,
                        options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob is not None and ob.type == "MESH" and ob.mode == "EDIT")

    def execute(self, context):
        ob = context.active_object
        bm = bmesh.from_edit_mesh(ob.data)
        n = 0
        for e in bm.edges:
            if self.clear:
                if not e.smooth:
                    e.smooth = True; n += 1
            elif e.select:
                if e.smooth:
                    e.smooth = False; n += 1
        bmesh.update_edit_mesh(ob.data)
        self.report({"INFO"},
                    f"{'cleared' if self.clear else 'marked'} {n} edges")
        return {"FINISHED"}



class QUADREMESH_OT_clean_between(Operator):
    """Dissolve everything that is not a feature line, in place.

    Uses the same mask `Remesh Hardsurface` builds from - detector plus the
    user's own marked edges, after the prune - so the lines that survive here
    are exactly the lines that survive there. It is not a second algorithm;
    it is the same decision applied to the original mesh instead of to a
    freshly built one.
    """

    bl_idname = "mesh.quadremesh_clean_between"
    bl_label = "Clean Between Lines"
    bl_description = ("Clean the area enclosed by the edges you have selected. "
                      "Other lines, and anything outside that area, are left "
                      "alone")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        st.source = obj.name
        cache = get_cache(obj)
        mask, info, plog, crease, flat, auto_c, auto_f = detect(context, cache, st)

        # The mask indexes the analysis edge list, whose vertex numbers are the
        # mesh's own, so the lines map straight back onto bmesh edges.
        E = cache["edges"]
        want = set()
        for i in np.flatnonzero(mask).tolist():
            a, b = int(E[i][0]), int(E[i][1])
            want.add((a, b) if a < b else (b, a))

        # Keep the mesh as it was, so the percentage slider can redo the
        # clean from scratch instead of eating its own output.
        stash = bpy.data.meshes.get(obj.get(PZ_ORIG_KEY) or "")
        if stash is None:
            stash = obj.data.copy()
            stash.name = obj.data.name + "_preclean"
            stash.use_fake_user = True
            obj[PZ_ORIG_KEY] = stash.name
            _remember_base(obj, stash)

        bm = bmesh.new()
        bm.from_mesh(stash)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        # Tag the user's own lines only. Adding the 800 detector lines as well
        # was tried and cuts every pocket into slivers that touch the open
        # mesh, so no region qualifies and nothing is removed at all - measured,
        # 9671 faces in and 9671 out. The detector's lines are for building
        # from; these are for cutting along.
        # The selection alone says where to cut. Using every marked line
        # instead meant a pocket anywhere on the model got flattened too;
        # Milad wants to point at lines and have only those gaps cleaned -
        # any number of them, each area they close off taken on its own.
        # (bmesh spells Mark Sharp as `smooth = False`; `use_edge_sharp`
        # exists only on the mesh datablock.)
        # Every line splits regions, so a line lying inside the cleaned area
        # still has faces on both sides and survives. Only the selection says
        # which of those regions actually gets cleaned.
        # Here selection IS the instruction - the user picked these lines for
        # this run - so it counts however much of the mesh it covers, unlike
        # the whole-model drop where a leftover select-all means nothing.
        n_sel = 0
        for e in bm.edges:
            e.tag = e.select or (not e.smooth)
            if e.select:
                n_sel += 1
        if not n_sel:
            bm.free()
            if editing:
                bpy.ops.object.mode_set(mode="EDIT")
            self.report({"ERROR"},
                        "Select the lines to clean between, in Edit Mode. Any number - "
                        "every area they close off is cleaned.")
            return {"CANCELLED"}

        # Dissolving every untagged edge at once flattens the whole model into
        # nothing - measured, 9888 faces to 18 - because these lines are drawn
        # to be rebuilt from, not to be cut along. Only a region the lines
        # actually close off can safely become one face, so each pocket is
        # tested and the rest is left alone.
        doomed = PZ.enclosed_interior(bm, require_selected=True)
        doomed = PZ.thin_out(doomed, st.pz_amount)
        before = len(bm.faces)
        if doomed:
            PZ.dissolve_keeping_rims(bm, doomed, region=PZ.region_faces(bm))
        bm.normal_update()
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()

        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        st.build_info = (f"{before} -> {len(obj.data.polygons)} faces  |  "
                         f"{len(want)} lines kept"
                         + (f"  |  {info['n_marked']} of your own"
                            if info.get("n_marked") else ""))
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}



class QUADREMESH_OT_clean_reset(Operator):
    """Put the mesh back as it was before the cleaning started.

    The stash the percentage slider redoes from is also the way back, so this
    is just handing it over and forgetting it. After this the slider starts a
    fresh stash from whatever the mesh is then.
    """

    bl_idname = "mesh.quadremesh_clean_reset"
    bl_label = "Reset"
    bl_description = ("Undo the cleaning entirely and forget it, so the next "
                      "slider move starts again from the mesh as it is now")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH"
                and bool(o.get(PZ_ORIG_KEY)))

    def execute(self, context):
        obj = context.active_object
        st = context.scene.quadremesh_lines
        stash = bpy.data.meshes.get(obj.get(PZ_ORIG_KEY) or "")
        if stash is None:
            obj.pop(PZ_ORIG_KEY, None)
            self.report({"WARNING"}, "nothing stored to go back to")
            return {"CANCELLED"}
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        before = len(obj.data.polygons)
        bm = bmesh.new()
        bm.from_mesh(stash)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        obj.pop(PZ_ORIG_KEY, None)
        stash.use_fake_user = False
        if stash.users == 0:
            bpy.data.meshes.remove(stash)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        with suspend_live():
            st.pz_amount = 100.0
        st.build_info = f"reset  |  {before} -> {len(obj.data.polygons)} faces"
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}



class QUADREMESH_OT_clean_confirm(Operator):
    """Accept the cleaned area and stop the slider touching it again.

    Dropping the stash is what does it: the slider rebuilds from the stash
    every time, so once there is none the current mesh is simply the new
    starting point. The selection is cleared too, which is what keeps the
    slider quiet until the next area is picked.
    """

    bl_idname = "mesh.quadremesh_clean_confirm"
    bl_label = "Confirm"
    bl_description = ("Keep this area as it is now. The slider stops affecting "
                      "it and stays off until you select the next area")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_ORIG_KEY))

    def execute(self, context):
        obj = context.active_object
        st = context.scene.quadremesh_lines
        stash = bpy.data.meshes.get(obj.get(PZ_ORIG_KEY) or "")
        obj.pop(PZ_ORIG_KEY, None)
        if stash is not None:
            stash.use_fake_user = False
            if stash.users == 0:
                bpy.data.meshes.remove(stash)

        if obj.mode == "EDIT":
            bm = bmesh.from_edit_mesh(obj.data)
            for e in bm.edges:
                e.select = False
            for v in bm.verts:
                v.select = False
            for f in bm.faces:
                f.select = False
            bm.select_flush(False)
            bmesh.update_edit_mesh(obj.data)
        else:
            for e in obj.data.edges:
                e.select = False
            for v in obj.data.vertices:
                v.select = False
            for f in obj.data.polygons:
                f.select = False

        with suspend_live():
            st.pz_amount = 100.0
        st.build_info = f"confirmed  |  {len(obj.data.polygons)} faces"
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}



class QUADREMESH_OT_clean_revert_all(Operator):
    """Undo every cleaning on this object, confirmed ones included.

    Reset only steps back to the last stash, which Confirm throws away. This
    works from the snapshot taken the first time the object was touched, so it
    reaches past every Confirm in the session.
    """

    bl_idname = "mesh.quadremesh_clean_revert_all"
    bl_label = "Revert All Cleaning"
    bl_description = ("Put this object back the way it was before any cleaning, "
                      "including areas already confirmed")
    bl_options = {"REGISTER", "UNDO"}

    all_objects: BoolProperty(
        name="Every Object", default=False,
        description="Do it for every object in the file that has been cleaned, "
                    "not just this one")

    @classmethod
    def poll(cls, context):
        if any(o.get(PZ_BASE_KEY) for o in bpy.data.objects):
            return True
        o = context.active_object
        return o is not None and bool(o.get(PZ_BASE_KEY))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        col = self.layout.column(align=True)
        col.label(text="Undoes all cleaning, confirmed areas included.")
        col.prop(self, "all_objects")

    def execute(self, context):
        st = context.scene.quadremesh_lines
        act = context.active_object
        if act is not None and act.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")

        targets = ([o for o in bpy.data.objects
                    if o.type == "MESH" and o.get(PZ_BASE_KEY)]
                   if self.all_objects
                   else ([act] if act is not None and act.get(PZ_BASE_KEY) else []))
        if not targets:
            self.report({"WARNING"}, "nothing has been cleaned")
            return {"CANCELLED"}

        done = 0
        for obj in targets:
            base = bpy.data.meshes.get(obj.get(PZ_BASE_KEY) or "")
            if base is None:
                obj.pop(PZ_BASE_KEY, None)
                continue
            bm = bmesh.new()
            bm.from_mesh(base)
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()
            for key in (PZ_ORIG_KEY, PZ_BASE_KEY, PZ_DROP_KEY):
                name = obj.get(key)
                obj.pop(key, None)
                m = bpy.data.meshes.get(name or "")
                if m is not None:
                    m.use_fake_user = False
                    if m.users == 0:
                        bpy.data.meshes.remove(m)
            done += 1

        with suspend_live():
            st.pz_amount = 100.0
        st.build_info = f"reverted {done} object{'s' if done != 1 else ''}"
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}






_AXIS_COUNTS = {}


def axis_loop_counts(obj, limit=60000):
    """How many whole loops run along X, Y and Z on this mesh.

    Cached against the mesh's own state, because walking every loop is far
    too slow to repeat on each redraw of the panel. The key changes whenever
    the geometry or the user's markings do, which is exactly when the answer
    changes.

    Past `limit` faces the walk is skipped and None is returned; the panel
    offers a button instead, so opening the sidebar on a heavy scan never
    stalls Blender.
    """
    me = obj.data
    npoly = len(me.polygons)
    # The heavy-mesh guard comes first, and on a cheap attribute. It used to
    # sum every edge's select and sharp flags in Python before this check -
    # on a scan of a few hundred thousand edges that ran on every redraw of
    # the sidebar, once per mouse move, and dragged Blender to a crawl for as
    # long as the Smart Remesh panel was open. Above the limit there is
    # nothing to compute, so return before touching the edges at all.
    if npoly > limit:
        return None
    ne = len(me.edges)
    # numpy, not a Python loop: foreach_get pulls both flag arrays in C, so
    # the key costs microseconds instead of walking every edge by hand.
    sel = np.empty(ne, dtype=bool)
    me.edges.foreach_get("select", sel)
    shp = np.empty(ne, dtype=bool)
    me.edges.foreach_get("use_edge_sharp", shp)
    key = (obj.name, npoly, ne, int(sel.sum()), int(shp.sum()))
    hit = _AXIS_COUNTS.get(obj.name)
    if hit and hit[0] == key:
        return hit[1]
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.edges.ensure_lookup_table()
    PZ.tag_marked(bm)
    pool = [e for e in bm.edges if len(e.link_faces) == 2 and not e.tag]
    whole, partial = PZ.complete_loops(pool)
    counts = [0, 0, 0]
    for lp in whole:
        counts[PZ.loop_axis(lp)] += 1
    bm.free()
    out = (counts[0], counts[1], counts[2], len(whole), len(partial))
    _AXIS_COUNTS[obj.name] = (key, out)
    return out


class QUADREMESH_OT_count_loops(Operator):
    """Count the loops per axis on a mesh too heavy to do it automatically."""

    bl_idname = "mesh.quadremesh_count_loops"
    bl_label = "Count Loops"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    @classmethod
    def description(cls, context, properties):
        """The tooltip, written out with this model's own numbers in it.

        A label carries no tooltip in Blender, so the row heading is drawn as
        this operator with the frame switched off: it looks like text, and
        resting on it explains what the three figures are.
        """
        nl = chr(10)
        head = (
            "How many edge loops run along each axis." + nl + nl
            + "A loop's axis is the direction it actually travels: the "
              "lengths of its edges are added up along X, Y and Z, and the "
              "largest wins. Every loop belongs to one axis only, so the "
              "three figures add up to the total and no loop is counted "
              "twice." + nl + nl
            + "Tick an axis to work on that group alone. The bigger the "
              "figure, the more that axis has to give."
        )
        o = context.active_object
        if o is None or o.type != "MESH" or not len(o.data.polygons):
            return head
        hit = _AXIS_COUNTS.get(o.name)
        if not hit:
            return head + nl + nl + "Click to count them on this model."
        x, y, z, total, part = hit[1]
        biggest = max(((x, "X"), (y, "Y"), (z, "Z")))[1]
        tail = (nl + nl + "On " + o.name + ":   X " + str(x)
                + "   Y " + str(y) + "   Z " + str(z) + nl
                + str(total) + " loops in all")
        if part:
            tail += (", and " + str(part) + " that never close into a ring - "
                     "those are left alone")
        tail += "." + nl + "Most to gain right now: " + biggest + "."
        return head + tail


class QUADREMESH_OT_drop_useless(Operator):
    """Remove every edge loop that is not holding any shape.

    No marking needed. Each loop is measured by how far the surface turns
    across it: a loop down the middle of a flat panel turns nothing and is
    only costing vertices, while one round a fillet turns a lot and is the
    shape itself. Only the first kind goes.

    Always measured against the mesh as it was before the first run, never
    against the last result. Removing a loop lengthens the edges crossing its
    neighbours, which flattens how they measure, so working from the current
    mesh made every press eat further into the model. From a fixed baseline a
    second press at the same setting simply reproduces the first.
    """

    bl_idname = "mesh.quadremesh_drop_useless"
    bl_label = "Drop Useless Loops"
    bl_description = ("Remove the edge loops that carry no shape, over the "
                      "whole model. Nothing has to be marked first, and "
                      "pressing it again changes nothing")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        base = bpy.data.meshes.get(obj.get(PZ_DROP_KEY) or "")
        if base is None:
            base = obj.data.copy()
            base.name = obj.data.name + "_predrop"
            base.use_fake_user = True
            obj[PZ_DROP_KEY] = base.name

        bm = bmesh.new()
        bm.from_mesh(base)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        # Same as above: with an axis filter on, the selection is the
        # target, not something to spare.
        # Protect UV walls the walk off again, at Milad's word. Taking the
        # loops whole across the seams and mending afterwards did give an
        # even pattern, but the mend cannot put the texture back: a face
        # merged across a seam carries only one side's coordinates, and 11
        # faces in 410 came out showing the wrong patch of the map. That
        # was fixable by baking, but the original is gone by then in his
        # pipeline, so the texture has to survive the drop itself.
        PZ.tag_marked(bm, keep_seams=st.pz_keep_seams,
                      uv_layers=list(bm.loops.layers.uv.values()),
                      use_selection=False)
        _confine_to_selection(bm)

        before = len(bm.faces)
        dropped = partial = 0
        if st.pz_every >= 1:
            doomed, n2 = PZ.thin_every(
                bm, st.pz_every, keep_marked=st.pz_keep_marked,
                axes=(st.pz_axis_x, st.pz_axis_y, st.pz_axis_z),
                rot=obj.matrix_world.to_3x3())
            if doomed:
                PZ.dissolve_keeping_rims(bm, doomed, polish=True)
                PZ.heal_stubs(bm)
                PZ.polish_verts(
                bm, uv_layers=list(bm.loops.layers.uv.values()))
                dropped += n2
        if st.pz_useless > 0.0:
            n1, partial = PZ.drop_loops(
                bm, tol_deg=st.pz_useless, keep_marked=st.pz_keep_marked,
                sag_pct=0.0,
                axes=(st.pz_axis_x, st.pz_axis_y, st.pz_axis_z),
                rot=obj.matrix_world.to_3x3())
            dropped += n1
        PZ.polish_verts(bm, uv_layers=list(bm.loops.layers.uv.values()))
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        st.build_info = (f"{dropped} loop{'s' if dropped != 1 else ''} dropped"
                         f"  |  {before} -> {len(obj.data.polygons)} faces"
                         + (f"  |  {partial} left alone, they do not run to "
                            "a clean end" if partial else ""))
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_force_loop(Operator):
    """Cut an edge loop that carries on through n-gons and poles alike."""

    bl_idname = "mesh.quadremesh_force_loop"
    bl_label = "Force Edge Loop"
    bl_description = ("Click an edge in the viewport to cut a loop through "
                     "it, exactly where you clicked - and unlike Blender's "
                     "loop cut it keeps going through n-gons. Escape or "
                     "right-click to cancel")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and o.mode == "EDIT"

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"ERROR"}, "works in the 3D viewport")
            return {"CANCELLED"}
        context.window.cursor_modal_set("KNIFE")
        context.area.header_text_set(
            "Force Edge Loop: click an edge to cut through it  |  "
            "Esc / right-click to cancel")
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _finish(self, context):
        context.window.cursor_modal_restore()
        context.area.header_text_set(None)

    def modal(self, context, event):
        if event.type in {"RIGHTMOUSE", "ESC"}:
            self._finish(context)
            return {"CANCELLED"}
        if event.type != "LEFTMOUSE" or event.value != "PRESS":
            return {"RUNNING_MODAL"}

        from bpy_extras import view3d_utils
        obj = context.active_object
        region = context.region
        rv3d = context.region_data
        co = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, co)
        inv = obj.matrix_world.inverted()
        o_local = inv @ origin
        d_local = (inv.to_3x3() @ direction).normalized()

        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        from mathutils.bvhtree import BVHTree
        tree = BVHTree.FromBMesh(bm)
        hit = tree.ray_cast(o_local, d_local)
        if hit is None or hit[0] is None:
            return {"RUNNING_MODAL"}     # clicked past the mesh, keep waiting
        loc, _n, fidx, _d = hit
        face = bm.faces[fidx]
        edge = min(face.edges, key=lambda e: (
            loc - (e.verts[0].co + e.verts[1].co) / 2).length)
        a, b = edge.verts[0].co, edge.verts[1].co
        ab = b - a
        t = 0.5 if ab.length_squared < 1e-18 else             (loc - a).dot(ab) / ab.length_squared
        t = min(max(t, 0.05), 0.95)

        axis = context.scene.quadremesh_lines.pz_loop_axis
        if axis == "AUTO":
            cuts = PZ.force_loop(bm, edge, factor=t)
        else:
            no = {"X": Vector((1, 0, 0)), "Y": Vector((0, 1, 0)),
                  "Z": Vector((0, 0, 1))}[axis]
            no_local = (inv.to_3x3() @ no).normalized()
            res = bmesh.ops.bisect_plane(
                bm, geom=list(bm.verts) + list(bm.edges) + list(bm.faces),
                plane_co=loc, plane_no=no_local)
            cuts = sum(1 for g in res["geom_cut"]
                       if isinstance(g, bmesh.types.BMEdge))
        bmesh.update_edit_mesh(obj.data, loop_triangles=True,
                               destructive=True)
        self._finish(context)
        if not cuts:
            self.report({"WARNING"}, "could not cut from there")
            return {"CANCELLED"}
        self.report({"INFO"}, f"cut through {cuts} faces")
        return {"FINISHED"}

    def execute(self, context):
        # fallback for calls without a viewport: cut at the selected edge
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [e for e in bm.edges if e.select]
        if len(sel) != 1:
            self.report({"ERROR"}, "select exactly one edge to start from")
            return {"CANCELLED"}
        cuts = PZ.force_loop(bm, sel[0])
        bmesh.update_edit_mesh(obj.data, loop_triangles=True,
                               destructive=True)
        if not cuts:
            self.report({"WARNING"}, "could not cut from here")
            return {"CANCELLED"}
        self.report({"INFO"}, f"cut through {cuts} faces")
        return {"FINISHED"}


def _uv_seam_edges(bm):
    """Edges where the active UV map is cut: open borders and UV jumps."""
    uv = bm.loops.layers.uv.active
    if uv is None:
        return []
    out = []
    for e in bm.edges:
        faces = e.link_faces
        seam = False
        if len(faces) == 1:
            seam = True
        elif len(faces) == 2:
            for v in e.verts:
                uvs = []
                for f in faces:
                    for l in f.loops:
                        if l.vert is v:
                            uvs.append(l[uv].uv)
                            break
                if len(uvs) == 2 and (uvs[0] - uvs[1]).length > 1e-5:
                    seam = True
                    break
        if seam:
            out.append(e)
    return out


def _with_bmesh(obj, fn):
    """Run `fn(bm)` on the object's mesh whichever mode it is in."""
    if obj.mode == "EDIT":
        bm = bmesh.from_edit_mesh(obj.data)
        n = fn(bm)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False,
                               destructive=False)
    else:
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        n = fn(bm)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
    return n


def _uv_show_update(self, context):
    """Tick: the UV seams show as red lines. Untick: they go."""
    obj = context.active_object
    if obj is None or obj.type != "MESH" or not obj.data.uv_layers:
        return
    on = self.uv_show_seams

    def apply(bm):
        n = 0
        for e in _uv_seam_edges(bm):
            e.seam = on
            n += 1
        return n
    _with_bmesh(obj, apply)
    from . import marks
    marks.invalidate()
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            area.spaces.active.overlay.show_edge_seams = True
            area.tag_redraw()


def _uv_sharp_update(self, context):
    """Tick: the UV seams are Sharp, the blue lines the remesh keeps."""
    obj = context.active_object
    if obj is None or obj.type != "MESH" or not obj.data.uv_layers:
        return
    on = self.uv_seams_sharp

    def apply(bm):
        n = 0
        for e in _uv_seam_edges(bm):
            e.smooth = not on        # bmesh spells Mark Sharp this way
            n += 1
        return n
    _with_bmesh(obj, apply)
    if on:
        self.hs_use_marked = True
    from . import marks
    marks.invalidate()
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            area.spaces.active.overlay.show_edge_sharp = True
            area.tag_redraw()


def _source_disp_scale(src_obj):
    """The displacement scale the original uses, so the baked height map
    moves the surface by the same amount."""
    for slot in src_obj.material_slots:
        m = slot.material
        if not (m and m.use_nodes):
            continue
        out = next((n for n in m.node_tree.nodes
                    if n.type == "OUTPUT_MATERIAL"), None)
        if out and out.inputs["Displacement"].is_linked:
            dn = out.inputs["Displacement"].links[0].from_node
            if "Scale" in dn.inputs:
                return dn.inputs["Scale"].default_value
    return 1.0


def _bake_via_emission(src_obj, socket_name, default_is_color):
    """Rewire every material on the source so the chosen Principled input
    shines out as emission, and hand back a function that undoes it.

    Cycles can bake colour and normals directly but has no bake type for
    roughness or metallic. Whatever feeds that input - a texture, a value -
    is routed into an Emission shader on the Material Output for the length
    of one EMIT bake, so the image receives exactly that channel.
    """
    undo = []
    for slot in src_obj.material_slots:
        mat = slot.material
        if mat is None or not mat.use_nodes:
            continue
        nt = mat.node_tree
        out = next((n for n in nt.nodes
                    if n.type == "OUTPUT_MATERIAL" and n.is_active_output),
                   None) or next((n for n in nt.nodes
                                  if n.type == "OUTPUT_MATERIAL"), None)
        bsdf = next((n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"), None)
        if out is None:
            continue
        if socket_name == "Height":
            # the height map feeds the Displacement node on the output
            d = out.inputs["Displacement"]
            dn = d.links[0].from_node if d.is_linked else None
            if dn is None or "Height" not in dn.inputs:
                continue
            sock = dn.inputs["Height"]
        else:
            if bsdf is None or socket_name not in bsdf.inputs:
                continue
            sock = bsdf.inputs[socket_name]
        emit = nt.nodes.new("ShaderNodeEmission")
        emit.name = "qr_bake_emit"
        if sock.is_linked:
            nt.links.new(sock.links[0].from_socket, emit.inputs["Color"])
        else:
            v = sock.default_value
            if default_is_color:
                emit.inputs["Color"].default_value = (v[0], v[1], v[2], 1.0)
            else:
                emit.inputs["Color"].default_value = (v, v, v, 1.0)
        prev = [(l.from_socket, l.to_socket) for l in out.inputs["Surface"].links]
        for l in list(out.inputs["Surface"].links):
            nt.links.remove(l)
        nt.links.new(emit.outputs["Emission"], out.inputs["Surface"])
        undo.append((nt, emit, out, prev))

    def restore():
        for nt, emit, out, prev in undo:
            for l in list(out.inputs["Surface"].links):
                nt.links.remove(l)
            for fs, ts in prev:
                nt.links.new(fs, ts)
            nt.nodes.remove(emit)
    return restore


BAKE_UNDO_MATS = "quadremesh_prebake_mats"
BAKE_UNDO_UV = "quadremesh_prebake_uv"


def _worst_drift(target, src_obj):
    """How far the remeshed surface strays from the original, in world units."""
    from mathutils.bvhtree import BVHTree
    me = src_obj.data
    if not len(me.polygons) or not len(target.data.vertices):
        return 0.0
    mw = src_obj.matrix_world
    tree = BVHTree.FromPolygons([(mw @ v.co)[:] for v in me.vertices],
                                [p.vertices[:] for p in me.polygons])
    tw = target.matrix_world
    verts = target.data.vertices
    step = max(1, len(verts) // 3000)
    worst = 0.0
    for i in range(0, len(verts), step):
        hit = tree.find_nearest(tw @ verts[i].co)
        if hit and hit[3] is not None and hit[3] > worst:
            worst = hit[3]
    return worst


class QUADREMESH_OT_unbake(Operator):
    """Put the model back the way it was before Bake From Original."""

    bl_idname = "mesh.quadremesh_unbake"
    bl_label = "Undo Bake"
    bl_description = ("Restore the materials and the UV map this model had "
                     "before the bake, and delete the baked images")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH"
                and BAKE_UNDO_MATS in o)

    def execute(self, context):
        obj = context.active_object
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        me = obj.data

        # the baked material and its images go, but only if nothing else
        # has picked them up in the meantime
        baked = [m for m in me.materials if m]
        me.materials.clear()
        for name in obj.get(BAKE_UNDO_MATS, []):
            me.materials.append(bpy.data.materials.get(name) if name else None)
        n_img = 0
        for mat in baked:
            if mat.users > 0 or not mat.use_nodes:
                continue
            for node in list(mat.node_tree.nodes):
                img = getattr(node, "image", None)
                if img is not None and img.users <= 1:
                    bpy.data.images.remove(img)
                    n_img += 1
            bpy.data.materials.remove(mat)

        # the unwrap the bake made goes too
        layer = me.uv_layers.get("BakeUV")
        if layer is not None and len(me.uv_layers) > 1:
            me.uv_layers.remove(layer)
        want = obj.get(BAKE_UNDO_UV) or ""
        back = me.uv_layers.get(want)
        if back is not None:
            me.uv_layers.active = back
            back.active_render = True

        del obj[BAKE_UNDO_MATS]
        obj.pop(BAKE_UNDO_UV, None)
        me.update()
        self.report({"INFO"}, f"bake undone, {n_img} images removed")
        return {"FINISHED"}


def _uv_tiles(me, layer):
    """The UDIM tiles a UV layer actually uses, as 1001-style numbers."""
    import numpy as _np
    n = len(layer.data)
    arr = _np.empty(n * 2, dtype=_np.float32)
    layer.data.foreach_get("uv", arr)
    arr = arr.reshape(n, 2)
    u = _np.clip(_np.floor(arr[:, 0]).astype(int), 0, 9)
    v = _np.clip(_np.floor(arr[:, 1]).astype(int), 0, None)
    nums = sorted({1001 + int(a) + 10 * int(b) for a, b in zip(u, v)})
    return nums or [1001]


def _new_bake_image(name, size, tiles, colorspace):
    """One image, tiled when the layout spans more than the first UDIM."""
    # Always tiled when the layout is: an untiled image only ever covers
    # UDIM 1001, so everything past the first tile bakes into nothing. The
    # Metallic and Roughness maps came out flat for exactly that reason -
    # they were created before this and stayed single-tile.
    img = bpy.data.images.new(name, size, size, tiled=len(tiles) > 1)
    img.colorspace_settings.name = colorspace
    if len(tiles) > 1:
        first = tiles[0]
        img.tiles[0].number = first
        for t in tiles[1:]:
            img.tiles.new(tile_number=t)
        with bpy.context.temp_override(edit_image=img):
            for t in img.tiles:
                img.tiles.active = t
                bpy.ops.image.tile_fill(width=size, height=size,
                                        color=(0, 0, 0, 1), alpha=True)
    return img


def _prefill_from_source(img, src_obj, socket):
    """Start a bake target off as the original's own map for that channel.

    Only sound when the UV layout is shared, which is what Bake Into
    Existing UV means. A ray that finds nothing then leaves the original
    pixel in place instead of a hole - and a hole is what the specks around
    the eyes and collar were.
    """
    found = None
    for slot in src_obj.material_slots:
        mat = slot.material
        if not (mat and mat.use_nodes):
            continue
        bsdf = next((n for n in mat.node_tree.nodes
                     if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf is None or socket not in bsdf.inputs:
            continue
        inp = bsdf.inputs[socket]
        if socket == "Normal" and inp.is_linked:
            nm = inp.links[0].from_node
            if "Color" in nm.inputs and nm.inputs["Color"].is_linked:
                inp = nm.inputs["Color"]
        if not inp.is_linked:
            continue
        node = inp.links[0].from_node
        if node.type == "TEX_IMAGE" and node.image:
            found = node.image
            break
    if found is None or tuple(found.size) == (0, 0):
        return False
    tmp = found.copy()
    try:
        if tuple(tmp.size) != tuple(img.size):
            tmp.scale(img.size[0], img.size[1])
        px = np.empty(img.size[0] * img.size[1] * 4, dtype=np.float32)
        tmp.pixels.foreach_get(px)
        img.pixels.foreach_set(px)
        img.update()
    finally:
        bpy.data.images.remove(tmp)
    return True


def _gpu_ready():
    """Is there a GPU device Cycles can actually bake on?

    Asking for GPU with nothing enabled in Preferences leaves Cycles falling
    back silently on some builds and erroring on others, so the switch checks
    first and stays on the processor when there is nothing to move to.
    """
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
    except Exception:
        return False
    try:
        prefs.get_devices()
    except Exception:
        pass
    if getattr(prefs, "compute_device_type", "NONE") in ("NONE", "", None):
        return False
    return any(getattr(d, "use", False) and d.type != "CPU"
               for d in getattr(prefs, "devices", []))


def _build_cage(target, src_obj, floor):
    """A cage that hugs the target, pushed out by its own local error.

    One extrusion for the whole model cannot serve a character: too small
    and the ray never reaches the shirt, too large and it carries on past
    the shirt into the body - which is the skin baked onto the hem of
    Milad's crop top, and it grows worse the further the face count drops.
    Each vertex is pushed out by what the remesh actually lost there, so
    the ray always starts just outside its own surface and stops soon after.
    """
    from mathutils.bvhtree import BVHTree
    me = src_obj.data
    if not len(me.polygons):
        return None, floor
    mw = src_obj.matrix_world
    tree = BVHTree.FromPolygons([(mw @ v.co)[:] for v in me.vertices],
                                [p.vertices[:] for p in me.polygons])
    cage_me = target.data.copy()
    cage_me.name = target.name + "_cage"
    tw = target.matrix_world
    n = len(cage_me.vertices)
    co = np.empty(n * 3, dtype=np.float32)
    cage_me.vertices.foreach_get("co", co)
    co = co.reshape(n, 3)
    nor = np.empty(n * 3, dtype=np.float32)
    cage_me.vertices.foreach_get("normal", nor)
    nor = nor.reshape(n, 3)
    # Built in world space and written back through the inverse. The
    # distance to the source is a world length, and it used to be added to a
    # local coordinate: on an object with an unapplied scale of 3.47 every
    # vertex went out three and a half times too far, the cage swallowed the
    # model, and the rays flew past it - seven out of ten pixels came back
    # black. On an object at scale 1 the two spaces agree, which is why it
    # went unnoticed.
    inv = tw.inverted()
    worst = 0.0
    for i in range(n):
        p_world = tw @ Vector(co[i])
        n_world = (tw.to_3x3() @ Vector(nor[i])).normalized()
        hit = tree.find_nearest(p_world)
        d = hit[3] if hit and hit[3] is not None else 0.0
        worst = max(worst, d)
        push = max(d * 1.5, floor)
        co[i] = inv @ (p_world + n_world * push)
    cage_me.vertices.foreach_set("co", co.reshape(-1))
    cage_me.update()
    cage = bpy.data.objects.new(target.name + "_cage", cage_me)
    bpy.context.scene.collection.objects.link(cage)
    cage.matrix_world = target.matrix_world.copy()
    cage.hide_render = True
    return cage, max(worst * 3.0, floor * 3.0)


# Progress of the bake that is running, read by the card and both panels.
#
# A bake is several passes - colour, every PBR channel, normals - each one a
# Cycles job, and it used to run them back to back with Blender frozen from
# the first to the last. Now each pass is started as Blender's own background
# job and the operator waits for it on a timer, so the window keeps drawing
# and this shows which pass it is on.
BAKE = {
    "busy": False,
    "stage": "",
    "done": 0,        # passes finished
    "total": 0,       # passes in all
    "shown": 0.0,     # what the bar shows, 0..1
    "t0": 0.0,
    "pass_t0": 0.0,   # when the pass under way started
    "pass_avg": 0.0,  # how long a finished pass took, on average
    "cancel": False,
}


def bake_progress_text():
    import time
    return "%d%%  %s  %ds" % (int(BAKE["shown"] * 100.0), BAKE["stage"],
                              int(time.time() - BAKE["t0"]))


def draw_bake_progress(layout):
    """The bar under the Bake button in the classic panels."""
    if BAKE["busy"]:
        layout.progress(factor=BAKE["shown"], type="BAR",
                        text=bake_progress_text())
        layout.label(text="Esc to stop", icon="INFO")


class _BakeStopped(Exception):
    pass


def _bake_redraw():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in {"VIEW_3D", "STATUSBAR"}:
                    area.tag_redraw()
    except Exception:
        pass


class QUADREMESH_OT_bake_esc(Operator):
    """Hears Escape during a bake pass. Started with each pass, never by hand.

    Blender's bake job puts its own modal on top of every other, and that one
    swallows Escape - so the bake operator underneath never learned the user
    wanted out, and started the next pass as soon as Blender killed this one.
    This sits above the job's modal, notes the key, and lets it through.
    """

    bl_idname = "mesh.quadremesh_bake_esc"
    bl_label = "Bake Escape"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        BAKE["watch"] = BAKE.get("watch", 0) + 1
        self._token = BAKE["watch"]
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not BAKE["busy"] or self._token != BAKE.get("watch"):
            return {"FINISHED", "PASS_THROUGH"}
        if event.type == "ESC" and event.value == "PRESS":
            BAKE["cancel"] = True
            BAKE["stage"] = "stopping"
        return {"PASS_THROUGH"}


class QUADREMESH_OT_bake_from_original(Operator):
    """Give the remeshed model a fresh UV and bake the original's texture onto it."""

    bl_idname = "mesh.quadremesh_bake_from_original"
    bl_label = "Bake From Original"
    bl_description = ("Unwrap the remeshed model afresh and bake the original "
                     "model's colour (and optionally its normals) onto it. "
                     "Independent of UV islands, so it works even where the "
                     "original has surfaces lying on top of each other")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if BAKE["busy"]:
            return False
        o = context.active_object
        return o is not None and o.type == "MESH" and (
            bool(o.get("quadremesh_source"))
            or bool(o.get("quadremesh_orig_mesh")))

    # -- scripts: every pass back to back, as before ------------------------
    def execute(self, context):
        gen = self._run()
        try:
            job = next(gen)
            while True:
                try:
                    bpy.ops.object.bake(**job[1])
                except Exception as exc:
                    job = gen.throw(exc)
                    continue
                job = gen.send(None)
        except StopIteration as stop:
            return stop.value or {"FINISHED"}

    # -- the button: each pass as Blender's own job, the window left free ---
    _timer = None
    _gen = None
    _waiting = False

    def invoke(self, context, event):
        import time
        now = time.time()
        BAKE.update(busy=True, stage="preparing the UV", done=0, total=0,
                    shown=0.0, t0=now, pass_t0=now, pass_avg=0.0,
                    cancel=False)
        self._gen = self._run()
        self._waiting = False
        self._started = False
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        _bake_redraw()
        return {"RUNNING_MODAL"}

    def _end(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        BAKE["busy"] = False
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        _bake_redraw()

    def _step(self, context, send=None, throw=None):
        """Run the bake up to its next pass and start that pass as a job."""
        import time
        try:
            if throw is not None:
                job = self._gen.throw(throw)
            elif not self._started:
                self._started = True
                job = next(self._gen)
            else:
                job = self._gen.send(send)
        except StopIteration as stop:
            value = stop.value or {"FINISHED"}
            if "FINISHED" in value:
                self._closing = True
                BAKE["stage"] = "done"
                return {"RUNNING_MODAL"}
            self._end(context)
            return value
        while True:
            label, kw = job
            BAKE["stage"] = label
            BAKE["pass_t0"] = time.time()
            try:
                ret = bpy.ops.object.bake("INVOKE_DEFAULT", **kw)
            except Exception as exc:
                ret = None
                err = exc
            else:
                err = None if "CANCELLED" not in ret else RuntimeError(
                    "Cycles refused the bake - see the report above")
            if err is None:
                self._waiting = True
                try:
                    bpy.ops.mesh.quadremesh_bake_esc("INVOKE_DEFAULT")
                except Exception:
                    pass
                return {"RUNNING_MODAL"}
            try:
                job = self._gen.throw(err)
            except StopIteration as stop:
                self._end(context)
                return stop.value or {"CANCELLED"}

    def modal(self, context, event):
        import math
        import time

        if event.type == "ESC" and event.value == "PRESS":
            BAKE["cancel"] = True
            BAKE["stage"] = "stopping"
            return {"PASS_THROUGH"}       # Blender's own job hears it too
        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        if getattr(self, "_closing", False):
            from . import ease_bar
            if ease_bar(BAKE, 1.0, ending=True):
                self._end(context)
                return {"FINISHED"}
            _bake_redraw()
            return {"PASS_THROUGH"}

        if not self._started:
            # the bar is on screen now; the unwrap before the first pass is
            # quick next to the passes but does block, so it waits for this
            return self._step(context)

        if self._waiting and bpy.app.is_job_running("OBJECT_BAKE"):
            from . import ease_bar
            n = max(1, BAKE["total"])
            ease_bar(BAKE, 0.05 + 0.95 * BAKE["done"] / n)
            try:
                context.workspace.status_text_set(
                    "Smart Remesh bake - " + bake_progress_text()
                    + "   Esc to stop")
            except Exception:
                pass
            _bake_redraw()
            return {"PASS_THROUGH"}

        if self._waiting:
            self._waiting = False
            took = time.time() - BAKE["pass_t0"]
            done = BAKE["done"]
            BAKE["pass_avg"] = (BAKE["pass_avg"] * done + took) / (done + 1)
            BAKE["done"] = done + 1
            _bake_redraw()
            if BAKE["cancel"]:
                return self._step(context, throw=_BakeStopped())
            return self._step(context)
        return {"PASS_THROUGH"}

    def cancel(self, context):
        self._end(context)

    def _run(self):
        # A generator: it yields at every pass, so the same steps serve the
        # script path above and the timer path. Blender's context is read
        # fresh at every resume - an old one is not safe to hold across.
        context = bpy.context
        st = context.scene.quadremesh_lines
        target = context.active_object
        scene = context.scene

        # the original: a live object, or the mesh stashed by Replace Original
        src_obj = bpy.data.objects.get(target.get("quadremesh_source") or "")
        temp = None
        if src_obj is None:
            me = bpy.data.meshes.get(target.get("quadremesh_orig_mesh") or "")
            if me is None:
                self.report({"ERROR"}, "the original model is gone")
                return {"CANCELLED"}
            temp = bpy.data.objects.new("qr_bake_src", me)
            scene.collection.objects.link(temp)
            temp.matrix_world = target.matrix_world.copy()
            src_obj = temp
        elif not at_same_place(src_obj, target):
            # Baking shoots a ray from the result towards the original. Drag
            # the result aside to compare the two - which is the first thing
            # anyone does - and the ray now points at empty space: every map
            # comes back black and nothing in the interface says why. Worse,
            # the cage inflates to bridge the gap and the few rays that do
            # land hit the far side of the model. A copy of the original is
            # placed exactly on the result for the bake, so neither of the
            # user's objects moves.
            temp = bpy.data.objects.new("qr_bake_src", src_obj.data)
            scene.collection.objects.link(temp)
            temp.matrix_world = target.matrix_world.copy()
            for i, slot in enumerate(src_obj.material_slots):
                if i < len(temp.material_slots):
                    temp.material_slots[i].link = slot.link
                    temp.material_slots[i].material = slot.material
            src_obj = temp
        if not any(m for m in src_obj.data.materials):
            if temp is not None:
                bpy.data.objects.remove(temp, do_unlink=True)
            self.report({"ERROR"}, "the original has no material to bake from")
            return {"CANCELLED"}

        if target.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        size = int(st.bake_size)
        margin = max(16, size // 128)
        base = target.name.replace("_S-Remesh", "")
        ext = max(target.dimensions) or 1.0
        # How far the ray starts out from the surface, and how far it may
        # travel. Both come from how far the remesh actually strayed from
        # the original, not from the model's overall size: 5% of a whole
        # statue puts the ray origin inside the far leg, it hits nothing,
        # and the texel is left black - the patches under the boar. Twice
        # the worst measured deviation covers every real case with room to
        # spare, and stays small enough not to reach across a gap.
        drift = _worst_drift(target, src_obj)
        # Just enough to cross the gap between the two surfaces, and no
        # further. The old three-times-over ray reached past the eyelid to
        # the eyeball and past the shirt to the body, and those wrong hits
        # are the specks around the eye, the mouth and the collar. A model's
        # own parts sit closer together than people expect.
        cage = min(max(drift * 1.5, ext * 0.0005), ext * 0.01)
        ray = cage * 1.2

        # 1. the UV to bake into
        prev_uv = (target.data.uv_layers.active.name
                   if target.data.uv_layers.active else "")
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        keep_uv = st.uv_keep_islands and bool(target.data.uv_layers)
        if keep_uv:
            # Bake into the layout the model already has. The fresh unwrap
            # below is what threw Milad's UDIM layout away every time he
            # baked - everything was right up to that point.
            uv = next((l for l in target.data.uv_layers if l.active_render),
                      target.data.uv_layers[0])
            target.data.uv_layers.active = uv
            uv.active_render = True
        else:
            uv = target.data.uv_layers.new(name="BakeUV")
            target.data.uv_layers.active = uv
            uv.active_render = True
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_all(action="SELECT")
            # Islands that sit on top of each other bake into each other -
            # the black patch on the statue's base. Packing cannot fix it,
            # because the overlap is usually an island folded onto itself;
            # the fold has to be cut. 45 degrees leaves far fewer than the
            # usual 66, then each remaining offender is walled off with a
            # seam and its island unwrapped again. Measured on the statue:
            # 12 faces, then 4, then none.
            saved_seams = [e.use_seam for e in target.data.edges]
            bpy.ops.uv.smart_project(angle_limit=math.radians(45.0),
                                     island_margin=0.001,
                                     correct_aspect=True,
                                     scale_to_bounds=False)
            bpy.ops.uv.seams_from_islands()

            def overlapping():
                bpy.ops.mesh.select_all(action="DESELECT")
                bpy.ops.uv.select_all(action="DESELECT")
                bpy.ops.uv.select_overlap()
                bpy.ops.object.mode_set(mode="OBJECT")
                n = sum(1 for f in target.data.polygons if f.select)
                bpy.ops.object.mode_set(mode="EDIT")
                return n

            try:
                for _round in range(4):
                    if not overlapping():
                        break
                    bpy.ops.mesh.region_to_loop()
                    bpy.ops.mesh.mark_seam(clear=False)
                    bpy.ops.mesh.select_all(action="SELECT")
                    bpy.ops.uv.unwrap(method="ANGLE_BASED", margin=0.001)
            except RuntimeError:
                pass
            bpy.ops.mesh.select_all(action="SELECT")
            # Even texel density first, then packed tight. Smart Project
            # leaves every island at its own scale and pads them heavily -
            # measured on Milad's character the islands covered 1.3% of a
            # 4096 sheet, so a 4K bake carried about 460 pixels of real
            # detail. Averaging the scale and packing at a hair's margin is
            # what makes the resolution he asked for actually arrive.
            try:
                bpy.ops.uv.average_islands_scale()
            except RuntimeError:
                pass
            try:
                bpy.ops.uv.pack_islands(rotate=True, scale=True,
                                        merge_overlap=False, margin=0.002,
                                        margin_method="FRACTION",
                                        shape_method="CONCAVE")
            except TypeError:
                bpy.ops.uv.pack_islands(rotate=True, margin=0.002)
            bpy.ops.object.mode_set(mode="OBJECT")
            # the seams were scaffolding for the unwrap, not the user's marks
            for e, was in zip(target.data.edges, saved_seams):
                e.use_seam = was
        tiles = _uv_tiles(target.data, uv) if keep_uv else [1001]

        # 2. a material on the target that receives the bake
        mat = bpy.data.materials.new(base + "_Baked")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        bsdf = nodes.get("Principled BSDF")
        color = _new_bake_image(base + "_Color", size, tiles, "sRGB")
        if keep_uv:
            _prefill_from_source(color, src_obj, "Base Color")
        n_col = nodes.new("ShaderNodeTexImage")
        n_col.image = color
        n_col.location = (-400, 300)
        # linked to the shader only after the bake: an image feeding the
        # material it is baked into is a circular dependency
        extra = []                      # (socket on the target, image node)
        height_node = None
        if st.bake_pbr:
            # Every channel the original drives with a texture comes across,
            # whatever it is - roughness, metallic, alpha, specular, coat,
            # emission - so nothing of the old material is left un-baked.
            # Base Color and Normal have their own bakes; the rest go through
            # the emission trick, one image each.
            COLOR_SOCKETS = {"Emission Color", "Subsurface Radius",
                             "Coat Tint", "Sheen Tint", "Specular Tint"}
            driven = []
            seen = set()
            for slot in src_obj.material_slots:
                m = slot.material
                if not (m and m.use_nodes):
                    continue
                b = next((n for n in m.node_tree.nodes
                          if n.type == "BSDF_PRINCIPLED"), None)
                if b is None:
                    continue
                for inp in b.inputs:
                    if inp.name in ("Base Color", "Normal", "Tangent",
                                    "Coat Normal", "Weight"):
                        continue
                    if inp.type not in ("VALUE", "RGBA"):
                        continue
                    if inp.is_linked and inp.name not in seen:
                        seen.add(inp.name)
                        driven.append(inp.name)
                # emission also counts when it is a plain colour that glows
                if ("Emission Color" in b.inputs
                        and "Emission Color" not in seen):
                    e = b.inputs["Emission Color"]
                    st_ = b.inputs.get("Emission Strength")
                    if st_ and st_.default_value > 0 \
                            and max(e.default_value[:3]) > 0:
                        seen.add("Emission Color")
                        driven.append("Emission Color")
                # a height map on the output's displacement
                out = next((n for n in m.node_tree.nodes
                            if n.type == "OUTPUT_MATERIAL"), None)
                if out and out.inputs["Displacement"].is_linked \
                        and "Height" not in seen:
                    seen.add("Height")
                    driven.append("Height")
            y = -350
            for sock in driven:
                suffix = "_" + sock.replace(" ", "")
                img = _new_bake_image(
                    base + suffix, size, tiles,
                    "sRGB" if sock in COLOR_SOCKETS else "Non-Color")
                if keep_uv:
                    _prefill_from_source(img, src_obj, sock)
                node = nodes.new("ShaderNodeTexImage")
                node.image = img
                node.location = (-400, y)
                y -= 250
                if sock == "Height":
                    height_node = node
                else:
                    extra.append((sock, node))
        n_nrm = None
        if st.bake_pbr:
            normal = _new_bake_image(base + "_Normal", size, tiles,
                                     "Non-Color")
            if keep_uv:
                _prefill_from_source(normal, src_obj, "Normal")
            n_nrm = nodes.new("ShaderNodeTexImage")
            n_nrm.image = normal
            n_nrm.location = (-600, -100)
            nmap = nodes.new("ShaderNodeNormalMap")
            nmap.location = (-300, -100)
            links.new(n_nrm.outputs["Color"], nmap.inputs["Color"])
            links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
        old_mats = [m for m in target.data.materials]
        # What Undo Bake puts back: the material slots as they were, and the
        # UV layer that was active before the fresh unwrap. Stored on the
        # object, so it survives leaving and returning to the scene.
        target[BAKE_UNDO_MATS] = [m.name if m else "" for m in old_mats]
        target[BAKE_UNDO_UV] = prev_uv
        target.data.materials.clear()
        target.data.materials.append(mat)

        # 3. bake, original -> new, in Cycles
        engine = scene.render.engine
        bake = scene.render.bake
        cage_obj = None
        cyc = scene.cycles
        saved = (bake.use_selected_to_active, bake.cage_extrusion,
                 bake.max_ray_distance, bake.use_pass_direct,
                 bake.use_pass_indirect, bake.use_pass_color, bake.margin)
        saved_cyc = (cyc.device, cyc.samples, cyc.use_denoising)
        # Colour and normals need no light, so one sample is the whole job -
        # the default 4096 samples was minutes of work for the same pixels.
        # CPU, because a GPU bake is what crashed Blender on Milad's machine;
        # and the viewports drop to solid so EEVEE is not compiling the very
        # material being written to while the bake runs.
        shadings = []
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                sp = area.spaces.active
                shadings.append((sp, sp.shading.type))
                sp.shading.type = "SOLID"
        try:
            scene.render.engine = "CYCLES"
            cyc.device = "GPU" if (st.bake_gpu and _gpu_ready()) else "CPU"
            cyc.samples = 1
            cyc.use_denoising = False
            src_obj.hide_set(False)
            src_obj.hide_render = False
            src_obj.select_set(True)
            target.select_set(True)
            context.view_layer.objects.active = target
            cage_obj, ray = _build_cage(target, src_obj, cage)
            bake.use_selected_to_active = True
            bake.use_cage = cage_obj is not None
            if cage_obj is not None:
                bake.cage_object = cage_obj
            bake.cage_extrusion = cage
            bake.max_ray_distance = ray
            # 8 pixels was a hairline at 4096: the island borders came out
            # short and the texture read as different from the original.
            # Blender fills from the adjacent face where it can, which is
            # exact, and extends outward only past that.
            bake.margin = margin
            try:
                bake.margin_type = "ADJACENT_FACES"
            except Exception:
                pass
            bake.use_pass_direct = False
            bake.use_pass_indirect = False
            bake.use_pass_color = True
            # Base Colour goes through the same emission route as the rest.
            # The DIFFUSE/COLOR pass runs the colour through Cycles' shading
            # model first, so anything metallic or transmissive came back
            # altered; an emission bake copies the value itself.
            BAKE["total"] = (1 + len(extra) + (1 if height_node else 0)
                             + (1 if n_nrm is not None else 0))
            BAKE["shown"] = max(BAKE["shown"], 0.05)
            nodes.active = n_col
            restore = _bake_via_emission(src_obj, "Base Color", True)
            try:
                yield ("baking colour", dict(
                    type="EMIT", use_selected_to_active=True,
                    cage_extrusion=cage, max_ray_distance=ray,
                    margin=margin))
            finally:
                restore()
            color.pack()
            jobs = list(extra)
            if height_node is not None:
                jobs.append(("Height", height_node))
            for sock, node in jobs:
                is_color = sock in COLOR_SOCKETS if st.bake_pbr else False
                restore = _bake_via_emission(src_obj, sock, is_color)
                try:
                    nodes.active = node
                    yield ("baking " + sock.lower(), dict(
                        type="EMIT", use_selected_to_active=True,
                        cage_extrusion=cage, max_ray_distance=ray,
                        margin=margin))
                    node.image.pack()
                finally:
                    restore()
            if n_nrm is not None:
                nodes.active = n_nrm
                yield ("baking normals", dict(
                    type="NORMAL", use_selected_to_active=True,
                    cage_extrusion=cage, max_ray_distance=ray,
                    margin=margin))
                n_nrm.image.pack()
        except Exception as e:
            target.data.materials.clear()
            for m in old_mats:
                target.data.materials.append(m)
            if isinstance(e, _BakeStopped):
                self.report({"WARNING"}, "bake stopped")
            else:
                self.report({"ERROR"}, f"bake failed: {e}")
            return {"CANCELLED"}
        finally:
            bake.use_cage = False
            bake.cage_object = None
            if cage_obj is not None:
                cm = cage_obj.data
                bpy.data.objects.remove(cage_obj, do_unlink=True)
                if cm.users == 0:
                    bpy.data.meshes.remove(cm)
            scene.render.engine = engine
            (bake.use_selected_to_active, bake.cage_extrusion,
             bake.max_ray_distance, bake.use_pass_direct,
             bake.use_pass_indirect, bake.use_pass_color, bake.margin) = saved
            cyc.device, cyc.samples, cyc.use_denoising = saved_cyc
            links.new(n_col.outputs["Color"], bsdf.inputs["Base Color"])
            for sock, node in extra:
                if sock in bsdf.inputs:
                    links.new(node.outputs["Color"], bsdf.inputs[sock])
                    if sock == "Emission Color" and "Emission Strength" in bsdf.inputs:
                        bsdf.inputs["Emission Strength"].default_value = 1.0
            if height_node is not None:
                out = next((n for n in nodes if n.type == "OUTPUT_MATERIAL"), None)
                if out is not None:
                    disp = nodes.new("ShaderNodeDisplacement")
                    disp.location = (0, -900)
                    disp.inputs["Scale"].default_value = \
                        _source_disp_scale(src_obj)
                    links.new(height_node.outputs["Color"], disp.inputs["Height"])
                    links.new(disp.outputs["Displacement"], out.inputs["Displacement"])
            for sp, kind in shadings:
                sp.shading.type = kind
            if temp is not None:
                bpy.data.objects.remove(temp, do_unlink=True)
            else:
                src_obj.select_set(False)
            target.select_set(True)
            context.view_layer.objects.active = target

        self.report({"INFO"}, f"baked {size}x{size} onto {target.name}")
        return {"FINISHED"}


class QUADREMESH_OT_drop_original(Operator):
    """All the way back: undo every drop and every Confirm on this object."""

    bl_idname = "mesh.quadremesh_drop_original"
    bl_label = "Back To Start"
    bl_description = ("Return to the mesh as it was before the very first "
                     "drop, wiping every confirmed stage on the way")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_FIRST_KEY))

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        first = bpy.data.meshes.get(obj.get(PZ_FIRST_KEY) or "")
        if first is None:
            obj.pop(PZ_FIRST_KEY, None)
            self.report({"WARNING"}, "nothing stored to go back to")
            return {"CANCELLED"}
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        before = len(obj.data.polygons)
        bm = bmesh.new()
        bm.from_mesh(first)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        for key in (PZ_DROP_KEY, PZ_FIRST_KEY):
            stored = bpy.data.meshes.get(obj.get(key) or "")
            obj.pop(key, None)
            if stored is not None:
                stored.use_fake_user = False
                if stored.users == 0:
                    bpy.data.meshes.remove(stored)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        with suspend_live():
            st.pz_useless = 1.0
            st.pz_every = 0
            st.pz_keep_marked = True
            st.pz_axis_x = st.pz_axis_y = st.pz_axis_z = True
        st.build_info = (f"back to start  |  {before} -> "
                         f"{len(obj.data.polygons)} faces")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_drop_confirm(Operator):
    """Accept the drop as it stands and make it the new starting point."""

    bl_idname = "mesh.quadremesh_drop_confirm"
    bl_label = "Confirm"
    bl_description = ("Keep the current result. The sliders start fresh from "
                     "here, so the next drop stacks on top instead of redoing "
                     "this one")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_DROP_KEY))

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        base = bpy.data.meshes.get(obj.get(PZ_DROP_KEY) or "")
        obj.pop(PZ_DROP_KEY, None)
        if base is not None:
            base.use_fake_user = False
            if base.users == 0:
                bpy.data.meshes.remove(base)
        st.build_info = f"confirmed at {len(obj.data.polygons)} faces"
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_drop_reset(Operator):
    """Put back everything Drop Useless Loops removed."""

    bl_idname = "mesh.quadremesh_drop_reset"
    bl_label = "Reset"
    bl_description = "Undo Drop Useless Loops on this object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_DROP_KEY))

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        base = bpy.data.meshes.get(obj.get(PZ_DROP_KEY) or "")
        if base is None:
            obj.pop(PZ_DROP_KEY, None)
            self.report({"WARNING"}, "nothing stored to go back to")
            return {"CANCELLED"}
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        before = len(obj.data.polygons)
        bm = bmesh.new()
        bm.from_mesh(base)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        obj.pop(PZ_DROP_KEY, None)
        base.use_fake_user = False
        if base.users == 0:
            bpy.data.meshes.remove(base)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        # the section itself starts over too - Milad wants Reset to mean the
        # panel as well as the mesh, and a slider left behind at its old
        # value would silently re-run the drop on the next nudge
        with suspend_live():
            st.pz_useless = 1.0
            st.pz_every = 0
            st.pz_keep_marked = True
            st.pz_axis_x = st.pz_axis_y = st.pz_axis_z = True
        st.build_info = f"drop reset  |  {before} -> {len(obj.data.polygons)} faces"
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_min_valence(Operator):
    """Remove every vertex with fewer than three edges."""

    bl_idname = "mesh.quadremesh_min_valence"
    bl_label = "At Least 3 Edges"
    bl_description = ("Clear out every vertex with fewer than three edges: "
                      "stray points and spurs are deleted, and a vertex "
                      "sitting between just two edges is dissolved")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.vertices)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        # Kept before anything is touched, so the button beside this one can
        # put the mesh back. Ctrl+Z reaches it too, but only until the next
        # thing pushes it off the stack - and this is a pass a model can be
        # left worse by, on the rim of a bore especially.
        keep = bpy.data.meshes.get(obj.get(PZ_VAL_KEY) or "")
        if keep is not None and keep.users <= 1:
            keep.use_fake_user = False
            bpy.data.meshes.remove(keep)
        snap = obj.data.copy()
        snap.name = obj.data.name + "_prevalence"
        snap.use_fake_user = True
        obj[PZ_VAL_KEY] = snap.name

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        before = len(bm.verts)
        got = PZ.min_three_edges(bm)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        st.build_info = (
            f"{before} -> {len(obj.data.vertices)} verts  |  "
            f"{got['loose']} stray, {got['spurs']} spurs, "
            f"{got['two_edge']} two-edge"
        )
        if got["of_those_on_a_curve"]:
            st.build_info += (f"  |  {got['of_those_on_a_curve']} of those sat "
                              "on a curve and joining them squares it off")
            self.report({"WARNING"}, st.build_info)
        else:
            self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_min_valence4(Operator):
    """Remove every vertex with fewer than four edges."""

    bl_idname = "mesh.quadremesh_min_valence4"
    bl_label = "At Least 4 Edges"
    bl_description = ("Clear out every vertex with fewer than four edges. "
                      "Everything At Least 3 Edges does, and the poles as "
                      "well: a three-edge vertex is where a loop dies, and "
                      "dissolving it merges the three faces round it so the "
                      "run carries on. Poles on an open border are left, or "
                      "the edge of the mesh would be eaten into")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.vertices)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        # the same snapshot the three-edge pass keeps, so one Back button
        # serves both and pressing either does not lose the other's return
        keep = bpy.data.meshes.get(obj.get(PZ_VAL_KEY) or "")
        if keep is not None and keep.users <= 1:
            keep.use_fake_user = False
            bpy.data.meshes.remove(keep)
        snap = obj.data.copy()
        snap.name = obj.data.name + "_prevalence"
        snap.use_fake_user = True
        obj[PZ_VAL_KEY] = snap.name

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        before = len(bm.verts)
        got = PZ.min_four_edges(bm)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        st.build_info = (
            f"{before} -> {len(obj.data.vertices)} verts  |  "
            f"{got['loose']} stray, {got['spurs']} spurs, "
            f"{got['two_edge']} two-edge, {got['three_edge']} poles"
        )
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_sweep_flat(Operator):
    """Dissolve the flat leftovers the loop drop cannot reach."""

    bl_idname = "mesh.quadremesh_sweep_flat"
    bl_label = "Sweep Flat"
    bl_description = ("Remove the runs that belong to no loop - the zig-zag "
                      "staircases a drop leaves behind - taking the flattest "
                      "share first. Marks, seams and sharp edges are left "
                      "alone. It makes n-gons: that is what merging coplanar "
                      "faces is. The slider works live, so the button is only "
                      "needed to start")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        st.build_info = _clean_apply(obj, st, _clean_baseline(obj))
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_absorb_small(Operator):
    """Collapse the faces far smaller than the rest."""

    bl_idname = "mesh.quadremesh_absorb_small"
    bl_label = "Absorb Small"
    bl_description = ("Collapse every face smaller than this share of the "
                      "mesh's average, and nothing else. It takes out the "
                      "ladders of little faces a drop leaves behind without "
                      "touching the big ones - unlike Sweep Flat, which asks "
                      "whether an edge is flat and on a scanned surface that "
                      "is true nearly everywhere")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        keep = bpy.data.meshes.get(obj.get(PZ_VAL_KEY) or "")
        if keep is not None and keep.users <= 1:
            keep.use_fake_user = False
            bpy.data.meshes.remove(keep)
        snap = obj.data.copy()
        snap.name = obj.data.name + "_prevalence"
        snap.use_fake_user = True
        obj[PZ_VAL_KEY] = snap.name

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        PZ.tag_marked(bm, keep_seams=st.pz_keep_seams,
                      uv_layers=list(bm.loops.layers.uv.values()))
        before = len(bm.faces)
        gone = PZ.absorb_small(bm, pct=st.pz_absorb,
                               keep_marked=st.pz_keep_marked)
        PZ.min_three_edges(bm)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        _heal_uv(obj.data)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        st.build_info = (f"{before} -> {len(obj.data.polygons)} faces  |  "
                         f"{gone} small faces absorbed")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_weld(Operator):
    """Merge the vertices that sit closer together than Weld Range."""

    bl_idname = "mesh.quadremesh_weld"
    bl_label = "Weld"
    bl_description = ("Merge every pair of vertices closer together than "
                      "Weld Range, in the object's own units - the ones the "
                      "N panel shows. The slider works live, so the button "
                      "is only needed to start")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.vertices)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        st.build_info = _clean_apply(obj, st, _clean_baseline(obj))
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_select_axis_loops(Operator):
    """Select the loops running in the ticked directions, and stop there."""

    bl_idname = "mesh.quadremesh_select_axis_loops"
    bl_label = "Select Axis Loops"
    bl_description = ("Select every loop belonging to the axes ticked above "
                      "and leave the mesh alone. A loop's axis is the "
                      "direction the mesh gets thinner in when it goes - so "
                      "the rings round a beam belong to the beam's length. "
                      "Drops you into Edit Mode with them selected, to do "
                      "with as you like")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        axes = (st.pz_axis_x, st.pz_axis_y, st.pz_axis_z)
        if not any(axes):
            self.report({"WARNING"}, "tick an axis first")
            return {"CANCELLED"}
        if obj.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        # Edge by edge, not loop by loop. A loop is given one axis for the
        # whole of its length, and a line that runs up the front of a model
        # and along the top belongs mostly to whichever half is longer - so
        # the vertical lines down the side of Milad's block came back
        # unselected while the same loop's horizontal half did not. Asking
        # each edge which way it points has no such seam: tick Z and every
        # edge running up and down is in, wherever its loop goes afterwards.
        picked = 0
        edges = 0
        part_picked = 0
        # In world space, not the object's own. This object carries a 90
        # degree rotation, so its local Z points along the world Y: ticking
        # Z picked the horizontal lines and Y the vertical ones. The axis
        # names have to mean what the gizmo in the corner of the viewport
        # says they mean.
        rot = obj.matrix_world.to_3x3()
        for e in bm.edges:
            e.select = False
        seeds = []
        for e in bm.edges:
            if len(e.link_faces) < 1:
                continue
            d = rot @ (e.verts[0].co - e.verts[1].co)
            comp = (abs(d.x), abs(d.y), abs(d.z))
            top = max(comp)
            if top > 0.0 and axes[comp.index(top)]:
                seeds.append(e)
        # Each seed is followed to the end of its loop. Picking edges one at
        # a time stopped wherever the line turned - the vertical runs down
        # Milad's block came out selected part way and then gave up. A loop
        # is one line whatever it does further along, so the whole of it goes
        # in.
        if not st.pz_sel_whole_loops:
            # just the edges pointing that way, stopping where they turn
            for e in seeds:
                e.select = True
                edges += 1
            picked = len(seeds)
        else:
            seen = set()
            for seed in seeds:
                if seed.index in seen:
                    continue
                picked += 1
                chain = [seed]
                seen.add(seed.index)
                for end in (0, 1):
                    cur, v = seed, seed.verts[end]
                    while True:
                        nxt = PZ._next_in_loop(cur, v)
                        if nxt is None or nxt.index in seen:
                            break
                        seen.add(nxt.index)
                        chain.append(nxt)
                        v = nxt.other_vert(v)
                        cur = nxt
                for e in chain:
                    e.select = True
                    edges += 1
        keep = [e.index for e in bm.edges if e.select]
        bm.to_mesh(obj.data)
        bm.free()
        # Written straight onto the mesh rather than flushed through bmesh:
        # flushing upward selects any face whose edges are all in, and on a
        # loop that runs beside another that is most of the model - Milad's
        # crate came back solid yellow. Edges only, and their vertices,
        # because an edge with unselected ends does not draw as selected.
        me = obj.data
        me.polygons.foreach_set("select", [False] * len(me.polygons))
        flags = [False] * len(me.edges)
        vsel = [False] * len(me.vertices)
        for i in keep:
            flags[i] = True
            for vi in me.edges[i].vertices:
                vsel[vi] = True
        me.edges.foreach_set("select", flags)
        me.vertices.foreach_set("select", vsel)
        me.update()

        bpy.ops.object.mode_set(mode="EDIT")
        context.tool_settings.mesh_select_mode = (False, True, False)
        names = "".join(n for n, on in zip("XYZ", axes) if on)
        what = "loops" if st.pz_sel_whole_loops else "edges"
        st.build_info = (f"{picked} {what} selected on {names}  |  "
                         f"{edges} edges")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_relax_poles(Operator):
    """Walk the poles off the sharp edges onto flatter ground."""

    bl_idname = "mesh.quadremesh_relax_poles"
    bl_label = "Tidy Poles"
    bl_description = ("Move the vertices that do not have four edges away "
                      "from the creases and into the flat, by rotating the "
                      "edges around them. Nothing moves in space and the "
                      "number of poles never goes up - they cannot be got "
                      "rid of, a closed surface always needs some, but they "
                      "do not have to sit on the edges where they show")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        from .core import poles as PL

        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        keep = bpy.data.meshes.get(obj.get(PZ_VAL_KEY) or "")
        if keep is not None and keep.users <= 1:
            keep.use_fake_user = False
            bpy.data.meshes.remove(keep)
        snap = obj.data.copy()
        snap.name = obj.data.name + "_prevalence"
        snap.use_fake_user = True
        obj[PZ_VAL_KEY] = snap.name

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        PZ.tag_marked(bm, keep_seams=st.pz_keep_seams,
                      uv_layers=list(bm.loops.layers.uv.values()),
                      use_selection=False)
        was = PL.survey(bm)
        moved, secs = PL.relax_poles(bm, rounds=st.pz_pole_rounds,
                                     budget=st.pz_pole_budget,
                                     keep_marked=st.pz_keep_marked)
        now = PL.survey(bm)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        st.build_info = (
            f"{moved} edges rotated in {secs:.1f}s  |  poles "
            f"{was['poles']} -> {now['poles']}, on creases "
            f"{was['on_edges']} -> {now['on_edges']}, middle bend "
            f"{was['median_bend']:.0f} -> {now['median_bend']:.0f} degrees")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_use_this_mesh(Operator):
    """Read this object's own mesh, not the one it was built from."""

    bl_idname = "mesh.quadremesh_use_this_mesh"
    bl_label = "Use This Mesh"
    bl_description = ("Work from what is on screen. With Replace Original on "
                      "the add-on keeps reading the mesh the result was built "
                      "from, and a piece pulled out of a result carries that "
                      "link with it - so remeshing the piece would rebuild "
                      "the whole model instead")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(ORIG_KEY))

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        if obj.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
        name = obj.get(ORIG_KEY)
        obj.pop(ORIG_KEY, None)
        # Let go of the mesh we were holding open, unless another object is
        # still reading it - a piece separated out of a result leaves the
        # object it came from still pointing at the same original.
        held = bpy.data.meshes.get(name or "")
        if held is not None and held is not obj.data:
            if not any(o.type == "MESH" and o.get(ORIG_KEY) == name
                       for o in bpy.data.objects):
                held.use_fake_user = False
                if held.users == 0:
                    bpy.data.meshes.remove(held)
        forget_cache(obj)
        st.source = ""
        st.result = ""
        st.build_info = ("reading this mesh now - %d faces"
                         % len(obj.data.polygons))
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_subdiv_cage(Operator):
    """Build a subdivision cage over this model."""

    bl_idname = "mesh.quadremesh_subdiv_cage"
    bl_label = "Build Subdiv Cage"
    bl_description = ("Build a small all-quad cage over this model, sit it on "
                      "the surface, crease the model's own hard edges into it "
                      "and put a Subdivision Surface on top")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH"
                and len(o.data.polygons) > 8 and o.mode == "OBJECT")

    def execute(self, context):
        from mathutils.bvhtree import BVHTree
        from mathutils.kdtree import KDTree
        from mathutils import Vector
        import time

        st = context.scene.quadremesh_lines
        src = context.active_object
        t0 = time.time()

        # -- the cage, box modelled the way the tutorial does it --------------
        #
        # Not a remesh. The tutorial starts from a cube, cuts it down onto the
        # reference and pulls it into shape, so that is what this does: a cube
        # over the model's own bounding box, cut into a grid, and pulled onto
        # the surface. Box topology all the way through, every face a quad,
        # and nothing in it that a hand could not have placed.
        want = max(20, int(st.cage_faces))
        cuts = 1
        while 6 * (cuts + 1) ** 2 < want and cuts < 64:
            cuts += 1

        bb = [Vector(c) for c in src.bound_box]
        lo = Vector((min(v.x for v in bb), min(v.y for v in bb),
                     min(v.z for v in bb)))
        hi = Vector((max(v.x for v in bb), max(v.y for v in bb),
                     max(v.z for v in bb)))
        mid = (lo + hi) * 0.5
        size = hi - lo

        bm = bmesh.new()
        bmesh.ops.create_cube(bm, size=1.0)
        for v in bm.verts:
            v.co.x = mid.x + v.co.x * size.x * 1.02
            v.co.y = mid.y + v.co.y * size.y * 1.02
            v.co.z = mid.z + v.co.z * size.z * 1.02
        bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=cuts,
                                  use_grid_fill=True)
        cme = bpy.data.meshes.new(src.name + "_Cage")
        bm.to_mesh(cme)
        bm.free()
        cage = bpy.data.objects.new(src.name + "_Cage", cme)
        context.collection.objects.link(cage)
        cage.matrix_world = src.matrix_world
        context.view_layer.objects.active = cage
        for o in context.selected_objects:
            o.select_set(False)
        cage.select_set(True)

        # -- pulled onto the surface, then evened out and pulled again --------
        #
        # One shrinkwrap leaves the grid stretched where the box corners were.
        # A relax between two wraps is what a modeller does by hand when they
        # slide the loops around after snapping them down.
        for i in range(3):
            wrap = cage.modifiers.new("fit", "SHRINKWRAP")
            wrap.target = src
            wrap.wrap_method = "NEAREST_SURFACEPOINT"
            bpy.ops.object.modifier_apply(modifier=wrap.name)
            if i < 2:
                sm = cage.modifiers.new("even", "SMOOTH")
                sm.factor = 0.5
                sm.iterations = 4
                bpy.ops.object.modifier_apply(modifier=sm.name)

        # -- the model's own hard edges, creased into the cage ----------------
        me = src.data
        nv = len(me.vertices)
        co = np.empty(nv * 3)
        me.vertices.foreach_get("co", co)
        co = co.reshape(nv, 3)
        span = float(np.linalg.norm(co.max(0) - co.min(0))) or 1.0
        ne = len(me.edges)
        nl = len(me.loops)
        le = np.empty(nl, dtype=np.int32)
        me.loops.foreach_get("edge_index", le)
        lt = np.empty(len(me.polygons), dtype=np.int32)
        me.polygons.foreach_get("loop_total", lt)
        fol = np.repeat(np.arange(len(me.polygons), dtype=np.int32), lt)
        order = np.argsort(le, kind="stable")
        se, sf = le[order], fol[order]
        cnt = np.bincount(se, minlength=ne)
        start = np.searchsorted(se, np.arange(ne))
        shared = np.flatnonzero(cnt == 2)
        nrm = np.empty(len(me.polygons) * 3)
        me.polygons.foreach_get("normal", nrm)
        nrm = nrm.reshape(-1, 3)
        f1 = sf[start[shared]]
        f2 = sf[start[shared] + 1]
        ang = np.degrees(np.arccos(np.clip(
            np.einsum("ij,ij->i", nrm[f1], nrm[f2]), -1.0, 1.0)))
        hard = shared[ang >= float(st.cage_crease)]
        ev = np.empty(ne * 2, dtype=np.int32)
        me.edges.foreach_get("vertices", ev)
        ev = ev.reshape(ne, 2)

        creased = 0
        if len(hard):
            tree = KDTree(len(hard))
            mids = (co[ev[hard, 0]] + co[ev[hard, 1]]) * 0.5
            for i, m in enumerate(mids.tolist()):
                tree.insert(m, i)
            tree.balance()
            tol = span * 0.01

            cme = cage.data
            cme.edges.foreach_set("use_edge_sharp",
                                  np.zeros(len(cme.edges), dtype=bool))
            cnv = len(cme.vertices)
            cco = np.empty(cnv * 3)
            cme.vertices.foreach_get("co", cco)
            cco = cco.reshape(cnv, 3)
            cev = np.empty(len(cme.edges) * 2, dtype=np.int32)
            cme.edges.foreach_get("vertices", cev)
            cev = cev.reshape(-1, 2)
            crease = np.zeros(len(cme.edges), dtype=np.float32)
            sharp = np.zeros(len(cme.edges), dtype=bool)
            for i in range(len(cme.edges)):
                a = Vector(cco[cev[i, 0]].tolist())
                b = Vector(cco[cev[i, 1]].tolist())
                hits = 0
                for f in (0.25, 0.5, 0.75):
                    q = a.lerp(b, f)
                    _c, j, d = tree.find(q)
                    if j is None or d is None or d > tol:
                        continue
                    hits += 1
                if hits >= 2:
                    crease[i] = 1.0
                    sharp[i] = True
                    creased += 1
            if creased:
                if not cme.edge_creases:
                    cme.edge_creases_ensure()
                cme.edge_creases.data.foreach_set("value", crease)
                cme.edges.foreach_set("use_edge_sharp", sharp)
                cme.update()

        # -- and the subdivision it was built for -----------------------------
        sub = cage.modifiers.new("Subdivision", "SUBSURF")
        sub.levels = int(st.cage_levels)
        sub.render_levels = int(st.cage_levels)
        sub.show_only_control_edges = True

        # -- how close it lands ----------------------------------------------
        dg = context.evaluated_depsgraph_get()
        ev_obj = cage.evaluated_get(dg)
        fine = ev_obj.to_mesh()
        bvh = BVHTree.FromPolygons([v.co[:] for v in me.vertices],
                                   [pg.vertices[:] for pg in me.polygons])
        n = len(fine.vertices)
        step = max(1, n // 4000)
        gaps = []
        for i in range(0, n, step):
            hit = bvh.find_nearest(fine.vertices[i].co)
            if hit and hit[0] is not None:
                gaps.append((fine.vertices[i].co - hit[0]).length)
        ev_obj.to_mesh_clear()
        off = (100.0 * float(np.median(gaps)) / span) if gaps else 0.0

        st.build_info = ("cage %d faces  |  %d edges creased  |  subdivided it "
                         "sits %.2f%% of the model away  |  %.1fs"
                         % (len(cage.data.polygons), creased, off,
                            time.time() - t0))
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_flatten_fans(Operator):
    """Take every flat area out as one face and put it back clean."""

    bl_idname = "mesh.quadremesh_flatten_fans"
    bl_label = "Rebuild Flat Areas"
    bl_description = ("Find the areas that are flat, dissolve everything "
                      "inside them - fans, diagonals, the points sitting on "
                      "them - and leave one clean face per area")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons) > 2

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        keep = bpy.data.meshes.get(obj.get(PZ_FLAT_KEY) or "")
        if keep is not None and keep.users <= 1:
            keep.use_fake_user = False
            bpy.data.meshes.remove(keep)
        snap = obj.data.copy()
        snap.name = obj.data.name + "_preflat"
        snap.use_fake_user = True
        obj[PZ_FLAT_KEY] = snap.name

        limit = math.cos(math.radians(max(0.01, float(st.flat_fan_angle))))
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        before_f = len(bm.faces)
        before_v = len(bm.verts)

        # Lines the user asked to keep. A flat area may not be dissolved
        # across one of these, so a line drawn on a flat panel survives
        # instead of vanishing with the fan around it. The selection is read
        # the same way the rest of the add-on reads it: a mesh that arrives
        # with everything selected is not a choice anyone made.
        total = len(bm.edges)
        picked = sum(1 for e in bm.edges if e.select)
        read_sel = total == 0 or picked < total * 0.95
        keep_marked = bool(st.flat_keep_marked)

        def marked(e):
            if not keep_marked:
                return False
            return (not e.smooth) or e.seam or (read_sel and e.select)

        held = sum(1 for e in bm.edges if marked(e))

        # Which faces belong to the same flat area.
        #
        # Comparing a face with the neighbour it happens to touch is wrong,
        # and wrong in a way that gets worse as the setting is raised: each
        # step is allowed its own few degrees, so a curved surface chains
        # itself together one small step at a time. At 30 degrees the whole
        # shell came out as a single "flat" area, the dissolve refused it, and
        # the button did less than it did at 5 - 6 areas against 164. So each
        # area is grown from a seed and every face in it is measured against
        # the seed's own plane: both how it faces and how far off the plane it
        # sits. Raising the setting can then only ever sweep up more.
        span = max((bm.verts[i].co - bm.verts[0].co).length
                   for i in range(0, len(bm.verts),
                                  max(1, len(bm.verts) // 64))) or 1.0
        off_tol = span * 0.01
        seen = [False] * len(bm.faces)
        groups = {}
        for seed in bm.faces:
            if seen[seed.index]:
                continue
            n0 = seed.normal.copy()
            c0 = seed.calc_center_median()
            seen[seed.index] = True
            group = [seed]
            stack = [seed]
            while stack:
                f = stack.pop()
                for e in f.edges:
                    if marked(e):
                        continue         # a line the user wants kept
                    for g in e.link_faces:
                        if g is f or seen[g.index]:
                            continue
                        if g.normal.dot(n0) < limit:
                            continue
                        if abs((g.calc_center_median() - c0).dot(n0)) > off_tol:
                            continue
                        seen[g.index] = True
                        group.append(g)
                        stack.append(g)
            groups[seed.index] = group

        areas = 0
        refused = 0
        for faces in groups.values():
            if len(faces) < 2:
                continue
            try:
                bmesh.ops.dissolve_faces(bm, faces=faces, use_verts=True)
            except Exception:
                refused += 1
                continue
            areas += 1
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        # The points left along the border of an area, where two of its edges
        # carry straight on. Nothing is holding them any more, so they go too.
        straight = []
        for v in bm.verts:
            if len(v.link_edges) != 2:
                continue
            if any(marked(e) for e in v.link_edges):
                continue                 # it holds up a line that was kept
            a = v.link_edges[0].other_vert(v).co - v.co
            b = v.link_edges[1].other_vert(v).co - v.co
            if a.length < 1e-12 or b.length < 1e-12:
                continue
            if a.angle(b) >= math.radians(179.0):
                straight.append(v)
        if straight:
            bmesh.ops.dissolve_verts(bm, verts=straight)

        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        gone_f = before_f - len(obj.data.polygons)
        gone_v = before_v - len(obj.data.vertices)
        st.build_info = ("%d flat areas rebuilt  |  %d faces and %d points "
                         "gone  |  %d marked lines kept%s"
                         % (areas, gone_f, gone_v, held,
                            "  |  %d refused" % refused if refused else ""))
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_flatten_fans_undo(Operator):
    """Put the mesh back the way it was before Rebuild Flat Areas."""

    bl_idname = "mesh.quadremesh_flatten_fans_undo"
    bl_label = "Undo Rebuild Flat Areas"
    bl_description = "Restore the mesh as it was before the last rebuild"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_FLAT_KEY))

    def execute(self, context):
        obj = context.active_object
        base = bpy.data.meshes.get(obj.get(PZ_FLAT_KEY) or "")
        if base is None:
            obj.pop(PZ_FLAT_KEY, None)
            self.report({"WARNING"}, "nothing stored to go back to")
            return {"CANCELLED"}
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        bm = bmesh.new()
        bm.from_mesh(base)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        obj.pop(PZ_FLAT_KEY, None)
        base.use_fake_user = False
        if base.users == 0:
            bpy.data.meshes.remove(base)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        self.report({"INFO"}, "put back")
        return {"FINISHED"}


class QUADREMESH_OT_min_valence_undo(Operator):
    """Put the mesh back the way it was before At Least 3 Edges ran."""

    bl_idname = "mesh.quadremesh_min_valence_undo"
    bl_label = "Undo At Least 3 Edges"
    bl_description = ("Restore the mesh as it was before the last At Least 3 "
                      "Edges. Only the last one is kept")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_VAL_KEY))

    def execute(self, context):
        st = context.scene.quadremesh_lines
        obj = context.active_object
        base = bpy.data.meshes.get(obj.get(PZ_VAL_KEY) or "")
        if base is None:
            obj.pop(PZ_VAL_KEY, None)
            self.report({"WARNING"}, "nothing stored to go back to")
            return {"CANCELLED"}
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")
        before = len(obj.data.vertices)
        bm = bmesh.new()
        bm.from_mesh(base)
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        obj.pop(PZ_VAL_KEY, None)
        base.use_fake_user = False
        if base.users == 0:
            bpy.data.meshes.remove(base)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        st.build_info = (f"valence undone  |  {before} -> "
                         f"{len(obj.data.vertices)} verts")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


# Every mesh this object keeps a copy of. They all live in the object's own
# space, so a turn applied to the object has to be applied to them too.
# Otherwise Drop Useless Loops - which rebuilds from its snapshot on every
# nudge of the slider - writes an untouched mesh back under a turned object,
# and the model jumps. That is what "press Axes Along Model, then tick one
# of X Y Z" showed: nothing out of place before, 0.2 of a unit after.
SNAPSHOT_KEYS = ("quadremesh_drop_orig", "quadremesh_drop_first",
                 "quadremesh_clean_orig", "quadremesh_clean_base",
                 "quadremesh_valence_orig", "quadremesh_orig_mesh")


def turn_snapshots(obj, step):
    """Apply the 4x4 `step` to every mesh `obj` has stored away."""
    done = 0
    seen = set()
    for key in SNAPSHOT_KEYS:
        me = bpy.data.meshes.get(obj.get(key) or "")
        if me is None or me.name in seen or me is obj.data:
            continue
        seen.add(me.name)
        n = len(me.vertices)
        if not n:
            continue
        co = np.empty(n * 3, dtype=np.float64)
        me.vertices.foreach_get("co", co)
        co = co.reshape(n, 3)
        me.vertices.foreach_set(
            "co", (co @ step[:3, :3].T + step[:3, 3]).reshape(-1))
        me.update()
        done += 1
    return done


class QUADREMESH_OT_align_axes(Operator):
    """Turn the object's own X, Y and Z to follow the model.

    Every axis tool in this panel works in the object's local space - the
    Only Axis buttons, the loop count table, the gizmo. On a beam lying
    diagonally across the world that space means nothing: the loops running
    the length of it are split between X and Y, and picking one of the three
    removes half of what you meant and half of something else.

    The three directions the model itself is built along are found from the
    spread of its own vertices, longest first, and the object is turned so
    that those become X, Y and Z. The mesh is turned the other way by the
    same amount, so nothing moves on screen - only the frame the tools
    measure in.
    """

    bl_idname = "mesh.quadremesh_align_axes"
    bl_label = "Axes Along Model"
    bl_description = ("Turn this object's local X, Y and Z to follow the "
                      "model's own directions, longest first, without moving "
                      "it. The Only Axis buttons and the gizmo then mean "
                      "what you see")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.vertices) >= 4

    def execute(self, context):
        from mathutils import Matrix

        st = context.scene.quadremesh_lines
        obj = context.active_object
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        me = obj.data
        n = len(me.vertices)
        co = np.empty(n * 3, dtype=np.float64)
        me.vertices.foreach_get("co", co)
        co = co.reshape(n, 3)
        mid = co.mean(axis=0)
        # The directions the shape actually runs along: the eigenvectors of
        # its own spread, which is what "the length of it" means for a shape
        # that is not a box.
        cov = np.cov((co - mid).T)
        if not np.isfinite(cov).all():
            self.report({"WARNING"}, "the mesh has no usable spread")
            return {"CANCELLED"}
        vals, vecs = np.linalg.eigh(cov)
        order = np.argsort(vals)[::-1]          # longest first
        R = vecs[:, order]
        if np.linalg.det(R) < 0:                # keep it right-handed
            R[:, 2] *= -1.0
        # Each axis is pointed the way the model leans, so the arrow does not
        # come out backwards on a shape that is longer one way than the other.
        for k in range(3):
            if float(np.dot((co - mid) @ R[:, k], np.abs((co - mid) @ R[:, k]))) < 0:
                R[:, k] *= -1.0
        if np.linalg.det(R) < 0:
            R[:, 2] *= -1.0

        # What the undo needs, kept outright rather than worked back out
        # of the two matrices afterwards: deriving it came out 0.8 of a
        # unit off.
        #
        # The turn is stored as one 4x4 and composed with whatever is
        # already there, so pressing this twice can still be undone. The
        # first version kept only the first press's rotation, and undoing
        # after a second press reversed half the turn and left the model
        # standing somewhere it had never been.
        this = np.eye(4)
        this[:3, :3] = R.T
        this[:3, 3] = mid - R.T @ mid
        step = this
        prev = obj.get(PZ_AXIS_MESH)
        if prev is not None and len(prev) == 16:
            step = this @ np.array([float(x) for x in prev]).reshape(4, 4)
        else:
            obj[PZ_AXIS_KEY] = [float(x) for x in
                                np.array(obj.matrix_world).reshape(-1)]
        obj[PZ_AXIS_MESH] = [float(x) for x in step.reshape(-1)]
        # the stored copies are in the frame this press starts from, so
        # they take this one turn, not the accumulated one
        turned = turn_snapshots(obj, this)

        # The mesh turns one way...
        me.vertices.foreach_set("co", ((co - mid) @ R + mid).reshape(-1))
        me.update()
        rot = Matrix.Identity(4)
        for r in range(3):
            for c in range(3):
                rot[r][c] = float(R[r, c])
        # ...and the object turns the other, so nothing moves on screen.
        # The mesh now holds R-transpose times the old coordinates, so
        # the object has to carry R itself. Its inverse, which is what
        # this first did, slid the model 0.8 of a unit off where it stood.
        obj.matrix_world = (obj.matrix_world
                            @ Matrix.Translation(Vector(mid))
                            @ rot
                            @ Matrix.Translation(-Vector(mid)))

        # so the change is visible the moment it is pressed
        try:
            context.scene.transform_orientation_slots[0].type = "LOCAL"
        except Exception:
            pass
        forget_cache(obj)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")

        ext = np.sqrt(np.maximum(vals[order], 0.0)) * 2.0
        st.build_info = ("axes along the model  |  spread X %.3f  Y %.3f  "
                         "Z %.3f" % (ext[0], ext[1], ext[2]))
        if turned:
            st.build_info += "  |  %d stored copies turned too" % turned
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_OT_align_axes_undo(Operator):
    """Put the object's axes back where they were."""

    bl_idname = "mesh.quadremesh_align_axes_undo"
    bl_label = "Axes Back"
    bl_description = "Put this object's local axes back the way they were"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and bool(o.get(PZ_AXIS_KEY))

    def execute(self, context):
        from mathutils import Matrix

        st = context.scene.quadremesh_lines
        obj = context.active_object
        stored = obj.get(PZ_AXIS_KEY)
        if not stored or len(stored) != 16:
            obj.pop(PZ_AXIS_KEY, None)
            self.report({"WARNING"}, "nothing stored to go back to")
            return {"CANCELLED"}
        editing = obj.mode == "EDIT"
        if editing:
            bpy.ops.object.mode_set(mode="OBJECT")

        old = Matrix([[float(stored[r * 4 + c]) for c in range(4)]
                      for r in range(4)])
        step = obj.get(PZ_AXIS_MESH)
        if step is None or len(step) != 16:
            obj.pop(PZ_AXIS_KEY, None)
            self.report({"WARNING"}, "the stored frame is incomplete")
            return {"CANCELLED"}
        back = np.linalg.inv(np.array([float(x) for x in step])
                             .reshape(4, 4))
        me = obj.data
        n = len(me.vertices)
        co = np.empty(n * 3, dtype=np.float64)
        me.vertices.foreach_get("co", co)
        co = co.reshape(n, 3)
        # every turn that was applied, however many, run backwards at once
        out = co @ back[:3, :3].T + back[:3, 3]
        me.vertices.foreach_set("co", out.reshape(-1))
        me.update()
        turn_snapshots(obj, back)
        obj.matrix_world = old
        for key in (PZ_AXIS_KEY, PZ_AXIS_MESH):
            obj.pop(key, None)
        forget_cache(obj)
        if editing:
            bpy.ops.object.mode_set(mode="EDIT")
        st.build_info = "axes back where they were"
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class QUADREMESH_PT_lines(Panel):
    bl_label = "Smart Remesh (Hardsurface)"
    bl_idname = "QUADREMESH_PT_lines"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Remesh"
    bl_order = 20

    def draw(self, context):
        layout = self.layout
        st = context.scene.quadremesh_lines

        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator("mesh.quadremesh_panels_build",
                     text="Remesh Hardsurface",
                     icon="MESH_GRID")
        row.operator("mesh.quadremesh_restore", text="", icon="LOOP_BACK")
        row.operator("mesh.quadremesh_lines_clear", text="", icon="X")

        layout.prop(st, "hs_replace")
        row = layout.row(align=True)
        row.prop(st, "hs_mirror")
        if st.hs_mirror:
            row.prop(st, "hs_mirror_axis", text="")

        layout.separator()
        row = layout.row()
        row.operator("mesh.quadremesh_reset_all",
                     text="Reset Everything", icon="FILE_REFRESH")


        if st.source:
            layout.label(text=f"Source: {st.source}", icon="MESH_DATA")

        row = layout.row(align=True)
        row.prop(st, "preset", text="")
        row.operator("mesh.quadremesh_preset_save", text="", icon="ADD")
        row.operator("mesh.quadremesh_preset_delete", text="", icon="REMOVE")

        col = layout.column(align=True)
        col.prop(st, "auto_thresholds")
        sub = col.column(align=True)
        sub.enabled = not st.auto_thresholds
        sub.prop(st, "crease_deg")
        sub.prop(st, "flat_deg")

        layout.separator()
        col = layout.column(align=True)
        col.prop(st, "weld_close")
        col.prop(st, "dissolve_straight")
        col.prop(st, "refit_circles")
        col.prop(st, "min_chain")
        col.prop(st, "use_type")
        col.prop(st, "close_gaps")
        sub = col.row()
        sub.enabled = st.close_gaps
        sub.prop(st, "gap_span")
        col.operator("mesh.quadremesh_fill_gaps", icon="MOD_TRIANGULATE")
        col.operator("mesh.quadremesh_join_points", icon="EYEDROPPER")

        layout.separator()
        box = fold_head(layout, st, "show_cleanup", "Smart Cleanup",
                        "EDGESEL")
        col = box.column(align=True)
        col.prop(st, "hs_use_marked")
        col.prop(st, "hs_only_marked")
        col.separator()
        r = col.row()
        r.scale_y = 1.3
        r.operator("mesh.quadremesh_clean_between", icon="MOD_DECIM")
        r.operator("mesh.quadremesh_clean_confirm", text="", icon="CHECKMARK")
        r.operator("mesh.quadremesh_clean_reset", text="", icon="LOOP_BACK")
        col.prop(st, "pz_amount", slider=True)
        col.prop(st, "pz_confine")
        col.operator("mesh.quadremesh_clean_revert_all",
                     text="Revert All Cleaning", icon="TRASH")
        col.label(text="or press Remesh Hardsurface above")
        col.separator()
        # The operator has been here since the panel builds went in, but it
        # was never drawn - the only way to reach it was the search menu.
        rv = col.row(align=True)
        rv.operator("mesh.quadremesh_min_valence", text="3 Edges",
                    icon="VERTEXSEL")
        rv.operator("mesh.quadremesh_min_valence_undo", text="",
                    icon="LOOP_BACK")

        layout.separator()
        box = fold_head(layout, st, "show_uv", "UV", "UV")
        box.prop(st, "uv_keep_islands")
        box.prop(st, "uv_show_seams")
        box.prop(st, "uv_seams_sharp")
        box.separator()
        rbk = box.row(align=True)
        rbk.operator("mesh.quadremesh_bake_from_original", icon="RENDER_STILL")
        rbk.operator("mesh.quadremesh_unbake", text="", icon="LOOP_BACK")
        draw_bake_progress(box)
        rb = box.row(align=True)
        rb.prop(st, "bake_size", text="")
        rb.prop(st, "bake_pbr", toggle=True)
        box.prop(st, "bake_gpu")
        if st.bake_gpu and not _gpu_ready():
            box.label(text="No GPU device enabled - using the processor",
                      icon="ERROR")
        box.label(text="If the UV is stretched after a remesh, bake it.",
                  icon="INFO")


        layout.separator()
        box = fold_head(layout, st, "show_loops", "Erase Useless Loops",
                        "MOD_DECIM")
        sub = box.column(align=True)
        r4 = sub.row(align=True)
        r4.operator("mesh.quadremesh_drop_useless", icon="MOD_DECIM")
        r4.operator("mesh.quadremesh_drop_confirm", text="", icon="CHECKMARK")
        r4.operator("mesh.quadremesh_drop_reset", text="", icon="LOOP_BACK")
        sub.operator("mesh.quadremesh_drop_original", icon="FILE_REFRESH")

        r3 = sub.row(align=True)
        r3.prop(st, "pz_useless")
        r3.prop(st, "pz_keep_marked", toggle=True)
        tgt_uv = context.active_object
        if (tgt_uv is not None and tgt_uv.type == "MESH"
                and tgt_uv.data.uv_layers):
            sub.prop(st, "pz_keep_seams")
        sub.prop(st, "pz_every")
        ra = sub.row(align=True)
        ra.operator("mesh.quadremesh_align_axes", icon="ORIENTATION_LOCAL")
        ra.operator("mesh.quadremesh_align_axes_undo", text="",
                    icon="LOOP_BACK")
        r5 = sub.row(align=True)
        r5.label(text="Only Axis")
        r5.prop(st, "pz_axis_x", toggle=True)
        r5.prop(st, "pz_axis_y", toggle=True)
        r5.prop(st, "pz_axis_z", toggle=True)
        rsel = sub.row(align=True)
        rsel.operator("mesh.quadremesh_select_axis_loops",
                      icon="EDGESEL")
        rsel.prop(st, "pz_sel_whole_loops", toggle=True)
        # How many loops each axis actually owns. Without it the three
        # buttons are a guess: on a twisted model one axis can hold sixty
        # loops and another four, and there is no way to tell by looking.
        tgt = context.active_object
        if tgt is not None and tgt.type == "MESH" and len(tgt.data.polygons):
            counts = axis_loop_counts(tgt)
            r6 = sub.row(align=True)
            r6.operator("mesh.quadremesh_count_loops", text="Loops",
                        icon="QUESTION", emboss=False)
            if counts is None:
                r6.operator("mesh.quadremesh_count_loops", text="Count")
            else:
                for n in counts[:3]:
                    r6.label(text=str(n))
                sub.label(text=f"{counts[3]} loops"
                               + (f", {counts[4]} do not close"
                                  if counts[4] else ""),
                          icon="INFO")

        layout.separator()
        box = fold_head(layout, st, "show_chamfer", "Chamfer",
                        "MOD_BEVEL")
        box.prop(st, "planar_tol")
        box.prop(st, "straighten")
        box.prop(st, "chamfer")
        sub = box.column(align=True)
        sub.enabled = st.chamfer > 0.0
        sub.prop(st, "chamfer_segments")
        if st.chamfer > 0.0 and st.chamfer_segments % 2:
            sub.label(text="odd count leaves corner triangles", icon="ERROR")
        sub.prop(st, "chamfer_profile")
        sub.prop(st, "chamfer_clamp")



CLASSES = (QuadRemeshLines, QUADREMESH_OT_fill_gaps,
           QUADREMESH_OT_join_points,
           QUADREMESH_OT_lines_preview,
           QUADREMESH_OT_panelize_mark, QUADREMESH_OT_clean_between, QUADREMESH_OT_clean_reset, QUADREMESH_OT_clean_confirm, QUADREMESH_OT_drop_useless, QUADREMESH_OT_count_loops, QUADREMESH_OT_bake_esc, QUADREMESH_OT_bake_from_original, QUADREMESH_OT_unbake, QUADREMESH_OT_force_loop, QUADREMESH_OT_drop_original, QUADREMESH_OT_drop_confirm, QUADREMESH_OT_drop_reset, QUADREMESH_OT_subdiv_cage, QUADREMESH_OT_use_this_mesh, QUADREMESH_OT_flatten_fans, QUADREMESH_OT_flatten_fans_undo, QUADREMESH_OT_min_valence, QUADREMESH_OT_min_valence4, QUADREMESH_OT_sweep_flat, QUADREMESH_OT_relax_poles, QUADREMESH_OT_absorb_small, QUADREMESH_OT_weld, QUADREMESH_OT_select_axis_loops, QUADREMESH_OT_min_valence_undo, QUADREMESH_OT_align_axes, QUADREMESH_OT_align_axes_undo, QUADREMESH_OT_clean_revert_all,
           QUADREMESH_OT_panels_preview, QUADREMESH_OT_panels_build,
           QUADREMESH_OT_lines_clear, QUADREMESH_OT_tris_to_quads, QUADREMESH_OT_preset_save,
           QUADREMESH_OT_preset_delete)


def register():
    load_user_presets()
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.quadremesh_lines = bpy.props.PointerProperty(
        type=QuadRemeshLines)


def unregister():
    # Unregistering must not raise. A half-finished earlier attempt, a reload
    # during an upgrade, or Blender tearing things down in its own order all
    # leave pieces already gone, and one exception here aborts the rest -
    # leaving classes registered that can never be registered again without a
    # restart.
    if hasattr(bpy.types.Scene, "quadremesh_lines"):
        del bpy.types.Scene.quadremesh_lines
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
    _CACHE.clear()
