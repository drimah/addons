# Remesh Ultimate - smart one-click quad remesher for Blender
# Pure Python, no external binaries: works the same on Windows and Linux.
# License: GPL-3.0-or-later

bl_info = {
    "name": "Remesh Ultimate",
    "author": "Drimah",
    "version": (1, 6, 8),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Remesh Ultimate",
    "description": "One-click smart quad remesher: auto-repair, turbo pre-pass, "
                   "best-of-N QuadriFlow, surface-locked relax, exact symmetry, quality report",
    "category": "Mesh",
}

import bpy
import bmesh
import os
import math
import re
import time
import heapq
import shutil
import numpy as np
from mathutils import Vector, Matrix, Color
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy.props import (IntProperty, FloatProperty, BoolProperty,
                       EnumProperty, PointerProperty, StringProperty)
from bpy.types import Operator, Panel, PropertyGroup, AddonPreferences

ADDON_ID = __package__ or __name__
VERSION_STR = ".".join(str(v) for v in bl_info["version"])
TEMP_COLL = "RU_TEMP_WORK"
RESULT_SUFFIX = "_RU"


# --------------------------------------------------------------------------
#  Presets
# --------------------------------------------------------------------------
PRESETS = {
    'FAST':     dict(target_faces=800, tries=1, relax_iterations=3,
                     sharp_mode='AUTO', turbo=True),
    'BALANCED': dict(target_faces=2000, tries=2, relax_iterations=5,
                     sharp_mode='AUTO', turbo=True),
    'QUALITY':  dict(target_faces=3500, tries=4, relax_iterations=8,
                     sharp_mode='AUTO', turbo=True),
    'HARD':     dict(target_faces=2500, tries=3, relax_iterations=4,
                     sharp_mode='ON', turbo=True),
    'ORGANIC':  dict(target_faces=3000, tries=2, relax_iterations=10,
                     sharp_mode='OFF', turbo=True),
}


def _apply_preset(self, context):
    p = PRESETS.get(self.preset)
    if not p:
        return
    for k, v in p.items():
        setattr(self, k, v)


class RU_Settings(PropertyGroup):
    preset: EnumProperty(
        name="Preset",
        items=[('FAST', "Fast", "Quick low-poly result"),
               ('BALANCED', "Balanced", "Good default for most models"),
               ('QUALITY', "Quality", "Best of 3 solutions, strong relax"),
               ('HARD', "Hard Surface", "Keeps sharp edges and corners"),
               ('ORGANIC', "Organic", "Sculpts, characters, creatures")],
        default='BALANCED', update=_apply_preset)
    quad_size: EnumProperty(
        name="Quad Size",
        items=[('S', "Small", "Dense: lots of small quads (edge = 1/100 of the model size)"),
               ('SM', "Small-Medium", "Edge = 1/70 of the model size"),
               ('M', "Medium", "Balanced density (edge = 1/50 of the model size)"),
               ('ML', "Medium-Large", "Edge = 1/35 of the model size"),
               ('L', "Large", "Light: big quads (edge = 1/25 of the model size)"),
               ('CUSTOM', "Custom", "Type the number of quads yourself")],
        default='M')
    target_faces: IntProperty(name="Target Quads", default=2000, min=50, max=300000,
                              soft_min=200, soft_max=50000,
                              description="Approximate number of quads in the result")
    symmetry: EnumProperty(
        name="Symmetry",
        items=[('NONE', "Off", ""), ('AUTO', "Auto", "Detect mirror symmetry automatically"),
               ('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")],
        default='AUTO')
    sharp_mode: EnumProperty(
        name="Sharp Edges",
        items=[('AUTO', "Auto", "Detect hard-surface parts and lock their creases and corners"),
               ('ON', "Keep", "Always lock creases and corners"),
               ('OFF', "Soft", "Organic: let quads flow freely")],
        default='AUTO')
    sharp_angle: FloatProperty(name="Sharp Angle", default=math.radians(30.0),
                               min=math.radians(5), max=math.radians(120), subtype='ANGLE')
    preserve_boundary: BoolProperty(name="Keep Open Borders", default=True)
    clean_mode: EnumProperty(
        name="Parts",
        items=[('AUTO', "Smart Parts", "Remesh every separate part on its own, repair broken "
                                       "parts locally, mirror twin parts, never lose a part"),
               ('VOXEL', "Merge Parts", "Fuse everything into one watertight shell (voxel)"),
               ('NONE', "Single Mesh", "Treat the whole object as one surface")],
        default='AUTO')
    turbo: BoolProperty(name="Turbo Pre-Pass", default=True,
                        description="Simplify dense meshes before solving (much faster, "
                                    "accuracy is restored by projecting onto the original)")
    tries: IntProperty(name="Best of N", default=1, min=1, max=8,
                       description="Solve with N different seeds and keep the best scored result")
    relax_iterations: IntProperty(name="Relax", default=4, min=0, max=50,
                                  description="Surface-locked relax iterations (evens out quads)")
    relax_strength: FloatProperty(name="Relax Strength", default=0.5, min=0.0, max=1.0)
    project: BoolProperty(name="Project to Surface", default=True)
    add_shrinkwrap: BoolProperty(name="Add Shrinkwrap", default=False,
                                 description="Keep a live Shrinkwrap modifier to the original")
    hide_original: BoolProperty(name="Hide Original", default=True)
    seed: IntProperty(name="Seed", default=0, min=0, max=9999)
    method: EnumProperty(
        name="Method",
        items=[('AUTO', "Smart", "Per part: keep exact shape on clean low-poly / hard-surface "
                                 "parts, rebuild dense or organic parts"),
               ('REMESH', "Rebuild", "Always rebuild the topology from scratch"),
               ('QUADIFY', "Keep Shape", "Never rebuild: convert the existing mesh to quads")],
        default='AUTO')
    pure_quads: BoolProperty(name="100% Quads", default=False,
                             description="Kept-shape parts get one flat subdivision so not a single "
                                         "triangle remains (4x the faces there)")
    area_count: IntProperty(name="Max Areas", default=24, min=2, max=400,
                            description="Upper limit for Detect Areas on the surfaces. Separate pieces "
                                        "are always their own area on top of this. Borders only go "
                                        "where the shape really changes, so a simple model gets fewer")
    use_guides: BoolProperty(name="Follow Areas & Lines", default=True,
                             description="Make the quad flow follow area borders and drawn lines")
    color_parts: BoolProperty(name="Color Parts", default=True,
                              description="Give every part its own coloured material, visible in "
                                          "Solid, Material Preview and Rendered")
    separate_parts: BoolProperty(name="Separate Parts", default=False,
                                 description="Optional: REMESH delivers one coloured object per area, "
                                             "inside a sub-collection (seams match exactly). "
                                             "Off = one continuous mesh, areas by material")
    isolated: BoolProperty(name="Safe Parallel Solver", default=True,
                           description="Solve in separate background processes on several CPU "
                                       "cores, with a time limit: a solver hang can never freeze Blender")
    last_report: StringProperty(default="")


# --------------------------------------------------------------------------
#  Helpers
# --------------------------------------------------------------------------
def _status(context, text):
    try:
        if text:
            context.workspace.status_text_set(text)
        else:
            context.workspace.status_text_set(None)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    except Exception:
        pass


def _temp_collection(context):
    coll = bpy.data.collections.get(TEMP_COLL)
    if coll is None:
        coll = bpy.data.collections.new(TEMP_COLL)
    if coll.name not in context.scene.collection.children:
        context.scene.collection.children.link(coll)
    return coll


def _cleanup_temp(context):
    coll = bpy.data.collections.get(TEMP_COLL)
    if coll is None:
        return
    for ob in list(coll.objects):
        me = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if me and me.users == 0:
            bpy.data.meshes.remove(me)
    bpy.data.collections.remove(coll)


def _new_temp_object(context, mesh, name="RU_tmp"):
    ob = bpy.data.objects.new(name, mesh)
    _temp_collection(context).objects.link(ob)
    return ob


def _eval_modifier(context, ob, mod_type, **kw):
    """Apply one modifier through the depsgraph (no operator context needed)."""
    mod = ob.modifiers.new("RU_tmp_mod", mod_type)
    for k, v in kw.items():
        setattr(mod, k, v)
    dg = context.evaluated_depsgraph_get()
    dg.update()
    ev = ob.evaluated_get(dg)
    new_me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=False, depsgraph=dg)
    ob.modifiers.remove(mod)
    old = ob.data
    ob.data = new_me
    if old.users == 0:
        bpy.data.meshes.remove(old)
    return new_me


def _work_matrix(ob):
    """World orientation and real proportions (as 1.6.3).  X / Y / Z in the
    Symmetry menu are the axes you see in the viewport, whatever the object's
    own rotation."""
    return ob.matrix_world.to_3x3()


def _mesh_co(me):
    co = np.empty(len(me.vertices) * 3, dtype=np.float64)
    me.vertices.foreach_get("co", co)
    return co.reshape(-1, 3)


def _mesh_edges(me):
    ed = np.empty(len(me.edges) * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", ed)
    return ed.reshape(-1, 2)


def _bvh_from_mesh(me):
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    tree = BVHTree.FromBMesh(bm)
    bm.free()
    return tree


def _tri_count(me):
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    return int((lt - 2).clip(min=0).sum())


def _analyze_fast(me, merge_dist):
    """Pure numpy mesh diagnosis (fast on millions of faces)."""
    nv, ne, nl = len(me.vertices), len(me.edges), len(me.loops)
    le = np.empty(nl, dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    lv = np.empty(nl, dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    efc = np.bincount(le, minlength=ne)
    area = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", area)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    nxt = np.arange(nl, dtype=np.int64) + 1
    nxt[ls + lt - 1] = ls
    # winding check in O(n): on a consistent 2-face edge, exactly one of its
    # two loops walks the edge "forward" (low -> high vertex index)
    fwd = (lv < lv[nxt]).astype(np.float64)
    fcount = np.bincount(le, weights=fwd, minlength=ne)
    inconsistent = int(((efc == 2) & (fcount != 1.0)).sum())
    used = np.bincount(lv, minlength=nv) > 0
    co = _mesh_co(me)
    q = np.round(co / max(merge_dist, 1e-12)).astype(np.int64)
    order = np.lexsort((q[:, 2], q[:, 1], q[:, 0]))
    qs = q[order]
    dups = int(np.all(qs[1:] == qs[:-1], axis=1).sum()) if len(qs) > 1 else 0
    return dict(nonmanifold_edges=int((efc > 2).sum()), boundary_edges=int((efc == 1).sum()),
                loose=int((efc == 0).sum() + (~used).sum()), inconsistent=inconsistent,
                duplicates=dups, area=float(area.sum()), faces=len(me.polygons))


def _analyze_and_clean(me, merge_dist):
    info = _analyze_fast(me, merge_dist)
    if not (info["loose"] or info["inconsistent"] or info["duplicates"] or info["nonmanifold_edges"]):
        info["cleaned"] = False
        return info
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=merge_dist)
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges[:], dist=merge_dist)
    loose_v = [v for v in bm.verts if not v.link_faces]
    if loose_v:
        bmesh.ops.delete(bm, geom=loose_v, context='VERTS')
    loose_e = [e for e in bm.edges if not e.link_faces]
    if loose_e:
        bmesh.ops.delete(bm, geom=loose_e, context='EDGES')
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(me)
    bm.free()
    me.update()
    info = _analyze_fast(me, merge_dist)
    info["cleaned"] = True
    return info


def _detect_symmetry(co, bvh, diag):
    """Return 'X', 'Y', 'Z' or 'NONE' - mirror plane through the local origin."""
    if len(co) < 8:
        return 'NONE'
    rng = np.random.default_rng(1)
    idx = rng.choice(len(co), size=min(1500, len(co)), replace=False)
    sample = co[idx]
    tol = diag * 0.006
    best, best_ratio = 'NONE', 0.0
    for axis_i, name in enumerate("XYZ"):
        hits = 0
        for p in sample:
            q = Vector(p)
            q[axis_i] = -q[axis_i]
            loc, _n, _i, d = bvh.find_nearest(q)
            if loc is not None and d <= tol:
                hits += 1
        ratio = hits / len(sample)
        if ratio > best_ratio:
            best, best_ratio = name, ratio
    return best if best_ratio >= 0.93 else 'NONE'


def _mesh_quality(me, bvh_target, target_co, diag, target_faces):
    nf = len(me.polygons)
    nv = len(me.vertices)
    if nf == 0 or nv == 0:
        return dict(score=0.0, faces=0, quads=0, quad_pct=0.0, poles=0,
                    deviation_pct=100.0, uniformity=0.0)
    lt = np.empty(nf, dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    quads = int((lt == 4).sum())
    ed = _mesh_edges(me)
    ne = len(ed)
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    efc = np.bincount(le, minlength=ne)
    bverts = np.zeros(nv, dtype=bool)
    bverts[ed[efc == 1].ravel()] = True
    val = np.bincount(ed.ravel(), minlength=nv)
    poles = int(((val != 4) & ~bverts).sum())
    co = _mesh_co(me)
    lens = np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1)
    cv = float(lens.std() / max(lens.mean(), 1e-12))

    rng = np.random.default_rng(7)
    # result -> original
    idx = rng.choice(nv, size=min(2500, nv), replace=False)
    d1 = []
    for p in co[idx]:
        r = bvh_target.find_nearest(Vector(p))
        if r[0] is not None:
            d1.append(r[3])
    # original -> result (catches lost details)
    bvh_res = _bvh_from_mesh(me)
    idx2 = rng.choice(len(target_co), size=min(2500, len(target_co)), replace=False)
    d2 = []
    for p in target_co[idx2]:
        r = bvh_res.find_nearest(Vector(p))
        if r[0] is not None:
            d2.append(r[3])
    dev = max(float(np.mean(d1)) if d1 else 0.0, float(np.mean(d2)) if d2 else 0.0)
    dev_pct = 100.0 * dev / max(diag, 1e-12)

    quad_ratio = quads / nf
    pole_ratio = poles / nv
    s_quad = quad_ratio
    s_pole = 1.0 - min(1.0, pole_ratio * 8.0)
    s_dev = 1.0 - min(1.0, dev_pct / 1.5)
    s_uni = 1.0 - min(1.0, cv)
    score = 100.0 * (0.35 * s_quad + 0.25 * s_pole + 0.25 * s_dev + 0.15 * s_uni)
    return dict(score=round(score, 1), faces=nf, quads=quads,
                quad_pct=round(100.0 * quad_ratio, 1), poles=poles,
                deviation_pct=round(dev_pct, 3), uniformity=round(100 * s_uni, 1))


def _run_quadriflow(context, ob, s, target, seed, sym_axis, sharp=False, boundary=None):
    if boundary is None:
        boundary = s.preserve_boundary
    me = ob.data
    me.use_mirror_x = sym_axis == 'X'
    me.use_mirror_y = sym_axis == 'Y'
    me.use_mirror_z = sym_axis == 'Z'
    vl = context.view_layer
    for o in context.selected_objects:
        o.select_set(False)
    ob.hide_set(False)
    ob.select_set(True)
    vl.objects.active = ob
    before = len(me.polygons)
    try:
        with context.temp_override(object=ob, active_object=ob,
                                   selected_objects=[ob], selected_editable_objects=[ob]):
            ret = bpy.ops.object.quadriflow_remesh(
                use_mesh_symmetry=(sym_axis != 'NONE'),
                use_preserve_sharp=bool(sharp),
                use_preserve_boundary=bool(boundary),
                preserve_attributes=False,
                smooth_normals=False,
                mode='FACES',
                target_faces=int(target),
                seed=int(seed))
    except Exception as ex:
        print("[Remesh Ultimate] QuadriFlow error:", ex)
        return False
    if 'FINISHED' not in ret:
        return False
    nf = len(ob.data.polygons)
    if nf == 0:
        return False
    lt = np.empty(nf, dtype=np.int64)
    ob.data.polygons.foreach_get("loop_total", lt)
    # QuadriFlow output is pure quads; anything else means it silently gave up
    if (lt == 4).mean() < 0.9 and nf == before:
        return False
    return True


def _symmetry_pairs(co, axis_i, tol):
    kd = KDTree(len(co))
    for i, p in enumerate(co):
        kd.insert(p, i)
    kd.balance()
    center = np.where(np.abs(co[:, axis_i]) < tol)[0]
    pairs = []
    for i in np.where(co[:, axis_i] >= tol)[0]:
        q = Vector(co[i])
        q[axis_i] = -q[axis_i]
        _c, j, d = kd.find(q)
        if j is not None and d < tol * 2.0 and j != i:
            pairs.append((i, j))
    return center, np.array(pairs, dtype=np.int64).reshape(-1, 2)


def _poly_topology(me):
    lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    nxt = np.arange(len(lv), dtype=np.int64) + 1
    if len(ls):
        nxt[ls + lt - 1] = ls
    poly_of_loop = np.repeat(np.arange(len(ls), dtype=np.int64), lt)
    return lv, ls, lt, nxt, poly_of_loop


def _vertex_normals_np(co, topo):
    """Area-weighted vertex normals (Newell), fully vectorised."""
    lv, ls, lt, nxt, pol = topo
    cr = np.cross(co[lv], co[lv[nxt]])
    fn = np.add.reduceat(cr, ls, axis=0) if len(ls) else np.zeros((0, 3))
    vn = np.zeros_like(co)
    np.add.at(vn, lv, fn[pol])
    ln = np.linalg.norm(vn, axis=1)
    ln[ln == 0] = 1.0
    return vn / ln[:, None]


# --------------------------------------------------------------------------
#  Feature lines of the ORIGINAL surface (creases, borders, corners)
# --------------------------------------------------------------------------
class _Features:
    def __init__(self):
        self.crease = None      # (A, B) arrays of segments
        self.border = None
        self.kd_crease = None
        self.kd_border = None
        self.seg_crease = None
        self.seg_border = None
        self.corners = np.zeros((0, 3))
        self.hard = False
        self.count = 0


def _segments_kd(A, B, step):
    """Sample segments every `step` so a KD-tree can find the nearest segment."""
    L = np.linalg.norm(B - A, axis=1)
    n = np.maximum(1, np.ceil(L / max(step, 1e-9)).astype(np.int64))
    total = int(n.sum() + len(A))
    kd = KDTree(total)
    seg_id = np.empty(total, dtype=np.int64)
    k = 0
    for i in range(len(A)):
        a, b, m = A[i], B[i], n[i]
        for j in range(m + 1):
            t = j / m
            kd.insert(a + (b - a) * t, k)
            seg_id[k] = i
            k += 1
    kd.balance()
    return kd, seg_id


def _extract_features(me, angle, want_border, step, mode='AUTO', extra=None):
    f = _Features()
    ne = len(me.edges)
    if ne == 0 or len(me.polygons) == 0:
        return f
    co = _mesh_co(me)
    ed = _mesh_edges(me)
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    lv, ls, lt, nxt, pol = _poly_topology(me)
    fnorm = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fnorm)
    fnorm = fnorm.reshape(-1, 3)
    efc = np.bincount(le, minlength=ne)
    # the two faces of every 2-face edge
    order = np.argsort(le, kind='stable')
    le_s, pol_s = le[order], pol[order]
    starts = np.searchsorted(le_s, np.arange(ne))
    two = np.flatnonzero(efc == 2)
    f0 = pol_s[starts[two]]
    f1 = pol_s[starts[two] + 1]
    dots = np.einsum('ij,ij->i', fnorm[f0], fnorm[f1]).clip(-1.0, 1.0)
    crease_e = two[dots < math.cos(angle)]
    border_e = np.flatnonzero(efc == 1) if want_border else np.zeros(0, dtype=np.int64)

    f.count = len(crease_e)
    frac = len(crease_e) / max(ne, 1)
    # hard-surface = real crease lines, not sculpt noise
    if mode == 'ON':
        f.hard = 0 < len(crease_e) <= 60000
    elif mode == 'OFF':
        f.hard = False
    else:
        f.hard = len(crease_e) >= 8 and frac >= 0.003 and len(crease_e) <= 60000
    if not f.hard:
        crease_e = np.zeros(0, dtype=np.int64)

    feat_e = np.concatenate([crease_e, border_e])
    if len(feat_e):
        deg = np.bincount(ed[feat_e].ravel(), minlength=len(co))
        # corners: 3+ feature lines meet, or a feature line ends
        corner_v = np.flatnonzero((deg >= 3) | (deg == 1))
        f.corners = co[corner_v]
    cA = [co[ed[crease_e, 0]]] if len(crease_e) else []
    cB = [co[ed[crease_e, 1]]] if len(crease_e) else []
    if extra is not None and len(extra[0]):
        cA.append(extra[0])
        cB.append(extra[1])
        f.hard = True
        # junctions and ends of the guide network become corners
        ends = np.round(np.vstack([extra[0], extra[1]]) / max(step * 0.25, 1e-9)).astype(np.int64)
        u, inv, cnt = np.unique(ends, axis=0, return_inverse=True, return_counts=True)
        pts = np.vstack([extra[0], extra[1]])
        firsts = np.zeros(len(u), dtype=np.int64)
        firsts[inv[::-1]] = np.arange(len(inv))[::-1]
        jn = pts[firsts[(cnt >= 3) | (cnt == 1)]]
        if len(jn):
            f.corners = np.vstack([f.corners, jn]) if len(f.corners) else jn
    if cA:
        f.crease = (np.concatenate(cA), np.concatenate(cB))
        f.kd_crease, f.seg_crease = _segments_kd(*f.crease, step)
    if len(border_e):
        f.border = (co[ed[border_e, 0]], co[ed[border_e, 1]])
        f.kd_border, f.seg_border = _segments_kd(*f.border, step)
    return f


def _closest_on_segment(p, a, b):
    ab = b - a
    t = float(np.dot(p - a, ab) / max(np.dot(ab, ab), 1e-20))
    t = min(1.0, max(0.0, t))
    return a + ab * t, ab


# --------------------------------------------------------------------------
#  Fit: thin-safe projection + feature snapping + tangential relax
# --------------------------------------------------------------------------
def _fit_to_surface(me, bvh, feats, s, sym_axis, avg_edge):
    co = _mesh_co(me)
    n = len(co)
    if n == 0:
        return
    topo = _poly_topology(me)
    ed = _mesh_edges(me)
    deg = np.bincount(ed.ravel(), minlength=n).astype(np.float64)
    ae = max(avg_edge, 1e-9)

    # result borders
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    efc = np.bincount(le, minlength=len(ed))
    res_border = np.zeros(n, dtype=bool)
    res_border[ed[efc == 1].ravel()] = True

    axis_i = "XYZ".index(sym_axis) if sym_axis in ('X', 'Y', 'Z') else -1
    if axis_i >= 0:
        center, pairs = _symmetry_pairs(co, axis_i, ae * 0.25)
    else:
        center = pairs = None

    def symmetrize():
        if axis_i < 0:
            return
        if len(pairs):
            a, b = pairs[:, 0], pairs[:, 1]
            mb = co[b].copy()
            mb[:, axis_i] *= -1.0
            m = 0.5 * (co[a] + mb)
            co[a] = m
            m2 = m.copy()
            m2[:, axis_i] *= -1.0
            co[b] = m2
        if len(center):
            co[center, axis_i] = 0.0

    co_solver = co.copy()

    # orientation of the result vs the reference (QuadriFlow may flip it)
    vn = _vertex_normals_np(co, topo)
    agree = 0
    probe = range(0, n, max(1, n // 400))
    cnt = 0
    for i in probe:
        r = bvh.find_nearest(Vector(co[i]))
        if r[0] is not None:
            cnt += 1
            if r[1].dot(Vector(vn[i])) > 0.0:
                agree += 1
    sign = 1.0 if agree >= cnt * 0.5 else -1.0

    # ---- feature assignment (done once, on the solver output)
    kind = np.zeros(n, dtype=np.int8)     # 0 surface, 1 crease, 2 border, 3 corner
    seg = np.full(n, -1, dtype=np.int64)
    snap_tol = ae * 0.35
    if feats is not None:
        if feats.kd_border is not None:
            for i in np.flatnonzero(res_border):
                _c, k, d = feats.kd_border.find(co[i])
                if k is not None and d <= ae * 0.75:
                    kind[i] = 2
                    seg[i] = feats.seg_border[k]
        if feats.kd_crease is not None and s.project:
            for i in range(n):
                if kind[i]:
                    continue
                _c, k, d = feats.kd_crease.find(co[i])
                if k is not None and d <= snap_tol:
                    kind[i] = 1
                    seg[i] = feats.seg_crease[k]
        if len(feats.corners) and s.project:
            kdv = KDTree(n)
            for i in range(n):
                kdv.insert(co[i], i)
            kdv.balance()
            for c in feats.corners:
                _p, i, d = kdv.find(c)
                if i is not None and d <= ae * 0.75:
                    co[i] = c
                    kind[i] = 3
    elif s.preserve_boundary:
        kind[res_border] = 3        # no feature data: just keep borders still

    def seg_of(i):
        if kind[i] == 1:
            A, B = feats.crease
        else:
            A, B = feats.border
        return A[seg[i]], B[seg[i]]

    def project():
        nonlocal vn
        vn = _vertex_normals_np(co, topo) * sign
        if not s.project:
            return
        maxd = ae * 1.5
        for i in range(n):
            k = kind[i]
            if k == 3:
                continue
            if k in (1, 2):
                a, b = seg_of(i)
                # stay on the line; re-pick the neighbouring segment when we slide past an end
                p, _ab = _closest_on_segment(co[i], a, b)
                kd = feats.kd_crease if k == 1 else feats.kd_border
                ids = feats.seg_crease if k == 1 else feats.seg_border
                _c, kk, _d = kd.find(co[i])
                if kk is not None and ids[kk] != seg[i] and _d <= ae * 0.5:
                    A2, B2 = feats.crease if k == 1 else feats.border
                    p2, _ = _closest_on_segment(co[i], A2[ids[kk]], B2[ids[kk]])
                    if np.linalg.norm(p2 - co[i]) < np.linalg.norm(p - co[i]):
                        seg[i] = ids[kk]
                        p = p2
                co[i] = p
                continue
            pv = Vector(co[i])
            nv_ = Vector(vn[i])
            loc, no, _idx, _d = bvh.find_nearest(pv)
            if loc is not None and no.dot(nv_) > 0.1:
                co[i] = loc
                continue
            # the nearest point is on the other side of a thin wall: search along the normal
            best = None
            for dirn in (nv_, -nv_):
                h = bvh.ray_cast(pv, dirn, maxd)
                if h[0] is not None and h[1].dot(nv_) > 0.1:
                    if best is None or h[3] < best[1]:
                        best = (h[0], h[3])
            if best is not None:
                co[i] = best[0]

    project()
    symmetrize()

    movable = kind != 3
    k_str = s.relax_strength
    for _it in range(s.relax_iterations):
        acc = np.zeros_like(co)
        np.add.at(acc, ed[:, 0], co[ed[:, 1]])
        np.add.at(acc, ed[:, 1], co[ed[:, 0]])
        avg = acc / np.maximum(deg, 1.0)[:, None]
        delta = avg - co
        # slide along the surface only, never shrink
        delta -= (delta * vn).sum(axis=1)[:, None] * vn
        # feature vertices slide only along their line
        fi = np.flatnonzero((kind == 1) | (kind == 2))
        for i in fi:
            a, b = seg_of(i)
            d = b - a
            dl = np.linalg.norm(d)
            if dl > 0:
                d = d / dl
                delta[i] = d * float(np.dot(delta[i], d))
        delta[~movable] = 0.0
        if axis_i >= 0 and len(center):
            delta[center, axis_i] = 0.0
        co += k_str * delta
        project()
        symmetrize()

    # safety net: any vertex that produced a stretched edge goes back to the
    # solver position, projected safely onto the surface
    for _pass in range(3):
        L = np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1)
        med = float(np.median(L)) if len(L) else 0.0
        badE = np.flatnonzero(L > max(med * 3.5, 1e-9))
        if len(badE) == 0:
            break
        bad_v = np.unique(ed[badE].ravel())
        for i in bad_v:
            loc, _no, _ix, _d = bvh.find_nearest(Vector(co_solver[i]))
            co[i] = loc if loc is not None else co_solver[i]
            kind[i] = 3

    me.vertices.foreach_set("co", co.ravel())
    me.update()


def _voxel_size_for(area, faces_wanted):
    return math.sqrt(max(area, 1e-12) / max(faces_wanted, 1))


def _voxelize(context, ob, area, faces_wanted):
    """OpenVDB rebuild + one light smoothing pass. The raw voxel grid has
    perfectly coplanar staircase faces that QuadriFlow's field solver often
    rejects; one smoothing step removes them without losing shape."""
    vs = _voxel_size_for(area, faces_wanted)
    _eval_modifier(context, ob, 'REMESH', mode='VOXEL', voxel_size=vs, adaptivity=0.0)
    _eval_modifier(context, ob, 'SMOOTH', factor=0.5, iterations=1)


# --------------------------------------------------------------------------
#  Mesh building blocks (numpy, fast)
# --------------------------------------------------------------------------
TMP_PREFIX = "RU__tmp"


def _tmp_copy(me):
    m = me.copy()
    m.name = TMP_PREFIX
    return m


def _mesh_arrays(me):
    co = _mesh_co(me)
    lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    return co, lv, ls, lt


def _build_mesh(co, lv, lt, name=TMP_PREFIX):
    me = bpy.data.meshes.new(name)
    if len(lt) == 0:
        return me
    ls = np.zeros(len(lt), dtype=np.int64)
    ls[1:] = np.cumsum(lt)[:-1]
    me.vertices.add(len(co))
    me.vertices.foreach_set("co", np.ascontiguousarray(co, dtype=np.float32).ravel())
    me.loops.add(len(lv))
    me.loops.foreach_set("vertex_index", lv.astype(np.int32))
    me.polygons.add(len(lt))
    me.polygons.foreach_set("loop_start", ls.astype(np.int32))
    me.update(calc_edges=True)
    me.validate(clean_customdata=False)
    return me


def _join_meshes(meshes, name=TMP_PREFIX):
    cos, lvs, lts, off = [], [], [], 0
    for m in meshes:
        co, lv, _ls, lt = _mesh_arrays(m)
        cos.append(co)
        lvs.append(lv + off)
        lts.append(lt)
        off += len(co)
    if not cos:
        return bpy.data.meshes.new(name)
    return _build_mesh(np.concatenate(cos), np.concatenate(lvs), np.concatenate(lts), name)


def _components(me):
    """Connected parts (by shared vertices). Numpy union-find with pointer jumping."""
    nv = len(me.vertices)
    ed = _mesh_edges(me)
    parent = np.arange(nv, dtype=np.int64)
    if len(ed) == 0:
        return parent
    a, b = ed[:, 0], ed[:, 1]
    for _round in range(64):
        pa, pb = parent[a], parent[b]
        if np.array_equal(pa, pb):
            break
        lo = np.minimum(pa, pb)
        hi = np.maximum(pa, pb)
        np.minimum.at(parent, hi, lo)
        while True:
            gp = parent[parent]
            if np.array_equal(gp, parent):
                break
            parent = gp
    _u, labels = np.unique(parent, return_inverse=True)
    return labels


def _split_parts(me, labels):
    co, lv, ls, lt = _mesh_arrays(me)
    face_lab = labels[lv[ls]]
    parts = []
    order = np.argsort(face_lab, kind='stable')
    bounds = np.flatnonzero(np.diff(face_lab[order])) + 1
    groups = np.split(order, bounds)
    for faces in groups:
        if len(faces) == 0:
            continue
        sel_lt = lt[faces]
        idx = _loop_ranges(ls[faces], sel_lt)
        verts = lv[idx]
        uniq, remap = np.unique(verts, return_inverse=True)
        parts.append(_build_mesh(co[uniq], remap.astype(np.int64), sel_lt))
    return parts


def _loop_ranges(starts, totals):
    total = int(totals.sum())
    rep = np.repeat(starts - np.concatenate([[0], np.cumsum(totals)[:-1]]), totals)
    return np.arange(total, dtype=np.int64) + rep


def _mirror_mesh(me, axis_i):
    m = _tmp_copy(me)
    co = _mesh_co(m)
    co[:, axis_i] *= -1.0
    m.vertices.foreach_set("co", co.ravel())
    bm = bmesh.new()
    bm.from_mesh(m)
    bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
    bm.to_mesh(m)
    bm.free()
    m.update()
    return m


def _weld_mirror_seam(me, axis_i, diag):
    """Snap open-border points lying next to the mirror plane onto it and weld
    the two halves together there.  Returns how many points were welded."""
    bm = bmesh.new()
    bm.from_mesh(me)
    edges = [e for e in bm.edges if e.is_boundary]
    if not edges:
        bm.free()
        return 0
    lens = sorted(e.calc_length() for e in bm.edges)
    ae = lens[len(lens) // 2] if lens else diag * 0.01
    tol = min(ae * 0.6, diag * 0.01)
    # only open edges that run ALONG the plane (both ends on it) form a seam; an
    # opening that merely crosses the plane (a hole in the middle) is left alone
    seam = {v for e in edges if all(abs(x.co[axis_i]) <= tol for x in e.verts)
            for v in e.verts}
    # ... and only points that really have a twin on the other side get welded
    if seam:
        from mathutils.kdtree import KDTree
        sl = list(seam)
        kd = KDTree(len(sl))
        for i, v in enumerate(sl):
            kd.insert(v.co, i)
        kd.balance()
        paired = set()
        for v in sl:
            q = v.co.copy()
            q[axis_i] = -q[axis_i]
            hit = kd.find(q)
            if hit[1] is not None and sl[hit[1]] is not v and hit[2] <= tol * 0.5:
                paired.add(v)
        seam = paired
    if not seam:
        bm.free()
        return 0
    for v in seam:
        v.co[axis_i] = 0.0
    before = len(bm.verts)
    bmesh.ops.remove_doubles(bm, verts=list(seam), dist=max(diag * 1e-5, tol * 0.05))
    welded = before - len(bm.verts)
    if welded:
        bm.to_mesh(me)
        me.update()
    bm.free()
    return welded


def _boundary_loops(me):
    """Lengths of the open border loops (holes, openings) of a mesh."""
    ne = len(me.edges)
    if ne == 0 or len(me.loops) == 0:
        return []
    ei = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", ei)
    use = np.bincount(ei, minlength=ne)
    b = np.flatnonzero(use == 1)
    if len(b) == 0:
        return []
    ev = np.empty(ne * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", ev)
    ev = ev.reshape(-1, 2)[b]
    co = _mesh_co(me)
    elen = np.linalg.norm(co[ev[:, 0]] - co[ev[:, 1]], axis=1)
    parent = {}

    def find(x):
        while parent.get(x, x) != x:
            parent[x] = parent.get(parent[x], parent[x])
            x = parent[x]
        return x
    for a_, b_ in ev.tolist():
        ra, rb = find(a_), find(b_)
        if ra != rb:
            parent[ra] = rb
    tot = {}
    for (a_, _b), L in zip(ev.tolist(), elen.tolist()):
        r = find(a_)
        tot[r] = tot.get(r, 0.0) + L
    return sorted(tot.values(), reverse=True)


def _repair_part(me, merge_dist):
    """Local repair without voxels: weld, drop junk, split non-manifold fans,
    make normals consistent."""
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=merge_dist)
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges[:], dist=merge_dist)
    junk = [v for v in bm.verts if not v.link_faces]
    if junk:
        bmesh.ops.delete(bm, geom=junk, context='VERTS')
    nm = [e for e in bm.edges if len(e.link_faces) > 2]
    if nm:
        bmesh.ops.split_edges(bm, edges=nm)
    nmv = [v for v in bm.verts if not v.is_manifold and v.link_faces and not v.is_boundary]
    if nmv:
        bmesh.ops.split_edges(bm, edges=list({e for v in nmv for e in v.link_edges}))
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(me)
    bm.free()
    me.update()


def _bvh_from_mesh_shift(me, axis_i, c):
    bm = bmesh.new()
    bm.from_mesh(me)
    for v in bm.verts:
        v.co[axis_i] -= c
    tree = BVHTree.FromBMesh(bm)
    bm.free()
    return tree


def _sample_points(me, limit=3000, seed=3):
    co = _mesh_co(me)
    cen = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("center", cen)
    pts = np.concatenate([co, cen.reshape(-1, 3)])
    if len(pts) > limit:
        rng = np.random.default_rng(seed)
        pts = pts[rng.choice(len(pts), size=limit, replace=False)]
    return pts


def _avg_edge(me):
    co = _mesh_co(me)
    ed = _mesh_edges(me)
    if len(ed) == 0:
        return 0.0
    return float(np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1).mean())


def _coverage(ref_pts, res_me, tol):
    """Fraction of the original surface that the result still covers."""
    if len(res_me.polygons) == 0:
        return 0.0
    bvh = _bvh_from_mesh(res_me)
    hit = 0
    for p in ref_pts:
        r = bvh.find_nearest(Vector(p))
        if r[0] is not None and r[3] <= tol:
            hit += 1
    return hit / max(len(ref_pts), 1)


def _is_symmetric(co, bvh, diag, axis_i):
    if len(co) < 8:
        return False
    rng = np.random.default_rng(1)
    sample = co[rng.choice(len(co), size=min(800, len(co)), replace=False)]
    tol = diag * 0.006
    hits = 0
    for p in sample:
        q = Vector(p)
        q[axis_i] = -q[axis_i]
        loc, _n, _i, d = bvh.find_nearest(q)
        if loc is not None and d <= tol:
            hits += 1
    return hits / len(sample) >= 0.93


# --------------------------------------------------------------------------
#  One part -> quads
# --------------------------------------------------------------------------
COVER_MIN = 0.95


# --------------------------------------------------------------------------
#  Isolated, parallel QuadriFlow
#  Each solve runs in a background Blender process with a time limit, so a
#  solver hang can never freeze the user's Blender, and parts are solved on
#  several CPU cores at once.
# --------------------------------------------------------------------------
import sys
import json
import tempfile
import subprocess

_WORKER_SRC = r'''
import sys, os, json
import numpy as np
import bpy

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
jobdir, listfile = argv[0], argv[1]
ids = json.load(open(listfile))

def build(co, lv, lt):
    me = bpy.data.meshes.new("ru_w")
    ls = np.zeros(len(lt), dtype=np.int64)
    if len(lt) > 1:
        ls[1:] = np.cumsum(lt)[:-1]
    me.vertices.add(len(co))
    me.vertices.foreach_set("co", co.astype(np.float32).ravel())
    me.loops.add(len(lv))
    me.loops.foreach_set("vertex_index", lv.astype(np.int32))
    me.polygons.add(len(lt))
    me.polygons.foreach_set("loop_start", ls.astype(np.int32))
    me.update(calc_edges=True)
    me.validate(clean_customdata=False)
    return me

for jid in ids:
    base = os.path.join(jobdir, jid)
    meta = json.load(open(base + ".json"))
    d = np.load(os.path.join(jobdir, meta["input"] + ".in.npz"))
    me = build(d["co"], d["lv"], d["lt"])
    sym = meta["sym"]
    me.use_mirror_x = sym == "X"
    me.use_mirror_y = sym == "Y"
    me.use_mirror_z = sym == "Z"
    ob = bpy.data.objects.new("ru_w", me)
    bpy.context.scene.collection.objects.link(ob)
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    ok = False
    try:
        with bpy.context.temp_override(object=ob, active_object=ob,
                                       selected_objects=[ob], selected_editable_objects=[ob]):
            r = bpy.ops.object.quadriflow_remesh(
                use_mesh_symmetry=(sym != "NONE"),
                use_preserve_sharp=bool(meta["sharp"]),
                use_preserve_boundary=bool(meta["boundary"]),
                preserve_attributes=False, smooth_normals=False,
                mode='FACES', target_faces=int(meta["target"]), seed=int(meta["seed"]))
        ok = 'FINISHED' in r and len(ob.data.polygons) > 0
    except Exception as ex:
        ok = False
    if ok:
        m = ob.data
        co = np.empty(len(m.vertices) * 3, dtype=np.float64); m.vertices.foreach_get("co", co)
        lv = np.empty(len(m.loops), dtype=np.int64); m.loops.foreach_get("vertex_index", lv)
        lt = np.empty(len(m.polygons), dtype=np.int64); m.polygons.foreach_get("loop_total", lt)
        tmp = base + ".tmp.npz"
        np.savez(tmp, co=co.reshape(-1, 3), lv=lv, lt=lt)
        os.replace(tmp, base + ".out.npz")
    else:
        open(base + ".fail", "w").close()
    old = ob.data
    bpy.data.objects.remove(ob)
    if old.users == 0:
        bpy.data.meshes.remove(old)
    sys.stdout.flush()
'''


def _blender_cmd(worker, jobdir, listfile):
    exe = bpy.app.binary_path
    if exe and os.path.isfile(exe):
        return [exe, "--background", "--factory-startup", "--python", worker, "--", jobdir, listfile]
    # Blender running as a Python module (bpy from pip): plain python works
    return [sys.executable, worker, jobdir, listfile]


def _worker_count(n_jobs):
    try:
        cpus = os.cpu_count() or 2
    except Exception:
        cpus = 2
    return max(1, min(n_jobs, max(1, cpus // 2), 6))


def _qf_isolated(jobs, inputs):
    """jobs: list of dict(id, input, target, seed, sym, sharp, boundary, faces)
       inputs: dict input_id -> (co, lv, lt)
       Returns dict id -> (co, lv, lt) | 'fail' | 'timeout', or None if the
       isolated runner is not available at all."""
    if not jobs:
        return {}
    tmp = tempfile.mkdtemp(prefix="ru_qf_")
    try:
        worker = os.path.join(tmp, "ru_worker.py")
        with open(worker, "w", encoding="utf-8") as fh:
            fh.write(_WORKER_SRC)
        for iid, (co, lv, lt) in inputs.items():
            np.savez(os.path.join(tmp, iid + ".in.npz"), co=co, lv=lv, lt=lt)
        for j in jobs:
            with open(os.path.join(tmp, j["id"] + ".json"), "w") as fh:
                json.dump(j, fh)

        def limit(j):
            t = 10.0 + j["faces"] / 6000.0 + j["target"] / 1500.0
            return t * (2.0 if j["sharp"] else 1.0)

        results = {}
        pending = [j for j in jobs]
        flags = 0x08000000 if sys.platform == "win32" else 0   # no console window
        attempts = 0
        while pending and attempts < 6:
            attempts += 1
            nw = _worker_count(len(pending))
            chunks = [pending[k::nw] for k in range(nw)]
            procs = []
            for k, chunk in enumerate(chunks):
                if not chunk:
                    continue
                lf = os.path.join(tmp, "list_%d_%d.json" % (attempts, k))
                with open(lf, "w") as fh:
                    json.dump([j["id"] for j in chunk], fh)
                try:
                    p = subprocess.Popen(_blender_cmd(worker, tmp, lf), stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL, creationflags=flags)
                except Exception as ex:
                    print("[Remesh Ultimate] isolated solver unavailable:", ex)
                    for q in procs:
                        q[0].kill()
                    return None
                procs.append([p, chunk, 0, time.time(), 15.0])   # +15 s start-up allowance
            requeue = []
            while procs:
                time.sleep(0.03)
                now = time.time()
                for st in list(procs):
                    p, chunk, idx, t_last, extra = st
                    while idx < len(chunk):
                        b = os.path.join(tmp, chunk[idx]["id"])
                        if os.path.exists(b + ".out.npz"):
                            d = np.load(b + ".out.npz")
                            results[chunk[idx]["id"]] = (d["co"], d["lv"], d["lt"])
                        elif os.path.exists(b + ".fail"):
                            results[chunk[idx]["id"]] = 'fail'
                        else:
                            break
                        idx += 1
                        t_last, extra = now, 0.0
                    st[2], st[3], st[4] = idx, t_last, extra
                    if idx >= len(chunk):
                        if p.poll() is None:
                            try:
                                p.wait(timeout=5)
                            except Exception:
                                p.kill()
                        procs.remove(st)
                        continue
                    if p.poll() is not None:
                        # worker died on chunk[idx]: count it as failed, retry the rest
                        results[chunk[idx]["id"]] = 'fail'
                        requeue.extend(chunk[idx + 1:])
                        procs.remove(st)
                    elif now - t_last > limit(chunk[idx]) + extra:
                        p.kill()
                        try:
                            p.wait(timeout=5)
                        except Exception:
                            pass
                        results[chunk[idx]["id"]] = 'timeout'
                        requeue.extend(chunk[idx + 1:])
                        procs.remove(st)
            pending = [j for j in requeue if j["id"] not in results]
        for j in pending:
            results.setdefault(j["id"], 'fail')
        return results
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _qf_inprocess(context, jobs, inputs):
    """Fallback: same interface, solved inside this Blender (sharp disabled: it can hang)."""
    results = {}
    for j in jobs:
        co, lv, lt = inputs[j["input"]]
        me = _build_mesh(co, lv, lt)
        ob = _new_temp_object(context, me, "RU_qf")
        ok = _run_quadriflow(context, ob, None, j["target"], j["seed"], j["sym"], sharp=False,
                             boundary=j["boundary"])
        if ok:
            a = _mesh_arrays(ob.data)
            results[j["id"]] = (a[0], a[1], a[3])
        else:
            results[j["id"]] = 'fail'
        old = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if old.users == 0:
            bpy.data.meshes.remove(old)
    return results


def _solve_jobs(context, s, jobs, inputs):
    res = None
    if s.isolated:
        res = _qf_isolated(jobs, inputs)
    if res is None:
        for j in jobs:
            j["sharp"] = False
        res = _qf_inprocess(context, jobs, inputs)
    return res


# --------------------------------------------------------------------------
#  Per-part work, in two phases (prepare -> batch solve -> finish)
# --------------------------------------------------------------------------
class _PartWork:
    pass


def _arrays_of(me):
    co, lv, _ls, lt = _mesh_arrays(me)
    return co, lv, lt


def _prepare_part(context, key, part, s, target, sym, merge_dist, info=None, ref_bvh=None,
                  guides=None):
    w = _PartWork()
    w.key, w.target, w.sym = key, target, sym
    if info is None:
        info = _analyze_fast(part, merge_dist)
    w.border0 = _boundary_loops(part)        # real openings, before any repair
    if info["nonmanifold_edges"] or info["inconsistent"] or info["loose"] or info["duplicates"]:
        _repair_part(part, merge_dist)
        info = _analyze_fast(part, merge_dist)
        ref_bvh = None
    w.part = part
    w.info = info
    w.closed = info["boundary_edges"] == 0
    w.co = _mesh_co(part)
    w.diag = float(np.linalg.norm(w.co.max(axis=0) - w.co.min(axis=0))) or 1.0
    w.ref_bvh = ref_bvh if ref_bvh is not None else _bvh_from_mesh(part)
    w.ref_pts = _sample_points(part)
    est_edge = math.sqrt(max(info["area"], 1e-12) / max(target, 1))
    w.feats = None
    if len(part.polygons) <= 400000:
        w.feats = _extract_features(part, s.sharp_angle, s.preserve_boundary, est_edge / 3.0,
                                    mode=s.sharp_mode, extra=guides)
    w.hard = bool(w.feats is not None and w.feats.hard)

    # candidate solver inputs, best first (built lazily)
    tris = _tri_count(part)
    cap = max(target * 12, 30000)
    stages = []

    def mk_turbo():
        tmp = _new_temp_object(context, _tmp_copy(part), "RU_turbo")
        if w.closed:
            _voxelize(context, tmp, info["area"], target * 6)
        else:
            _eval_modifier(context, tmp, 'DECIMATE', decimate_type='COLLAPSE',
                           ratio=cap / tris, use_collapse_triangulate=True)
        return _arrays_of(tmp.data)

    def mk_direct():
        return _arrays_of(part)

    def mk_tri():
        tmp = _new_temp_object(context, _tmp_copy(part), "RU_tri")
        _eval_modifier(context, tmp, 'TRIANGULATE')
        return _arrays_of(tmp.data)

    def mk_vox(mult):
        def f():
            tmp = _new_temp_object(context, _tmp_copy(part), "RU_vox")
            _voxelize(context, tmp, info["area"], target * mult)
            return _arrays_of(tmp.data)
        return f

    if s.turbo and tris > cap * 1.3:
        stages.append(("turbo", mk_turbo))
    stages.append(("direct", mk_direct))
    if not w.closed:
        stages.append(("tri", mk_tri))
    if w.closed:
        stages.append(("voxel x3", mk_vox(3)))
        stages.append(("voxel x2", mk_vox(2)))
    w.stages = stages
    w.stage = 0
    w.no_sharp = set()
    w.result = None
    w.tag = None
    w.sym_dropped = False
    w.retry_same = False
    w.lumpy = False
    w.backup = None
    w.backup_bad = 1e9
    return w


# 1.6.4 wrinkle test (measured on real runs: clean solves 0 - 0.3 % flipped quads and
# no vertex off the surface; wrinkled solves 5 - 9 % flipped or vertices 1 - 21 quad
# edges away).  Distance percentiles are NOT used to reject: on a noisy sculpt with
# big quads they are naturally high and would throw away good results.
LUMP_MAX = 1.0    # no result vertex may float more than one quad edge off the surface
LUMP_FLIP = 3.0   # at most this % of quads may face against the surface below them
DENSE_KEEP = 4.0  # a part with more than this x its quad budget is never kept as-is


def _shape_check(ref_pts, ref_bvh, res_me, tol, edge):
    """Coverage of the original surface plus how far the two surfaces stray apart,
    both ways.  Lumps and dents: the original strays from the result.  Spikes and
    folds: the result strays from the original.  Measured in quad edges."""
    if len(res_me.polygons) == 0 or len(ref_pts) == 0:
        return 0.0, 1e9, 1e9, 1e9, 90.0, 1e9
    bvh = _bvh_from_mesh(res_me)
    d = np.full(len(ref_pts), 1e9)
    for i, p in enumerate(ref_pts.tolist()):
        r = bvh.find_nearest(p)
        if r[0] is not None:
            d[i] = r[3]
    cover = float((d <= tol).mean())
    e = max(edge, 1e-12)
    p90 = float(np.percentile(d, 90)) / e
    p99 = float(np.percentile(d, 99)) / e
    # every result vertex: a single spike is enough to spoil a part
    rp = _mesh_co(res_me)
    d2 = np.full(len(rp), 1e9)
    for i, p in enumerate(rp.tolist()):
        r = ref_bvh.find_nearest(p)
        if r[0] is not None:
            d2[i] = r[3]
    dmax = 0.0
    if len(d2):
        p90 = max(p90, float(np.percentile(d2, 90)) / e)
        p99 = max(p99, float(np.percentile(d2, 99)) / e)
        dmax = float(d2.max()) / e
    # crumpled quads (folds that stay on the surface): the quad faces another way
    # than the surface below it
    nf = len(res_me.polygons)
    fc = np.empty(nf * 3)
    res_me.polygons.foreach_get("center", fc)
    fn = np.empty(nf * 3)
    res_me.polygons.foreach_get("normal", fn)
    fc, fn = fc.reshape(-1, 3), fn.reshape(-1, 3)
    # quads stretched over a hole or a gap keep their corners on the surface, but
    # their middle floats over empty space
    dc = np.zeros(nf)
    for i, p in enumerate(fc.tolist()):
        r = ref_bvh.find_nearest(p)
        dc[i] = r[3] if r[0] is not None else 1e9
    span = float(np.percentile(dc, 99.5)) / e if nf else 0.0
    pick = np.arange(0, nf, max(1, nf // 4000))
    dots = np.ones(len(pick))
    for k, i in enumerate(pick.tolist()):
        r = ref_bvh.find_nearest(fc[i].tolist())
        if r[1] is not None:
            dots[k] = r[1].dot(Vector(fn[i]))
    if dots.mean() < 0.0:              # the result is wound the other way as a whole
        dots = -dots
    tilt = float((dots < -0.2).mean() * 100.0)     # % of quads flipped against the surface
    return cover, p90, p99, dmax, tilt, span


def _finish_candidates(w, s, cands, tag):
    best, best_q = None, None
    for (co, lv, lt) in cands:
        m = _build_mesh(co, lv, lt)
        q = _mesh_quality(m, w.ref_bvh, w.co, w.diag, w.target)
        if best is None or q["score"] > best_q["score"]:
            if best is not None:
                bpy.data.meshes.remove(best)
            best, best_q = m, q
        else:
            bpy.data.meshes.remove(m)
    if best is None:
        return None
    ae = _avg_edge(best) or w.diag * 0.01
    _fit_to_surface(best, w.ref_bvh, w.feats, s, w.sym, ae)
    tol = max(ae * 0.75, w.diag * 0.004)
    cover, p90, p99, dmax, tilt, span = _shape_check(w.ref_pts, w.ref_bvh, best, tol, ae)
    w.check = (round(cover, 3), round(p90, 2), round(p99, 2), round(dmax, 2), round(tilt, 1), round(span, 2))
    # 1.6.4: openings (air intakes, windows) must stay open - a solve that
    # stretches quads over them changes the model
    border_ok = True
    if getattr(w, "border0", None) and s.preserve_boundary:
        # every opening big enough for the quads (3 edges round) must still be there
        need = sorted((L for L in w.border0 if L >= ae * 3.0), reverse=True)
        have = sorted((L for L in _boundary_loops(best) if L >= ae * 1.5), reverse=True)
        # every opening needs its own border of a similar size in the result
        border_ok = len(have) >= len(need) and all(
            h >= n * 0.6 for n, h in zip(need, have))
    w.check = w.check + (border_ok,)
    if cover >= COVER_MIN and dmax <= LUMP_MAX and tilt <= LUMP_FLIP and border_ok:
        w.tag = tag
        return best
    w.lumpy = cover >= COVER_MIN
    if w.lumpy:
        # keep the least wrinkled solve in reserve: a dense part (a sculpt) must
        # still come out light even if no solve passes the wrinkle test
        bad = tilt + 10.0 * max(0.0, dmax - LUMP_MAX)
        if w.backup is None or bad < w.backup_bad:
            if w.backup is not None:
                bpy.data.meshes.remove(w.backup)
            w.backup, w.backup_bad = best, bad
            return None
    bpy.data.meshes.remove(best)
    return None


def _finish_guarded(w, s, mine, res, tag):
    """Finish a part.  1.6.4 symmetry guard: QuadriFlow's own mirror mode can wrinkle
    a part (lumps / spikes on joined or repaired meshes).  If the mirrored solve
    fails the wrinkle test, the same input is solved again without the mirror."""
    cands = [res[j["id"]] for j in mine if isinstance(res.get(j["id"]), tuple)]
    m = _finish_candidates(w, s, cands, tag) if cands else None
    if m is None and w.sym != 'NONE' and not w.sym_dropped:
        w.sym_dropped = True
        w.sym = 'NONE'
        w.retry_same = True
    return m


def _solve_parts(context, s, works):
    """Batch-solve every part; each round tries the next input for parts still open."""
    rnd = 0
    while True:
        open_w = [w for w in works if w.result is None and w.stage < len(w.stages)]
        if not open_w:
            break
        rnd += 1
        jobs, inputs = [], {}
        for w in open_w:
            tag, builder = w.stages[w.stage]
            iid = "p%s_s%d" % (w.key, w.stage)
            arr = builder()
            inputs[iid] = arr
            sharp = w.hard and (w.stage not in w.no_sharp)
            for k in range(max(1, s.tries)):
                jobs.append(dict(id="%s_r%d_k%d" % (iid, rnd, k), input=iid, target=int(w.target),
                                 seed=int(s.seed + k * 7919), sym=w.sym, sharp=bool(sharp),
                                 boundary=bool(s.preserve_boundary), faces=int(len(arr[2])),
                                 part=w.key))
        res = _solve_jobs(context, s, jobs, inputs)
        for w in open_w:
            mine = [j for j in jobs if j["part"] == w.key]
            cands = [res[j["id"]] for j in mine if isinstance(res.get(j["id"]), tuple)]
            timed_out = any(res.get(j["id"]) == 'timeout' for j in mine)
            was_sharp = any(j["sharp"] for j in mine)
            m = _finish_guarded(w, s, mine, res, w.stages[w.stage][0])
            if m is not None:
                w.result = m
                continue
            if w.retry_same:
                w.retry_same = False            # same input again, without the mirror
                continue
            if timed_out and was_sharp and not cands:
                w.no_sharp.add(w.stage)        # same input again, without the slow sharp mode
                continue
            w.stage += 1
        _cleanup_temp(context)

    # last resort for solids: plain voxel quads (no solver involved)
    for w in works:
        if w.result is None and w.closed:
            tmp = _new_temp_object(context, _tmp_copy(w.part), "RU_fb")
            vs = _voxel_size_for(w.info["area"], w.target)
            _eval_modifier(context, tmp, 'REMESH', mode='VOXEL', voxel_size=vs, adaptivity=0.0)
            m = _finish_candidates(w, s, [_arrays_of(tmp.data)], "voxel quads")
            if m is not None:
                w.result = m
    _cleanup_temp(context)



# --------------------------------------------------------------------------
#  Quadify: exact-shape conversion for well-modelled low-poly / hard-surface
#  parts. A solver can never beat a clean hand-made mesh at the same density,
#  so the existing topology is turned into quads instead of being rebuilt.
# --------------------------------------------------------------------------
def _crease_info(me, angle):
    ne = len(me.edges)
    if ne == 0 or len(me.polygons) == 0:
        return 0, 0.0
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    pol = np.repeat(np.arange(len(lt), dtype=np.int64), lt)
    fn = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    efc = np.bincount(le, minlength=ne)
    order = np.argsort(le, kind='stable')
    le_s, pol_s = le[order], pol[order]
    starts = np.searchsorted(le_s, np.arange(ne))
    two = np.flatnonzero(efc == 2)
    dots = np.einsum('ij,ij->i', fn[pol_s[starts[two]]], fn[pol_s[starts[two] + 1]])
    n = int((dots < math.cos(angle)).sum())
    return n, n / max(ne, 1)


def _quad_ratio(me):
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    return float((lt == 4).mean()) if len(lt) else 1.0


def _is_star_shaped(f):
    c = f.calc_center_median()
    n = f.normal
    vs = [v.co for v in f.verts]
    for i in range(len(vs)):
        a, b = vs[i] - c, vs[(i + 1) % len(vs)] - c
        if a.cross(b).dot(n) <= 0.0:
            return False
    return True


def _pair_fans(bm, fan):
    """Join the fan triangles of a poked n-gon two by two (exact, no search)."""
    centers = {}
    fs = set(fan)
    for f in fan:
        for v in f.verts:
            if all(x in fs for x in v.link_faces):
                centers.setdefault(v, []).append(f)
                break
    for cv, tris in centers.items():
        # order triangles around the centre
        ring = []
        start = tris[0]
        seen = {start}
        ring.append(start)
        cur = start
        while True:
            nxt = None
            for e in cur.edges:
                if cv in e.verts:
                    for lf in e.link_faces:
                        if lf is not cur and lf in fs and lf not in seen:
                            nxt = lf
                            break
                if nxt:
                    break
            if nxt is None:
                break
            ring.append(nxt)
            seen.add(nxt)
            cur = nxt
        if len(ring) != len(tris) or len(ring) % 2:
            continue
        for k in range(0, len(ring), 2):
            a, b = ring[k], ring[k + 1]
            shared = [e for e in a.edges if e in b.edges and cv in e.verts]
            if shared:
                bmesh.ops.dissolve_edges(bm, edges=shared, use_verts=False)


def _quadify(me, s):
    """Same shape, (almost) all quads: join triangle pairs, split n-gons cleanly."""
    m = _tmp_copy(me)
    bm = bmesh.new()
    bm.from_mesh(m)
    ang = math.radians(40.0)
    for _round in range(2):
        tri = [f for f in bm.faces if len(f.verts) == 3]
        if tri:
            bmesh.ops.join_triangles(bm, faces=tri, angle_face_threshold=ang,
                                     angle_shape_threshold=ang)
        ngons = [f for f in bm.faces if len(f.verts) > 4]
        if not ngons:
            break
        even = [f for f in ngons if len(f.verts) % 2 == 0 and _is_star_shaped(f)]
        other = [f for f in ngons if f not in set(even)]
        if even:
            # even n-gon -> centre point + n/2 radial quads (classic cap topology)
            res = bmesh.ops.poke(bm, faces=even)
            fan = [f for f in res["faces"] if f.is_valid]
            _pair_fans(bm, fan)
        if other:
            # odd / irregular n-gons -> beauty triangles -> paired into quads next round
            bmesh.ops.triangulate(bm, faces=other, quad_method='BEAUTY', ngon_method='BEAUTY')
    bm.to_mesh(m)
    bm.free()
    m.update()
    if s.pure_quads and _quad_ratio(m) < 1.0:
        # one flat (simple) subdivision: 100 % quads, shape unchanged
        tmp = bpy.data.objects.new("RU_pq", m)
        _temp_collection(bpy.context).objects.link(tmp)
        _eval_modifier(bpy.context, tmp, 'SUBSURF', subdivision_type='SIMPLE', levels=1,
                       render_levels=1)
        m = _tmp_copy(tmp.data)
    return m


def _purge_tmp_meshes():
    for m in list(bpy.data.meshes):
        if m.name.startswith(TMP_PREFIX) and m.users == 0:
            bpy.data.meshes.remove(m)


def remesh_object(context, src, s):
    t0 = time.time()
    log = []

    # 1) evaluated copy (modifiers applied), scale baked in, origin kept
    dg = context.evaluated_depsgraph_get()
    ev = src.evaluated_get(dg)
    base_me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=False, depsgraph=dg)
    base_me.name = TMP_PREFIX
    # work in true world proportions (rotation + any scale, even negative),
    # then bring the result back so it keeps the original transform
    lin = _work_matrix(src)
    if abs(lin.determinant()) < 1e-12:
        raise RuntimeError("Object has zero scale")
    flipped = lin.determinant() < 0.0
    base_me.transform(lin.to_4x4())
    if flipped:
        base_me.flip_normals()
    result_matrix = src.matrix_world.copy()

    co0 = _mesh_co(base_me)
    if len(co0) == 0 or len(base_me.polygons) == 0:
        raise RuntimeError("Object has no faces")
    diag = float(np.linalg.norm(co0.max(axis=0) - co0.min(axis=0)))
    merge_dist = diag * 1e-5

    # 2) symmetry: the mirror plane may pass through the object origin OR through
    #    the middle of the model (meshes modelled away from their origin)
    sym_axis, offset = 'NONE', Vector((0.0, 0.0, 0.0))
    if s.symmetry != 'NONE':
        mid = (co0.min(axis=0) + co0.max(axis=0)) * 0.5
        probe_bvh = _bvh_from_mesh(base_me)
        axes = "XYZ" if s.symmetry == 'AUTO' else s.symmetry
        found = False
        for plane in ("origin", "middle"):
            for ax in axes:
                ai = "XYZ".index(ax)
                c = 0.0 if plane == "origin" else float(mid[ai])
                shifted = co0.copy()
                shifted[:, ai] -= c
                bvh_s = probe_bvh if c == 0.0 else _bvh_from_mesh_shift(base_me, ai, c)
                if _is_symmetric(shifted, bvh_s, diag, ai):
                    sym_axis = ax
                    offset[ai] = c
                    found = True
                    break
            if found:
                break
        if not found and s.symmetry != 'AUTO':
            sym_axis = s.symmetry          # forced by the user, plane at the origin
    if offset.length > 0.0:
        base_me.transform(Matrix.Translation(-offset))
        co0 = _mesh_co(base_me)
    axis_i = "XYZ".index(sym_axis) if sym_axis in ('X', 'Y', 'Z') else -1
    if axis_i >= 0:
        # 1.6.5: halves joined by a Mirror modifier often stay open at the centre
        # (points a hair off the plane are not merged).  The solver then sees a
        # crack down the middle (dented wing).  Close that seam first.
        welded = _weld_mirror_seam(base_me, axis_i, diag)
        if welded:
            log.append("%d centre seam points welded" % welded)
            co0 = _mesh_co(base_me)

    # areas / drawn lines become guides the quads must follow
    guides = _guide_segments(src, lin, offset) if s.use_guides else None
    if guides is not None:
        log.append("%d guide segments" % len(guides[0]))
        gmid = (guides[0] + guides[1]) * 0.5

    # drawn lines alone: the user asked for a quad flow there, so such a part is
    # always rebuilt.  Area borders alone never force a rebuild (1.6.5).
    line_guides = _guide_segments(src, lin, offset, areas=False) if s.use_guides else None

    def part_guides(pmesh, guides=guides):
        if guides is None:
            return None
        gmid = (guides[0] + guides[1]) * 0.5
        pc = _mesh_co(pmesh)
        pad = diag * 0.02
        lo_, hi_ = pc.min(axis=0) - pad, pc.max(axis=0) + pad
        m = np.all((gmid >= lo_) & (gmid <= hi_), axis=1)
        if not m.any():
            return None
        # keep only segments that really lie on this part
        pb = _bvh_from_mesh(pmesh)
        keep = np.zeros(len(m), dtype=bool)
        tol = diag * 0.01
        for i in np.flatnonzero(m):
            r = pb.find_nearest(Vector(gmid[i]))
            keep[i] = r[0] is not None and r[3] <= tol
        if not keep.any():
            return None
        return guides[0][keep], guides[1][keep]

    # density: quads sized relative to the model, or a typed count
    QUAD_EDGE = {'S': 1 / 100.0, 'SM': 1 / 70.0, 'M': 1 / 50.0, 'ML': 1 / 35.0, 'L': 1 / 25.0}
    if s.quad_size in QUAD_EDGE:
        _ar = np.empty(len(base_me.polygons))
        base_me.polygons.foreach_get("area", _ar)
        edge = diag * QUAD_EDGE[s.quad_size]
        target_total = int(min(300000, max(60, float(_ar.sum()) / (edge * edge))))
    else:
        target_total = int(s.target_faces)
    log.append("~%d quads (%s)" % (target_total, s.quad_size))

    # the untouched original surface: used to measure the final result
    orig_pts = _sample_points(base_me, limit=6000, seed=11)
    if s.symmetry != 'NONE' and offset.length == 0.0:
        orig_bvh = probe_bvh
    else:
        orig_bvh = _bvh_from_mesh(base_me)

    # 3) parts
    single_info = None
    if s.clean_mode == 'VOXEL':
        tmp = _new_temp_object(context, _tmp_copy(base_me), "RU_merge")
        area = float(sum(p.area for p in base_me.polygons))
        _voxelize(context, tmp, area, min(max(target_total * 8, 40000), 600000))
        parts = [_tmp_copy(tmp.data)]
        log.append("parts merged (voxel)")
    elif s.clean_mode == 'NONE':
        parts = [_tmp_copy(base_me)]
    else:
        base_info = _analyze_fast(base_me, merge_dist)
        if base_info["duplicates"]:
            _weld = bmesh.new()
            _weld.from_mesh(base_me)
            bmesh.ops.remove_doubles(_weld, verts=_weld.verts[:], dist=merge_dist)
            _weld.to_mesh(base_me)
            _weld.free()
            base_me.update()
            base_info = None
            orig_bvh = _bvh_from_mesh(base_me)
        labels = _components(base_me)
        lp = np.empty(len(base_me.loops), dtype=np.int64)
        base_me.loops.foreach_get("vertex_index", lp)
        n_parts = len(np.unique(labels[lp]))
        if n_parts > 1:
            parts = _split_parts(base_me, labels)
        else:
            parts = [base_me]
            single_info = base_info
    log.append("%d part%s" % (len(parts), "s" if len(parts) != 1 else ""))

    areas = []
    for p in parts:
        a = np.empty(len(p.polygons))
        p.polygons.foreach_get("area", a)
        areas.append(float(a.sum()))
    total_area = sum(areas) or 1.0

    # 4) mirrored twins: solve one side, mirror the other (exact symmetry, half the work)
    info_parts = []
    for p, a in zip(parts, areas):
        c = _mesh_co(p)
        info_parts.append(dict(center=c.mean(axis=0), area=a, faces=len(p.polygons), twin=None))
    if axis_i >= 0:
        for i, pi in enumerate(info_parts):
            if pi["twin"] is not None or pi["center"][axis_i] <= diag * 1e-3:
                continue
            mc = pi["center"].copy()
            mc[axis_i] *= -1.0
            for j, pj in enumerate(info_parts):
                if j == i or pj["twin"] is not None:
                    continue
                if (pj["faces"] == pi["faces"] and abs(pj["area"] - pi["area"]) <= 0.01 * pi["area"]
                        and np.linalg.norm(pj["center"] - mc) <= diag * 0.003):
                    pi["twin"], pj["twin"] = j, -1   # -1: produced by mirroring i
                    break

    # 5) solve every part: batched, isolated, parallel
    plan, works = [], []
    kept, mirrored, solved, quadified, clean = 0, 0, 0, 0, 0
    for i, (p, pinfo) in enumerate(zip(parts, info_parts)):
        if pinfo["twin"] == -1:
            continue
        share = target_total * pinfo["area"] / total_area
        if len(parts) == 1:
            share = target_total
        if pinfo["faces"] <= 60 or share < 12:
            # tiny detail: exact shape, converted to quads
            if _quad_ratio(p) >= 0.98 and not s.pure_quads:
                plan.append(('mesh', _tmp_copy(p), pinfo))
                clean += 1
            else:
                plan.append(('mesh', _quadify(p, s), pinfo))
                quadified += 1
            continue
        target = int(max(share, 40))
        pg = part_guides(p)
        plg = part_guides(p, line_guides) if line_guides is not None else None
        # --- never make a part worse than its source
        src_faces = pinfo["faces"]
        qr = _quad_ratio(p)
        n_cr, fr_cr = _crease_info(p, s.sharp_angle)
        is_hard = s.sharp_mode != 'OFF' and n_cr >= 8 and (fr_cr >= 0.003 or s.sharp_mode == 'ON')
        low_poly = src_faces <= target * 1.5
        if s.method == 'QUADIFY' or (s.method == 'AUTO' and plg is None and
                                     (low_poly or (is_hard and src_faces <= 4000))):
            if qr >= 0.98 and not s.pure_quads:
                plan.append(('mesh', _tmp_copy(p), pinfo))
                clean += 1
            else:
                plan.append(('mesh', _quadify(p, s), pinfo))
                quadified += 1
            continue
        part_sym = 'NONE'
        if axis_i >= 0 and len(parts) == 1:
            part_sym = sym_axis
        elif axis_i >= 0 and abs(pinfo["center"][axis_i]) <= diag * 0.01:
            pc = _mesh_co(p)
            pdiag = float(np.linalg.norm(pc.max(axis=0) - pc.min(axis=0))) or 1.0
            if _is_symmetric(pc, _bvh_from_mesh(p), pdiag, axis_i):
                part_sym = sym_axis
        if p is base_me:
            w = _prepare_part(context, i, _tmp_copy(p), s, target, part_sym, merge_dist,
                              info=single_info, ref_bvh=orig_bvh, guides=pg)
        else:
            w = _prepare_part(context, i, p, s, target, part_sym, merge_dist, guides=pg)
        works.append(w)
        plan.append(('work', w, pinfo))

    _solve_parts(context, s, works)

    out_meshes = []
    hard_parts = sum(1 for w in works if w.hard)
    for kind_, obj_, pinfo in plan:
        if kind_ == 'mesh':
            res = obj_
        elif obj_.result is None:
            if obj_.backup is not None and len(obj_.part.polygons) > DENSE_KEEP * obj_.target:
                # dense part: the best solve, even if not perfect, beats keeping it dense
                res, obj_.backup = obj_.backup, None
                solved += 1
            else:
                res = _quadify(obj_.part, s)
                quadified += 1
        else:
            # shape guard: if the quads are too coarse for this piece, keep its exact
            # shape instead (converted to quads) - small/thin parts stay crisp
            qq = _mesh_quality(obj_.result, obj_.ref_bvh, obj_.co, obj_.diag, obj_.target)
            allowed = 100.0 * 0.3 * _avg_edge(obj_.result) / max(obj_.diag, 1e-9)
            if qq["deviation_pct"] > max(allowed, 0.5):
                bpy.data.meshes.remove(obj_.result)
                res = _quadify(obj_.part, s)
                quadified += 1
            else:
                res = obj_.result
                solved += 1
        out_meshes.append(res)
        if pinfo["twin"] is not None and pinfo["twin"] >= 0:
            out_meshes.append(_mirror_mesh(res, axis_i))
            mirrored += 1

    for w in works:
        if getattr(w, "backup", None) is not None:
            bpy.data.meshes.remove(w.backup)
            w.backup = None
    log.append("%d remeshed" % solved)
    if quadified:
        log.append("%d quadified (exact shape)" % quadified)
    if clean:
        log.append("%d already clean quads" % clean)
    if hard_parts:
        log.append("%d hard-surface" % hard_parts)
    if mirrored:
        log.append("%d mirrored twins" % mirrored)
    guarded = sum(1 for w in works if getattr(w, "sym_dropped", False))
    if guarded:
        log.append("%d part%s solved without mirror (cleaner shape)" % (guarded, "s" if guarded != 1 else ""))
    if kept:
        log.append("%d kept original" % kept)
    log.append("symmetry: %s" % ("none" if axis_i < 0 else sym_axis + (" (model centre)" if offset.length > 0 else "")))

    best = _join_meshes(out_meshes, src.name + RESULT_SUFFIX)
    if offset.length > 0.0:
        best.transform(Matrix.Translation(offset))
        base_me.transform(Matrix.Translation(offset))
        orig_pts = orig_pts + np.array(offset)
        orig_bvh = _bvh_from_mesh(base_me)
    # quality is measured in world proportions, then the mesh goes back to local space
    final_q = _mesh_quality(best, orig_bvh, _mesh_co(base_me), diag, target_total)
    cover = _coverage(orig_pts, best, max(_avg_edge(best) * 0.75, diag * 0.004))
    best.transform(lin.inverted().to_4x4())
    if flipped:
        best.flip_normals()

    # 6) final object
    best.polygons.foreach_set("use_smooth", np.ones(len(best.polygons), dtype=bool))
    try:
        best.set_sharp_from_angle(angle=max(s.sharp_angle * 1.8, math.radians(55.0)))
    except Exception:
        pass
    best.update()
    res = bpy.data.objects.new(src.name + RESULT_SUFFIX, best)
    res.matrix_world = result_matrix
    for coll in src.users_collection:
        coll.objects.link(res)
    if not res.users_collection:
        context.scene.collection.objects.link(res)
    for slot in src.material_slots:
        if slot.material:
            res.data.materials.append(slot.material)
    if s.add_shrinkwrap:
        sw = res.modifiers.new("RU Shrinkwrap", 'SHRINKWRAP')
        sw.target = src
        sw.wrap_method = 'NEAREST_SURFACEPOINT'

    dt = time.time() - t0
    method = "QuadriFlow" if solved else ("Quadify" if quadified else "Original kept")
    if solved and quadified:
        method = "QuadriFlow + Quadify"
    res["ru_source"] = src.name
    res["ru_score"] = round(final_q["score"] * min(1.0, cover / 0.98), 1)
    res["ru_cover"] = round(100.0 * cover, 1)
    res["ru_report"] = ("%d faces | %.0f%% quads | %d poles | cover %.1f%% | dev %.2f%% | %.1fs | %s" %
                        (final_q["faces"], final_q["quad_pct"], final_q["poles"], 100.0 * cover,
                         final_q["deviation_pct"], dt, method))
    res["ru_log"] = "; ".join(log)
    return res, final_q, dt


# --------------------------------------------------------------------------
#  Areas & Lines (Nitro-style patches, automatic + hand-drawn guides)
# --------------------------------------------------------------------------
AREAS_SUFFIX = "_RU_AREAS"
LINES_SUFFIX = "_RU_LINES"


def _uf_labels(n, a, b):
    """Connected labels for n items joined by pairs (a[i], b[i]) - numpy union-find."""
    parent = np.arange(n, dtype=np.int64)
    if len(a):
        for _round in range(64):
            pa, pb = parent[a], parent[b]
            if np.array_equal(pa, pb):
                break
            lo = np.minimum(pa, pb)
            hi = np.maximum(pa, pb)
            np.minimum.at(parent, hi, lo)
            while True:
                gp = parent[parent]
                if np.array_equal(gp, parent):
                    break
                parent = gp
    _u, labels = np.unique(parent, return_inverse=True)
    return labels


def _face_pairs(me):
    """Faces sharing an edge, found by POSITION (works on meshes whose seams are not
    welded). Returns face_a, face_b, edge end ids (welded) and the welded coordinates."""
    co = _mesh_co(me)
    lv, ls, lt, nxt, pol = _poly_topology(me)
    if len(co) == 0 or len(lv) == 0:
        z = np.zeros(0, dtype=np.int64)
        return z, z, z, z, co
    span = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    q = np.round(co / (span * 1e-6)).astype(np.int64)
    # weld by position with ONE int64 key per vertex (same grouping and order as
    # np.unique(q, axis=0), a fraction of its memory): every axis spans <= ~1e6
    # steps, so x*R*R + y*R + z stays far below 2**63
    q -= q.min(axis=0)
    R = int(q.max()) + 1
    if R ** 3 < 2 ** 62:
        key1 = (q[:, 0] * R + q[:, 1]) * R + q[:, 2]
        del q
        nw_keys, uid = np.unique(key1, return_inverse=True)
        del key1
        n_w = len(nw_keys)
    else:
        wco_keys, uid = np.unique(q, axis=0, return_inverse=True)
        n_w = len(wco_keys)
    uid = uid.ravel()
    wco = np.zeros((n_w, 3))
    np.add.at(wco, uid, co)
    wco /= np.maximum(np.bincount(uid, minlength=n_w), 1)[:, None]
    # per-loop arrays are the big ones: drop each as soon as it is used
    a, b = uid[lv], uid[lv[nxt]]
    del lv, nxt, ls, lt, uid
    lo, hi = np.minimum(a, b), np.maximum(a, b)
    del a, b
    keep = np.flatnonzero(lo != hi)
    lo, hi, pk = lo[keep], hi[keep], pol[keep]
    del keep, pol
    key = lo * n_w + hi
    order = np.argsort(key, kind='stable')
    key, pk = key[order], pk[order]
    lo_k, hi_k = lo[order], hi[order]
    del lo, hi, order
    start = np.ones(len(key), dtype=bool)
    start[1:] = key[1:] != key[:-1]
    sidx = np.flatnonzero(start)
    cnt = np.diff(np.append(sidx, len(key)))
    two = sidx[cnt == 2]
    return pk[two], pk[two + 1], lo_k[two], hi_k[two], wco


AREA_JUNCTION = 9.0    # concave curvature (x model size) that counts as a real junction
AREA_CONVEX = 0.12     # convex bends weigh this much: rounded shells are NOT cut
AREA_CREASE = 18.0     # a sharp crease (above Sharp Angle) is always a strong border
AREA_TINY = 0.0015     # regions below this fraction of the surface are merged first
AREA_COMPACT = 0.7      # preference for compact areas (0 = none)
AREA_REFINE = 12       # passes that pull borders into the valleys
AREA_SMOOTH = 8        # passes that even out soft borders


def _segment_areas(me, angle, n_areas):
    """Split a surface into areas the way a modeller would (1.6.3).

    Borders go where the shape really changes: sharp creases and concave
    junctions (where a fender meets the body, a post meets the wing...).
    Smooth or convex surfaces are never cut just to reach a count, so a round
    nose stays one area.  `n_areas` is the maximum: a simple model gets fewer.
    Separate pieces always stay separate areas.

    1. curvature of every edge from scale-aware smoothed normals
       (concave = strong border, convex = weak, crease = always a border)
    2. small compact patches ("superfaces") grown on the surface
    3. patches merged, weakest shared border first (average strength along
       the border, so one noisy edge never decides)
    4. borders pulled into the valleys, crumbs merged into their neighbour
    """
    nf = len(me.polygons)
    if nf == 0:
        return np.zeros(0, dtype=np.int64)
    # 1.6.5: separate pieces are always their own area, so they do not use up the
    # budget - Max Areas is what the surfaces themselves may be divided into
    try:
        _vc = _components(me)
        _fv = np.empty(len(me.loops), dtype=np.int64)
        me.loops.foreach_get("vertex_index", _fv)
        _ls = np.empty(nf, dtype=np.int64)
        me.polygons.foreach_get("loop_start", _ls)
        n_pieces = int(len(np.unique(_vc[_fv[_ls]])))
    except Exception:
        n_pieces = 1
    n_areas = int(n_areas) + max(0, n_pieces - 1)
    fn = np.empty(nf * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    fc = np.empty(nf * 3)
    me.polygons.foreach_get("center", fc)
    fc = fc.reshape(-1, 3)
    fa = np.empty(nf)
    me.polygons.foreach_get("area", fa)
    f0, f1, ea, eb, wco = _face_pairs(me)
    if len(f0) == 0:
        return np.arange(nf, dtype=np.int64)
    diag = float(np.linalg.norm(fc.max(axis=0) - fc.min(axis=0))) or 1.0
    total = float(fa.sum()) or 1.0
    elen = np.linalg.norm(wco[ea] - wco[eb], axis=1)

    # ---- 1. edge strength -------------------------------------------------
    crease = np.einsum('ij,ij->i', fn[f0], fn[f1]) < math.cos(angle)
    sm = ~crease
    a0, a1 = f0[sm], f1[sm]
    fns = fn.copy()
    iters = int(np.clip(round(math.sqrt(nf) / 25.0), 4, 24))   # denser mesh -> wider smoothing
    for _it in range(iters):
        acc = fns.copy()
        for k in range(3):
            acc[:, k] += (np.bincount(a0, weights=fns[a1, k], minlength=nf)
                          + np.bincount(a1, weights=fns[a0, k], minlength=nf))
        ln = np.linalg.norm(acc, axis=1)
        ln[ln == 0] = 1.0
        fns = acc / ln[:, None]
    d = fc[f1] - fc[f0]
    dist = np.maximum(np.linalg.norm(d, axis=1), diag * 1e-7)
    th = np.arccos(np.einsum('ij,ij->i', fns[f0], fns[f1]).clip(-1.0, 1.0))
    concave = np.einsum('ij,ij->i', fns[f1] - fns[f0], d) < 0.0
    w = th / dist * diag * np.where(concave, 1.0, AREA_CONVEX)
    w[crease] = np.maximum(w[crease], AREA_CREASE)
    del fns, d, dist, th, concave

    # ---- 2. superfaces: compact patches grown from random seeds -------------
    rng = np.random.default_rng(0)
    m = int(min(nf, np.clip(nf // 40, 300, 5000)))
    sup = np.full(nf, -1, dtype=np.int64)
    sup[rng.choice(nf, size=m, replace=False)] = np.arange(m)
    nxt_id = m
    A = np.concatenate([a0, a1])          # grow across smooth edges only:
    B = np.concatenate([a1, a0])          # a patch never straddles a crease
    for _guard in range(10000):
        grow = (sup[A] < 0) & (sup[B] >= 0)
        if grow.any():
            sup[A[grow]] = sup[B[grow]]
            continue
        rest = np.flatnonzero(sup < 0)
        if len(rest) == 0:
            break
        k = max(1, len(rest) // 40)
        pick = rest[rng.choice(len(rest), size=k, replace=False)]
        sup[pick] = np.arange(nxt_id, nxt_id + k)
        nxt_id += k
    sup[sup < 0] = np.arange(nxt_id, nxt_id + int((sup < 0).sum()))
    _u, sup = np.unique(sup, return_inverse=True)
    sup = sup.ravel()
    m = int(sup.max()) + 1

    # ---- 3. merge patches, weakest border first -----------------------------
    sa, sb = sup[f0], sup[f1]
    cross = sa != sb
    lo = np.minimum(sa[cross], sb[cross])
    hi = np.maximum(sa[cross], sb[cross])
    key, inv = np.unique(lo * m + hi, return_inverse=True)
    inv = inv.ravel()
    wl = np.bincount(inv, weights=(w * elen)[cross])
    ll = np.bincount(inv, weights=elen[cross])
    area = np.bincount(sup, weights=fa, minlength=m).tolist()
    perim = (np.bincount(sa[cross], weights=elen[cross], minlength=m)
             + np.bincount(sb[cross], weights=elen[cross], minlength=m)).tolist()
    nb = [dict() for _ in range(m)]
    for x, y, s1, s2 in zip((key // m).tolist(), (key % m).tolist(), wl.tolist(), ll.tolist()):
        nb[x][y] = (s1, s2)
        nb[y][x] = (s1, s2)
    tiny = total * AREA_TINY
    ver = [0] * m
    parent = list(range(m))
    heap = []

    def push(x, y):
        s1, s2 = nb[x][y]
        avg = s1 / max(s2, 1e-12)
        # compact shapes: a patch that is mostly wrapped by its neighbour joins it first
        wrap = s2 / max(min(perim[x], perim[y]), 1e-12)
        # 1.6.5: not across a real crease - a lip / bumper wrapped all round by a
        # sharp edge is a separate part of the design, not a crumb to absorb
        compact = AREA_COMPACT if avg < AREA_CREASE * 0.75 else 0.0
        eff = avg * (1.0 - compact * min(wrap, 1.0))
        if min(area[x], area[y]) < tiny:
            eff *= 0.001
        heapq.heappush(heap, (eff, avg, x, y, ver[x], ver[y]))

    for x in range(m):
        for y in nb[x]:
            if x < y:
                push(x, y)
    count = m
    while heap:
        eff, avg, x, y, vx, vy = heapq.heappop(heap)
        if ver[x] != vx or ver[y] != vy or nb[x] is None or nb[y] is None:
            continue
        small = min(area[x], area[y]) < tiny
        if count <= n_areas and not small and avg >= AREA_JUNCTION:
            break
        if len(nb[x]) < len(nb[y]):
            x, y = y, x
        for z, (s1, s2) in nb[y].items():
            if z == x:
                continue
            del nb[z][y]
            if z in nb[x]:
                t1, t2 = nb[x][z]
                nb[x][z] = (t1 + s1, t2 + s2)
            else:
                nb[x][z] = (s1, s2)
            nb[z][x] = nb[x][z]
        shared = nb[x][y][1]
        del nb[x][y]
        nb[y] = None
        area[x] += area[y]
        perim[x] += perim[y] - 2.0 * shared
        parent[y] = x
        ver[x] += 1
        count -= 1
        for z in nb[x]:
            push(x, z)
    par = np.array(parent, dtype=np.int64)
    for _r in range(64):
        pp = par[par]
        if np.array_equal(pp, par):
            break
        par = pp
    _u, lab = np.unique(par[sup], return_inverse=True)
    lab = lab.ravel()

    # ---- 4a. pull borders into the valleys -----------------------------------
    aff = np.exp(-w / (AREA_JUNCTION * 0.5))
    F = np.concatenate([f0, f1])
    Nb = np.concatenate([f1, f0])
    Af = np.concatenate([aff, aff])
    for _it in range(AREA_REFINE):
        nl = int(lab.max()) + 1
        uk, inv = np.unique(F * nl + lab[Nb], return_inverse=True)
        sc = np.bincount(inv.ravel(), weights=Af)
        kf, kl = uk // nl, uk % nl
        own = np.zeros(nf)
        mine = kl == lab[kf]
        own[kf[mine]] = sc[mine]
        order = np.lexsort((-sc, kf))
        kf, kl, sc = kf[order], kl[order], sc[order]
        first = np.ones(len(kf), dtype=bool)
        first[1:] = kf[1:] != kf[:-1]
        bf, bl, bs = kf[first], kl[first], sc[first]
        flip = (bl != lab[bf]) & (bs > own[bf] * 1.05 + 1e-12)
        if not flip.any():
            break
        lab = lab.copy()
        lab[bf[flip]] = bl[flip]

    # ---- 4b. crumbs: fragments cut off by 4a join the neighbour they touch most
    for _pass in range(3):
        same = lab[f0] == lab[f1]
        frag = _uf_labels(nf, f0[same], f1[same])
        nfr = int(frag.max()) + 1
        fr_area = np.bincount(frag, weights=fa, minlength=nfr)
        fr_lab = np.zeros(nfr, dtype=np.int64)
        fr_lab[frag] = lab
        big = np.zeros(int(lab.max()) + 1)
        np.maximum.at(big, fr_lab, fr_area)
        crumb = (fr_area < big[fr_lab] * 0.5) | (fr_area < tiny)
        if not crumb.any():
            break
        x, y = frag[f0[~same]], frag[f1[~same]]
        L2 = elen[~same]
        xs = np.concatenate([x, y]); ys = np.concatenate([y, x]); ws = np.concatenate([L2, L2])
        keep = crumb[xs]
        if not keep.any():
            break
        uk, inv = np.unique(xs[keep] * nfr + ys[keep], return_inverse=True)
        sl = np.bincount(inv.ravel(), weights=ws[keep])
        kx, ky = uk // nfr, uk % nfr
        order = np.lexsort((-sl, kx))
        kx, ky = kx[order], ky[order]
        first = np.ones(len(kx), dtype=bool)
        first[1:] = kx[1:] != kx[:-1]
        new_lab = fr_lab.copy()
        new_lab[kx[first]] = fr_lab[ky[first]]
        if np.array_equal(new_lab, fr_lab):
            break
        lab = new_lab[frag]
    # ---- 4c. even out the borders that are not creases (majority of neighbours)
    Fs = np.concatenate([a0, a1])
    Ns = np.concatenate([a1, a0])
    deg = np.bincount(Fs, minlength=nf)
    for _it in range(AREA_SMOOTH):
        nl = int(lab.max()) + 1
        uk, cnt = np.unique(Fs * nl + lab[Ns], return_counts=True)
        kf, kl = uk // nl, uk % nl
        order = np.lexsort((-cnt, kf))
        kf, kl, cnt = kf[order], kl[order], cnt[order]
        first = np.ones(len(kf), dtype=bool)
        first[1:] = kf[1:] != kf[:-1]
        bf, bl, bc = kf[first], kl[first], cnt[first]
        flip = (bl != lab[bf]) & ((bc * 2 > deg[bf]) | ((bc * 2 == deg[bf]) & (_it == 0)))
        if not flip.any():
            break
        lab = lab.copy()
        lab[bf[flip]] = bl[flip]
    _u, lab = np.unique(lab, return_inverse=True)
    return lab.ravel()


def _area_palette(n):
    cols = np.empty((n, 4), dtype=np.float32)
    for i in range(n):
        h = (i * 0.61803398875) % 1.0
        c = Color()
        c.hsv = (h, 0.55, 0.95)
        cols[i] = (c.r, c.g, c.b, 1.0)
    return cols


# --------------------------------------------------------------------------
#  1.6.4  Mirror-aware areas
#  Areas are worked out on one half of a symmetric model and mirrored onto the
#  other half, so left and right are identical.  An area that crosses the mirror
#  plane (hood, wing) stays one area; an area on one side gets a twin on the
#  other side.  Twins share one colour and one material and are named .L / .R.
# --------------------------------------------------------------------------
SIDE_NAMES = {0: (".L", ".R"), 1: (".Back", ".Front"), 2: (".Top", ".Bottom")}


def _find_mirror_plane(me, mode):
    """(axis index, plane position) of the mirror plane of `me`, or (-1, 0.0).
    Same rule as REMESH: the plane passes through the object origin or through
    the middle of the model."""
    if mode == 'NONE' or len(me.polygons) == 0:
        return -1, 0.0
    co = _mesh_co(me)
    if len(co) < 8:
        return -1, 0.0
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    mid = (co.min(axis=0) + co.max(axis=0)) * 0.5
    probe = _bvh_from_mesh(me)
    axes = "XYZ" if mode == 'AUTO' else mode
    for plane in ("origin", "middle"):
        for ax in axes:
            ai = "XYZ".index(ax)
            c = 0.0 if plane == "origin" else float(mid[ai])
            shifted = co.copy()
            shifted[:, ai] -= c
            bvh_s = probe if c == 0.0 else _bvh_from_mesh_shift(me, ai, c)
            if _is_symmetric(shifted, bvh_s, diag, ai):
                return ai, c
    if mode != 'AUTO':
        return "XYZ".index(mode), 0.0
    return -1, 0.0


def _face_centers_areas(me, lin=None):
    nf = len(me.polygons)
    cen = np.empty(nf * 3)
    me.polygons.foreach_get("center", cen)
    cen = cen.reshape(-1, 3)
    fa = np.empty(nf)
    me.polygons.foreach_get("area", fa)
    if lin is not None:
        cen = cen @ np.array(lin).T
    return cen, fa


def _mirror_lookup(me, lin, axis_i, c):
    """For every face on the negative side of the plane: the face on the positive
    side it mirrors onto.  Returns (positive mask, negative face ids, their partner)."""
    co, lv, ls, lt = _mesh_arrays(me)
    if lin is not None:
        co = co @ np.array(lin).T
    cen, _fa = _face_centers_areas(me, lin)
    x = cen[:, axis_i] - c
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    pos = x >= -diag * 1e-5
    pos_ids = np.flatnonzero(pos)
    neg_ids = np.flatnonzero(~pos)
    if len(pos_ids) == 0 or len(neg_ids) == 0:
        return pos, neg_ids, np.zeros(0, dtype=np.int64)
    idx = _loop_ranges(ls[pos_ids], lt[pos_ids])
    half = _build_mesh(co, lv[idx], lt[pos_ids])
    bvh = _bvh_from_mesh(half)
    bpy.data.meshes.remove(half)
    q = cen[neg_ids].copy()
    q[:, axis_i] = 2.0 * c - q[:, axis_i]
    partner = np.empty(len(neg_ids), dtype=np.int64)
    fn = bvh.find_nearest
    for k, p in enumerate(q.tolist()):
        r = fn(p)
        partner[k] = pos_ids[r[2]] if r[2] is not None else -1
    return pos, neg_ids, partner


def _mirror_area_labels(me, lab, axis_i, c):
    """Make segmentation labels mirror-symmetric (mesh already in world proportions).
    Returns labels, twin[label], side[label] (0 centre, +1 / -1)."""
    lab = np.asarray(lab, dtype=np.int64)
    pos, neg_ids, partner = _mirror_lookup(me, None, axis_i, c)
    n0 = int(lab.max()) + 1 if len(lab) else 0
    if len(neg_ids) == 0 or n0 == 0:
        return lab, np.arange(n0), np.zeros(n0, dtype=np.int64)
    _cen, fa = _face_centers_areas(me)
    co, lv, ls, lt = _mesh_arrays(me)
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    # a face touches the plane when one of its corners lies on it (or it crosses it)
    vx = co[lv, axis_i] - c
    touch = np.minimum.reduceat(np.abs(vx), ls) <= diag * 1e-4
    touch |= (np.minimum.reduceat(vx, ls) < 0.0) & (np.maximum.reduceat(vx, ls) > 0.0)
    tot = np.bincount(lab[pos], weights=fa[pos], minlength=n0)
    near = pos & touch
    inb = np.bincount(lab[near], weights=fa[near], minlength=n0)
    # an area that runs along the plane (hood, wing, chin) is one centre area
    centre = (tot > 0) & (inb >= 0.01 * tot)
    twin_id = np.arange(n0) + n0                 # provisional id of each label's twin
    new = lab.copy()
    ok = partner >= 0
    src_lab = lab[partner[ok]]
    new[neg_ids[ok]] = np.where(centre[src_lab], src_lab, twin_id[src_lab])
    # faces with no partner (asymmetric spot) keep a label of the positive side
    bad = neg_ids[~ok]
    if len(bad):
        new[bad] = lab[pos][0]
    u, comp = np.unique(new, return_inverse=True)
    comp = comp.ravel()
    remap = -np.ones(2 * n0, dtype=np.int64)
    remap[u] = np.arange(len(u))
    n = len(u)
    twin = np.arange(n)
    side = np.zeros(n, dtype=np.int64)
    for L in range(n0):
        a, b = remap[L], remap[twin_id[L]]
        if a < 0:
            continue
        if centre[L] or b < 0:
            continue
        twin[a], twin[b] = b, a
        side[a], side[b] = 1, -1
    for L in range(n0, 2 * n0):              # a twin whose source vanished: plain area
        b = remap[L]
        if b >= 0 and twin[b] == b:
            side[b] = 0
    return comp, twin, side


def _area_groups(lab, fa, twin):
    """Colour group of every label: twins share one; biggest group first."""
    n = len(twin)
    size = np.bincount(lab, weights=fa, minlength=n)
    gsize = size + np.where(twin != np.arange(n), size[twin], 0.0)
    group = -np.ones(n, dtype=np.int64)
    g = 0
    for L in np.argsort(-gsize, kind='stable'):
        if group[L] >= 0:
            continue
        group[L] = g
        group[twin[L]] = g
        g += 1
    return group


def _area_meta(ao):
    """twin, side, group arrays, axis, plane of an areas object (defaults for old files)."""
    me = ao.data
    lab = np.empty(len(me.polygons), dtype=np.int32)
    me.attributes["ru_area"].data.foreach_get("value", lab)
    n = int(lab.max()) + 1 if len(lab) else 1
    twin = np.array(ao.get("ru_twin", []), dtype=np.int64)
    side = np.array(ao.get("ru_side", []), dtype=np.int64)
    group = np.array(ao.get("ru_group", []), dtype=np.int64)
    if len(twin) != n or len(side) != n or len(group) != n:
        twin = np.arange(n)
        side = np.zeros(n, dtype=np.int64)
        group = np.arange(n)
    return dict(lab=lab, twin=twin, side=side, group=group, n=n,
                axis=int(ao.get("ru_sym_axis", -1)), c=float(ao.get("ru_sym_c", 0.0)),
                ngroups=int(group.max()) + 1 if len(group) else 1)


def _mirror_result_labels(src, me, lab, meta):
    """Copy the labels of the positive half of a result onto its negative half
    (through the twin table), so twin parts match quad for quad."""
    if meta["axis"] < 0 or len(lab) == 0:
        return lab
    lin = _work_matrix(src)
    pos, neg_ids, partner = _mirror_lookup(me, lin, meta["axis"], meta["c"])
    ok = partner >= 0
    lab = np.asarray(lab, dtype=np.int64).copy()
    lab[neg_ids[ok]] = meta["twin"][lab[partner[ok]]]
    return lab


def _side_suffix(meta, L):
    sd = int(meta["side"][L])
    if sd == 0 or meta["axis"] < 0:
        return ""
    names = SIDE_NAMES.get(meta["axis"], (".A", ".B"))
    return names[0] if sd > 0 else names[1]


def _corner_normals(me):
    """Per-corner shading normals of the whole mesh (None if unavailable)."""
    try:
        cn = np.empty(len(me.loops) * 3)
        me.corner_normals.foreach_get("vector", cn)
        return cn.reshape(-1, 3)
    except Exception:
        return None


def _apply_corner_normals(m, cn_part):
    """Give a split-off part the shading of the whole model: no seams between parts."""
    if cn_part is None:
        return False
    try:
        m.polygons.foreach_set("use_smooth", np.ones(len(m.polygons), dtype=bool))
        m.normals_split_custom_set(cn_part.astype(np.float32))
        return True
    except Exception as ex:
        print("[Remesh Ultimate] custom normals:", ex)
        return False


def _areas_obj(src):
    return bpy.data.objects.get(src.name + AREAS_SUFFIX)


def _lines_obj(src):
    return bpy.data.objects.get(src.name + LINES_SUFFIX)


def _selected_sources(context):
    """1.6.8: every selected model (active first), never a result or a helper twice."""
    out = []
    obs = list(context.selected_objects)
    if context.active_object is not None:
        obs.insert(0, context.active_object)
    for o in obs:
        o = _source_of(o)
        if (o is not None and o.type == 'MESH' and "ru_source" not in o
                and o not in out):
            out.append(o)
    return out


def _source_of(ob):
    if ob is None:
        return None
    s = ob.get("ru_helper_of") or ob.get("ru_area_of")
    if s:
        return bpy.data.objects.get(s)
    return ob


def _guide_segments(src, lin, offset, areas=True):
    """Area borders + drawn lines of `src`, in the remesh working space."""
    A, B = [], []
    M = lin.to_4x4()
    ao = _areas_obj(src) if areas else None
    if ao is not None and "ru_area" in ao.data.attributes:
        me = ao.data
        lab = np.empty(len(me.polygons), dtype=np.int32)
        me.attributes["ru_area"].data.foreach_get("value", lab)
        f0, f1, ea, eb, co = _face_pairs(me)
        diffm = lab[f0] != lab[f1]
        # relax the soft (curvature) borders so the guides are smooth curves;
        # real creases and junctions stay exactly where they are
        fn = np.empty(len(me.polygons) * 3)
        me.polygons.foreach_get("normal", fn)
        fn = fn.reshape(-1, 3)
        dots = np.einsum('ij,ij->i', fn[f0[diffm]], fn[f1[diffm]])
        hardcut = dots < math.cos(math.radians(30.0))
        ce = np.stack([ea[diffm], eb[diffm]], axis=1)
        nv = len(co)
        dg_ = np.bincount(ce.ravel(), minlength=nv)
        pinned = np.zeros(nv, dtype=bool)
        pinned[ce[hardcut].ravel()] = True
        movable = (dg_ == 2) & ~pinned
        if movable.any():
            bvh_a = _bvh_from_mesh(me)
            pos = co.copy()
            for _it in range(25):
                acc = np.zeros_like(pos)
                np.add.at(acc, ce[:, 0], pos[ce[:, 1]])
                np.add.at(acc, ce[:, 1], pos[ce[:, 0]])
                avg = acc / np.maximum(dg_, 1)[:, None]
                mv = np.flatnonzero(movable)
                pos[mv] = pos[mv] * 0.5 + avg[mv] * 0.5
                if _it % 5 == 4:
                    for i in mv:
                        r = bvh_a.find_nearest(Vector(pos[i]))
                        if r[0] is not None:
                            pos[i] = r[0]
            co = pos
        # only real creases between areas guide the quads; soft (curvature) borders are
        # for organisation - forcing loops onto them would ripple smooth surfaces
        if hardcut.any():
            A.append(co[ce[hardcut, 0]])
            B.append(co[ce[hardcut, 1]])
    lo = _lines_obj(src)
    if lo is not None and len(lo.data.edges):
        co = _mesh_co(lo.data)
        ed = _mesh_edges(lo.data)
        A.append(co[ed[:, 0]])
        B.append(co[ed[:, 1]])
    if not A:
        return None
    A = np.concatenate(A)
    if len(A) == 0:
        return None
    B = np.concatenate(B)
    R = np.array(lin)
    A = A @ R.T - np.array(offset)
    B = B @ R.T - np.array(offset)
    return A, B


def _make_areas(context, src, s):
    """Create (or replace) the coloured area preview object of `src`."""
    old = _areas_obj(src)
    if old is not None:
        m = old.data
        bpy.data.objects.remove(old, do_unlink=True)
        if m.users == 0:
            bpy.data.meshes.remove(m)
    dg = context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(src.evaluated_get(dg), preserve_all_data_layers=False,
                                         depsgraph=dg)
    me.name = src.name + AREAS_SUFFIX
    tmp = me.copy()
    _wm = _work_matrix(src)
    tmp.transform(_wm.to_4x4())
    if _wm.determinant() < 0.0:
        # 1.6.5: a mirrored object (negative scale) turns its faces inside out
        # once transformed - concave and convex would swap and the borders go to
        # the wrong places (a bumper melted into the hood)
        tmp.flip_normals()
    lab = _segment_areas(tmp, s.sharp_angle, s.area_count)
    axis_i, c = _find_mirror_plane(tmp, s.symmetry) if len(lab) else (-1, 0.0)
    if axis_i >= 0:
        lab, twin, side = _mirror_area_labels(tmp, lab, axis_i, c)
    else:
        n0 = int(lab.max()) + 1 if len(lab) else 0
        twin, side = np.arange(n0), np.zeros(n0, dtype=np.int64)
    _cen, fa = _face_centers_areas(tmp)
    bpy.data.meshes.remove(tmp)
    group = _area_groups(lab, fa, twin) if len(lab) else np.zeros(0, dtype=np.int64)
    n = int(lab.max()) + 1 if len(lab) else 0
    at = me.attributes.new("ru_area", 'INT', 'FACE')
    at.data.foreach_set("value", lab.astype(np.int32))
    col = me.color_attributes.new("RU_Areas", 'BYTE_COLOR', 'CORNER')
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    pal = _area_palette(max(int(group.max()) + 1 if len(group) else 1, 1))
    if len(lab):
        col.data.foreach_set("color", np.repeat(pal[group[lab]], lt, axis=0).ravel())
    me.color_attributes.active_color = col
    ob = bpy.data.objects.new(src.name + AREAS_SUFFIX, me)
    ob.matrix_world = src.matrix_world
    ob["ru_helper_of"] = src.name
    ob["ru_twin"] = [int(v) for v in twin]
    ob["ru_side"] = [int(v) for v in side]
    ob["ru_group"] = [int(v) for v in group]
    ob["ru_sym_axis"] = int(axis_i)
    ob["ru_sym_c"] = float(c)
    for cl in src.users_collection:
        cl.objects.link(ob)
    return ob, n


def _face_areas(me):
    fa = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", fa)
    return fa


def _crease_mask(me, pairs, angle=math.radians(40.0)):
    """Edge pairs (from _face_pairs) that sit on a real crease of the result."""
    f0, f1 = pairs[:2]
    if len(f0) == 0:
        return np.zeros(0, dtype=bool)
    fn = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    return np.abs(np.einsum('ij,ij->i', fn[f0], fn[f1])) < math.cos(angle)


def _classify_faces(me, abvh, alab, pairs=None):
    """Which source area each new quad belongs to.

    The centre alone misreads thin plates and the seams where two areas meet,
    so a face votes with its centre (weight 3) plus its corners pulled in towards
    that centre (weight 1 each), and the label with most votes wins (the centre
    wins ties).

    Sparse version (1.6.2): memory is O(faces), never O(faces x areas).  Every
    face casts its centre; only faces near a border (a neighbour got another
    label, or the centre missed) and their neighbours cast the extra corner
    votes - inside an area all votes would agree anyway.
    """
    nf = len(me.polygons)
    if nf == 0:
        return np.zeros(0, dtype=np.int64)
    co = _mesh_co(me)
    lv, ls, lt, _nxt, _pol = _poly_topology(me)
    cen = np.empty(nf * 3)
    me.polygons.foreach_get("center", cen)
    cen = cen.reshape(-1, 3)
    alab = np.asarray(alab, dtype=np.int32)
    fno = np.empty(nf * 3)
    me.polygons.foreach_get("normal", fno)
    fno = fno.reshape(-1, 3)
    span = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) if len(co) else 1.0
    reach = max(math.sqrt(max(float(np.median(_face_areas(me))), 1e-18)) * 1.5, span * 1e-4)

    # 1.6.4 thin plates (a wing, a fin): the nearest original face can be the one on
    # the far side.  Pick the nearest face that looks the same way as the quad.
    # The quads may be wound the other way round as a whole: measure that first.
    probe = np.arange(0, nf, max(1, nf // 500))
    agree = 0
    for i in probe.tolist():
        r = abvh.find_nearest(cen[i].tolist())
        if r[1] is not None and r[1].dot(Vector(fno[i])) > 0.0:
            agree += 1
    sign = 1.0 if agree >= len(probe) * 0.5 else -1.0

    def cast(points, normals):
        out = np.full(len(points), -1, dtype=np.int32)
        fn = abvh.find_nearest
        fr = abvh.find_nearest_range
        for i, pt in enumerate(points.tolist()):
            r = fn(pt)
            if r[2] is None:
                continue
            hit = r[2]
            nrm = Vector(normals[i]) * sign
            if r[1].dot(nrm) < -0.5:
                best = None
                for loc_, n_, ix_, d_ in fr(pt, max(r[3] * 1.01, reach)):
                    if ix_ is not None and n_.dot(nrm) > 0.5 and (best is None or d_ < best[1]):
                        best = (ix_, d_)
                if best is not None:
                    hit = best[0]
            out[i] = alab[hit]
        return out

    lab_c = cast(cen, fno)

    # faces whose label is uncertain: centre missed or a neighbour disagrees,
    # grown by one ring so both sides of every border are re-checked
    f0, f1 = (pairs if pairs is not None else _face_pairs(me))[:2]
    cand = lab_c < 0
    if len(f0):
        diff = lab_c[f0] != lab_c[f1]
        cand[f0[diff]] = True
        cand[f1[diff]] = True
        ring = cand.copy()
        ring[f0[cand[f1]]] = True
        ring[f1[cand[f0]]] = True
        cand = ring
    idx_c = np.flatnonzero(cand)
    lab = lab_c.astype(np.int64)
    if len(idx_c) == 0:
        lab[lab < 0] = 0
        return lab

    # votes of the candidate faces only: (k, 5) labels + (5,) weights
    n_cols = 1 + min(int(lt.max()), 4)
    L = np.full((len(idx_c), n_cols), -1, dtype=np.int32)
    L[:, 0] = lab_c[idx_c]
    W = np.array([3] + [1] * (n_cols - 1), dtype=np.int32)
    s_ls, s_lt, s_cen = ls[idx_c], lt[idx_c], cen[idx_c]
    for c in range(n_cols - 1):
        vi = lv[np.minimum(s_ls + c, s_ls + s_lt - 1)]
        L[:, c + 1] = cast(co[vi] * 0.35 + s_cen * 0.65, fno[idx_c])

    # weighted mode per row: score of column j = total weight of columns with the same label
    valid = L >= 0
    score = np.zeros(L.shape, dtype=np.int32)
    for j in range(n_cols):
        same = (L == L[:, j:j + 1]) & valid
        score[:, j] = (same * W).sum(axis=1)
    score[~valid] = -1
    best = L[np.arange(len(idx_c)), score.argmax(axis=1)]   # argmax: first column (centre) wins ties
    lab[idx_c] = best
    lab[lab < 0] = 0
    return lab


def _result_labels(src, res, ao, meta):
    am = ao.data
    abvh = _bvh_from_mesh(am)
    rm = res.data
    pairs = _face_pairs(rm)
    lab = _smooth_labels(rm, _classify_faces(rm, abvh, meta["lab"], pairs), pairs=pairs,
                         crease=_crease_mask(rm, pairs))
    del pairs
    return _mirror_result_labels(src, rm, lab, meta)


def _colour_single_mesh(context, src, res, ao):
    """One continuous mesh, every area painted with its own material (twins share one)."""
    meta = _area_meta(ao)
    rm = res.data
    lab = _result_labels(src, res, ao, meta)
    grp = meta["group"][lab]
    used = np.unique(grp)
    pal = _area_palette(max(meta["ngroups"], 1))
    rm.materials.clear()
    slot = {}
    for i, g in enumerate(used):
        rm.materials.append(_part_material(int(g), pal[g], src.name))
        slot[int(g)] = i
    midx = np.array([slot[int(g)] for g in grp], dtype=np.int32)
    rm.polygons.foreach_set("material_index", midx)
    rm.update()
    return len(np.unique(lab))


def _split_result_by_areas(context, src, res, ao):
    """Give every quad of `res` the area it lies on and deliver one object per area."""
    meta = _area_meta(ao)
    rm = res.data
    lab = _result_labels(src, res, ao, meta)
    coll, made = _split_into_collection(context, src, rm, lab, src.name + "_QUAD_AREAS",
                                        "Quad", meta)
    for o in made:
        o["ru_source"] = src.name
        o["ru_report"] = res.get("ru_report", "")
        o["ru_score"] = res.get("ru_score", 0.0)
    bpy.data.objects.remove(res, do_unlink=True)
    if rm.users == 0:
        bpy.data.meshes.remove(rm)
    return coll, made


def _screen_areas(context):
    """3D View areas of the current screen; empty when there is no screen
    (scripts, MCP, background) so no operator fails just because of the UI."""
    screen = getattr(context, "screen", None)
    return list(screen.areas) if screen is not None else []


def _show_material_colours(context):
    """Solid view shows the material colour, so Solid, Material Preview and
    Rendered all agree; Wireframe draws every part's wires in its own colour
    (1.6.7).  Safe without a screen (scripts, MCP, background)."""
    for area in _screen_areas(context):
        if area.type != 'VIEW_3D':
            continue
        sh = area.spaces.active.shading
        try:
            sh.wireframe_color_type = 'OBJECT'
        except Exception:
            pass
        if sh.type == 'SOLID':
            try:
                sh.color_type = 'MATERIAL'
            except Exception:
                try:
                    sh.color_type = 'OBJECT'
                except Exception:
                    pass


def _show_object_colours(context):
    _show_material_colours(context)


class RU_OT_detect_areas(Operator):
    bl_idname = "remesh_ultimate.detect_areas"
    bl_label = "Detect Areas"
    bl_description = ("Split the model into coloured areas (along creases and curvature changes). "
                      "REMESH will make the quad flow follow every area border")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_sources(context))

    def execute(self, context):
        s = context.scene.remesh_ultimate
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        made, n, fails = [], 0, []
        for src in _selected_sources(context):
            try:
                ob, k = _make_areas(context, src, s)
            except Exception as ex:
                fails.append("%s (%s)" % (src.name, ex))
                continue
            src.hide_set(True)
            made.append(ob)
            n += k
        for o in context.selected_objects:
            o.select_set(False)
        for ob in made:
            ob.select_set(True)
        if made:
            context.view_layer.objects.active = made[0]
        if fails:
            self.report({'WARNING'}, "No areas for: " + ", ".join(fails))
        for area in _screen_areas(context):
            if area.type == 'VIEW_3D':
                sh = area.spaces.active.shading
                if sh.type == 'SOLID':
                    try:
                        sh.color_type = 'VERTEX'      # "Attribute" colours
                    except TypeError:
                        sh.color_type = 'ATTRIBUTE'
        self.report({'INFO'}, "%d areas on %d object%s" % (n, len(made), "s" if len(made) != 1 else ""))
        return {'FINISHED'}


class RU_OT_areas_to_collection(Operator):
    bl_idname = "remesh_ultimate.areas_to_collection"
    bl_label = "Areas to Collection"
    bl_description = ("Put every detected area in its own object, inside a sub-collection "
                      "named after the model (largest area first)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_sources(context))

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        s = context.scene.remesh_ultimate
        made, names = [], []
        for src in _selected_sources(context):
            ao = _areas_obj(src)
            if ao is None:                          # 1.6.8: detect on the fly
                ao, _n = _make_areas(context, src, s)
            meta = _area_meta(ao)
            cname = src.name + "_AREAS"
            parent = src.users_collection[0] if src.users_collection else context.scene.collection
            coll, part = _split_into_collection(context, src, ao.data, meta["lab"], cname,
                                                "Area", meta, parent=parent, materials=True)
            ao.hide_set(True)
            src.hide_set(True)
            made.extend(part)
            names.append(cname)
        _show_material_colours(context)
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        if made:
            context.view_layer.objects.active = made[0]
        self.report({'INFO'}, "%d areas in %s" % (len(made), ", ".join(names)))
        return {'FINISHED'}


SMOOTH_ITERS = 6          # was 14 in 1.6.1; converges in a few passes, borders no longer creep
SMOOTH_KEEP = 0.75        # an area may lose at most 25% of its faces to smoothing
SMOOTH_FREEZE = 12        # areas this small (in faces) are never touched


def _smooth_labels(me, lab, iters=SMOOTH_ITERS, pairs=None, crease=None):
    """Majority vote of edge neighbours: removes staircase borders between labels.

    Protected (1.6.2): smoothing cleans stray specks and jagged borders but can
    never erase an area or eat into it - every label keeps at least
    SMOOTH_KEEP of its faces, and tiny areas (<= SMOOTH_FREEZE faces) are frozen.
    Specks of a big area can still be cleaned, because the budget is per area,
    not per speck.
    """
    lab = np.asarray(lab, dtype=np.int64).copy()
    nf = len(me.polygons)
    if nf == 0 or len(lab) == 0:
        return lab
    f0, f1 = (pairs if pairs is not None else _face_pairs(me))[:2]
    if len(f0) == 0:
        return lab
    if crease is not None and len(crease) == len(f0) and crease.any():
        # 1.6.4: a border that sits on a real crease is geometry, not noise -
        # faces never take a label from across a crease
        f0, f1 = f0[~crease], f1[~crease]
        if len(f0) == 0:
            return lab
    F = np.concatenate([f0, f1])
    Nb = np.concatenate([f1, f0])
    deg = np.bincount(F, minlength=nf)
    nl = int(lab.max()) + 1
    orig = np.bincount(lab, minlength=nl)
    floor = np.where(orig <= SMOOTH_FREEZE, orig,
                     np.ceil(orig * SMOOTH_KEEP).astype(np.int64))
    for it in range(iters):
        key = F * nl + lab[Nb]
        uk, cnt = np.unique(key, return_counts=True)
        kf, kl = uk // nl, uk % nl
        order = np.lexsort((-cnt, kf))
        kf, kl, cnt = kf[order], kl[order], cnt[order]
        first = np.ones(len(kf), dtype=bool)
        first[1:] = kf[1:] != kf[:-1]
        bf, bl, bc = kf[first], kl[first], cnt[first]
        # same-label neighbours of every face: 0 = an isolated speck
        same_n = np.bincount(F[lab[F] == lab[Nb]], minlength=nf)
        speck = (same_n[bf] == 0) & (deg[bf] > 0)
        # strict majority always; a 50/50 tie only on the first pass (straightens
        # staircases once - repeating it makes borders creep); specks always go
        flip = (bl != lab[bf]) & ((bc * 2 > deg[bf]) | ((bc * 2 == deg[bf]) & (it == 0)) | speck)
        if not flip.any():
            break
        # budget: no label may drop below its floor
        cur = np.bincount(lab, minlength=nl)
        lose = lab[bf[flip]]
        loss = np.bincount(lose, minlength=nl)
        over = loss > (cur - floor)
        if over.any():
            flip_idx = np.flatnonzero(flip)
            ok = ~over[lose]
            # over-budget labels: allow only as many flips as the budget leaves
            for l in np.flatnonzero(over):
                room = int(cur[l] - floor[l])
                mine = np.flatnonzero(lose == l)
                if room > 0:
                    ok[mine[:room]] = True
            flip = np.zeros_like(flip)
            flip[flip_idx[ok]] = True
            if not flip.any():
                break
        lab[bf[flip]] = bl[flip]
    return lab


def _part_material(idx, col, owner=""):
    base = re.sub(r"[^0-9A-Za-z_.+-]", "_", str(owner))[:40] or "Part"
    name = "RU_%s_%02d" % (base, idx + 1)
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    rgba = (float(col[0]), float(col[1]), float(col[2]), 1.0)
    mat.diffuse_color = rgba                      # Solid view (Material colour)
    try:
        if not mat.use_nodes:
            mat.use_nodes = True
    except Exception:
        pass
    nt = getattr(mat, "node_tree", None)
    if nt is not None:
        bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if bsdf is None:
            bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            out = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
            if out is None:
                out = nt.nodes.new('ShaderNodeOutputMaterial')
            nt.links.new(bsdf.outputs[0], out.inputs[0])
        bsdf.inputs["Base Color"].default_value = rgba
        try:
            bsdf.inputs["Roughness"].default_value = 0.55
        except Exception:
            pass
    return mat


def _split_into_collection(context, src, me, lab, cname, prefix, meta, parent=None,
                           materials=True):
    """One object per area inside a sub-collection.  Twins (.L / .R) share colour and
    material, and every part keeps the shading of the whole model, so the parts
    look exactly like the unsplit mesh (no shading seams)."""
    co, lv, ls, lt = _mesh_arrays(me)
    lab = np.asarray(lab, dtype=np.int64)
    cn = _corner_normals(me)
    fa = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", fa)
    group = meta["group"]
    coll = bpy.data.collections.get(cname)
    if coll is None:
        coll = bpy.data.collections.new(cname)
        if (parent is None or parent == context.scene.collection
                or parent.name not in bpy.data.collections):
            context.scene.collection.children.link(coll)
        else:
            parent.children.link(coll)
    for o in list(coll.objects):
        m = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if m is not None and m.users == 0:
            bpy.data.meshes.remove(m)
    pal = _area_palette(max(meta["ngroups"], 1))
    # order: biggest colour group first; inside a pair the positive side first
    gsize = np.bincount(group[lab], weights=fa, minlength=meta["ngroups"])
    grank = np.empty(meta["ngroups"], dtype=np.int64)
    grank[np.argsort(-gsize, kind='stable')] = np.arange(meta["ngroups"])
    labels = [int(l) for l in np.unique(lab)]
    labels.sort(key=lambda l: (grank[group[l]], -int(meta["side"][l])))
    s = context.scene.remesh_ultimate
    made = []
    for l in labels:
        faces = np.flatnonzero(lab == l)
        if len(faces) == 0:
            continue
        g = int(group[l])
        idx = _loop_ranges(ls[faces], lt[faces])
        uniq, remap = np.unique(lv[idx], return_inverse=True)
        name = "%s_%s_%02d%s" % (src.name, prefix, grank[g] + 1, _side_suffix(meta, l))
        m = _build_mesh(co[uniq], remap.astype(np.int64), lt[faces], name)
        if not _apply_corner_normals(m, cn[idx] if cn is not None else None):
            m.polygons.foreach_set("use_smooth", np.ones(len(m.polygons), dtype=bool))
            try:
                m.set_sharp_from_angle(angle=max(s.sharp_angle * 1.8, math.radians(55.0)))
            except Exception:
                pass
        ob = bpy.data.objects.new(name, m)
        ob.matrix_world = src.matrix_world
        ob.color = tuple(pal[g])
        ob["ru_area_of"] = src.name
        if materials and s.color_parts:
            m.materials.append(_part_material(g, pal[g], src.name))
        elif materials:
            for slot in src.material_slots:
                if slot.material:
                    m.materials.append(slot.material)
        coll.objects.link(ob)
        made.append(ob)
    return coll, made


class RU_OT_remesh_areas(Operator):
    bl_idname = "remesh_ultimate.remesh_areas"
    bl_label = "Remesh Areas"
    bl_description = ("Remesh the model (following Method: Smart keeps clean hard-surface parts "
                      "exact) and deliver one object per area in a sub-collection. Mirrored areas "
                      "share colour and are named .L / .R")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_sources(context))

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        s = context.scene.remesh_ultimate
        made, lines, fails = [], [], []
        _status(context, "Remesh Ultimate  -  Please wait... Processing...")
        try:
            for src in _selected_sources(context):
                try:
                    ao = _areas_obj(src)
                    if ao is None:                  # 1.6.8: detect on the fly
                        ao, _n = _make_areas(context, src, s)
                    # 1.6.4: follows the Method setting.  Smart (default) keeps the
                    # exact shape of clean low-poly / hard-surface parts and rebuilds
                    # dense or organic ones.
                    try:
                        res, q, dt = remesh_object(context, src, s)
                    finally:
                        _cleanup_temp(context)
                        _purge_tmp_meshes()
                    coll, part = _split_result_by_areas(context, src, res, ao)
                except Exception as ex:
                    import traceback
                    traceback.print_exc()
                    fails.append("%s (%s)" % (src.name, ex))
                    continue
                for o in (src, ao, _lines_obj(src)):
                    if o is not None:
                        o.hide_set(True)
                dense = bpy.data.collections.get(src.name + "_AREAS")
                if dense is not None:
                    for o in dense.objects:
                        o.hide_set(True)
                made.extend(part)
                lines.append("%s: %d areas, %d quads" % (
                    src.name, len(part), sum(len(o.data.polygons) for o in part)))
        finally:
            _status(context, None)
        _show_material_colours(context)
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        if made:
            context.view_layer.objects.active = made[0]
        if lines:
            s.last_report = " || ".join(lines)
        if fails:
            self.report({'WARNING'}, "Failed: " + ", ".join(fails))
        self.report({'INFO'}, " | ".join(lines) if lines else "Nothing done")
        return {'FINISHED'} if made else {'CANCELLED'}


class RU_OT_clear_areas(Operator):
    bl_idname = "remesh_ultimate.clear_areas"
    bl_label = "Clear Areas"
    bl_description = "Remove the coloured areas and the drawn lines of this object"
    bl_options = {'REGISTER', 'UNDO'}
    lines_only: BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        return _source_of(context.active_object) is not None

    def execute(self, context):
        src = _source_of(context.active_object)
        targets = [_lines_obj(src)] if self.lines_only else [_areas_obj(src), _lines_obj(src)]
        for o in targets:
            if o is None:
                continue
            m = o.data
            bpy.data.objects.remove(o, do_unlink=True)
            if m.users == 0:
                bpy.data.meshes.remove(m)
        if not self.lines_only:
            src.hide_set(False)
            for o in context.selected_objects:
                o.select_set(False)
            src.select_set(True)
            context.view_layer.objects.active = src
            for area in _screen_areas(context):
                if area.type == 'VIEW_3D':
                    area.spaces.active.shading.color_type = 'MATERIAL'
        return {'FINISHED'}


# ---- Draw Lines (modal) ----------------------------------------------------
_draw_state = {"handle": None}


def _draw_lines_cb(op):
    try:
        import gpu
        from gpu_extras.batch import batch_for_shader
    except Exception:
        return
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.line_width_set(3.0)
    segs = []
    for line in op.done + [op.current]:
        for i in range(len(line) - 1):
            segs.append(line[i])
            segs.append(line[i + 1])
    if segs:
        b = batch_for_shader(sh, 'LINES', {"pos": segs})
        sh.bind()
        sh.uniform_float("color", (1.0, 0.25, 0.85, 1.0))
        b.draw(sh)
    pts = list(op.clicks)
    if pts:
        gpu.state.point_size_set(9.0)
        b = batch_for_shader(sh, 'POINTS', {"pos": pts})
        sh.bind()
        sh.uniform_float("color", (1.0, 1.0, 0.2, 1.0))
        b.draw(sh)
    gpu.state.depth_test_set('NONE')
    gpu.state.line_width_set(1.0)
    gpu.state.point_size_set(1.0)
    gpu.state.blend_set('NONE')


class RU_OT_draw_lines(Operator):
    bl_idname = "remesh_ultimate.draw_lines"
    bl_label = "Draw Lines"
    bl_description = ("Click points on the model to draw guide lines on its surface. "
                      "Enter: new line | C: close loop | Backspace: undo point | "
                      "Right-click / Esc: finish")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = _source_of(context.active_object)
        return (ob is not None and ob.type == 'MESH' and context.area is not None
                and context.area.type == 'VIEW_3D')

    def invoke(self, context, event):
        self.src = _source_of(context.active_object)
        target = _areas_obj(self.src) or self.src
        dg = context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(target.evaluated_get(dg), depsgraph=dg)
        me.transform(target.matrix_world)
        self.bvh = _bvh_from_mesh(me)
        co = _mesh_co(me)
        self.diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
        bpy.data.meshes.remove(me)
        self.clicks, self.current, self.done = [], [], []
        _draw_state["handle"] = bpy.types.SpaceView3D.draw_handler_add(
            _draw_lines_cb, (self,), 'WINDOW', 'POST_VIEW')
        context.workspace.status_text_set(
            "Draw Lines:  Click = point   Enter = new line   C = close loop   "
            "Backspace = undo   Right-click / Esc = finish   (middle mouse navigates)")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _hit(self, context, event):
        from bpy_extras import view3d_utils
        reg, rv3d = context.region, context.region_data
        mxy = (event.mouse_region_x, event.mouse_region_y)
        o = view3d_utils.region_2d_to_origin_3d(reg, rv3d, mxy)
        d = view3d_utils.region_2d_to_vector_3d(reg, rv3d, mxy)
        loc, no, _i, _d = self.bvh.ray_cast(o, d)
        return (loc, no) if loc is not None else (None, None)

    def _surface_path(self, a, b):
        """Straight between two clicks, glued to the surface."""
        L = (b - a).length
        n = max(2, int(L / (self.diag / 250.0)))
        pts = []
        for i in range(1, n + 1):
            p = a.lerp(b, i / n)
            loc, no, _i, _d = self.bvh.find_nearest(p)
            if loc is not None:
                pts.append(loc + no * self.diag * 0.0015)
        return pts

    def _add_point(self, loc, no):
        p = loc + no * self.diag * 0.0015
        if self.clicks:
            self.current.extend(self._surface_path(self.clicks[-1], p))
        else:
            self.current.append(p)
        self.clicks.append(p)

    def _end_line(self, close=False):
        if close and len(self.clicks) >= 3:
            self.current.extend(self._surface_path(self.clicks[-1], self.clicks[0]))
        if len(self.current) >= 2:
            self.done.append(list(self.current))
        self.current, self.clicks = [], []

    def _finish(self, context):
        self._end_line()
        if _draw_state["handle"] is not None:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_state["handle"], 'WINDOW')
            _draw_state["handle"] = None
        context.workspace.status_text_set(None)
        if not self.done:
            context.area.tag_redraw()
            return
        lo = _lines_obj(self.src)
        inv = self.src.matrix_world.inverted()
        verts, edges = [], []
        if lo is not None:
            verts = [v.co.copy() for v in lo.data.vertices]
            edges = [tuple(e.vertices) for e in lo.data.edges]
        for line in self.done:
            base = len(verts)
            verts.extend(inv @ p for p in line)
            edges.extend((base + i, base + i + 1) for i in range(len(line) - 1))
        me = bpy.data.meshes.new(self.src.name + LINES_SUFFIX)
        me.from_pydata(verts, edges, [])
        if lo is None:
            lo = bpy.data.objects.new(self.src.name + LINES_SUFFIX, me)
            lo["ru_helper_of"] = self.src.name
            for c in self.src.users_collection:
                c.objects.link(lo)
        else:
            old = lo.data
            lo.data = me
            if old.users == 0:
                bpy.data.meshes.remove(old)
        lo.matrix_world = self.src.matrix_world
        lo.display_type = 'WIRE'
        lo.show_in_front = True
        lo.color = (1.0, 0.25, 0.85, 1.0)
        context.area.tag_redraw()

    def modal(self, context, event):
        if context.area:
            context.area.tag_redraw()
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN',
                          'TRACKPADZOOM', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            return {'PASS_THROUGH'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if event.alt:
                return {'PASS_THROUGH'}
            loc, no = self._hit(context, event)
            if loc is not None:
                self._add_point(loc, no)
            return {'RUNNING_MODAL'}
        if event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        if event.type in {'RET', 'NUMPAD_ENTER', 'SPACE'}:
            self._end_line()
            return {'RUNNING_MODAL'}
        if event.type == 'C':
            self._end_line(close=True)
            return {'RUNNING_MODAL'}
        if event.type == 'BACK_SPACE':
            if self.clicks:
                self.clicks.pop()
                # rebuild the current path from the remaining clicks
                cl, self.clicks, self.current = self.clicks, [], []
                for p in cl:
                    if self.clicks:
                        self.current.extend(self._surface_path(self.clicks[-1], p))
                    else:
                        self.current.append(p)
                    self.clicks.append(p)
            elif self.done:
                self.done.pop()
            return {'RUNNING_MODAL'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._finish(context)
            return {'FINISHED'}
        if event.type.startswith('NUMPAD') or event.type in {'F', 'HOME'}:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}


# --------------------------------------------------------------------------
#  Operators
# --------------------------------------------------------------------------
class RU_OT_remesh(Operator):
    bl_idname = "remesh_ultimate.remesh"
    bl_label = "REMESH"
    bl_description = "Build a clean quad mesh from the selected objects (original is kept)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        s = context.scene.remesh_ultimate
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        sources = []
        for o in context.selected_objects:
            o = _source_of(o)
            if (o is not None and o.type == 'MESH' and "ru_source" not in o
                    and "ru_helper_of" not in o and o not in sources):
                sources.append(o)
        if not sources:
            self.report({'WARNING'}, "Select a mesh that is not already a Remesh Ultimate result")
            return {'CANCELLED'}
        try:
            context.window.cursor_set('WAIT')
        except Exception:
            pass
        _status(context, "Remesh Ultimate  -  Please wait... Processing...")
        results, lines, warn = [], [], []
        try:
            for src in sources:
                try:
                    res, q, dt = remesh_object(context, src, s)
                except Exception as ex:
                    import traceback
                    traceback.print_exc()
                    lines.append("%s: failed (%s)" % (src.name, ex))
                    continue
                finally:
                    _cleanup_temp(context)
                cover = float(res.get("ru_cover", 100.0))
                if s.color_parts and not s.separate_parts:
                    try:
                        ao = _areas_obj(src)
                        if ao is None:
                            ao, _n = _make_areas(context, src, s)
                        n_col = _colour_single_mesh(context, src, res, ao)
                        ao.hide_set(True)
                        _show_material_colours(context)
                        res["ru_report"] = res.get("ru_report", "") + " | %d areas" % n_col
                    except Exception as ex:
                        import traceback
                        traceback.print_exc()
                        warn.append("%s: could not colour areas (%s)" % (src.name, ex))
                if s.separate_parts:
                    try:
                        ao = _areas_obj(src)
                        if ao is None:
                            ao, _n = _make_areas(context, src, s)
                        rep_line = res.get("ru_report", "")
                        coll, made = _split_result_by_areas(context, src, res, ao)
                        ao.hide_set(True)
                        _show_object_colours(context)
                        results.extend(made)
                        lines.append("%s: %d parts in '%s' | %s" % (src.name, len(made),
                                                                     coll.name, rep_line))
                        if cover >= 90.0 and s.hide_original:
                            src.hide_set(True)
                        h = _lines_obj(src)
                        if h is not None:
                            h.hide_set(True)
                        continue
                    except Exception as ex:
                        import traceback
                        traceback.print_exc()
                        warn.append("%s: could not separate parts (%s)" % (src.name, ex))
                results.append(res)
                if cover < 90.0:
                    warn.append("%s: only %.0f%% of the surface covered - original left visible"
                                % (src.name, cover))
                elif s.hide_original:
                    src.hide_set(True)
                for h in (_areas_obj(src), _lines_obj(src)):
                    if h is not None:
                        h.hide_set(True)
                lines.append("%s: %s" % (src.name, res["ru_report"]))
        finally:
            _cleanup_temp(context)
            _purge_tmp_meshes()
            _status(context, None)
            try:
                context.window.cursor_set('DEFAULT')
            except Exception:
                pass

        for o in context.selected_objects:
            o.select_set(False)
        for r in results:
            r.select_set(True)
        if results:
            context.view_layer.objects.active = results[-1]
        s.last_report = " || ".join(lines)
        if not results:
            self.report({'ERROR'}, "Remesh failed: " + s.last_report)
            return {'CANCELLED'}
        if warn:
            self.report({'WARNING'}, " | ".join(warn))
        else:
            self.report({'INFO'}, "Remesh Ultimate: " + lines[-1])
        return {'FINISHED'}


def _pair(context):
    ob = context.active_object
    if ob is None:
        return None, None
    if "ru_source" in ob:
        return bpy.data.objects.get(ob["ru_source"]), ob
    for o in bpy.data.objects:
        if o.get("ru_source") == ob.name:
            return ob, o
    return ob, None


class RU_OT_compare(Operator):
    bl_idname = "remesh_ultimate.compare"
    bl_label = "Compare"
    bl_description = "Toggle between the original and the remeshed result"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        src, res = _pair(context)
        return src is not None and res is not None

    def execute(self, context):
        src, res = _pair(context)
        show_src = not src.visible_get()
        src.hide_set(not show_src)
        res.hide_set(show_src)
        target = src if show_src else res
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {'FINISHED'}


class RU_OT_revert(Operator):
    bl_idname = "remesh_ultimate.revert"
    bl_label = "Revert"
    bl_description = "Delete the remeshed result and show the original again"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        src, res = _pair(context)
        return res is not None

    def execute(self, context):
        src, res = _pair(context)
        me = res.data
        bpy.data.objects.remove(res, do_unlink=True)
        if me.users == 0:
            bpy.data.meshes.remove(me)
        if src:
            src.hide_set(False)
            src.select_set(True)
            context.view_layer.objects.active = src
        return {'FINISHED'}


class RU_OT_scale_target(Operator):
    bl_idname = "remesh_ultimate.scale_target"
    bl_label = "Scale Target"
    bl_options = {'INTERNAL'}
    factor: FloatProperty(default=2.0)

    def execute(self, context):
        s = context.scene.remesh_ultimate
        s.target_faces = int(max(50, min(300000, s.target_faces * self.factor)))
        return {'FINISHED'}


class RU_OT_uninstall(Operator):
    bl_idname = "remesh_ultimate.uninstall"
    bl_label = "Uninstall Remesh Ultimate"
    bl_description = "Disable and completely remove Remesh Ultimate from Blender"

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_confirm(
                self, event, title="Uninstall Remesh Ultimate?",
                message="The add-on will be disabled and its files deleted.",
                confirm_text="Uninstall", icon='WARNING')
        except TypeError:
            return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        mod = ADDON_ID
        path = os.path.dirname(os.path.abspath(__file__))

        def _do():
            try:
                bpy.ops.preferences.addon_disable(module=mod)
            except Exception as ex:
                print("[Remesh Ultimate] disable:", ex)
            if mod.startswith("bl_ext."):
                try:
                    _b, repo_mod, pkg = mod.split(".", 2)
                    for i, r in enumerate(bpy.context.preferences.extensions.repos):
                        if r.module == repo_mod:
                            bpy.ops.extensions.package_uninstall(repo_index=i, pkg_id=pkg)
                            break
                except Exception as ex:
                    print("[Remesh Ultimate] extension uninstall:", ex)
            else:
                try:
                    bpy.ops.preferences.addon_remove(module=mod)
                except Exception as ex:
                    print("[Remesh Ultimate] addon_remove:", ex)
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            try:
                if not bpy.context.preferences.use_preferences_save:
                    bpy.ops.wm.save_userpref()
            except Exception:
                pass
            print("[Remesh Ultimate] uninstalled")
            return None

        bpy.app.timers.register(_do, first_interval=0.2)
        self.report({'INFO'}, "Remesh Ultimate uninstalled")
        return {'FINISHED'}


# --------------------------------------------------------------------------
#  UI
# --------------------------------------------------------------------------
class RU_PT_main(Panel):
    bl_label = "Remesh Ultimate " + VERSION_STR
    bl_idname = "RU_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Remesh Ultimate"

    def draw(self, context):
        s = context.scene.remesh_ultimate
        lay = self.layout

        col = lay.column(align=True)
        col.label(text="Preset")
        grid = col.grid_flow(columns=3, align=True, even_columns=True)
        grid.prop_enum(s, "preset", 'FAST')
        grid.prop_enum(s, "preset", 'BALANCED')
        grid.prop_enum(s, "preset", 'QUALITY')
        row = col.row(align=True)
        row.prop_enum(s, "preset", 'HARD')
        row.prop_enum(s, "preset", 'ORGANIC')

        box = lay.box()
        box.prop(s, "quad_size")
        if s.quad_size == 'CUSTOM':
            row = box.row(align=True)
            row.prop(s, "target_faces")
            op = row.operator(RU_OT_scale_target.bl_idname, text="", icon='REMOVE')
            op.factor = 0.5
            op = row.operator(RU_OT_scale_target.bl_idname, text="", icon='ADD')
            op.factor = 2.0
        box.label(text="Symmetry")
        row = box.row(align=True)
        row.prop(s, "symmetry", expand=True)
        box.label(text="Sharp Edges")
        row = box.row(align=True)
        row.prop(s, "sharp_mode", expand=True)
        if s.sharp_mode != 'OFF':
            box.prop(s, "sharp_angle")
        box.prop(s, "preserve_boundary")

        box.label(text="Method")
        row = box.row(align=True)
        row.prop(s, "method", expand=True)
        box.prop(s, "pure_quads")

        ab = lay.box()
        ab.label(text="Areas & Lines", icon='MOD_UVPROJECT')
        row = ab.row(align=True)
        row.operator("remesh_ultimate.detect_areas", icon='SHADING_RENDERED')
        op = row.operator("remesh_ultimate.clear_areas", text="", icon='X')
        op.lines_only = False
        ab.prop(s, "area_count")
        row = ab.row(align=True)
        row.operator("remesh_ultimate.areas_to_collection", text="Dense to Collection",
                     icon='OUTLINER_COLLECTION')
        rr = ab.row()
        rr.scale_y = 1.5
        rr.operator("remesh_ultimate.remesh_areas", icon='MOD_REMESH')
        row = ab.row(align=True)
        row.operator("remesh_ultimate.draw_lines", icon='GREASEPENCIL')
        op = row.operator("remesh_ultimate.clear_areas", text="", icon='TRASH')
        op.lines_only = True
        ab.prop(s, "use_guides")

        ab2 = lay.box()
        ab2.label(text="Result")
        row = ab2.row(align=True)
        row.prop(s, "color_parts", toggle=False)
        row.prop(s, "separate_parts", toggle=False)
        if s.color_parts:
            ab2.label(text="One object per area" if s.separate_parts
                      else "One mesh, areas by material", icon='INFO')
        r = lay.row()
        r.scale_y = 2.2
        r.operator(RU_OT_remesh.bl_idname, text="REMESH", icon='MOD_REMESH')

        row = lay.row(align=True)
        row.operator(RU_OT_compare.bl_idname, icon='HIDE_OFF')
        row.operator(RU_OT_revert.bl_idname, icon='LOOP_BACK')

        ob = context.active_object
        if ob is not None and "ru_report" in ob:
            b = lay.box()
            sc = float(ob.get("ru_score", 0))
            b.label(text="Quality Score: %.0f / 100" % sc,
                    icon='CHECKMARK' if sc >= 75 else 'INFO')
            for part in str(ob["ru_report"]).split(" | "):
                b.label(text=part)


class RU_PT_advanced(Panel):
    bl_label = "Advanced"
    bl_idname = "RU_PT_advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Remesh Ultimate"
    bl_parent_id = "RU_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        s = context.scene.remesh_ultimate
        lay = self.layout
        lay.prop(s, "clean_mode")
        lay.prop(s, "turbo")
        lay.prop(s, "tries")
        lay.prop(s, "relax_iterations")
        lay.prop(s, "relax_strength", slider=True)
        lay.prop(s, "project")
        lay.prop(s, "add_shrinkwrap")
        lay.prop(s, "hide_original")
        lay.prop(s, "seed")
        lay.prop(s, "isolated")


class RU_Preferences(AddonPreferences):
    bl_idname = ADDON_ID

    def draw(self, context):
        lay = self.layout
        lay.label(text="Remesh Ultimate %s  -  Windows / Linux / macOS (pure Python)" % VERSION_STR)
        lay.label(text="Panel: 3D View > Sidebar (N) > Remesh Ultimate")
        row = lay.row()
        row.alert = True
        row.scale_y = 1.4
        row.operator(RU_OT_uninstall.bl_idname, text="Uninstall Remesh Ultimate", icon='TRASH')


classes = (RU_Settings, RU_OT_detect_areas, RU_OT_areas_to_collection, RU_OT_remesh_areas, RU_OT_clear_areas, RU_OT_draw_lines, RU_OT_remesh, RU_OT_compare, RU_OT_revert, RU_OT_scale_target,
           RU_OT_uninstall, RU_PT_main, RU_PT_advanced, RU_Preferences)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.remesh_ultimate = PointerProperty(type=RU_Settings)


def unregister():
    if _draw_state.get("handle") is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_state["handle"], 'WINDOW')
        except Exception:
            pass
        _draw_state["handle"] = None
    if hasattr(bpy.types.Scene, "remesh_ultimate"):
        del bpy.types.Scene.remesh_ultimate
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
