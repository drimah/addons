"""Monster Remesh - Smart Remesh + Boolean Quad Ready in one add-on.

Organic and Hard Surface come from Smart Remesh 3.0.5 (Milad Kambari -
3DRedbox Studio). The Boolean half (`bqr.py`) is Boolean Quad Ready 1.6 by
Artemis3D, drawn into the same viewport card.


Two halves, and they do not share an engine:

- Organic (this module) drives **Instant Meshes**, the prebuilt binary in
  `bin/`, by Wenzel Jakob, Daniele Panozzo, Marco Tarini and Olga
  Sorkine-Hornung. Shipped unmodified under the 3-clause BSD licence in
  `bin/LICENSE-instant-meshes.txt`. Everything around it - the analysis, the
  crease detection, the calibration and the search - is ours.
- Hardsurface (`lines_preview.py` and `core/hardsurface.py`, `core/prune.py`)
  is ours end to end. No Blender remesh operator, modifier or built-in, and no
  Instant Meshes either.

The claim used to read "the algorithm in core/ is ours end to end". That was
true while there was a third engine of our own in the list; it was taken out,
so both engines here now run the bundled binary and the sentence had to go.

3DRedbox Studio - Milad Kambari
"""

# Installed as an extension, Blender reads the version from
# blender_manifest.toml and `bl_info` is not kept in the module namespace at
# all - reading it while drawing a panel threw NameError on every redraw.
# Keep the number here and let both the manifest and bl_info quote it.
VERSION = (1, 0, 4)

# Blender's manifest wants three parts, but trailing zeros are noise on screen
# and in a filename. 3.0.0 shows as "3", 1.2.0 as "1.2", 1.2.1 keeps all three.
_shown = list(VERSION)
while len(_shown) > 1 and _shown[-1] == 0:
    _shown.pop()
VERSION_TEXT = ".".join(str(n) for n in _shown)

bl_info = {
    "name": "Monster Remesh",
    "author": "Drimah (based on Smart Remesh by Milad Kambari and BQR by Artemis3D)",
    "version": VERSION,
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Monster Remesh",
    "description": "Quad remesher for hard-surface and organic models. Rebuilds "
                   "flat panels as n-gons and drops the edge loops that carry "
                   "no shape, without moving the surface",
    "doc_url": "https://discord.gg/EC8d7nPsYj",
    "tracker_url": "https://discord.gg/EC8d7nPsYj",
    "category": "Mesh",
}

# Written onto every result so Restore Original can find its way back.
# A result made as a new object records the name of the mesh it came from;
# one made with Replace Original records the mesh datablock it displaced.
MONSTERREMESH_SOURCE = "monsterremesh_source"
MONSTERREMESH_ORIG = "monsterremesh_orig_mesh"
# Which half made a result. Both used to write only MONSTERREMESH_SOURCE, so
# Organic happily adopted a Hardsurface result and overwrote it - one model,
# one shared marker, and whichever ran last won. Restore still keys off
# MONSTERREMESH_SOURCE, so it undoes either.
MONSTERREMESH_KIND = "monsterremesh_kind"

ARTSTATION_URL = "https://www.artstation.com/milad_kambari"
SUPERHIVE_URL = "https://superhivemarket.com/seller/milad_kambari"
DISCORD_URL = "https://discord.gg/EC8d7nPsYj"
# The play button in the card header. Milad picks the video; until then
# it lands on the channel rather than on a dead watch id.
YOUTUBE_URL = "https://youtu.be/KEwWPCvxpkk"
# The Hard Surface lesson.
LESSON_HARDSURFACE = "https://youtu.be/x2a3n4pOFMY"

# The lessons, each beside the control it is about rather than gathered in a
# help page nobody opens. Key -> (what the button says, where it goes). Add a
# line here and one `_lesson(layout, key)` call where it belongs.
LESSONS = {
    "cloth": ("Cloth remeshing", "https://youtu.be/0v5kQkSJz5I"),
}


def _lesson(layout, key):
    """A play button for the lesson about the control just above it."""
    found = LESSONS.get(key)
    if not found:
        return
    label, url = found
    row = layout.row(align=True)
    row.operator("wm.url_open", text=label, icon="PLAY").url = url

import importlib
import os
import sys
import traceback

import bpy
import bmesh
import numpy as np
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       IntProperty, PointerProperty, StringProperty)
from bpy.types import Operator, Panel, PropertyGroup

# `core.remesh` is the function, not the module - core/__init__ re-exports it.
from .core import instantmeshes
from . import lines_preview
from . import overlay
from . import marks
from . import bqr
from .core.auto import auto_remesh
from .core import remesh as run_remesh
from .core.instantmeshes import find_exe

# Blender keeps modules alive across add-on reloads; force the core to refresh
# so editing the algorithm does not require restarting Blender.
for _name in list(sys.modules):
    if _name.startswith(__name__ + ".core"):
        importlib.reload(sys.modules[_name])


# ----------------------------------------------------------------------
# preferences
# ----------------------------------------------------------------------
class MonsterRemeshPrefs(bpy.types.AddonPreferences):
    """Where to find the Organic engine when it is not bundled.

    The add-on ships the Windows build of Instant Meshes. It cannot ship the
    macOS or Linux one: those have to be compiled on the matching platform,
    and a binary we compiled and signed ourselves would land quarantined on
    every buyer's Mac anyway.

    The authors publish official builds for all three platforms, so the way
    out is not to ship it - it is to let the user point at their own copy.
    Nothing is redistributed, the licence question does not arise, and the
    one-time Gatekeeper prompt is on a file they downloaded themselves.

    `find_exe` has always taken an explicit path and `exe` was already
    threaded through `auto_remesh` and `instantmeshes.remesh`; this is only
    the missing end of that wire.
    """

    bl_idname = __package__

    accent_hue: FloatProperty(
        name="Card Hue", default=0.235, min=0.0, max=1.0,
        description="The colour the viewport card is drawn in. Slide it and "
                    "the whole card follows",
        update=lambda self, context: _retint(context),
    )
    accent_sat: FloatProperty(
        name="Card Saturation", default=0.860, min=0.0, max=1.0,
        description="How strong that colour is. All the way down is grey",
        update=lambda self, context: _retint(context),
    )

    classic_panel: BoolProperty(
        name="Classic Panel",
        default=False,
        description="Use the side panel this add-on shipped with instead of "
                    "the card in the viewport. The switch back is at the top "
                    "of that panel",
        update=lambda self, context: _classic_later(),
    )

    corner: FloatProperty(
        name="Corner Rounding", default=8.0, min=0.0, max=16.0,
        description="How round the corners of the viewport card and its "
                    "controls are. 0 is square",
        update=lambda self, context: _retint(context),
    )

    exe_path: StringProperty(
        name="Instant Meshes",
        subtype="FILE_PATH",
        default="",
        description="Path to the Instant Meshes executable. Leave empty to "
                    "use the copy bundled with the add-on. Only needed on "
                    "macOS, where no copy is bundled",
    )

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.alert = True
        row.scale_y = 1.3
        row.operator("mesh.monsterremesh_uninstall", icon="TRASH")
        layout.separator()
        layout.prop(self, "classic_panel")
        col = layout.column(align=True)
        col.prop(self, "accent_hue", slider=True)
        col.prop(self, "accent_sat", slider=True)
        col.prop(self, "corner", slider=True)
        layout.separator()
        layout.prop(self, "exe_path")
        if engine_exe() is None:
            box = layout.box()
            box.label(text="Organic engine not found", icon="ERROR")
            col = box.column(align=True)
            col.label(text="Download the build for your platform from the")
            col.label(text="Instant Meshes project page, unzip it, and point")
            col.label(text="the field above at the executable.")
            col.label(text="On macOS that is inside the .app bundle, at")
            col.label(text="Instant Meshes.app/Contents/MacOS/Instant Meshes")
            col.separator()
            col.label(text="Monster Remesh (Hardsurface) needs none of this")
            col.label(text="and works on every platform as shipped.")
        else:
            layout.label(text="Organic engine found", icon="CHECKMARK")


# The card replaced the side panel, but the side panel is what 1,450 people
# already know and it still carries settings the card has not been given yet.
# So both ship, one at a time, and either one can hand over to the other.

def _classic_classes():
    return (MONSTERREMESH_PT_panel, lines_preview.MONSTERREMESH_PT_lines,
            bqr.MRBOOL_PT_panel, MONSTERREMESH_PT_about)


def _classic_on():
    try:
        return bool(bpy.context.preferences.addons[
            __package__].preferences.classic_panel)
    except Exception:
        return False


def _apply_classic():
    """Put up whichever interface the preference asks for."""
    on = _classic_on()
    for cls in _classic_classes():
        registered = getattr(bpy.types, cls.__name__, None) is not None
        try:
            if on and not registered:
                bpy.utils.register_class(cls)
            elif not on and registered:
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    try:
        overlay.clear()
        if not on:
            overlay.register_draw()
    except Exception:
        pass
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _classic_tick():
    _apply_classic()
    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        pass
    return None


def _classic_later():
    """Never register or unregister a panel while one is being drawn.

    One named function, not a fresh closure each time: a closure is never
    "already registered", so flicking the switch twice quickly used to queue
    two applies and the second could land after the user had changed their
    mind again.
    """
    if not bpy.app.timers.is_registered(_classic_tick):
        bpy.app.timers.register(_classic_tick, first_interval=0.0)


class MONSTERREMESH_OT_ui_switch(Operator):
    """Move between the viewport card and the classic side panel."""

    bl_idname = "mesh.monsterremesh_ui_switch"
    bl_label = "Switch Interface"
    bl_options = {"INTERNAL"}

    classic: BoolProperty(default=False)

    def execute(self, context):
        try:
            prefs = bpy.context.preferences.addons[__package__].preferences
        except Exception:
            return {"CANCELLED"}
        prefs.classic_panel = self.classic
        return {"FINISHED"}


def _retint(context):
    """Repaint the card in the colour just chosen.

    Preferences are written to disk by Blender on its own, so nothing here has
    to save anything - the colour is already permanent the moment it changes.
    """
    try:
        overlay.retint()
    except Exception:
        return
    wm = getattr(context, "window_manager", None) or bpy.context.window_manager
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def engine_path() -> str:
    """The user's explicit binary path, or "" when they have not set one.

    Reading preferences must never be what breaks a remesh, so every way this
    can fail - add-on not registered under the name we expect, preferences
    unavailable mid-teardown - falls back to the bundled lookup.
    """
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        return bpy.path.abspath(prefs.exe_path or "")
    except Exception:
        return ""


def engine_exe():
    """The Organic binary to run: the user's, else the bundled one, else None."""
    return find_exe(engine_path())


def engine_blocked() -> str:
    """The path of an engine macOS will not let start, or ""."""
    exe = engine_exe()
    if exe and instantmeshes.is_quarantined(exe):
        return exe
    return ""


class MONSTERREMESH_OT_unquarantine(Operator):
    """Clear the macOS quarantine flag from the bundled Organic engine.

    The engine is redistributed unmodified from its authors and carries no
    Apple signature, so macOS flags it like anything else that arrived in a
    download. Opened from Finder that would be the usual "Open Anyway"
    prompt; run in the background the way this add-on runs it, there is no
    prompt - it is killed and the remesh fails with nothing to click.

    Doing this silently at install time would have been easy and is exactly
    why it is not done: undoing a Gatekeeper flag is the user's decision, so
    it asks first and names the command it will run.
    """

    bl_idname = "mesh.monsterremesh_unquarantine"
    bl_label = "Allow Organic Engine"
    bl_description = ("Let macOS run the bundled Organic engine. Clears the "
                      "quarantine flag on the add-on's own bin folder")
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        col = self.layout.column(align=True)
        exe = engine_exe() or ""
        col.label(text="This runs, on the add-on's own folder only:")
        col.separator()
        box = self.layout.box().column(align=True)
        box.label(text="xattr -dr com.apple.quarantine")
        box.label(text=os.path.dirname(exe) if exe else "")
        col = self.layout.column(align=True)
        col.separator()
        col.label(text="The engine is Instant Meshes, redistributed")
        col.label(text="unmodified from its authors. macOS flags it")
        col.label(text="because it has no Apple signature, not because")
        col.label(text="anything is wrong with it.")
        col.separator()
        col.label(text="Prefer to do it yourself? Run that command in")
        col.label(text="Terminal instead. Nothing else changes.")

    def execute(self, context):
        exe = engine_exe()
        if not exe:
            self.report({"ERROR"}, "Organic engine not found")
            return {"CANCELLED"}
        ok, why = instantmeshes.clear_quarantine(exe)
        if not ok:
            self.report({"ERROR"}, f"Could not clear the flag: {why}")
            return {"CANCELLED"}
        self.report({"INFO"}, "Organic engine enabled")
        return {"FINISHED"}


# ----------------------------------------------------------------------
# properties
# ----------------------------------------------------------------------
_ENGINE_ITEMS: list = []          # held so Blender does not collect the strings


def _engine_items(self, context):
    """Only the engines that can actually run here.

    Instant Meshes ships as a Windows binary. Where it is present it is the
    only sensible choice - measured against the in-house solver on a 189k
    triangle model it scored 83 to 37 - so the in-house one is not offered and
    cannot be picked by accident. Where the binary is absent it is the only
    thing left, so it is all that is listed.
    """
    global _ENGINE_ITEMS
    if engine_exe() is not None:
        items = [
            ("AUTO", "Auto",
             "Analyse the model, derive the crease angle from it, calibrate "
             "the face count, then try several settings and keep the best"),
            ("STABLE", "Manual",
             "One pass with exactly the settings below, no analysis"),
            ("CLOTH", "Cloth",
             "For thin garments from AI and scans. Welds the loose shells, "
             "remeshes, then closes the tears the thin double-walled cloth "
             "would otherwise leave - all in one pass"),
        ]
    else:
        items = [
            ("OURS", "In-house",
             "Pure Python, no binary. The engine used on platforms the "
             "Instant Meshes build does not cover. Slower, and its output is "
             "rougher - expect non-manifold edges and a lower quad ratio"),
            ("CLOTH", "Cloth",
             "For thin garments: weld the shells, remesh, then close the "
             "tears the thin cloth leaves"),
        ]
    _ENGINE_ITEMS = items
    return _ENGINE_ITEMS


def _meet_live(self, context):
    """Re-apply Meet Panel Vertices the moment its sliders move.

    Dragging the number has to change the mesh, not queue up a button press.
    Every pass rebuilds from the snapshot taken the first time, so moving the
    slider back and forth lands on the same result instead of pulling the
    borders further together each time.
    """
    obj = getattr(context, "active_object", None)
    if obj is None or obj.type != "MESH" or obj.mode != "OBJECT":
        return
    if not len(obj.data.polygons):
        return
    # No button press needed - the first move of the slider takes the snapshot
    # itself. Held to a remesh result (or something already being meeted) so
    # that idly dragging the slider can never reshape a source model.
    if not (obj.get(MEET_BASE) or obj.get(MONSTERREMESH_SOURCE)):
        return
    try:
        meet_panel_verts(obj, self.meet_dist, self.meet_weld)
    except Exception:
        traceback.print_exc()


class MonsterRemeshSettings(PropertyGroup):
    backend: EnumProperty(
        name="Engine", items=_engine_items,
        description="Which solver rebuilds the surface")

    # Ranges are deliberately tight. The first version let chamfer reach 0.1 -
    # a band 10% of the model wide - and simplify reach 0.05, which erases the
    # boundary. Both are far past anything useful, and a single slider drag
    # landed on them.
    auto_crease: BoolProperty(
        name="Detect Crease Angle", default=True,
        description="Read the crease angle off the model's own dihedral "
                    "histogram instead of using the value below",
    )
    auto_calibrate: BoolProperty(
        name="Calibrate Face Count", default=True,
        description="Instant Meshes treats the face target as a hint and "
                    "routinely overshoots it several times over. This probes "
                    "once and corrects for it",
    )
    auto_search: BoolProperty(
        name="Search Settings", default=True,
        description="Try several crease angles and keep whichever scores best. "
                    "Costs a few extra runs",
    )
    pure_quad: BoolProperty(
        name="Pure Quads", default=False,
        description="Instant Meshes only. Off gives a quad-dominant mesh that "
                    "hits the target face count more closely",
    )
    mode: EnumProperty(
        name="Target",
        items=[
            ("FACES", "Face Count", "Aim for a number of output faces"),
            ("EDGE", "Edge Length", "Aim for an absolute quad size"),
        ],
        default="FACES",
    )
    target_faces: IntProperty(
        name="Faces", default=2000, min=8, soft_max=200000,
        description="Approximate number of quads to produce",
    )
    target_edge: FloatProperty(
        name="Edge Length", default=0.1, min=1e-5, soft_max=10.0,
        subtype="DISTANCE",
        description="Approximate quad side length, in object units",
    )
    feature_angle: FloatProperty(
        name="Sharp Angle", default=30.0, min=0.0, max=180.0,
        description="Dihedral angle in degrees above which an edge is treated "
                    "as a crease and preserved",
    )
    close_tears: BoolProperty(
        name="Close Tears", default=False,
        description="Fill the holes a remesh tears into thin cloth. A thin "
                    "open garment makes the remesher bridge its two sides and "
                    "tear; this fills those holes afterwards. It also caps the "
                    "garment's real openings (collar, cuffs) - delete those "
                    "caps if you want it open",
    )
    tear_size: FloatProperty(
        name="Max Tear", default=0.35, min=0.0, max=1.0, subtype="FACTOR",
        description="Largest hole to close, as a fraction of the model. Tears "
                    "are small; the garment's real openings (collar, cuffs) "
                    "are large, so this closes the tears and leaves the "
                    "openings open. 1 closes every hole",
    )
    mark_sharp: BoolProperty(
        name="Mark Sharp Edges", default=False,
        description="Mark an edge sharp wherever the result turns more than "
                    "35 degrees. Off by default: marked edges shade as hard "
                    "creases and get in the way of sculpting, subdividing and "
                    "baking on an organic model. Turn it on for a hard-surface "
                    "piece that should keep its corners crisp",
    )
    no_sharp: BoolProperty(
        name="No Sharp Edges", default=False,
        description="Leave the result with no sharp edges at all. The rebuild "
                    "normally marks an edge sharp wherever the surface turns "
                    "more than 35 degrees, which is right for a hard-surface "
                    "model but draws crease lines across a garment. With this "
                    "on nothing is marked, the creases are cleared and the "
                    "whole result is shaded smooth",
    )
    meet_dist: FloatProperty(
        name="Meet Distance", default=0.5, min=0.0, max=5.0, soft_max=2.0,
        precision=3, subtype="FACTOR",
        description="How far apart two panels' border vertices may be and "
                    "still be brought onto each other, measured in the mesh's "
                    "own edge lengths rather than scene units, so it means the "
                    "same on any model. 0.5 is half a border spacing",
        update=_meet_live,
    )
    meet_weld: BoolProperty(
        name="Weld", default=False,
        description="Merge the vertices that met into one, joining the panels "
                    "into a single mesh. Off keeps the panels separate, with "
                    "their vertices sitting exactly on each other",
        update=_meet_live,
    )
    uv_panels: BoolProperty(
        name="Remesh Separately", default=False,
        description="Remesh each UV island on its own instead of welding the "
                    "whole garment. A model from Marvelous Designer or a scan "
                    "is sewn pattern pieces, and every piece is one UV island; "
                    "this cuts along the seams and remeshes each piece alone, "
                    "so every panel stays clean with its own border. The "
                    "pieces are left unwelded, reassembled in place. Trims and "
                    "topstitching (tiny islands) are carried over untouched",
    )
    merge_shells: BoolProperty(
        name="Merge Shells", default=False,
        description="Weld the input into one surface before remeshing. AI "
                    "and sculpt models often come as dozens of separate "
                    "shells lying on top of each other, and the remesh keeps "
                    "them separate - the result comes out in pieces. This "
                    "joins vertices that sit within Merge Distance of each "
                    "other first",
    )
    close_holes: BoolProperty(
        name="Close Holes", default=False,
        description="Fill the holes of the input before remeshing. AI and "
                    "scan models often come with the surface cut open where "
                    "parts meet - around the face, the hairline, the eyes - "
                    "and the remesh keeps those openings, so the result has "
                    "holes in the same places. This welds touching vertices "
                    "and closes every open border first. Leave it off for "
                    "models that are open on purpose (a single-sided sheet, a "
                    "scanned wall)",
    )
    solid_rebuild: EnumProperty(
        name="Solid Rebuild",
        items=[("AUTO", "Auto", "Rebuild as one solid only for closed models "
                "made of overlapping parts (kitbash, AI exports)"),
               ("ON", "On", "Always rebuild the input as one solid first"),
               ("OFF", "Off", "Remesh the input exactly as it is")],
        default="AUTO",
        description="Kitbash and AI models are many parts pushed into each "
                    "other. Remeshed as they are, the overlaps tear holes into "
                    "the result. This first turns the model into one fine, "
                    "closed solid (a voxel pass much finer than the result), "
                    "then remeshes that and closes any leftover hole. Never "
                    "used on open models",
    )
    two_pass: BoolProperty(
        name="Two Pass", default=True,
        description="For closed models rebuilt as a solid: build at twice "
                    "the face count first, then remesh that whole result "
                    "down to the count asked for. At low counts the faces "
                    "are wider than thin parts such as blade teeth and "
                    "cracks, and a single pass tears holes there",
    )
    merge_dist: FloatProperty(
        name="Merge Distance", default=0.0, min=0.0, max=1000.0,
        soft_max=0.02, precision=5, subtype="DISTANCE",
        description="How close two vertices must be to be welded before the "
                    "remesh. 0 welds only vertices sitting exactly on top of "
                    "each other; raise it to close the gaps between shells "
                    "that merely touch",
    )
    orient_iterations: IntProperty(
        name="Orientation Steps", default=40, min=1, max=500,
        description="Smoothing passes for the direction field. Raise this if "
                    "the flow looks noisy",
    )
    position_iterations: IntProperty(
        name="Position Steps", default=40, min=1, max=500,
        description="Smoothing passes for the lattice positions",
    )
    smooth_iterations: IntProperty(
        name="Relax", default=0, min=0, max=20,
        description="Relaxation of the output. For our engine this has no "
                    "reprojection, so it only pulls vertices off the surface - "
                    "leave at 0. For Instant Meshes it is the reprojection "
                    "step count and 2 is a good value",
    )
    thin_density: FloatProperty(
        name="Thin Parts", default=1.0, min=0.0, max=1.0,
        description="Put smaller quads where the model is thin, so a sheet "
                    "of cloth or a fingernail is never spanned by a quad "
                    "wider than it is thick. 0 turns it off")
    spread_over: FloatProperty(
        name="Build Over", default=3.0, min=1.5, max=6.0,
        description="With Adaptive Density on the bundled engine, build this "
                    "many times the face count you asked for and then drop "
                    "the loops that carry no shape. Higher gives the drop "
                    "more to choose from, and takes longer")
    density_strength: FloatProperty(
        name="Match Strength", default=1.0, min=0.0, max=1.0,
        description="How closely to follow the reference's own density. 1 "
                    "reproduces it exactly, 0 falls back to a uniform mesh",
    )
    adaptive: BoolProperty(
        name="Adaptive Density", default=False,
        description="Put smaller quads near creases and in curved regions. "
                    "Our engine only - Instant Meshes has no equivalent",
    )
    feature_density: FloatProperty(
        name="Near Creases", default=1.0, min=0.0, max=1.0,
        description="How strongly to refine around sharp edges",
    )
    curvature_density: FloatProperty(
        name="By Curvature", default=0.6, min=0.0, max=1.0,
        description="How strongly to refine where the surface bends",
    )
    inner_density: FloatProperty(
        name="Inner Edges", default=1.0, min=0.0, max=1.0,
        description="Refine concave edges - inside corners, grooves, the "
                    "places an AO bake goes dark",
    )
    outer_density: FloatProperty(
        name="Outer Edges", default=0.5, min=0.0, max=1.0,
        description="Refine convex edges - outside corners, ridges, rims",
    )
    min_size_ratio: FloatProperty(
        name="Min Size", default=0.5, min=0.15, max=1.0,
        description="Smallest quad as a fraction of the base size. Below 0.35 "
                    "quad quality drops sharply",
    )
    gradient_limit: FloatProperty(
        name="Transition", default=0.1, min=0.02, max=0.6,
        description="How fast quad size may change with distance. Low is "
                    "smoother and measurably better - 0.1 scored 75 against "
                    "55 for 0.4 in testing",
    )
    use_curvature: BoolProperty(
        name="Follow Curvature", default=True,
        description="Seed the direction field from principal curvature. Turn "
                    "off for a purely crease-driven flow",
    )
    replace: BoolProperty(
        name="Replace Original", default=False,
        description="Replace the source object instead of adding a new one "
                    "beside it",
    )


# ----------------------------------------------------------------------
# operator
# ----------------------------------------------------------------------



MEET_BASE = "monsterremesh_meet_base"


def _meet_base_mesh(obj):
    """The untouched copy every Meet pass rebuilds from.

    Taken the first time the tool runs on an object and kept alive with a fake
    user. Without it, dragging the distance would work on borders that had
    already been pulled together, and the mesh would creep instead of
    following the slider.
    """
    name = obj.get(MEET_BASE)
    me = bpy.data.meshes.get(name) if name else None
    if me is None:
        me = obj.data.copy()
        me.name = obj.data.name + "_meetbase"
        me.use_fake_user = True
        obj[MEET_BASE] = me.name
    return me


def meet_panel_verts(obj, dist=0.0, weld=False):
    """Bring neighbouring panels' border vertices onto each other.

    Only vertices belonging to *different* panels are pulled together, so a
    panel's own border spacing is never disturbed. They are moved onto their
    common point, not merged - unless `weld`, which then joins them.

    Returns (vertices that met, tolerance used).
    """
    import bmesh
    from mathutils import Vector
    from mathutils.kdtree import KDTree

    base = _meet_base_mesh(obj)
    bm = bmesh.new()
    bm.from_mesh(base)
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    lengths = sorted(e.calc_length() for e in bm.edges)
    if not lengths:
        bm.free()
        return 0, 0, 0.0
    # Measured against the mesh's own edge, not in scene units. A raw distance
    # only suits the model it was picked on: the slider topped out at 0.05,
    # which is half a border spacing on a metre-tall garment and nothing at all
    # on one whose edges are 0.7 - there the tool looked dead because it could
    # not reach a single vertex.
    #
    # The middle edge, not the average: a remesh leaves a tail of very short
    # edges that drags the mean down to a tolerance which reaches nothing.
    med = lengths[len(lengths) // 2]
    tol = med * (dist if dist > 0.0 else 0.5)

    panel = {}
    seen = set()
    pid = 0
    for f in bm.faces:
        if f.index in seen:
            continue
        stack = [f]
        seen.add(f.index)
        while stack:
            cur = stack.pop()
            panel[cur.index] = pid
            for e in cur.edges:
                for nf in e.link_faces:
                    if nf.index not in seen:
                        seen.add(nf.index)
                        stack.append(nf)
        pid += 1

    bnd = [v for v in bm.verts
           if any(len(e.link_faces) == 1 for e in v.link_edges)]
    met = 0
    slid = 0
    paired = set()
    if bnd:
        vpanel = {v.index: panel[v.link_faces[0].index]
                  for v in bnd if v.link_faces}
        kd = KDTree(len(bnd))
        for i, v in enumerate(bnd):
            kd.insert(v.co, i)
        kd.balance()

        parent = list(range(len(bnd)))

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        for i, v in enumerate(bnd):
            for (_co, j, _d) in kd.find_range(v.co, tol):
                if j <= i:
                    continue
                if vpanel.get(v.index) == vpanel.get(bnd[j].index):
                    continue
                ra, rb = find(i), find(j)
                if ra != rb:
                    parent[ra] = rb

        groups = {}
        for i in range(len(bnd)):
            groups.setdefault(find(i), []).append(i)
        for members in groups.values():
            if len(members) < 2:
                continue
            c = Vector((0.0, 0.0, 0.0))
            for i in members:
                c += bnd[i].co
            c /= len(members)
            for i in members:
                bnd[i].co = c
            met += len(members)
            for i in members:
                paired.add(i)

        # The two panels along a seam rarely carry the same number of border
        # vertices, so some are left with nobody to meet - and those are the
        # little notches left along an otherwise closed seam. A vertex with no
        # partner is slid onto the nearest border *edge* of another panel
        # instead: it then lies exactly on the neighbour's border line, and the
        # gap closes even though there is no vertex there to pair with.
        seg = []
        for e in bm.edges:
            if len(e.link_faces) == 1:
                seg.append((panel[e.link_faces[0].index],
                            e.verts[0].co.copy(), e.verts[1].co.copy()))
        if seg:
            kd2 = KDTree(len(seg))
            for i, (_p, a, b) in enumerate(seg):
                kd2.insert((a + b) * 0.5, i)
            kd2.balance()
            reach = tol + lengths[len(lengths) // 2]
            for i, v in enumerate(bnd):
                if i in paired:
                    continue
                mine = vpanel.get(v.index)
                best = None
                bd = tol
                for (_c, si, _d) in kd2.find_range(v.co, reach):
                    p, a, b = seg[si]
                    if p == mine:
                        continue
                    ab = b - a
                    l2 = ab.dot(ab)
                    t = 0.0 if l2 < 1e-18 else max(
                        0.0, min(1.0, (v.co - a).dot(ab) / l2))
                    q = a + ab * t
                    d = (v.co - q).length
                    if d < bd:
                        bd = d
                        best = q
                if best is not None:
                    v.co = best
                    slid += 1

        if weld and (met or slid):
            bmesh.ops.remove_doubles(bm, verts=bnd,
                                     dist=max(tol * 1e-3, 1e-9))

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return met, slid, tol


def close_tears(obj, max_ratio=0.35):
    """Fill the small holes a remesh tears into thin cloth, keep the openings.

    A tear and a real opening (a cuff, a collar) can have the same number of
    edges - the sleeve cuff on Milad's suit was 48 edges, a mid tear 28 - so
    filling by edge count either leaves tears or caps the cuffs. What tells
    them apart is size: measured on that suit, tears sit at 0.13-0.30 of the
    model across, the cuffs and collar at 0.55-0.74. So each boundary loop is
    filled only when its radius is below `max_ratio` of the model; the big
    openings are left open.
    """
    import bmesh
    from mathutils import Vector

    me = obj.data
    size = max(obj.dimensions) or 1.0
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.verts.ensure_lookup_table()
    bnd = [e for e in bm.edges if len(e.link_faces) == 1]
    before = len(bnd)
    if not before:
        bm.free()
        return 0, 0
    at = {}
    for e in bnd:
        for v in e.verts:
            at.setdefault(v.index, []).append(e)
    seen = set()
    small_edges = set()
    for e in bnd:
        if e.index in seen:
            continue
        stack = [e]
        seen.add(e.index)
        vs = set()
        es = []
        while stack:
            c = stack.pop()
            es.append(c.index)
            for v in c.verts:
                vs.add(v.index)
                for nb in at.get(v.index, []):
                    if nb.index not in seen:
                        seen.add(nb.index)
                        stack.append(nb)
        pts = [bm.verts[i].co for i in vs]
        ctr = Vector((0.0, 0.0, 0.0))
        for p in pts:
            ctr += p
        ctr /= len(pts)
        rad = sum((p - ctr).length for p in pts) / len(pts)
        if rad / size <= max_ratio:
            small_edges.update(es)
    bm.free()
    if not small_edges:
        return before, before

    win = bpy.context.window_manager.windows[0]
    area = next((a for a in win.screen.areas if a.type == "VIEW_3D"), None)
    if area is None:
        return before, before
    region = next(r for r in area.regions if r.type == "WINDOW")
    sel = list(bpy.context.selected_objects)
    for o in sel:
        o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    with bpy.context.temp_override(window=win, area=area, region=region,
                                   object=obj, active_object=obj,
                                   selected_objects=[obj]):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="EDGE")
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        for i in small_edges:
            me.edges[i].select = True
        bpy.ops.object.mode_set(mode="EDIT")
        # only the selected tear loops are filled; the big openings stay open
        bpy.ops.mesh.fill_holes(sides=0)
        bpy.ops.object.mode_set(mode="OBJECT")
    bm = bmesh.new()
    bm.from_mesh(me)
    after = sum(1 for e in bm.edges if len(e.link_faces) == 1)
    bm.free()
    return before, after


def _edge_counts(loops, sizes):
    """How many faces use each edge: (n_boundary, n_nonmanifold, n_edges)."""
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    nxt = np.arange(len(loops)) + 1
    nxt[starts + sizes - 1] = starts
    a, b = loops, loops[nxt]
    key = (np.minimum(a, b).astype(np.int64) * (int(loops.max()) + 1)
           + np.maximum(a, b))
    _, cnt = np.unique(key, return_counts=True)
    return int((cnt == 1).sum()), int((cnt > 2).sum()), len(cnt)


def _surface_area(co, loops, sizes):
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    area = 0.0
    for k in range(1, int(sizes.max()) - 1):
        m = sizes > k + 1
        a = co[loops[starts[m]]]
        b = co[loops[starts[m] + k]]
        c = co[loops[starts[m] + k + 1]]
        area += 0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1).sum()
    return float(area)


def _n_components(nv, loops, sizes):
    """Connected pieces of a face list: hook-and-jump union-find in numpy,
    a fraction of a second on a few million faces."""
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    nxt = np.arange(len(loops)) + 1
    nxt[starts + sizes - 1] = starts
    a, b = loops, loops[nxt]
    lab = np.arange(nv)
    for _ in range(100):
        ra, rb = lab[a], lab[b]
        m = ra != rb
        if not m.any():
            break
        a, b, ra, rb = a[m], b[m], ra[m], rb[m]
        np.minimum.at(lab, np.maximum(ra, rb), np.minimum(ra, rb))
        while True:
            j = lab[lab]
            if np.array_equal(j, lab):
                break
            lab = j
    used = np.zeros(nv, bool)
    used[loops] = True
    return int(len(np.unique(lab[used])))


def wants_solid(co, loops, sizes, welded=0):
    """Auto rule for Solid Rebuild: a (nearly) closed model that is still not
    one clean surface after the exact weld - parts pushed into each other
    (more than one piece) or edges shared by three faces or more. A sculpt
    that welds into one clean surface is left alone, and an open model (a
    sheet, a scan with no back) never qualifies."""
    bnd, nonman, ne = _edge_counts(loops, sizes)
    if bnd > 0.005 * ne:
        return False
    return nonman > 0 or _n_components(len(co), loops, sizes) > 1


def solid_prepass(co, loops, sizes, target_faces=None, target_edge=None,
                  max_faces=2_000_000, div=3.0):
    """Turn the input into one closed solid with a voxel remesh far finer than
    the result (three voxels per result edge), on a throwaway mesh.

    Overlapping parts, walls inside walls and non-manifold seams all vanish:
    the engine then sees one clean surface, which is what kept tearing holes
    into kitbash models. Details narrower than a voxel are the only loss, and
    they are far below the result's own edge length anyway."""
    area = _surface_area(co, loops, sizes)
    if target_edge:
        edge = float(target_edge)
    else:
        edge = (area / max(int(target_faces or 4000), 1)) ** 0.5
    vox = max(edge / div, (area / max_faces) ** 0.5)
    me = bpy.data.meshes.new("_sr_solid_tmp")
    me.vertices.add(len(co))
    me.vertices.foreach_set("co", co.astype(np.float32).ravel())
    me.loops.add(len(loops))
    me.loops.foreach_set("vertex_index", loops.astype(np.int32))
    me.polygons.add(len(sizes))
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    me.polygons.foreach_set("loop_start", starts.astype(np.int32))
    me.update(calc_edges=True)
    ob = bpy.data.objects.new("_sr_solid_tmp", me)
    bpy.context.scene.collection.objects.link(ob)
    try:
        mod = ob.modifiers.new("solid", "REMESH")
        mod.mode = "VOXEL"
        mod.voxel_size = vox
        mod.adaptivity = 0.0
        dg = bpy.context.evaluated_depsgraph_get()
        ev = ob.evaluated_get(dg)
        out = ev.to_mesh()
        nv, nf = len(out.vertices), len(out.polygons)
        co2 = np.empty(nv * 3, dtype=np.float64)
        out.vertices.foreach_get("co", co2)
        sz2 = np.empty(nf, dtype=np.int64)
        out.polygons.foreach_get("loop_total", sz2)
        lp2 = np.empty(int(sz2.sum()), dtype=np.int64)
        out.loops.foreach_get("vertex_index", lp2)
        ev.to_mesh_clear()
    finally:
        bpy.data.objects.remove(ob)
        bpy.data.meshes.remove(me)
    return co2.reshape(nv, 3), lp2, sz2, vox


def _grid_cap(bm, ring):
    """Close an even hole with a clean a x b quad grid (no star pole).

    The loop is cut into four sides a, b, a, b with a + b = n / 2, starting
    at its sharpest corner, and the inside is a Coons patch of those sides."""
    n = len(ring)
    P = [v.co.copy() for v in ring]

    def turn(i):
        d0 = (P[i] - P[i - 1]).normalized()
        d1 = (P[(i + 1) % n] - P[i]).normalized()
        return d0.dot(d1)
    s0 = min(range(n), key=turn)
    ring = ring[s0:] + ring[:s0]
    P = P[s0:] + P[:s0]
    a = n // 4
    b = n // 2 - a
    bot = list(range(0, a + 1))
    right = list(range(a, a + b + 1))
    top = [(a + b + a - i) % n for i in range(a + 1)]     # left to right
    left = [(n - j) % n for j in range(b + 1)]            # bottom to top
    G = {}
    for i in range(a + 1):
        G[(i, 0)] = ring[bot[i]]
        G[(i, b)] = ring[top[i]]
    for j in range(b + 1):
        G[(0, j)] = ring[left[j]]
        G[(a, j)] = ring[right[j]]
    C = lambda ij: G[ij].co
    for i in range(1, a):
        for j in range(1, b):
            u, w = i / a, j / b
            p = ((1 - w) * C((i, 0)) + w * C((i, b))
                 + (1 - u) * C((0, j)) + u * C((a, j))
                 - ((1 - u) * (1 - w) * C((0, 0)) + u * (1 - w) * C((a, 0))
                    + u * w * C((a, b)) + (1 - u) * w * C((0, b))))
            G[(i, j)] = bm.verts.new(p)
    for i in range(a):
        for j in range(b):
            bm.faces.new((G[(i, j)], G[(i + 1, j)], G[(i + 1, j + 1)],
                          G[(i, j + 1)]))


def folded_fraction(V, faces, ref_co, ref_loops, ref_sizes):
    """Share of result faces whose normal points against the nearest reference
    surface (the closed solid the engine was given). A remesh that folds over a
    thin flap or a narrow gap shows up here: the folded faces read as dark holes
    on screen even though the mesh is closed."""
    from mathutils.bvhtree import BVHTree
    starts = np.concatenate(([0], np.cumsum(ref_sizes)[:-1]))
    polys = [ref_loops[a:a + n].tolist() for a, n in zip(starts, ref_sizes)]
    tree = BVHTree.FromPolygons([tuple(v) for v in ref_co], polys)
    V = np.asarray(V, dtype=np.float64)
    bad = 0
    for f in faces:
        P = V[list(f)]
        if len(P) == 4:
            n = np.cross(P[2] - P[0], P[3] - P[1])
        else:
            n = np.cross(P[1] - P[0], P[2] - P[0])
        ln = np.linalg.norm(n)
        if ln == 0:
            continue
        hit = tree.find_nearest(P.mean(0))
        if hit[0] is not None and float(np.dot(n / ln, hit[1])) < -0.3:
            bad += 1
    return bad / max(len(faces), 1)


def drop_small_pieces(mesh, frac=0.01):
    """Delete the loose crumbs a remesh leaves beside the model: every
    connected piece with fewer than `frac` of the largest piece's faces."""
    import bmesh
    bm = bmesh.new()
    bm.from_mesh(mesh)
    seen = set()
    pieces = []
    for f in bm.faces:
        if f in seen:
            continue
        stack = [f]
        seen.add(f)
        piece = []
        while stack:
            g = stack.pop()
            piece.append(g)
            for e in g.edges:
                for h in e.link_faces:
                    if h not in seen:
                        seen.add(h)
                        stack.append(h)
        pieces.append(piece)
    big = max((len(p) for p in pieces), default=0)
    small = [f for p in pieces if len(p) < frac * big for f in p]
    if small:
        bmesh.ops.delete(bm, geom=small, context="FACES")
        bm.to_mesh(mesh)
        mesh.update()
    bm.free()
    return len(small)


def clean_solid_result(mesh):
    """Make a result remeshed from a closed solid closed again: drop the extra
    faces on edges shared by three or more (keeping quads first), cap every
    tear, then collapse the few tiny rims (<= 8 vertices) that still cannot
    take a cap - typically where a fold left a three- or four-edge slit.
    Returns the number of holes closed."""
    import bmesh
    from mathutils import Vector
    bm = bmesh.new()
    bm.from_mesh(mesh)
    kill = set()
    for e in bm.edges:
        lf = [f for f in e.link_faces if f not in kill]
        if len(lf) > 2:
            lf.sort(key=lambda f: (len(f.verts) == 4, f.calc_area()))
            kill.update(lf[:len(lf) - 2])
    if kill:
        bmesh.ops.delete(bm, geom=list(kill), context="FACES_ONLY")
        bmesh.ops.delete(bm, geom=[e for e in bm.edges if not e.link_faces], context="EDGES")
        bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_edges], context="VERTS")
    bm.to_mesh(mesh)
    bm.free()
    closed = fill_result_holes(mesh)
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bnd = {e for e in bm.edges if len(e.link_faces) == 1}
    rims = []
    while bnd:
        e = bnd.pop()
        st = [e]
        es = [e]
        while st:
            x = st.pop()
            for v in x.verts:
                for y in v.link_edges:
                    if y in bnd:
                        bnd.discard(y)
                        st.append(y)
                        es.append(y)
        rims.append(list({v for x in es for v in x.verts}))
    for vs in rims:
        if len(vs) <= 8:
            c = Vector((0.0, 0.0, 0.0))
            for v in vs:
                c += v.co
            bmesh.ops.pointmerge(bm, verts=vs, merge_co=c / len(vs))
            closed += 1
    if rims:
        bmesh.ops.dissolve_degenerate(bm, dist=1e-6, edges=bm.edges[:])
        bmesh.ops.delete(bm, geom=[e for e in bm.edges if not e.link_faces], context="EDGES")
        bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_edges], context="VERTS")
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return closed


def fill_result_holes(mesh):
    """Close every hole in a result remeshed from a closed solid - there the
    input had none, so each one is a tear. Each hole gets a fan of quads
    around its centre (a quad mesh's hole has an even edge count; an odd one
    gets a single triangle). A hole pinched at one vertex - two loops touching
    in a figure eight - is split there and each loop closed on its own.
    Returns the number of loops closed."""
    import bmesh
    bm = bmesh.new()
    bm.from_mesh(mesh)
    # the hole runs against its neighbour face: face edge a->b gives b->a
    out = {}
    for e in bm.edges:
        if len(e.link_faces) != 1:
            continue
        lv = [l.vert for l in e.link_faces[0].loops]
        i = lv.index(e.verts[0])
        if lv[(i + 1) % len(lv)] is e.verts[1]:
            u, w = e.verts[1], e.verts[0]
        else:
            u, w = e.verts[0], e.verts[1]
        out.setdefault(u, []).append(w)
    rings = []
    while out:
        u = next(iter(out))
        path = [u]
        cur = u
        while True:
            nx = out.get(cur)
            if not nx:
                path = None
                break
            w = nx.pop()
            if not nx:
                del out[cur]
            if w in path:
                # a closed sub-loop: cut it off the walk
                k = path.index(w)
                rings.append(path[k:])
                path = path[:k + 1]
                if len(path) == 1 and path[0] not in out:
                    break
                cur = w
                continue
            path.append(w)
            cur = w
        # an unfinished walk (open chain) is left alone
    closed = 0
    for ring in rings:
        n = len(ring)
        if n < 3:
            continue
        try:
            if n in (3, 4):
                bm.faces.new(ring)
            else:
                if n % 2:
                    # odd: cut one triangle off the sharpest corner, the rest
                    # is even and takes a clean grid
                    def turn(i):
                        d0 = (ring[i].co - ring[i - 1].co).normalized()
                        d1 = (ring[(i + 1) % n].co - ring[i].co).normalized()
                        return d0.dot(d1)
                    i = min(range(n), key=turn)
                    bm.faces.new((ring[i - 1], ring[i], ring[(i + 1) % n]))
                    ring = ring[:i] + ring[i + 1:] if i else ring[1:]
                if len(ring) == 4:
                    bm.faces.new(ring)
                else:
                    _grid_cap(bm, ring)
            closed += 1
        except ValueError:
            pass
    # Whatever is still open - a hole whose rim faces disagree on winding, so
    # the directed walk above cannot chain it - is capped by Blender's own
    # hole filler and the cap is turned to match its neighbours.
    rest = [e for e in bm.edges if len(e.link_faces) == 1]
    if rest:
        new = bmesh.ops.holes_fill(bm, edges=rest, sides=0)["faces"]
        if new:
            closed += len(new)
            ring = set(new)
            for f in new:
                for e in f.edges:
                    ring.update(e.link_faces)
            bmesh.ops.recalc_face_normals(bm, faces=list(ring))
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return closed


def close_input_holes(co, loops, sizes):
    """Weld touching vertices and fill every open border of the input.

    AI models often arrive with the surface cut open where parts meet: on a
    character the face shell was open along the hairline, round the eyes and
    under the goggles, and the remesh carried every opening into the result -
    raising the face count only made the holes finer. Closed first, the same
    model came back with the face whole. Returns (co, loops, sizes, n_filled).
    """
    if len(co) == 0:
        return co, loops, sizes, 0
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    faces = [loops[s:s + n].tolist() for s, n in zip(starts, sizes)]
    me = bpy.data.meshes.new("_sr_close_holes")
    try:
        me.from_pydata(co.tolist(), [], faces)
        me.validate(verbose=False)
        bm = bmesh.new()
        bm.from_mesh(me)
    finally:
        bpy.data.meshes.remove(me)
    diag = float(np.linalg.norm(co.max(0) - co.min(0)))
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=diag * 1e-5)
    filled = bmesh.ops.holes_fill(bm, edges=bm.edges, sides=0)["faces"]
    if filled:
        bmesh.ops.triangulate(bm, faces=filled)
    bm.verts.index_update()
    co2 = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
    sizes2 = np.array([len(f.verts) for f in bm.faces], dtype=np.int64)
    loops2 = np.array([v.index for f in bm.faces for v in f.verts],
                      dtype=np.int64)
    bm.free()
    return co2, loops2, sizes2, len(filled)


def weld_coincident(co, loops, sizes):
    """Join vertices that sit on the same point (to 1e-7 of the model size).

    Fast numpy version for big scans: returns (co, loops, sizes, n_welded);
    faces that collapse onto fewer than three distinct vertices are dropped.
    """
    if len(co) == 0:
        return co, loops, sizes, 0
    size = float(np.ptp(co, axis=0).max()) or 1.0
    q = np.round(co / (size * 1e-7)).astype(np.int64)
    _, first, inv = np.unique(q, axis=0, return_index=True, return_inverse=True)
    inv = inv.ravel()
    welded = len(co) - len(first)
    if welded == 0:
        return co, loops, sizes, 0
    co2 = co[first]
    lp = inv[loops]
    # drop repeated corners inside a face, then faces with < 3 corners
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    fid = np.repeat(np.arange(len(sizes)), sizes)
    nxt = np.arange(len(lp)) + 1
    ends = starts + sizes
    nxt[ends - 1] = starts
    keep_c = lp != lp[nxt]
    new_sizes = np.bincount(fid[keep_c], minlength=len(sizes))
    good = new_sizes >= 3
    keep_c &= good[fid]
    return co2, lp[keep_c], new_sizes[good].astype(np.int64), welded


def merge_input_shells(me, dist=0.0):
    """Return welded (co, loops, sizes) arrays from `me`, joined into one.

    AI and sculpt exports arrive as many separate shells - the Tripo model
    Milad tested came as 50, sitting on top of one another - and the remesh
    keeps every shell, so the result falls into 49 loose pieces. Welding the
    coincident vertices first makes the engine see one surface.

    A weld distance of zero joins only vertices at the very same point, which
    is enough for shells that share a seam; a small distance closes the hair
    gaps between shells that merely overlap. The original mesh is not touched
    - this works on a throwaway bmesh and hands back plain arrays.
    """
    import bmesh

    bm = bmesh.new()
    bm.from_mesh(me)
    size = max((max(v.co[i] for v in bm.verts) - min(v.co[i] for v in bm.verts))
               for i in range(3)) if bm.verts else 1.0
    d = dist if dist > 0.0 else size * 1e-6
    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=d)
    bm.verts.ensure_lookup_table()
    bm.verts.index_update()
    co = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
    loops = []
    sizes = []
    for f in bm.faces:
        vs = [v.index for v in f.verts]
        loops.extend(vs)
        sizes.append(len(vs))
    bm.free()
    return (co, np.array(loops, dtype=np.int64),
            np.array(sizes, dtype=np.int64))


def remesh_uv_panels(me, st, exe="", progress=None):
    """Remesh every UV panel independently, in a single engine pass.

    A garment from Marvelous Designer or a scan is sewn pattern pieces, and
    each piece is one UV island. Instead of running the engine once per island
    - which on a double-walled garment is hundreds of separate passes and
    takes minutes - the mesh is cut apart along its UV seams so every island
    becomes its own disconnected shell, and the whole lot goes through Instant
    Meshes in ONE pass. The engine grids each shell on its own and never welds
    across the gaps, so every panel still comes out independent, with its own
    border - the same result as the per-panel loop, at a fraction of the time.

    A seam is any interior edge whose two faces give the shared vertices
    different UVs; splitting those (open borders are already cuts) frees the
    islands from one another.
    """
    import bmesh
    import time

    # Handed a BMesh already read off the model when this runs on a worker
    # thread: the thread must not touch Blender's own data, a BMesh it owns
    # outright it may.
    if isinstance(me, bmesh.types.BMesh):
        bm = me
    else:
        bm = bmesh.new()
        bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    uv = bm.loops.layers.uv.active
    if uv is None:
        bm.free()
        raise RuntimeError("the model has no UV map to read seams from")

    t0 = time.perf_counter()
    # the UV a face gives each of its vertices, looked up once
    fv_uv = {}
    for f in bm.faces:
        fi = f.index
        for l in f.loops:
            u = l[uv].uv
            fv_uv[(fi, l.vert.index)] = (round(u.x, 5), round(u.y, 5))

    seams = []
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        la, lb = e.link_faces
        for va in e.verts:
            if fv_uv[(la.index, va.index)] != fv_uv[(lb.index, va.index)]:
                seams.append(e)
                break
    panels_before = 0  # islands = seam-bounded regions; report the piece count
    if seams:
        bmesh.ops.split_edges(bm, edges=seams)
    bm.verts.ensure_lookup_table()
    bm.verts.index_update()

    # The panels, and the box each one occupies.
    seen = set()
    panels = []
    boxes = []
    for f in bm.faces:
        if f.index in seen:
            continue
        panels_before += 1
        stack = [f]
        seen.add(f.index)
        piece = []
        while stack:
            cur = stack.pop()
            piece.append(cur)
            for e in cur.edges:
                for nf in e.link_faces:
                    if nf.index not in seen:
                        seen.add(nf.index)
                        stack.append(nf)
        pts = np.array([v.co[:] for pf in piece for v in pf.verts])
        boxes.append((pts.min(0), pts.max(0)))
        panels.append([pf.index for pf in piece])

    total_faces = sum(len(pcs) for pcs in panels) or 1
    faces_arg = st.target_faces if st.mode == "FACES" else None

    # One run, and still nothing for a piece to interfere with.
    #
    # Running the engine once per piece is what stops the panels pulling on
    # each other's field, but the cost of starting the engine that many times
    # is the whole job on a garment with fifteen pieces or more. So the pieces
    # are moved apart in space first - laid out in a row with a gap between
    # them - and the whole lot goes through in a single pass. A piece that is
    # only translated remeshes exactly as it would on its own, and with the gap
    # there is nothing near enough to reach. Afterwards each piece is carried
    # back to where it came from.
    span = 0.0
    for lo, hi in boxes:
        span = max(span, float(np.max(hi - lo)))
    gap = span if span > 0.0 else 1.0

    shift = []
    cursor = 0.0
    for i in range(len(panels)):
        lo, hi = boxes[i]
        width = float(hi[0] - lo[0])
        off = np.array([cursor - float(lo[0]), 0.0, 0.0])
        shift.append(off)
        cursor += width + gap

    vmap = {}
    loc = []
    loops = []
    sizes = []
    owner = []                      # which piece each face belongs to
    for i, faces in enumerate(panels):
        off = shift[i]
        for k in faces:
            f = bm.faces[k]
            vs = []
            for v in f.verts:
                key = (i, v.index)
                j = vmap.get(key)
                if j is None:
                    j = len(loc)
                    vmap[key] = j
                    loc.append(tuple(np.array(v.co[:]) + off))
                vs.append(j)
            loops.extend(vs)
            sizes.append(len(vs))
            owner.append(i)
    bm.free()

    # the count is what each piece gets; over the whole spread that is the
    # count times the number of pieces, shared out by area the way the engine
    # does it
    tp = faces_arg * len(panels) if faces_arg else None
    rg = instantmeshes.remesh(
        np.array(loc, dtype=np.float64),
        np.array(loops, dtype=np.int64),
        np.array(sizes, dtype=np.int64),
        target_faces=tp,
        target_edge=(st.target_edge if st.mode == "EDGE" else None),
        feature_angle=st.feature_angle,
        smooth_iterations=max(st.smooth_iterations, 1),
        dominant=True,
        exe=exe,
        progress=progress,
    )
    log = rg["log"]

    # Carry every piece back, one whole piece at a time. Deciding lane by
    # lane for each vertex on its own left some of them behind - the result
    # still reached out to x=88 where the model ends at 37 - so the piece is
    # found first and moved as one.
    import bmesh as _bm

    rb = _bm.new()
    rverts = [rb.verts.new(tuple(v)) for v in rg["V"]]
    rb.verts.ensure_lookup_table()
    for f in rg["faces"]:
        try:
            rb.faces.new([rverts[i] for i in f])
        except ValueError:
            pass
    rb.faces.ensure_lookup_table()
    rb.faces.index_update()
    rb.verts.index_update()

    lane_lo = [float(shift[i][0] + boxes[i][0][0]) for i in range(len(panels))]
    lane_hi = [float(shift[i][0] + boxes[i][1][0]) for i in range(len(panels))]

    back = [None] * len(rg["V"])
    seen = set()
    for f in rb.faces:
        if f.index in seen:
            continue
        stack = [f]
        seen.add(f.index)
        piece = []
        while stack:
            cur = stack.pop()
            piece.append(cur)
            for e in cur.edges:
                for nf in e.link_faces:
                    if nf.index not in seen:
                        seen.add(nf.index)
                        stack.append(nf)
        cx = sum(pf.calc_center_median().x for pf in piece) / len(piece)
        # the lane this piece sits in, or the nearest one if it strayed
        which = 0
        best = 1e30
        for i in range(len(panels)):
            if lane_lo[i] <= cx <= lane_hi[i]:
                which = i
                break
            d = min(abs(cx - lane_lo[i]), abs(cx - lane_hi[i]))
            if d < best:
                best = d
                which = i
        off = shift[which]
        for pf in piece:
            for v in pf.verts:
                back[v.index] = off
    rb.free()

    outV = []
    for i, v in enumerate(rg["V"]):
        off = back[i]
        outV.append(tuple(np.array(v) - off) if off is not None else tuple(v))
    outF = [tuple(f) for f in rg["faces"]]

    nf = len(outF)
    quads = sum(1 for f in outF if len(f) == 4)
    tris = sum(1 for f in outF if len(f) == 3)
    r = {"V": outV, "faces": outF, "log": dict(log or {})}
    r["log"]["output"] = {"faces": nf, "quads": quads, "tris": tris,
                          "ngons": nf - quads - tris,
                          "quad_ratio": (quads / nf if nf else 0.0)}
    r["log"]["panels"] = panels_before
    r["log"]["engine_runs"] = 1
    r["log"]["split_seconds"] = round(time.perf_counter() - t0, 2)
    return r


def thin_shell_limit(me, samples=600):
    """The face count below which thin parts of `me` fuse to themselves.

    Instant Meshes lays a grid of roughly even edge length. Where the model
    is thinner than that edge - the hem of a shirt, a fingernail, a sheet of
    cloth - the front and back of the sheet fall in the same cell and the
    quads bridge straight across, which reads as the surface tearing into
    itself. Measured on Milad's character: 4.4% of faces bridged at 19500
    faces, 1.9% at 39700.

    Thickness is measured by shooting inward from sample faces and taking
    the first hit. The fifth percentile stands for "the thin parts", not the
    single thinnest sliver, so one stray tooth does not set the whole limit.
    """
    import bmesh
    from mathutils.bvhtree import BVHTree
    if len(me.polygons) < 8:
        return 0, 0.0
    # A search tree over a 939000-face scan takes longer than the remesh
    # itself, and this only produces a warning. Past this size the advice is
    # skipped rather than paid for.
    if len(me.polygons) > 200000:
        return 0, 0.0
    tree = BVHTree.FromPolygons([v.co[:] for v in me.vertices],
                                [f.vertices[:] for f in me.polygons])
    ext = [max(v.co[i] for v in me.vertices) - min(v.co[i] for v in me.vertices)
           for i in range(3)]
    diag = max(ext) or 1.0
    step = max(1, len(me.polygons) // samples)
    thick = []
    for i in range(0, len(me.polygons), step):
        f = me.polygons[i]
        o = f.center - f.normal * (diag * 1e-4)
        hit = tree.ray_cast(o, -f.normal, diag)
        if hit and hit[0] is not None and hit[3] > diag * 1e-5:
            thick.append(hit[3])
    if len(thick) < 8:
        return 0, 0.0
    thick.sort()
    thin = thick[int(len(thick) * 0.05)]
    # a quad grid of `n` faces over this surface has edges of about
    # sqrt(area / n), and it has to be finer than the thin part to resolve it
    area = sum(f.area for f in me.polygons)
    if thin <= 0 or area <= 0:
        return 0, 0.0
    return int(area / (thin * thin)), thin


def spread_by_shape(new_mesh, target_faces, keep_marked=False,
                    progress=None):
    """Take a uniform quad mesh down to `target_faces`, flat parts first.

    Instant Meshes only takes one size for the whole model, so its output is
    evenly dense everywhere - the same grid on a flat thigh as on the rolled
    hem beside it. Asking it for more than is wanted and then dropping the
    loops that carry no shape puts those faces where the form actually is,
    which is what the reference models do: dense at a rounded edge, sparse
    across a flat.

    The loop drop is the one already used by Erase Useless Loops. It only
    ever takes a loop whole, so the grid stays a grid.
    """
    import bmesh
    from .core import panelize as PZ

    bm = bmesh.new()
    bm.from_mesh(new_mesh)
    bm.edges.ensure_lookup_table()
    PZ.tag_marked(bm)
    start = len(bm.faces)
    if start <= target_faces:
        bm.free()
        return start, 0

    # Ranked by how much shape each loop is carrying, cheapest taken first,
    # until the budget is met. A flatness threshold was tried and cannot do
    # this job on a body: nothing there is flat, so it freed almost nothing.
    total = PZ.drop_to_budget(bm, target_faces, keep_marked=keep_marked,
                              progress=progress)
    PZ.heal_stubs(bm)
    PZ.polish_verts(bm)
    bm.to_mesh(new_mesh)
    bm.free()
    new_mesh.update()
    return start, total


class MONSTERREMESH_OT_spread(Operator):
    """Thin a freshly built mesh to its face budget, a round per tick."""

    bl_idname = "mesh.monsterremesh_spread"
    bl_label = "Spreading faces by shape"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    mesh_name: bpy.props.StringProperty()
    target: bpy.props.IntProperty(default=0)

    _timer = None
    _thinner = None
    _bm = None
    _mesh = None

    def execute(self, context):
        return self.invoke(context, None)

    def invoke(self, context, event):
        import bmesh
        from .core import panelize as PZ
        self._mesh = bpy.data.meshes.get(self.mesh_name)
        if self._mesh is None or not self.target:
            return {"CANCELLED"}
        self._bm = bmesh.new()
        self._bm.from_mesh(self._mesh)
        self._bm.edges.ensure_lookup_table()
        PZ.tag_marked(self._bm)
        if len(self._bm.faces) <= self.target:
            self._bm.free()
            return {"CANCELLED"}
        self._thinner = PZ.BudgetThinner(self._bm, self.target,
                                         keep_marked=False)
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        context.window_manager.progress_begin(0.0, 1.0)
        return {"RUNNING_MODAL"}

    def _shut(self, context, write):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        wm.progress_end()
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        n = 0
        if self._thinner is not None:
            n = self._thinner.finish()
        if write and self._bm is not None and self._mesh is not None:
            self._bm.to_mesh(self._mesh)
            self._mesh.update()
        if self._bm is not None:
            self._bm.free()
            self._bm = None
        return n

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            n = self._shut(context, True)
            self.report({"INFO"}, f"stopped early, {n} loops removed")
            return {"CANCELLED"}
        if event.type != "TIMER":
            return {"PASS_THROUGH"}
        going = True
        try:
            going = self._thinner.round()
        except Exception as exc:
            self._shut(context, True)
            self.report({"WARNING"}, f"thinning stopped: {exc}")
            return {"CANCELLED"}
        wm = context.window_manager
        wm.progress_update(self._thinner.fraction)
        try:
            context.workspace.status_text_set(
                f"Monster Remesh - spreading "
                f"{len(self._bm.faces):,} of {self.target:,} faces  "
                f"{self._thinner.fraction * 100:.0f}%   (Esc to stop)")
        except Exception:
            pass
        for area in context.screen.areas:
            area.tag_redraw()
        if not going:
            n = self._shut(context, True)
            self.report({"INFO"},
                        f"spread by shape: down to "
                        f"{len(self._mesh.polygons):,} faces, {n} loops removed")
            return {"FINISHED"}
        return {"RUNNING_MODAL"}


class MONSTERREMESH_OT_hand_to_hardsurface(Operator):
    """Carry the organic result over to the Hardsurface tools.

    The two halves of the add-on each work on their own object: Organic
    builds one and Hardsurface edits whatever it has been pointed at. Until
    now there was no way to say "the mesh I just built is the one I want to
    keep working on", so the loop tools were still aimed at the original
    scan. This hands the result over and clears the editing history that
    belonged to the previous subject, so Erase Useless Loops and Clean
    Between Lines start from this mesh instead of undoing their way back to
    another one.
    """

    bl_idname = "mesh.monsterremesh_to_hardsurface"
    bl_label = "Confirm & Edit"
    bl_description = ("Keep this result and carry on with it in Monster Remesh "
                      "(Hardsurface) - Erase Useless Loops, Clean Between "
                      "Lines and the rest then work on this mesh")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and len(o.data.polygons)

    def execute(self, context):
        obj = context.active_object
        lines = getattr(context.scene, "monsterremesh_lines", None)
        if lines is None:
            self.report({"ERROR"}, "the Hardsurface side is not loaded")
            return {"CANCELLED"}

        # Whatever the loop tools were holding belongs to another mesh.
        _drop_clean_snapshots(obj)
        for key in ("monsterremesh_drop_first",):
            if key in obj:
                name = obj.get(key)
                del obj[key]
                m = bpy.data.meshes.get(name or "")
                if m is not None:
                    m.use_fake_user = False
                    if m.users == 0:
                        bpy.data.meshes.remove(m)

        lines.source = obj.name
        lines.result = ""
        try:
            from .lines_preview import forget_cache
            forget_cache(obj)
        except Exception:
            pass

        for o in list(context.selected_objects):
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({"INFO"},
                    f"{obj.name} handed to Hardsurface - "
                    f"{len(obj.data.polygons):,} faces")
        return {"FINISHED"}


# Progress of the remesh that is running, read by the card and the N panel.
#
# Customers said that once Remesh was pressed Blender simply froze, with no
# sign whether it was working or had died - on a heavy model that is the best
# part of a minute of nothing. The engine now runs on a worker thread, which
# only writes here; Blender keeps drawing, and the panels show this.
RUN = {
    "busy": False,       # a remesh is on its worker thread
    "stage": "",         # what it is doing now, in words
    "frac": 0.0,         # how far the engine says it is, 0..1
    "shown": 0.0,        # what the bar shows - eased, so it never stands still
    "since": 0.0,        # when the engine last moved `frac`
    "t0": 0.0,           # when the job started
    "cancel": False,     # Escape was pressed
}


def ease_bar(state, real, ending=False):
    """Move a progress bar one timer tick, so it never stands still.

    The engines report in steps, and between two reports - or while Blender
    itself is busy building the result - a bar that only shows the last report
    sits on one number and then leaps to 100, which reads as a hang. Milad
    would rather it went slower and never stopped. So: when the real figure
    is ahead, the bar catches up smoothly; when it is not, the bar keeps
    walking toward the end at a pace worked out from how long the job has
    taken so far, which slows it down the longer the wait, and never lets it
    reach the end on its own.
    """
    import time
    shown = state["shown"]
    if ending:
        shown += max(0.012, (1.0 - shown) * 0.45)
        state["shown"] = min(1.0, shown)
        return state["shown"] >= 1.0
    if real > shown:
        shown = min(real, shown + max(0.003, (real - shown) * 0.3))
    else:
        took = max(0.1, time.time() - state["t0"])
        done = max(real, 0.03)
        # the rest of the job, if it keeps the pace it has had - generous,
        # because running out of bar is worse than running slow
        rest = max(2.0, took * (1.0 - done) / done) * 1.6
        shown += (0.995 - shown) * min(0.2, 0.1 / rest)
    state["shown"] = min(0.995, max(state["shown"], shown))
    return False


class _Cancelled(Exception):
    """Raised inside the engine's progress callback to stop the job."""


def run_progress_text():
    """'Remeshing  42%' with how long it has been, for the panels."""
    import time
    pct = int(RUN["shown"] * 100.0)
    secs = int(time.time() - RUN["t0"])
    return f"{pct}%  {RUN['stage']}  {secs}s"


def _redraw_views():
    wm = bpy.context.window_manager
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


class MONSTERREMESH_OT_run(Operator):
    bl_idname = "mesh.monsterremesh_run"
    bl_label = "Remesh (Organic)"
    bl_description = ("Rebuild the active mesh as quads using our own "
                      "cross-field solver")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if RUN["busy"]:
            return False
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and len(obj.data.polygons)

    SOURCE_KEY = MONSTERREMESH_SOURCE

    _timer = None
    _thread = None
    _job = None

    # -- read everything the engine needs, on the main thread ---------------
    def _gather(self, context):
        import types

        obj = context.active_object
        st = context.scene.monsterremesh

        # If the active object is one of our own results, work from the mesh it
        # came from. Re-running on a result compounds the reduction, and because
        # the second pass has almost nothing left to detect, every setting then
        # produces the same wreckage - which reads as "the sliders do nothing".
        src_name = obj.get(self.SOURCE_KEY)
        if src_name:
            src = bpy.data.objects.get(src_name)
            if src is not None and src.type == "MESH":
                self.report({"INFO"},
                            f"rebuilding from the original '{src_name}'")
                obj = src
            else:
                self.report({"WARNING"},
                            f"source '{src_name}' is gone; using this mesh")
        me = obj.data

        # The settings as they are now. The worker must not read Blender's
        # properties while the user is free to change them, so it gets a copy.
        snap = types.SimpleNamespace()
        for p in st.bl_rna.properties:
            if p.identifier != "rna_type" and p.type not in {"POINTER",
                                                             "COLLECTION"}:
                setattr(snap, p.identifier, getattr(st, p.identifier))
        exe = engine_path()

        # Per-panel path: split the garment along its UV seams and remesh each
        # piece on its own. It builds its own per-island arrays inside
        # remesh_uv_panels, so the whole-mesh input below is skipped.
        uv_mode = (st.backend == "CLOTH" and st.uv_panels)

        bm = None
        if uv_mode:
            co = loops = sizes = None
            bm = bmesh.new()
            bm.from_mesh(me)
        elif st.backend == "CLOTH" or st.merge_shells:
            # weld the loose shells into one surface before the engine sees
            # them, or the result comes out in as many pieces as went in
            before_v = len(me.vertices)
            co, loops, sizes = merge_input_shells(me, st.merge_dist)
            welded = before_v - len(co)
            if welded > 0:
                self.report({"INFO"}, f"merged shells: welded {welded} verts")
        else:
            nv = len(me.vertices)
            co = np.empty(nv * 3, dtype=np.float64)
            me.vertices.foreach_get("co", co)
            co = co.reshape(nv, 3)

            npoly = len(me.polygons)
            sizes = np.empty(npoly, dtype=np.int64)
            me.polygons.foreach_get("loop_total", sizes)
            loops = np.empty(int(sizes.sum()), dtype=np.int64)
            me.loops.foreach_get("vertex_index", loops)
            # Exports often split one surface into many shells along hard
            # edges / UV seams, with the vertices of both sides sitting on the
            # very same point. Left alone, the engine grids every shell on its
            # own and the result falls apart into hundreds of pieces. Joining
            # exactly coincident vertices changes no geometry, so it is always
            # done (Merge Shells is still there for gaps that need a distance).
            co, loops, sizes, welded = weld_coincident(co, loops, sizes)
            if welded > 0:
                self.report({"INFO"}, f"joined split shells: welded {welded} verts")

        if st.close_holes and not uv_mode and st.backend != "CLOTH":
            co, loops, sizes, filled = close_input_holes(co, loops, sizes)
            if filled > 0:
                self.report({"INFO"}, f"closed {filled} holes in the input")

        solid = False
        fine_solid = None
        if (not uv_mode and st.backend != "CLOTH"
                and st.solid_rebuild != "OFF"):
            w_ = 1 if st.merge_shells else welded
            if st.solid_rebuild == "ON" or wants_solid(co, loops, sizes, w_):
                tf_ = st.target_faces if st.mode == "FACES" else None
                te_ = st.target_edge if st.mode == "EDGE" else None
                # Two solids: a coarse one (three voxels per result edge)
                # closes the narrow gaps of kitbash parts cleanly; a fine one
                # (eight per edge) keeps thin flaps such as a shirt hem over
                # trousers apart. Which one a model needs cannot be read off
                # its thickness, so the coarse one runs first and the fine one
                # only if the coarse result comes out folded (see work()).
                fine_solid = solid_prepass(co, loops, sizes, target_faces=tf_,
                                           target_edge=te_, max_faces=4_000_000,
                                           div=8.0)
                co, loops, sizes, vox = solid_prepass(
                    co, loops, sizes, target_faces=tf_, target_edge=te_)
                solid = True
                self.report({"INFO"},
                            f"solid rebuild: voxel {vox * 1000:.2f} mm")

        faces_arg = st.target_faces if st.mode == "FACES" else None
        # Our engine only. This asks the engine for several times the face
        # count and then drops the loops that carry no shape, and it used to
        # run under Instant Meshes as well - where Adaptive Density is not
        # even shown, because that engine has no sizing field of its own. A
        # customer on Manual with the tick left on from an earlier session
        # got 15,000 faces built as 135,000 and thinned back down, and could
        # not find the setting that was doing it because the panel does not
        # offer it there. Under Instant Meshes the result now matches 1.x
        # exactly: the engine's own output, untouched.
        spread = (st.adaptive and st.backend == "OURS"
                  and st.mode == "FACES" and faces_arg)
        if spread:
            faces_arg = int(faces_arg * st.spread_over * st.spread_over)
        # Two passes for a low count on a closed solid. At a low count one
        # face is wider than the thin parts of the model (blade teeth, cracks,
        # horns) and Instant Meshes tears and folds there. Measured on a Tripo
        # sword: 10,000 asked straight gave 41 open edges and folded patches,
        # 20,000 came out whole. So the model is built at twice the count
        # first, that closed result is remeshed again at the count asked for
        # (see _finish_steps), and the second pass sees one smooth surface.
        second_pass = None
        if (st.two_pass and solid and st.backend == "STABLE"
                and faces_arg and not uv_mode):
            second_pass = int(faces_arg)
            faces_arg = int(faces_arg * 2)
        edge_arg = st.target_edge if st.mode == "EDGE" else None
        s = snap

        def engine(co, loops, sizes, progress):
            if uv_mode:
                return remesh_uv_panels(bm, s, exe=exe, progress=progress)
            if s.backend == "OURS":
                return run_remesh(
                    co, loops, sizes,
                    target_faces=faces_arg,
                    target_edge=edge_arg,
                    feature_angle=s.feature_angle,
                    orient_iterations=s.orient_iterations,
                    position_iterations=s.position_iterations,
                    smooth_iterations=s.smooth_iterations,
                    use_curvature=s.use_curvature,
                    adaptive=s.adaptive,
                    density_match=False,
                    density_strength=s.density_strength,
                    feature_density=s.feature_density,
                    curvature_density=s.curvature_density,
                    inner_density=s.inner_density,
                    outer_density=s.outer_density,
                    thin_strength=s.thin_density,
                    min_size_ratio=s.min_size_ratio,
                    gradient_limit=s.gradient_limit,
                    progress=progress,
                )
            if s.backend == "AUTO":
                return auto_remesh(
                    co, loops, sizes,
                    target_faces=faces_arg or 4000,
                    crease_override=None if s.auto_crease else s.feature_angle,
                    calibrate=s.auto_calibrate,
                    search=s.auto_search,
                    smooth_iterations=max(s.smooth_iterations, 1),
                    exe=exe,
                    progress=progress,
                    allow_dominant=True,
                )
            if s.backend in {"STABLE", "CLOTH"}:
                return instantmeshes.remesh(
                    co, loops, sizes,
                    target_faces=faces_arg,
                    target_edge=edge_arg,
                    feature_angle=s.feature_angle,
                    smooth_iterations=max(s.smooth_iterations, 1),
                    dominant=True,
                    exe=exe,
                    progress=progress,
                )
            raise RuntimeError(f"unknown engine {s.backend!r}")

        def work(progress):
            r = engine(co, loops, sizes, progress)
            if not solid or fine_solid is None:
                return r
            # judged against the FINE solid: it follows the source closely,
            # while the coarse solid already carries the folds being looked for
            rco, rlp, rsz, _ = fine_solid
            fold = folded_fraction(r["V"], r["faces"], rco, rlp, rsz)
            r["solid_choice"] = f"coarse voxel, {fold * 100:.1f}% folded"
            if fold <= 0.005:
                return r
            cf, lf, sf, voxf = fine_solid
            r2 = engine(cf, lf, sf, progress)
            fold2 = folded_fraction(r2["V"], r2["faces"], rco, rlp, rsz)
            if fold2 < fold:
                r2["solid_choice"] = (f"fine voxel {voxf * 1000:.2f} mm, "
                                      f"{fold2 * 100:.1f}% folded (coarse "
                                      f"{fold * 100:.1f}%)")
                return r2
            r["solid_choice"] += f" (fine {fold2 * 100:.1f}%, kept coarse)"
            return r

        def again(co, loops, sizes):
            return instantmeshes.remesh(
                co, loops, sizes,
                target_faces=second_pass,
                feature_angle=s.feature_angle,
                smooth_iterations=max(s.smooth_iterations, 1),
                dominant=True,
                exe=exe,
            )

        return {"obj": obj.name, "mesh": me.name, "uv_mode": uv_mode,
                "spread": spread, "solid": solid, "work": work, "result": None,
                "error": None,
                "second_pass": again if second_pass else None}

    # -- the synchronous path, for scripts and other operators ---------------
    def execute(self, context):
        job = self._gather(context)
        wm = context.window_manager
        wm.progress_begin(0.0, 1.0)

        def report_progress(name, frac):
            wm.progress_update(frac)
            try:
                context.workspace.status_text_set(
                    f"Monster Remesh - {name}  {frac * 100:.0f}%")
            except Exception:
                pass

        try:
            result = job["work"](report_progress)
        except Exception as exc:
            traceback.print_exc()
            wm.progress_end()
            self.report({"ERROR"}, f"Monster Remesh failed: {exc}")
            return {"CANCELLED"}
        return self._finish(context, job, result)

    # -- the button: the engine on a thread, Blender left free ---------------
    def invoke(self, context, event):
        import threading
        import time

        job = self._gather(context)
        self._job = job
        now = time.time()
        RUN.update(busy=True, stage="starting", frac=0.0, shown=0.0,
                   since=now, t0=now, cancel=False)

        def progress(name, frac):
            # Only plain values cross over; the modal below does the drawing.
            if RUN["cancel"]:
                raise _Cancelled()
            if frac >= RUN["frac"]:
                RUN["frac"] = float(frac)
                RUN["since"] = time.time()
            if name and name != "done":
                RUN["stage"] = name

        def run():
            try:
                job["result"] = job["work"](progress)
            except _Cancelled:
                job["error"] = "cancelled"
            except Exception as exc:
                traceback.print_exc()
                job["error"] = str(exc) or exc.__class__.__name__

        self._thread = threading.Thread(target=run, daemon=True,
                                        name="SmartRemesh")
        self._thread.start()
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        self._steps = None
        self._ending = False
        _redraw_views()
        return {"RUNNING_MODAL"}

    def _stop(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        RUN["busy"] = False
        _redraw_views()

    def modal(self, context, event):
        import math
        import time

        if event.type == "ESC" and event.value == "PRESS":
            RUN["cancel"] = True
            RUN["stage"] = "stopping"
            return {"RUNNING_MODAL"}
        if event.type != "TIMER":
            # orbit, zoom and select all keep working while it runs
            return {"PASS_THROUGH"}

        # The engine is the first 85% of the bar; building the result in
        # Blender is the rest, a step per tick so the bar moves through it.
        if self._thread.is_alive():
            ease_bar(RUN, RUN["frac"] * 0.85)
            self._show(context)
            return {"PASS_THROUGH"}

        job = self._job
        if self._ending:
            if ease_bar(RUN, 1.0, ending=True):
                self._stop(context)
                return {"FINISHED"}
            self._show(context)
            return {"PASS_THROUGH"}

        if self._steps is None:
            if job["error"] == "cancelled":
                self._stop(context)
                self.report({"WARNING"}, "remesh stopped")
                return {"CANCELLED"}
            if job["error"]:
                self._stop(context)
                self.report({"ERROR"}, f"Monster Remesh failed: {job['error']}")
                return {"CANCELLED"}
            if context.object is not None and context.object.mode != "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode="OBJECT")
                except Exception:
                    pass
            self._steps = self._finish_steps(job, job["result"])
            self._step_no = 0
            RUN["stage"] = "building the mesh"
            ease_bar(RUN, 0.85)
            self._show(context)
            return {"PASS_THROUGH"}     # drawn first, then the heavy part

        try:
            RUN["stage"] = next(self._steps)
            self._step_no += 1
            ease_bar(RUN, 0.85 + 0.15 * min(self._step_no, 5) / 6.0)
        except StopIteration as stop:
            if "FINISHED" not in (stop.value or {"FINISHED"}):
                self._stop(context)
                return {"CANCELLED"}
            RUN["stage"] = "done"
            self._ending = True
        self._show(context)
        return {"PASS_THROUGH"}

    def _show(self, context):
        try:
            context.workspace.status_text_set(
                "Monster Remesh - " + run_progress_text() + "   Esc to stop")
        except Exception:
            pass
        _redraw_views()

    def cancel(self, context):
        RUN["cancel"] = True
        self._stop(context)

    # -- build the result, on the main thread --------------------------------
    def _finish(self, context, job, result):
        steps = self._finish_steps(job, result)
        try:
            while True:
                next(steps)
        except StopIteration as stop:
            return stop.value or {"FINISHED"}

    def _finish_steps(self, job, result):
        # Yields between the parts that take time, so the button path can
        # move the bar in between. The context is read fresh each time.
        context = bpy.context
        wm = context.window_manager
        st = context.scene.monsterremesh
        obj = bpy.data.objects.get(job["obj"])
        me = bpy.data.meshes.get(job["mesh"])
        if obj is None or me is None:
            wm.progress_end()
            self.report({"ERROR"}, "the model was removed while it was being "
                                   "remeshed")
            return {"CANCELLED"}
        uv_mode = job["uv_mode"]
        spread = job["spread"]

        Vo = result["V"]
        faces = result["faces"]
        log = result["log"]

        new_mesh = bpy.data.meshes.new(me.name + "_S-Remesh")
        new_mesh.from_pydata([tuple(v) for v in Vo], [], faces)
        new_mesh.update()
        new_mesh.validate(verbose=False)
        yield "carrying the materials"
        # The engine's mesh is handed over as it came out. Version 2 used to
        # patch the holes it leaves, but on a model that is open on purpose -
        # a scanned wall, a single-sided sheet - that filled in the opening
        # and turned it solid, and no amount of guarding made the test
        # trustworthy on every asset. The material and UV transfer below
        # stays: measured, it leaves the topology untouched.
        patched = 0
        if result.get("solid_choice"):
            self.report({"INFO"}, "solid rebuild: " + result["solid_choice"])
        if job.get("solid"):
            # the engine saw one closed solid, so every hole is a tear
            patched = clean_solid_result(new_mesh)
            if patched:
                self.report({"INFO"}, f"closed {patched} tears")
        if job.get("second_pass"):
            yield "second pass"
            nv = len(new_mesh.vertices)
            c2 = np.empty(nv * 3, dtype=np.float64)
            new_mesh.vertices.foreach_get("co", c2)
            s2 = np.empty(len(new_mesh.polygons), dtype=np.int64)
            new_mesh.polygons.foreach_get("loop_total", s2)
            l2 = np.empty(int(s2.sum()), dtype=np.int64)
            new_mesh.loops.foreach_get("vertex_index", l2)
            try:
                r2 = job["second_pass"](c2.reshape(nv, 3), l2, s2)
            except Exception as exc:
                # the first pass is whole and stays the result
                self.report({"WARNING"}, f"second pass failed, kept the "
                                         f"first: {exc}")
            else:
                new_mesh.clear_geometry()
                new_mesh.from_pydata([tuple(v) for v in r2["V"]], [],
                                     r2["faces"])
                new_mesh.update()
                new_mesh.validate(verbose=False)
                drop_small_pieces(new_mesh)
                patched = clean_solid_result(new_mesh)
                log = r2["log"]
                self.report({"INFO"}, f"second pass: closed {patched} tears")
        wm.progress_end()
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        if spread:
            # handed to the modal thinner below, which runs a round per
            # timer tick so the bar moves and Escape still works
            spread_pending = (new_mesh, st.target_faces)
        else:
            spread_pending = None
        # Guarded: a part-replaced install - a new __init__ beside an old
        # lines_preview - used to stop the remesh dead with an ImportError
        # instead of simply doing without the material transfer.
        try:
            from .lines_preview import keep_materials, keep_uvs
        except ImportError:
            keep_materials = keep_uvs = None
        if keep_materials is not None:
            keep_materials(me, new_mesh)
        yield "shading"
        # The scan's custom split normals travel with the material transfer
        # and override every shading setting after it - see `fresh_shading`.
        try:
            from .lines_preview import fresh_shading
            fresh_shading(new_mesh, mark_sharp=st.mark_sharp)
        except ImportError:
            pass
        yield "carrying the UVs"

        if st.replace:
            old = obj.data
            obj.data = new_mesh
            # Keep it. It used to be deleted the moment it went unused, which
            # made Replace Original a one-way door - there was nothing left to
            # put back. The fake user keeps the datablock alive with no object
            # pointing at it until Restore Original hands it back.
            old.use_fake_user = True
            obj[MONSTERREMESH_ORIG] = old.name
            target = obj
            try:
                from .lines_preview import mute_topology_mods
                off = mute_topology_mods(obj)
                if off:
                    self.report({"INFO"},
                                "switched off " + ", ".join(off)
                                + " so they do not undo the remesh")
            except ImportError:
                pass
            if keep_uvs is not None:
                try:
                    from .lines_preview import keep_uvs_steps
                except ImportError:
                    keep_uvs(target, old)
                else:
                    yield from keep_uvs_steps(target, old)
        else:
            # A fresh object every time. It used to hunt down the previous
            # result and swap its mesh out, to stop duplicates piling up while
            # a setting was tweaked - but that made every earlier result
            # disposable: remesh, keep a copy, remesh again, and the copy was
            # overwritten because it carried the same source key. Milad's
            # words - once a mesh is remeshed its job is done, the next run
            # must not touch it. So each run makes its own object and leaves
            # every earlier one exactly where it is.
            target = bpy.data.objects.new(obj.name + "_S-Remesh", new_mesh)
            for coll in obj.users_collection:
                coll.objects.link(target)
            target[self.SOURCE_KEY] = obj.name
            if keep_uvs is not None:
                try:
                    from .lines_preview import keep_uvs_steps
                except ImportError:
                    keep_uvs(target, me)
                else:
                    yield from keep_uvs_steps(target, me)
            target[MONSTERREMESH_KIND] = "organic"
            target.matrix_world = obj.matrix_world.copy()
            # The source is deliberately left visible. Hiding it silently reads
            # as the add-on having deleted the reference.
            # Same reason as in lines_preview: `bpy.ops` needs a context
            # this operator may not have, and setting the flag does not.
            for o in list(context.selected_objects):
                o.select_set(False)
            target.select_set(True)
            context.view_layer.objects.active = target

        yield "finishing"
        if (st.close_tears or st.backend == "CLOTH") and not uv_mode:
            # Per-panel keeps every seam and opening open on purpose, so the
            # tear-filler is left off - it would cap the panel borders.
            b, a = close_tears(target, st.tear_size)
            if b:
                self.report({"INFO"}, f"closed tears: {b} -> {a} open edges")

        o = log["output"]
        msg = (f"{o['faces']} faces ({o['quads']} quad / {o['tris']} tri / "
               f"{o['ngons']} ngon, {o['quad_ratio']:.0%} quads) in "
               f"{log['seconds']:.1f}s")
        if st.backend == "AUTO":
            msg += (f" | crease {log['crease_used']:.0f}deg"
                    f" ({log['analysis']['kind']})"
                    f", score {log['final_score']}")
            for line in log["attempts"]:
                print("QuadRemesh attempt:", line)
        self.report({"INFO"}, msg)
        if spread_pending is not None:
            # a round per timer tick, so the bar moves, the viewport
            # keeps drawing, and Escape stops it part way
            bpy.ops.mesh.monsterremesh_spread(
                "INVOKE_DEFAULT", mesh_name=spread_pending[0].name,
                target=spread_pending[1])
        return {"FINISHED"}


def _drop_clean_snapshots(obj):
    """Forget any Clean Between Lines history stored on this object."""
    for key in ("monsterremesh_clean_orig", "monsterremesh_clean_base",
                "monsterremesh_drop_orig"):
        name = obj.get(key)
        if not name:
            continue
        del obj[key]
        mesh = bpy.data.meshes.get(name)
        if mesh is not None:
            mesh.use_fake_user = False
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)


def _own_repo():
    """(repo_index, repo_directory, package id) of this extension, or None.

    Installed as an extension the module is ``bl_ext.<repo>.<id>``; the repo
    is found by that middle part, the same way Blender's own card finds it.
    """
    parts = (__package__ or "").split(".")
    if len(parts) != 3 or parts[0] != "bl_ext":
        return None
    for i, repo in enumerate(bpy.context.preferences.extensions.repos):
        if repo.module == parts[1]:
            return i, repo.directory, parts[2]
    return None


def _uninstall_later():
    """Run Blender's own uninstall once nothing of ours is mid-call.

    The button is pressed from inside the card, whose modal operator is still
    on the stack; tearing the add-on down underneath it is what crashes. So
    the card is put away first and the uninstall runs on the next tick.
    """
    found = _own_repo()
    try:
        if found is not None:
            index, directory, pkg = found
            bpy.ops.extensions.package_uninstall(
                repo_directory=directory, repo_index=index, pkg_id=pkg)
        else:
            # installed the old way, as a plain add-on folder
            bpy.ops.preferences.addon_remove(module=__package__)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        print("Monster Remesh: uninstalled")
    except Exception as exc:
        print("Monster Remesh: uninstall failed:", exc)
    return None


class MONSTERREMESH_OT_uninstall(Operator):
    """Remove Monster Remesh from Blender - the same uninstall as the
    extension card in Preferences, asked for from here."""

    bl_idname = "mesh.monsterremesh_uninstall"
    bl_label = "Uninstall Monster Remesh"
    bl_description = ("Disable and delete Monster Remesh from this Blender. "
                      "Your saved presets are kept")
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self, event, title="Uninstall Monster Remesh?",
            message="The add-on is disabled and its files deleted. "
                    "Saved presets stay.",
            confirm_text="Uninstall", icon="WARNING")

    def execute(self, context):
        try:
            overlay.clear()
        except Exception:
            pass
        bpy.app.timers.register(_uninstall_later, first_interval=0.2)
        self.report({"INFO"}, "Uninstalling Monster Remesh...")
        return {"FINISHED"}


class MONSTERREMESH_OT_reset_all(Operator):
    """Put the whole file back: every remesh and every cleaning.

    The per-step buttons each undo one thing, which is right while working but
    useless when the answer is "start over". This walks every object the
    add-on has marked and undoes all of it in one go.
    """

    bl_idname = "mesh.monsterremesh_reset_all"
    bl_label = "Reset Everything"
    bl_description = ("Undo every remesh and every cleaning in this file, on "
                      "all objects, and delete the result objects")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" and (
                       MONSTERREMESH_ORIG in o or MONSTERREMESH_SOURCE in o
                       or o.get("monsterremesh_clean_base"))
                   for o in bpy.data.objects)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        if context.active_object is not None and context.active_object.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")

        restored = deleted = cleaned = 0

        # Cleaning first. Restoring a remesh swaps the whole datablock, so a
        # clean snapshot taken after it would be pointing at a mesh that is
        # about to be dropped.
        for obj in list(bpy.data.objects):
            if obj.type != "MESH":
                continue
            base = (bpy.data.meshes.get(obj.get("monsterremesh_drop_orig") or "")
                    or bpy.data.meshes.get(obj.get("monsterremesh_clean_base") or ""))
            if base is not None and MONSTERREMESH_ORIG not in obj:
                bm = bmesh.new()
                bm.from_mesh(base)
                bm.to_mesh(obj.data)
                bm.free()
                obj.data.update()
                cleaned += 1
            _drop_clean_snapshots(obj)

        for obj in list(bpy.data.objects):
            if obj.type != "MESH":
                continue
            orig_name = obj.get(MONSTERREMESH_ORIG)
            if orig_name:
                mesh = bpy.data.meshes.get(orig_name)
                if mesh is not None:
                    spent = obj.data
                    obj.data = mesh
                    mesh.use_fake_user = False
                    del obj[MONSTERREMESH_ORIG]
                    if spent.users == 0 and not spent.use_fake_user:
                        bpy.data.meshes.remove(spent)
                    restored += 1
                    obj.pop(MONSTERREMESH_SOURCE, None)
                    obj.pop(MONSTERREMESH_KIND, None)
                continue
            src_name = obj.get(MONSTERREMESH_SOURCE)
            if src_name:
                src = bpy.data.objects.get(src_name)
                if src is not None:
                    src.hide_set(False)
                    src.hide_viewport = False
                data = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                if data.users == 0 and not data.use_fake_user:
                    bpy.data.meshes.remove(data)
                deleted += 1

        st = context.scene.monsterremesh_lines
        st.source = ""
        st.result = ""
        st.build_info = (f"reset everything  |  {restored} restored, "
                         f"{deleted} results removed, {cleaned} uncleaned")
        self.report({"INFO"}, st.build_info)
        return {"FINISHED"}


class MONSTERREMESH_OT_restore(Operator):
    bl_idname = "mesh.monsterremesh_restore"
    bl_label = "Restore Original"
    bl_description = ("Put the selected results back the way they were. Works "
                      "on anything this add-on made: a result object is "
                      "deleted and its source unhidden, and a mesh that was "
                      "replaced in place gets its original geometry back")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def _targets(cls, o):
        """What to undo when `o` is selected.

        Three ways in, because a user thinks in models rather than in which
        datablock happens to carry the marker:

        - a result object undoes itself
        - a model that was replaced in place undoes itself
        - **the original model** undoes whatever was made from it. Without this
          the button sat greyed out when you selected the model you had just
          remeshed, which reads as broken - the result was sitting right next
          to it.
        """
        if o.type != "MESH":
            return []
        if MONSTERREMESH_ORIG in o or MONSTERREMESH_SOURCE in o:
            return [o]
        return [x for x in bpy.data.objects
                if x.type == "MESH" and x.get(MONSTERREMESH_SOURCE) == o.name]

    @classmethod
    def poll(cls, context):
        return any(cls._targets(o) for o in context.selected_objects)

    def execute(self, context):
        restored, deleted, missing = 0, 0, []
        # Resolve the whole worklist before touching anything: the loop deletes
        # objects, and a selected model's results must be collected while that
        # model is still there to ask.
        work, seen = [], set()
        for picked in list(context.selected_objects):
            for t in self._targets(picked):
                if t.name not in seen:
                    seen.add(t.name)
                    work.append(t)

        for obj in work:
            # Restore Original is the outer undo, so the cleaning snapshots go
            # with it. Left behind they point at a mesh that no longer matches,
            # and the next slider move rebuilds from that stale copy - which is
            # what made the two reset buttons fight each other.
            _drop_clean_snapshots(obj)

            orig_name = obj.get(MONSTERREMESH_ORIG)
            if orig_name:
                mesh = bpy.data.meshes.get(orig_name)
                if mesh is None:
                    missing.append(obj.name)
                    continue
                spent = obj.data
                obj.data = mesh
                mesh.use_fake_user = False
                del obj[MONSTERREMESH_ORIG]
                if spent.users == 0 and not spent.use_fake_user:
                    bpy.data.meshes.remove(spent)
                restored += 1
                continue

            src = bpy.data.objects.get(obj.get(MONSTERREMESH_SOURCE, ""))
            if src is None:
                missing.append(obj.name)
                continue
            # Every name is taken before anything is deleted. Removing a
            # single datablock invalidates every other Python handle into
            # bpy.data, so an object fetched earlier raises "StructRNA of
            # type Object has been removed" the moment it is touched after -
            # which is exactly what Reset All did once the previews existed.
            src_name = src.name
            obj_name = obj.name

            # The line and panel previews belong to the same run.
            for extra in (src_name + "_FEATURELINES", src_name + "_PANELS"):
                e = bpy.data.objects.get(extra)
                if e is not None:
                    d = e.data
                    bpy.data.objects.remove(e)
                    if d and d.users == 0:
                        try:
                            bpy.data.meshes.remove(d)
                        except Exception:
                            pass

            obj = bpy.data.objects.get(obj_name)
            if obj is not None:
                d = obj.data
                bpy.data.objects.remove(obj)
                if d and d.users == 0 and not d.use_fake_user:
                    bpy.data.meshes.remove(d)

            src = bpy.data.objects.get(src_name)
            if src is not None:
                if src_name in context.view_layer.objects:
                    src.hide_set(False)
                src.select_set(True)
                context.view_layer.objects.active = src
            deleted += 1

        if missing:
            self.report({"WARNING"},
                        f"no original recorded for: {', '.join(missing[:3])}")
        if not (restored or deleted):
            return {"CANCELLED"}
        self.report({"INFO"},
                    f"restored {restored} in place, removed {deleted} result"
                    + ("s" if deleted != 1 else ""))
        return {"FINISHED"}


# ----------------------------------------------------------------------
# panel
# ----------------------------------------------------------------------
class MONSTERREMESH_PT_panel(Panel):
    bl_label = "Monster Remesh (Organic)"
    bl_idname = "MONSTERREMESH_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Monster Remesh"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        st = context.scene.monsterremesh
        obj = context.active_object

        # The way back to the card. It is the first thing in the panel
        # because someone who landed here by accident should not have to
        # go looking through preferences to get out.
        back = layout.row()
        back.scale_y = 1.2
        back.operator("mesh.monsterremesh_ui_switch",
                      text="Switch to Monster Remesh 3 panel",
                      icon="WINDOW").classic = False
        layout.separator()

        # Organic drives a bundled binary, and there is one for Windows only.
        # Saying so plainly beats a button that throws when pressed - the
        # Hardsurface half needs no binary and works on every platform.
        engine = True
        blocked = engine_blocked()
        if blocked:
            box = layout.box()
            box.label(text="Organic engine is blocked by macOS", icon="ERROR")
            col = box.column(align=True)
            col.label(text="The engine is here but macOS will not let it")
            col.label(text="start, because it carries no Apple signature.")
            col.label(text="One click clears that; it will show you the")
            col.label(text="command first.")
            col.separator()
            col.operator("mesh.monsterremesh_unquarantine", icon="UNLOCKED")
            engine = False
        elif engine_exe() is None:
            box = layout.box()
            box.label(text="Running the in-house engine", icon="INFO")
            col = box.column(align=True)
            col.label(text="The faster engine ships with the Windows,")
            col.label(text="macOS and Linux downloads. This copy does")
            col.label(text="not have it - either the wrong package was")
            col.label(text="installed for this machine, or bin/ is")
            col.label(text="missing. Get the build for your platform")
            col.label(text="from the Instant Meshes project page and")
            col.label(text="set its path in")
            col.label(text="Preferences ▸ Add-ons ▸ Monster Remesh.")
            col.separator()
            col.label(text="Until then output is rougher: fewer quads,")
            col.label(text="and some non-manifold edges.")
            col.label(text="Monster Remesh (Hardsurface) below is")
            col.label(text="unaffected and works everywhere.")
            col.separator()
            col.operator("preferences.addon_show",
                         text="Open Add-on Preferences",
                         icon="PREFERENCES").module = __package__

        # Working a garment one pattern piece at a time only means anything on
        # cloth - the other engines are given a solid model with no seams to
        # pick pieces along - so the box goes away with the Cloth engine. The
        # one exception is a piece that is already out on its own: the rest of
        # the model is hidden behind it and Exit Isolate is the only way back,
        # so that button stays reachable whatever the engine is set to.
        iso = _isolated_piece(context)
        if st.backend == "CLOTH" or iso is not None:
            box = layout.box()
            if iso is None:
                box.operator("mesh.monsterremesh_pick_island", icon="EYEDROPPER")
                box.operator("mesh.monsterremesh_isolate", icon="MOD_MASK")
            else:
                box.label(text=f"on its own: {iso.name}", icon="MOD_MASK")
                box.operator("mesh.monsterremesh_isolate_exit", icon="LOOP_BACK")
            if (context.active_object
                    and context.active_object.mode == "SCULPT"):
                box.operator("mesh.monsterremesh_leave_sculpt", icon="CHECKMARK")
            elif st.backend == "CLOTH":
                box.operator("mesh.monsterremesh_relax_brush", icon="BRUSH_DATA")

        row = layout.row(align=True)
        row.scale_y = 1.5
        row.enabled = engine
        row.operator("mesh.monsterremesh_run", icon="MOD_REMESH")
        row.operator("mesh.monsterremesh_restore", text="", icon="LOOP_BACK")
        if RUN["busy"]:
            layout.progress(factor=RUN["shown"], type="BAR",
                            text=run_progress_text())
            layout.label(text="Esc to stop", icon="INFO")

        layout.prop(st, "mark_sharp")
        layout.prop(st, "backend", text="")
        if st.backend == "CLOTH":
            _lesson(layout, "cloth")

        col = layout.column(align=True)
        col.prop(st, "mode", expand=True)
        if st.mode == "FACES":
            col.prop(st, "target_faces")
        else:
            col.prop(st, "target_edge")

        if st.backend == "CLOTH":
            box = layout.box()
            box.prop(st, "uv_panels")
            if st.uv_panels:
                box.label(text="One remesh per UV piece,",
                          icon="UV_ISLANDSEL")
                box.label(text="and the count is per piece")
                # The slider here seeds the run; dragging Distance in the redo
                # panel at the bottom left (or F9) afterwards is what updates
                # the mesh live.
                row = box.row(align=True)
                row.prop(st, "meet_dist")
                row.prop(st, "meet_weld", toggle=True)
                op = box.operator("mesh.monsterremesh_meet_verts",
                                  icon="SNAP_VERTEX")
                op.dist = st.meet_dist
                op.weld = st.meet_weld
                box.label(text="then drag Distance in the F9 panel",
                          icon="INFO")
            else:
                box.label(text="Cloth: welds, remeshes, closes tears",
                          icon="MOD_CLOTH")
                box.prop(st, "merge_dist")
                box.prop(st, "tear_size")
        else:
            col = layout.column(align=True)
            col.prop(st, "merge_shells")
            if st.merge_shells:
                col.prop(st, "merge_dist")
            col.prop(st, "close_holes")
            col.prop(st, "solid_rebuild")
            col.prop(st, "two_pass")

        layout.separator()
        col = layout.column(align=True)

        if st.backend == "AUTO":
            box = layout.box()
            box.prop(st, "auto_crease")
            if not st.auto_crease:
                box.prop(st, "feature_angle")
            box.prop(st, "auto_calibrate")
            box.prop(st, "auto_search")
            box.prop(st, "smooth_iterations", text="Reprojection Steps")
            n_runs = (1 if st.auto_calibrate else 0) + (4 if st.auto_search else 1)
            box.label(text=f"{n_runs} engine runs", icon="TIME")
        else:
            col.prop(st, "feature_angle")

            box = layout.box()
            box.prop(st, "smooth_iterations", text="Reprojection Steps")

        # Follow Curvature, Adaptive Density and the Solver box are read only
        # by `run_remesh`, which is the Ours engine. Under Auto the build goes
        # to Instant Meshes, which has no sizing field and no solver of ours
        # to tune - those controls did nothing there and only invited people
        # to turn knobs that were not connected to anything. Relax was the
        # same property the Auto box already shows as Reprojection Steps,
        # printed a second time under another name.
        if st.backend == "OURS":
            col.prop(st, "use_curvature")

            box = layout.box()
            box.prop(st, "adaptive")
            if st.adaptive:
                sub = box.column(align=True)
                sub.prop(st, "inner_density")
                sub.prop(st, "outer_density")
                sub.separator()
                sub.prop(st, "feature_density")
                sub.prop(st, "curvature_density")
                sub.separator()
                sub.prop(st, "spread_over")
                sub.prop(st, "thin_density")
                sub.prop(st, "min_size_ratio")
                sub.prop(st, "gradient_limit")
                box.label(text="Costs ~10 pts of quad quality", icon="INFO")

            box = layout.box()
            box.label(text="Solver", icon="SETTINGS")
            box.prop(st, "orient_iterations")
            box.prop(st, "position_iterations")
            box.prop(st, "smooth_iterations")
            box.label(text="Expect non-manifold edges", icon="ERROR")

        layout.separator()
        obj_now = context.active_object
        if (obj_now is not None and obj_now.type == "MESH"
                and len(obj_now.data.polygons)):
            row = layout.row()
            row.scale_y = 1.2
            row.operator("mesh.monsterremesh_to_hardsurface", icon="CHECKMARK")
        layout.prop(st, "replace")

        # The bake works off the result's own source markers, which both
        # engines write, so it needed no new code here - only a way in.
        lines = getattr(context.scene, "monsterremesh_lines", None)
        if lines is not None:
            from .lines_preview import fold_head
            box = fold_head(layout, lines, "show_uv", "UV", "UV")
            box.prop(lines, "uv_keep_islands")
            box.prop(lines, "uv_show_seams")
            box.prop(lines, "uv_seams_sharp")
            box.separator()
            rbk = box.row(align=True)
            rbk.operator("mesh.monsterremesh_bake_from_original",
                         icon="RENDER_STILL")
            rbk.operator("mesh.monsterremesh_unbake", text="", icon="LOOP_BACK")
            from .lines_preview import draw_bake_progress
            draw_bake_progress(box)
            rb = box.row(align=True)
            rb.prop(lines, "bake_size", text="")
            rb.prop(lines, "bake_pbr", toggle=True)
            # The same bake box is drawn in both panels, so the switch has to
            # be added in both - it was put on the Hardsurface one alone and
            # was simply not there for anyone working in Organic.
            box.prop(lines, "bake_gpu")
            try:
                from .lines_preview import _gpu_ready
                if lines.bake_gpu and not _gpu_ready():
                    box.label(text="No GPU device enabled - using the processor",
                              icon="ERROR")
            except Exception:
                pass
            box.label(text="If the UV is stretched after a remesh, bake it.",
                      icon="INFO")

        if obj and obj.type == "MESH":
            n = len(obj.data.polygons)
            info = layout.column(align=True)
            info.label(text=f"Input: {n:,} faces")


class MONSTERREMESH_PT_about(Panel):
    bl_label = "About"
    bl_idname = "MONSTERREMESH_PT_about"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Monster Remesh"
    bl_order = 40

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="Monster Remesh  v" + VERSION_TEXT)
        col.label(text="Smart Remesh 3.0.5 - Milad Kambari, 3DRedbox Studio")
        col.label(text="Boolean Quad Ready 1.6 - Artemis3D")

        layout.separator()
        links = layout.column(align=True)
        links.scale_y = 1.2
        links.operator("wm.url_open", text="ArtStation",
                       icon="URL").url = ARTSTATION_URL
        links.operator("wm.url_open", text="Superhive",
                       icon="URL").url = SUPERHIVE_URL
        links.operator("wm.url_open", text="Discord - Support",
                       icon="URL").url = DISCORD_URL


def _bring_into_view(context, obj, always=False):
    """Point the viewport at the object the brush is about to work on.

    Sculpt Mode only ever touches the active object. If the view happens to be
    parked on some other copy of the garment - and on a desk full of remesh
    tries it usually is - the brush is painting on a mesh that is off screen
    and every stroke looks like it did nothing, no matter how far the strength
    is pushed. Measured on Milad's file: the active object sat at x=6 while the
    view was centred on x=11 with a hoodie in front of it.

    The view is moved by hand rather than through View Selected, which animates
    and so only arrives once the viewport has redrawn a few times - from a
    button that leaves the camera parked halfway, still buried inside the
    garment. Setting the two numbers puts it there at once.

    Nothing is touched when part of the object is already in sight and the
    camera is not sitting inside it, which leaves a good view alone.

    Returns True if the view was moved.
    """
    from bpy_extras import view3d_utils
    from mathutils import Vector

    win = getattr(context, "window", None)
    screen = getattr(win, "screen", None) if win else None
    if screen is None:
        return False
    area = next((a for a in screen.areas if a.type == "VIEW_3D"), None)
    if area is None:
        return False
    region = next((r for r in area.regions if r.type == "WINDOW"), None)
    rv3d = area.spaces[0].region_3d
    if region is None or rv3d is None:
        return False

    mw = obj.matrix_world
    corners = [mw @ Vector(c) for c in obj.bound_box]
    mid = sum(corners, Vector()) / 8.0
    radius = max((c - mid).length for c in corners) or 1.0

    seen = False
    if not always:
        for w in corners:
            q = view3d_utils.location_3d_to_region_2d(region, rv3d, w)
            if q and 0.0 <= q.x <= region.width and 0.0 <= q.y <= region.height:
                seen = True
                break
    # Sitting inside the garment counts as not seeing it: the corners land all
    # over the screen while the camera looks out through the cloth at nothing.
    if seen and rv3d.view_distance > radius * 0.6:
        return False

    rv3d.view_location = mid
    rv3d.view_distance = radius * 2.2
    area.tag_redraw()
    return True


ISO_HOME = "monsterremesh_iso_home"
ISO_HIDDEN = "monsterremesh_iso_hidden"


def _isolated_piece(context):
    """The piece that is currently out on its own, if there is one."""
    for o in context.view_layer.objects:
        if ISO_HOME in o:
            return o
    return None


class MONSTERREMESH_OT_isolate(Operator):
    """Take the selected piece out on its own to work on it.

    The long way round is Edit Mode, hover the panel, L, P to break it off,
    work on it, then select everything again and J to put it back - and the
    whole time the rest of the garment is in the way. This does the same in one
    press: the selection is broken off, everything else is put out of sight,
    and the piece is framed on its own. Exit Isolate joins it up again.

    Run from Object Mode the active object itself is the piece, so a garment
    that is already separate objects needs no cutting at all.
    """

    bl_idname = "mesh.monsterremesh_isolate"
    bl_label = "Isolate Piece"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH"
                and _isolated_piece(context) is None)

    def execute(self, context):
        obj = context.active_object
        home = ""
        piece = obj

        if obj.mode == "EDIT":
            import bmesh
            bm = bmesh.from_edit_mesh(obj.data)
            picked = sum(1 for f in bm.faces if f.select)
            if not picked:
                self.report({"ERROR"},
                            "select the piece first - hover it and press L")
                return {"CANCELLED"}
            if picked >= len(bm.faces):
                # the whole object was picked; there is nothing to break off
                bpy.ops.object.mode_set(mode="OBJECT")
            else:
                before = {o.name for o in context.view_layer.objects}
                bpy.ops.mesh.separate(type="SELECTED")
                bpy.ops.object.mode_set(mode="OBJECT")
                fresh = [o for o in context.view_layer.objects
                         if o.name not in before]
                if not fresh:
                    self.report({"ERROR"}, "nothing came off")
                    return {"CANCELLED"}
                piece = fresh[0]
                piece.name = obj.name + "_Piece"
                home = obj.name

        # Out of sight rather than Local View: a remesh makes a brand new
        # object, and a new object is not in the local view - the result would
        # land invisible and read as the remesh having failed.
        hidden = []
        for o in context.view_layer.objects:
            if o is piece:
                continue
            if not o.hide_get():
                hidden.append(o.name)
                o.hide_set(True)

        piece[ISO_HOME] = home
        piece[ISO_HIDDEN] = "\n".join(hidden)
        for o in list(context.selected_objects):
            o.select_set(False)
        piece.select_set(True)
        context.view_layer.objects.active = piece
        _bring_into_view(context, piece, always=True)

        if home:
            self.report({"INFO"}, f"{piece.name} is out on its own")
        else:
            self.report({"INFO"}, f"{piece.name} on its own, nothing was cut")
        return {"FINISHED"}


class MONSTERREMESH_OT_isolate_exit(Operator):
    """Join the piece back on and bring the rest of the model back.

    Whatever is selected is what goes back, so after a remesh the result is
    joined and not the piece it was built from. That leftover piece is cleared
    away unless it is asked for - it has already done its job, and left behind
    it is a second copy of the panel sitting loose in the file.
    """

    bl_idname = "mesh.monsterremesh_isolate_exit"
    bl_label = "Exit Isolate"
    bl_options = {"REGISTER", "UNDO"}

    keep_piece: BoolProperty(
        name="Keep The Working Copy", default=False,
        description="Leave the piece that was cut off in the file after the "
                    "remesh of it has been joined back on",
    )

    @classmethod
    def poll(cls, context):
        return _isolated_piece(context) is not None

    def execute(self, context):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        piece = _isolated_piece(context)
        home_name = piece.get(ISO_HOME) or ""
        hidden = (piece.get(ISO_HIDDEN) or "").split("\n")

        # what is in front of you is what goes back
        joining = [o for o in context.selected_objects if o.type == "MESH"]
        if not joining:
            joining = [piece]

        for name in hidden:
            o = bpy.data.objects.get(name)
            if o is not None:
                try:
                    o.hide_set(False)
                except Exception:
                    pass

        del piece[ISO_HOME]
        if ISO_HIDDEN in piece:
            del piece[ISO_HIDDEN]

        home = bpy.data.objects.get(home_name) if home_name else None
        if home is None:
            self.report({"INFO"}, "everything is back in sight")
            return {"FINISHED"}

        leftover = None if piece in joining else piece
        for o in list(context.selected_objects):
            o.select_set(False)
        for o in joining:
            o.select_set(True)
        home.select_set(True)
        context.view_layer.objects.active = home
        try:
            bpy.ops.object.join()
        except Exception as exc:
            self.report({"ERROR"}, f"could not join: {exc}")
            return {"CANCELLED"}

        msg = f"back on {home.name}"
        if leftover is not None and not self.keep_piece:
            try:
                bpy.data.objects.remove(leftover, do_unlink=True)
                msg += ", the working copy cleared away"
            except Exception:
                pass
        self.report({"INFO"}, msg)
        return {"FINISHED"}


def uv_island_map(me):
    """Which UV island each face belongs to.

    A sewn garment is one island per pattern piece, so this is the map that
    lets a piece be pointed at with the mouse instead of hunted for in Edit
    Mode. Two faces are in the same island when the edge between them hands
    both of them the same UV - the moment the two sides disagree the edge is a
    seam and the flood stops there. Nothing is cut; the mesh is only read.

    Returns (island of each face as an array, list of islands as face lists),
    or None when the model carries no UV map.
    """
    import bmesh

    bm = bmesh.new()
    bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.index_update()
    bm.edges.index_update()
    uv = bm.loops.layers.uv.active
    if uv is None:
        bm.free()
        return None

    fv = {}
    for f in bm.faces:
        fi = f.index
        for l in f.loops:
            u = l[uv].uv
            fv[(fi, l.vert.index)] = (round(u.x, 5), round(u.y, 5))

    seam = set()
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        la, lb = e.link_faces
        for v in e.verts:
            if fv[(la.index, v.index)] != fv[(lb.index, v.index)]:
                seam.add(e.index)
                break

    of_face = np.full(len(bm.faces), -1, dtype=np.int32)
    islands = []
    for f in bm.faces:
        if of_face[f.index] != -1:
            continue
        idx = len(islands)
        of_face[f.index] = idx
        stack = [f]
        group = []
        while stack:
            cur = stack.pop()
            group.append(cur.index)
            for e in cur.edges:
                if e.index in seam:
                    continue
                for nf in e.link_faces:
                    if of_face[nf.index] == -1:
                        of_face[nf.index] = idx
                        stack.append(nf)
        islands.append(group)
    bm.free()
    return of_face, islands


# The picker's highlight, held outside the operator so it can always be taken
# down again - the operator instance is gone by the time an add-on reload or a
# file load gets here.
_PICK_DRAW = []


def _drop_pick_draw():
    while _PICK_DRAW:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_PICK_DRAW.pop(),
                                                      "WINDOW")
        except Exception:
            pass


class MONSTERREMESH_OT_pick_island(Operator):
    """Point at a pattern piece and click to take it out on its own.

    With this running, whatever UV island is under the mouse lights up as the
    pointer crosses the garment, and a click breaks that piece off and hides
    the rest - the same as selecting it in Edit Mode with L and pressing
    Isolate, without leaving Object Mode. Escape or a right click stops the
    picking without changing anything; Exit Isolate ends the isolation.

    A sewn garment is one UV island per pattern piece, which is why the pieces
    can be pointed at at all: the island map is what the seams already say.
    """

    bl_idname = "mesh.monsterremesh_pick_island"
    bl_label = "Pick A Piece"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH" and o.mode == "OBJECT"
                and len(o.data.polygons) and _isolated_piece(context) is None)

    # ------------------------------------------------------------ drawing --
    def _shape(self, island):
        """World-space triangles of one island, ready for the shader."""
        if island in self._cache:
            return self._cache[island]
        keep = self._tri_island == island
        verts = self._tri_verts[keep].ravel()
        pts = self._world[verts]
        self._cache[island] = pts
        return pts

    def _draw(self, context):
        if self._hover < 0:
            return
        import gpu
        from gpu_extras.batch import batch_for_shader
        pts = self._shape(self._hover)
        if not len(pts):
            return
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        batch = batch_for_shader(shader, "TRIS", {"pos": pts})
        gpu.state.blend_set("ALPHA")
        gpu.state.depth_test_set("LESS_EQUAL")
        shader.bind()
        shader.uniform_float("color", (0.15, 0.6, 1.0, 0.4))
        batch.draw(shader)
        gpu.state.blend_set("NONE")
        gpu.state.depth_test_set("NONE")

    # ------------------------------------------------------------- modal ---
    def _under(self, context, event):
        """The island the mouse is over, or -1."""
        from bpy_extras import view3d_utils

        region = context.region
        rv3d = context.region_data
        if region is None or rv3d is None:
            return -1
        xy = (event.mouse_region_x, event.mouse_region_y)
        if not (0 <= xy[0] <= region.width and 0 <= xy[1] <= region.height):
            return -1
        org = view3d_utils.region_2d_to_origin_3d(region, rv3d, xy)
        dr = view3d_utils.region_2d_to_vector_3d(region, rv3d, xy)
        inv = self._obj.matrix_world.inverted()
        ok, _, _, face = self._obj.ray_cast(inv @ org,
                                            (inv.to_3x3() @ dr).normalized())
        if not ok or face < 0 or face >= len(self._of_face):
            return -1
        return int(self._of_face[face])

    def modal(self, context, event):
        if event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            self._cache.clear()      # the view moved, nothing else changed
            return {"PASS_THROUGH"}

        if event.type == "MOUSEMOVE":
            now = self._under(context, event)
            if now != self._hover:
                self._hover = now
                if context.area:
                    context.area.tag_redraw()
            return {"RUNNING_MODAL"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            hit = self._under(context, event)
            if hit < 0:
                return {"RUNNING_MODAL"}
            self._end(context)
            return self._take(context, hit)

        if event.type in {"RIGHTMOUSE", "ESC"}:
            self._end(context)
            self.report({"INFO"}, "picking stopped")
            return {"CANCELLED"}

        return {"RUNNING_MODAL"}

    def _take(self, context, island):
        """Break the picked island off, the same way Isolate does."""
        import bmesh
        obj = self._obj
        faces = self._islands[island]
        if len(faces) >= len(obj.data.polygons):
            self.report({"WARNING"}, "that is the whole model, nothing to cut")
            return {"CANCELLED"}
        context.tool_settings.mesh_select_mode = (False, False, True)
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="DESELECT")
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        for i in faces:
            bm.faces[i].select_set(True)
        bm.select_flush(True)
        bmesh.update_edit_mesh(obj.data)
        return bpy.ops.mesh.monsterremesh_isolate()

    def _end(self, context):
        _drop_pick_draw()
        self._handle = None
        if context.area:
            context.area.header_text_set(None)
            context.area.tag_redraw()

    def cancel(self, context):
        # Blender ends a modal on its own for a file load, a window closing,
        # an add-on reload. Without this the draw handler stayed behind and
        # threw once per frame forever after, which is both a dead highlight
        # stuck on the model and a real cost on every redraw.
        self._end(context)

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"ERROR"}, "run this from the 3D viewport")
            return {"CANCELLED"}
        obj = context.active_object
        me = obj.data
        found = uv_island_map(me)
        if found is None:
            self.report({"ERROR"}, "the model has no UV map to read pieces from")
            return {"CANCELLED"}
        self._obj = obj
        self._of_face, self._islands = found

        # The highlight is drawn straight from the triangles Blender already
        # keeps for display, picked out with a mask rather than a loop over
        # faces, so moving the mouse costs a ray cast and an array lookup.
        me.calc_loop_triangles()
        n = len(me.loop_triangles)
        polys = np.empty(n, dtype=np.int32)
        me.loop_triangles.foreach_get("polygon_index", polys)
        tv = np.empty(n * 3, dtype=np.int32)
        me.loop_triangles.foreach_get("vertices", tv)
        self._tri_island = self._of_face[polys]
        self._tri_verts = tv.reshape(-1, 3)

        co = np.empty(len(me.vertices) * 3, dtype=np.float32)
        me.vertices.foreach_get("co", co)
        co = co.reshape(-1, 3)
        nrm = np.empty(len(me.vertices) * 3, dtype=np.float32)
        me.vertices.foreach_get("normal", nrm)
        nrm = nrm.reshape(-1, 3)
        # lifted off the surface by a thousandth of the model, or the highlight
        # fights the cloth it is lying on and comes out speckled
        size = float(np.max(co.max(0) - co.min(0))) or 1.0
        lifted = co + nrm * (size * 0.001)
        mw = np.array(obj.matrix_world.to_4x4(), dtype=np.float32)
        self._world = (lifted @ mw[:3, :3].T + mw[:3, 3]).astype(np.float32)

        self._cache = {}
        self._hover = -1
        _drop_pick_draw()        # never two of them at once
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self._draw, (context,), "WINDOW", "POST_VIEW")
        _PICK_DRAW.append(self._handle)
        context.area.header_text_set(
            "Pick a piece: hover to light it up, click to take it out, "
            "Esc to stop")
        context.window_manager.modal_handler_add(self)
        self.report({"INFO"}, f"{len(self._islands)} pieces to pick from")
        return {"RUNNING_MODAL"}


class MONSTERREMESH_OT_relax_brush(Operator):
    """Hand over the smooth brush, ready to paint.

    Drops the object into Sculpt Mode with the smooth brush picked, so the
    crumpled spots can be brushed out by hand without going looking for the
    tool. Tab comes back to Object Mode.

    Blender moved its brushes into the asset system, and which route works
    depends on the version, so each is tried in turn and the first that takes
    is kept.
    """

    bl_idname = "mesh.monsterremesh_relax_brush"
    bl_label = "Relax Brush"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        if obj.mode != "SCULPT":
            try:
                obj.select_set(True)
                bpy.ops.object.mode_set(mode="SCULPT")
            except Exception as exc:
                self.report({"ERROR"}, f"could not enter Sculpt Mode: {exc}")
                return {"CANCELLED"}
        framed = _bring_into_view(context, obj)

        picked = ""
        # the asset the current Blender ships the brush as
        try:
            bpy.ops.brush.asset_activate(
                asset_library_type="ESSENTIALS",
                relative_asset_identifier=(
                    "brushes/essentials_brushes-mesh_sculpt.blend"
                    "/Brush/Smooth"))
            picked = "asset"
        except Exception:
            pass
        if not picked:
            try:
                bpy.ops.wm.tool_set_by_id(name="builtin_brush.Smooth")
                picked = "tool"
            except Exception:
                pass
        if not picked:
            try:
                br = bpy.data.brushes.get("Smooth")
                if br is not None:
                    context.tool_settings.sculpt.brush = br
                    picked = "brush"
            except Exception:
                pass

        # The name is always said out loud. The brush can only ever touch the
        # active object, so when a file holds several tries of the same garment
        # this is the line that tells which one is under the brush.
        where = " (view moved onto it)" if framed else ""
        if picked:
            self.report({"INFO"},
                        f"brushing {obj.name}{where} - paint the crumpled "
                        f"spots, Tab to come back")
        else:
            self.report({"WARNING"},
                        f"brushing {obj.name}{where} - pick Smooth yourself, "
                        f"or hold Shift while brushing")
        return {"FINISHED"}


class MONSTERREMESH_OT_leave_sculpt(Operator):
    """Come back to Object Mode from the brush."""

    bl_idname = "mesh.monsterremesh_leave_sculpt"
    bl_label = "Done Brushing"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.mode == "SCULPT"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        return {"FINISHED"}


class MONSTERREMESH_OT_meet_verts(Operator):
    """Bring the border vertices of neighbouring panels onto each other.

    Run after a By UV Seams remesh. Each panel came out of the engine with its
    own border sampling, so two panels cut from one seam sit next to each other
    without sharing a vertex - a hairline gap along every seam. This moves the
    border vertices that are within Distance of a vertex on another panel onto
    their common point, so they meet exactly.

    The panels are not joined: each keeps its own vertex, the copies simply
    stand in the same place. Tick Weld to merge them into one mesh instead.

    Once this has run, the Meet Distance and Weld controls in the panel are
    live - changing them re-applies straight away, each time from the snapshot
    taken here, so the mesh follows the number instead of creeping.
    """

    bl_idname = "mesh.monsterremesh_meet_verts"
    bl_label = "Meet Panel Vertices"
    bl_options = {"REGISTER", "UNDO"}

    dist: FloatProperty(
        name="Distance", default=0.5, min=0.0, max=5.0, soft_max=2.0,
        precision=3, subtype="FACTOR",
        description="How far apart two border vertices may be and still be "
                    "brought together, measured in the mesh's own edge "
                    "lengths. 0.5 is half a border spacing, which can only "
                    "ever reach the panel across the seam and never the next "
                    "vertex along the border. 0 uses that same 0.5",
    )
    weld: BoolProperty(
        name="Weld", default=False,
        description="Merge the vertices that met into one, joining the panels "
                    "into a single mesh. Off keeps the panels separate, with "
                    "their vertices sitting on each other",
    )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == "MESH"
                and o.mode == "OBJECT" and len(o.data.polygons))

    def execute(self, context):
        obj = context.active_object
        try:
            met, slid, tol = meet_panel_verts(obj, self.dist, self.weld)
        except Exception as exc:
            traceback.print_exc()
            self.report({"ERROR"}, f"could not bring the borders together: {exc}")
            return {"CANCELLED"}
        if not (met or slid):
            self.report({"WARNING"},
                        "nothing met - raise Meet Distance")
        else:
            self.report({"INFO"},
                        f"{met} vertices met, {slid} slid onto the "
                        f"neighbour's edge (reach {tol:.4f})")
        # keep the panel's own sliders in step, so dragging them from here on
        # carries on from the same numbers
        st = context.scene.monsterremesh
        if st.meet_dist != self.dist:
            st["meet_dist"] = self.dist
        if st.meet_weld != self.weld:
            st["meet_weld"] = self.weld
        return {"FINISHED"}


CLASSES = (MonsterRemeshPrefs, MonsterRemeshSettings, MONSTERREMESH_OT_run, MONSTERREMESH_OT_spread,
           MONSTERREMESH_OT_hand_to_hardsurface,
           MONSTERREMESH_OT_unquarantine, MONSTERREMESH_OT_meet_verts,
           MONSTERREMESH_OT_isolate, MONSTERREMESH_OT_isolate_exit,
           MONSTERREMESH_OT_pick_island,
           MONSTERREMESH_OT_ui_switch,
           MONSTERREMESH_OT_relax_brush, MONSTERREMESH_OT_leave_sculpt,
           MONSTERREMESH_OT_restore, MONSTERREMESH_OT_reset_all,
           MONSTERREMESH_OT_uninstall)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.monsterremesh = PointerProperty(type=MonsterRemeshSettings)
    lines_preview.register()
    bqr.register()
    overlay.register()
    marks.register()
    _apply_classic()


def unregister():
    # Unregistering must not raise. A half-finished earlier attempt, a reload
    # during an upgrade, or Blender tearing things down in its own order all
    # leave pieces already gone, and one exception here aborts the rest -
    # leaving classes registered that can never be registered again without a
    # restart.
    for cls in _classic_classes():
        try:
            if getattr(bpy.types, cls.__name__, None) is not None:
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    try:
        _drop_pick_draw()
    except Exception:
        pass
    try:
        marks.unregister()
    except Exception:
        pass
    try:
        overlay.unregister()
    except Exception:
        pass
    try:
        bqr.unregister()
    except Exception:
        pass
    try:
        lines_preview.unregister()
    except Exception:
        pass
    if hasattr(bpy.types.Scene, "monsterremesh"):
        del bpy.types.Scene.monsterremesh
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
