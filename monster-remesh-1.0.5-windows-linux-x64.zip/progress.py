"""Progress bar for the jobs that run in one go: Hard Surface and Boolean.

Organic runs its engine on a worker thread and has had a bar from the start
(``RUN`` in the package). Hard Surface and the Boolean tools work inside a
single operator call, so Blender would not draw anything until they finished
and the card sat there frozen. Here each of those jobs reports its stages,
and between stages the window is redrawn once - so the card's Remesh button
turns into the same bar the Organic remesh shows, and moves.
"""

import time

import bpy

JOB = {
    "busy": False,
    "kind": "",        # "HARD" or "BOOLEAN" - which tab shows the bar
    "title": "",       # what the bar says, e.g. "Remeshing"
    "stage": "",
    "shown": 0.0,
    "t0": 0.0,
    "drawn": 0.0,
}

_MIN_GAP = 0.06        # seconds between forced redraws


def _paint(force=False):
    now = time.time()
    if not force and now - JOB["drawn"] < _MIN_GAP:
        return
    JOB["drawn"] = now
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
        bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=1)
    except Exception:
        pass


def begin(kind, title, stage="starting"):
    JOB.update(busy=True, kind=kind, title=title, stage=stage, shown=0.02,
               t0=time.time(), drawn=0.0)
    _paint(force=True)


def step(stage, frac):
    """Report a stage. Does nothing unless a job was begun."""
    if not JOB["busy"]:
        return
    JOB["stage"] = stage
    JOB["shown"] = max(JOB["shown"], min(0.99, float(frac)))
    _paint()


def end():
    if not JOB["busy"]:
        return
    JOB["stage"] = "done"
    JOB["shown"] = 1.0
    _paint(force=True)
    JOB["busy"] = False
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    except Exception:
        pass


class job:
    """``with progress.job("HARD", "Remeshing"):`` - always ends the bar."""

    def __init__(self, kind, title, stage="starting"):
        self.args = (kind, title, stage)

    def __enter__(self):
        begin(*self.args)
        return self

    def __exit__(self, *exc):
        end()
        return False


def state(kind):
    """The job in progress for one tab, or None."""
    return JOB if JOB["busy"] and JOB["kind"] == kind else None
