"""Boolean half of Monster Remesh.

This is Boolean Quad Ready (BQR) 1.6 by Artemis3D, brought in as the third
half of the add-on next to Organic and Hard Surface. The tools and what they
do are unchanged; only the names were moved out of BQR's way (``bqr_`` ->
``mrbool_``) so Monster Remesh and the original BQR can both be installed.

Changes against BQR 1.6:
* identifiers renamed (operators, scene properties, panels)
* presets saved in Blender's config folder, not inside the add-on folder,
  so an update does not wipe them
* the auto-sync handler only writes a value when it actually changed and
  survives loading another file
* operators that need a mesh say so in their poll, so the card can explain
  instead of failing
* no side panel of its own; the card's "Boolean" tab carries the tools
"""

import json
import math
import os
import time

import bmesh
import bpy

from . import progress as PROG
from bpy.props import (BoolProperty, FloatProperty, FloatVectorProperty,
                       IntProperty, PointerProperty, StringProperty)

VERSION_TEXT = "1.6"
TRIPLANAR = "BQR Tri-Planar UV"   # the node group's name inside the .blend
BLEND_NAME = "UV Triplanar.blend"


# === Utility ================================================================

def modifier_exists(obj, mod_type):
    return any(mod.type == mod_type for mod in obj.modifiers)


def get_modifier(obj, mod_type):
    return next((mod for mod in obj.modifiers if mod.type == mod_type), None)


def has_modifier_stack(obj, types):
    have = [mod.type for mod in obj.modifiers]
    return all(t in have for t in types)


def has_stack(obj):
    return (obj is not None and obj.type == 'MESH'
            and has_modifier_stack(obj, ['REMESH', 'BEVEL', 'SUBSURF']))


def realtime_uv_mod(obj):
    if obj is None or obj.type != 'MESH':
        return None
    for mod in obj.modifiers:
        if mod.type == 'NODES' and mod.name == TRIPLANAR:
            return mod
    return None


def triangle_count(context, obj):
    try:
        eval_obj = obj.evaluated_get(context.evaluated_depsgraph_get())
        return sum(max(len(p.vertices) - 2, 1) for p in eval_obj.data.polygons)
    except Exception:
        return 0


def _mesh_poll(context):
    obj = context.active_object
    return obj is not None and obj.type == 'MESH'


class _MeshOp:
    @classmethod
    def poll(cls, context):
        return _mesh_poll(context)


# === Property updates =======================================================

def _update_mod(self, context, mod_type, prop_name, value_attr,
                transform=lambda x: x):
    obj = context.active_object
    if obj is None:
        return
    mod = get_modifier(obj, mod_type)
    if mod:
        new = transform(getattr(self, value_attr))
        if getattr(mod, prop_name) != new:
            setattr(mod, prop_name, new)


def update_remesh_depth(self, c): _update_mod(self, c, 'REMESH', 'octree_depth', 'remesh_depth')
def update_remesh_scale(self, c): _update_mod(self, c, 'REMESH', 'scale', 'remesh_scale')
def update_bevel_amount(self, c): _update_mod(self, c, 'BEVEL', 'width', 'bevel_amount')
def update_bevel_segments(self, c): _update_mod(self, c, 'BEVEL', 'segments', 'bevel_segments')
def update_bevel_angle(self, c): _update_mod(self, c, 'BEVEL', 'angle_limit', 'bevel_angle', math.radians)
def update_bevel_profile(self, c): _update_mod(self, c, 'BEVEL', 'profile', 'bevel_profile')
def update_subsurf_level(self, c): _update_mod(self, c, 'SUBSURF', 'levels', 'subsurf_level')
def update_smooth_repeat(self, c): _update_mod(self, c, 'SMOOTH', 'iterations', 'smooth_repeat')


def update_beauty_bevel(self, context):
    obj = context.active_object
    mod = get_modifier(obj, 'BEVEL') if obj else None
    if mod:
        mod.miter_outer = 'MITER_ARC' if self.use_beauty_bevel else 'MITER_SHARP'


def update_mirror_settings(self, context):
    obj = context.active_object
    if obj and obj.type == 'MESH':
        mirror = get_modifier(obj, 'MIRROR')
        if mirror:
            mirror.use_axis[0] = self.mirror_use_axis_x
            mirror.use_axis[1] = self.mirror_use_axis_y
            mirror.use_axis[2] = self.mirror_use_axis_z
            mirror.use_clip = self.mirror_use_clip
            mirror.use_mirror_merge = self.mirror_use_merge
            if self.mirror_object:
                mirror.mirror_object = self.mirror_object


def update_triplanar_settings(self, context):
    mod = realtime_uv_mod(context.active_object)
    if mod:
        try:
            for i in range(3):
                mod["Socket_2"][i] = self.triplanar_scale[i]
            mod["Socket_3"] = self.triplanar_pack_islands
            mod["Socket_4"] = self.triplanar_margin
            mod["Socket_5"] = self.triplanar_rotate
        except Exception:
            pass


# === Settings ===============================================================

class MRBOOL_Properties(bpy.types.PropertyGroup):
    use_beauty_bevel: BoolProperty(
        name="Beauty Bevel", description="Disable if geometry breaks",
        update=update_beauty_bevel, default=True)

    use_mirror: BoolProperty(name="Mirror", description="Toggle mirror tools panel",
                             default=False)
    mirror_empty_created: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    mirror_use_axis_x: BoolProperty(name="X", description="Mirror along X axis",
                                    update=update_mirror_settings, default=True)
    mirror_use_axis_y: BoolProperty(name="Y", description="Mirror along Y axis",
                                    update=update_mirror_settings, default=False)
    mirror_use_axis_z: BoolProperty(name="Z", description="Mirror along Z axis",
                                    update=update_mirror_settings, default=False)
    mirror_object: PointerProperty(type=bpy.types.Object, name="Mirror Object",
                                   description="Object to use as mirror center",
                                   update=update_mirror_settings)
    mirror_use_clip: BoolProperty(name="Clip",
                                  description="Prevent vertices from going through the mirror",
                                  update=update_mirror_settings, default=True)
    mirror_use_merge: BoolProperty(name="Merge",
                                   description="Merge vertices on the mirror plane",
                                   update=update_mirror_settings, default=True)

    triplanar_scale: FloatVectorProperty(name="Scale", description="Triplanar UV scale",
                                         default=(1.0, 1.0, 1.0), min=0.01, max=100.0,
                                         size=3, update=update_triplanar_settings)
    triplanar_pack_islands: BoolProperty(name="Pack UV Islands", default=False,
                                         update=update_triplanar_settings)
    triplanar_margin: FloatProperty(name="Margin", description="UV packing margin",
                                    default=0.005, min=0.0, max=1.0,
                                    update=update_triplanar_settings)
    triplanar_rotate: BoolProperty(name="Rotate", description="Rotate UV Islands",
                                   default=True, update=update_triplanar_settings)

    use_boolean_tools: BoolProperty(name="Boolean Tools", default=False)
    use_deform_tools: BoolProperty(name="Deform Tools", default=False)
    use_displace_tools: BoolProperty(name="Displace", default=False)

    remesh_depth: IntProperty(
        name="Octree Depth",
        description="Detail level of the Remesh modifier. Higher values produce finer "
                    "geometry. Tip: increase if booleans distort geometry",
        default=4, min=1, max=9, update=update_remesh_depth)
    remesh_scale: FloatProperty(
        name="Scale",
        description="Spacing of the remesh grid. Higher values give a denser mesh. "
                    "Tip: increase if the mesh gets holes, lower it as Octree Depth rises",
        default=0.9, min=0.01, max=1.0, update=update_remesh_scale)
    bevel_amount: FloatProperty(
        name="Amount", description="Thickness of the bevel",
        default=0.02, min=0.001, max=100.0, update=update_bevel_amount)
    bevel_segments: IntProperty(
        name="Segments", description="Number of segments in the bevel. Tip: 2-3 for most cases",
        default=3, min=1, max=10, update=update_bevel_segments)
    bevel_angle: FloatProperty(
        name="Angle", description="Minimum angle in degrees to apply the bevel",
        default=30.0, min=0.0, max=180.0, update=update_bevel_angle)
    bevel_profile: FloatProperty(
        name="Shape", description="Curve of the bevel. 0 concave, 1 convex, 0.5 uniform",
        default=0.5, min=0.0, max=1.0, update=update_bevel_profile)
    subsurf_level: IntProperty(
        name="Subdivision Level", description="Subdivision levels for smoothing",
        default=1, min=0, max=5, update=update_subsurf_level)
    smooth_repeat: IntProperty(
        name="Smooth Repeat", description="How many times to apply smoothing",
        default=15, min=1, max=100, update=update_smooth_repeat)
    decimate_iterations: IntProperty(
        name="Last Decimate Value", default=2, min=1, max=10,
        options={'HIDDEN', 'SKIP_SAVE'})
    clean_edge_loops_last_angle: FloatProperty(
        name="Last Clean Angle", default=5.0, options={'HIDDEN', 'SKIP_SAVE'})
    use_boolean_manager: BoolProperty(name="Boolean Manager", default=False)


# === Edge-loop helpers (unchanged from BQR) ================================

def get_loop(bm, e):
    checkverts, loop_edges = e.verts[:], [e]
    checked, loop_set = set(), {e}
    while checkverts:
        v = checkverts.pop()
        if v in checked:
            continue
        checked.add(v)
        if len(v.link_edges) == 4:
            estart = next((x for x in v.link_edges if x in loop_set), None)
            if estart:
                for e2 in v.link_edges:
                    if e2 in loop_set:
                        continue
                    if not any(f in estart.link_faces for f in e2.link_faces):
                        loop_edges.append(e2)
                        loop_set.add(e2)
                        for vn in e2.verts:
                            if vn not in checked and vn not in checkverts:
                                checkverts.append(vn)
    return loop_edges


def check_angles(edges, angle_threshold):
    for e in edges:
        if len(e.link_faces) != 2:
            return False
        try:
            if e.calc_face_angle() > angle_threshold:
                return False
        except ValueError:
            return False
    return True


def has_complex_topology(edges):
    if len(edges) < 3:
        return True
    angles = []
    for e in edges:
        if len(e.link_faces) == 2:
            try:
                angles.append(e.calc_face_angle())
            except ValueError:
                continue
    if len(angles) < 3:
        return True
    if max(angles) > 0.5:
        return True
    mean = sum(angles) / len(angles)
    prev = angles[0]
    for a in angles[1:]:
        if abs(a - prev) > 0.25:
            return True
        prev = a
    var = sum((x - mean) ** 2 for x in angles) / len(angles)
    return var ** 0.5 > 0.15


# === Main workflow ==========================================================

class MRBOOL_OT_remeshit(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_remeshit"
    bl_label = "RemeshIT"
    bl_description = "Apply Remesh + Bevel + Subdivision + Smooth as a live modifier stack"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.mrbool_props
        if has_stack(obj):
            self.report({'WARNING'}, "RemeshIT has already been applied")
            return {'CANCELLED'}
        PROG.begin("BOOLEAN", "RemeshIT", "preparing the mesh")
        try:
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            if obj.data.users > 1:
                obj.data = obj.data.copy()
                self.report({'INFO'}, "Made mesh data single user")
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            try:
                bpy.ops.mesh.remove_doubles(threshold=0.0001)
            except Exception:
                pass
            bpy.ops.object.mode_set(mode='OBJECT')

            smooth = obj.modifiers.new(name="Smooth", type='SMOOTH')
            smooth.iterations = props.smooth_repeat
            subsurf = obj.modifiers.new(name="Subdivision", type='SUBSURF')
            subsurf.levels = props.subsurf_level
            bevel = obj.modifiers.new(name="Bevel", type='BEVEL')
            bevel.segments = props.bevel_segments
            bevel.miter_outer = 'MITER_ARC' if props.use_beauty_bevel else 'MITER_SHARP'
            bevel.limit_method = 'ANGLE'
            bevel.angle_limit = math.radians(props.bevel_angle)
            bevel.profile = props.bevel_profile
            bevel.width = props.bevel_amount
            remesh = obj.modifiers.new(name="Remesh", type='REMESH')
            remesh.mode = 'SHARP'
            remesh.octree_depth = props.remesh_depth
            remesh.scale = props.remesh_scale
            remesh.use_remove_disconnected = False
            remesh.use_smooth_shade = True
            for m in (smooth, subsurf, bevel, remesh):
                m.use_pin_to_last = True
                m.show_expanded = False
                m.show_in_editmode = True

            bpy.ops.object.shade_smooth()
            # The modifiers are only computed when something asks for the
            # result; asking here does that work while the bar is up instead
            # of in the first frame after it is gone.
            PROG.step("remeshing and bevelling", 0.35)
            try:
                obj.evaluated_get(context.evaluated_depsgraph_get())
                context.view_layer.update()
            except Exception:
                pass
            PROG.step("drawing the result", 0.9)
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    for space in area.spaces:
                        if space.type == 'VIEW_3D':
                            space.overlay.show_wireframes = True
            return {'FINISHED'}
        except Exception as e:
            for t in ['SMOOTH', 'SUBSURF', 'BEVEL', 'REMESH']:
                m = get_modifier(obj, t)
                if m:
                    obj.modifiers.remove(m)
            self.report({'ERROR'}, f"Failed to apply RemeshIT: {e}")
            return {'CANCELLED'}
        finally:
            PROG.end()


class MRBOOL_OT_clear_modifiers(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_clear_modifiers"
    bl_label = "Clear Stack"
    bl_description = "Remove the Remesh, Bevel, Subdivision and Smooth modifiers RemeshIT added"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        for mod in obj.modifiers[:]:
            if mod.type in {'REMESH', 'BEVEL', 'SUBSURF', 'SMOOTH'}:
                obj.modifiers.remove(mod)
        self.report({'INFO'}, "Boolean stack removed")
        return {'FINISHED'}


class MRBOOL_OT_reset_remesh(bpy.types.Operator):
    bl_idname = "object.mrbool_reset_remesh"
    bl_label = "Reset Settings"
    bl_description = "Reset remesh, bevel and subdivision settings to default"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        p = context.scene.mrbool_props
        p.remesh_depth = 4
        p.remesh_scale = 0.9
        p.bevel_amount = 0.02
        p.bevel_segments = 3
        p.bevel_angle = 30.0
        p.bevel_profile = 0.5
        p.subsurf_level = 1
        self.report({'INFO'}, "Settings reset to default")
        return {'FINISHED'}


class MRBOOL_OT_toggle_autosync(bpy.types.Operator):
    bl_idname = "object.mrbool_toggle_autosync"
    bl_label = "Auto-Sync"
    bl_description = "Keep the settings in step with the active object's modifiers"

    def execute(self, context):
        context.scene.mrbool_autosync_enabled = not context.scene.mrbool_autosync_enabled
        return {'FINISHED'}


def sync_from_modifiers(obj, props):
    def put(name, value):
        if getattr(props, name) != value:
            setattr(props, name, value)

    mod = get_modifier(obj, 'REMESH')
    if mod:
        put('remesh_depth', mod.octree_depth)
        put('remesh_scale', round(mod.scale, 6))
    mod = get_modifier(obj, 'BEVEL')
    if mod:
        put('bevel_amount', mod.width)
        put('bevel_segments', mod.segments)
        put('bevel_angle', round(math.degrees(mod.angle_limit), 4))
        put('bevel_profile', mod.profile)
        put('use_beauty_bevel', mod.miter_outer == 'MITER_ARC')
    mod = get_modifier(obj, 'SUBSURF')
    if mod:
        put('subsurf_level', mod.levels)
    mod = get_modifier(obj, 'SMOOTH')
    if mod:
        put('smooth_repeat', mod.iterations)
    mod = get_modifier(obj, 'DECIMATE')
    if mod:
        put('decimate_iterations', max(1, min(10, mod.iterations)))
    mod = get_modifier(obj, 'MIRROR')
    if mod:
        put('mirror_use_merge', mod.use_mirror_merge)
        put('mirror_use_clip', mod.use_clip)
        put('mirror_use_axis_x', bool(mod.use_axis[0]))
        put('mirror_use_axis_y', bool(mod.use_axis[1]))
        put('mirror_use_axis_z', bool(mod.use_axis[2]))
        if props.mirror_object != mod.mirror_object:
            props.mirror_object = mod.mirror_object


class MRBOOL_OT_sync_now(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_sync_now"
    bl_label = "Sync From Modifiers"
    bl_description = "Read the settings back from the active object's modifiers"

    def execute(self, context):
        sync_from_modifiers(context.active_object, context.scene.mrbool_props)
        return {'FINISHED'}


class MRBOOL_OT_transfer_modifiers(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_transfer_modifiers"
    bl_label = "Transfer"
    bl_description = "Copy the active object's modifiers to the other selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source = context.active_object
        targets = [o for o in context.selected_objects if o != source and o.type == 'MESH']
        if not targets:
            self.report({'ERROR'}, "Select at least one target mesh, then the source last")
            return {'CANCELLED'}
        selected = context.selected_objects[:]
        try:
            bpy.ops.object.select_all(action='DESELECT')
            source.select_set(True)
            for t in targets:
                t.select_set(True)
                context.view_layer.objects.active = source
                bpy.ops.object.make_links_data(type='MODIFIERS')
                t.select_set(False)
            self.report({'INFO'}, f"Transferred modifiers to {len(targets)} objects")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to transfer modifiers: {e}")
            return {'CANCELLED'}
        finally:
            for o in selected:
                o.select_set(True)
            context.view_layer.objects.active = source


# === Finalization ===========================================================

class MRBOOL_OT_apply_all(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_apply_all"
    bl_label = "Apply Modifiers"
    bl_description = ("Apply all modifiers. A hidden copy of the object is kept in the "
                      "'Monster Backup' collection first")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        coll = bpy.data.collections.get("Monster Backup")
        if not coll:
            coll = bpy.data.collections.new("Monster Backup")
            context.scene.collection.children.link(coll)
            coll.color_tag = 'COLOR_06'
        backup = obj.copy()
        backup.data = obj.data.copy()
        coll.objects.link(backup)
        backup.name = f"{obj.name}_Backup"
        backup.hide_set(True)
        with PROG.job("BOOLEAN", "Applying", "applying the modifiers"):
            PROG.step("applying the modifiers", 0.3)
            bpy.ops.object.convert(target='MESH')
        return {'FINISHED'}


class MRBOOL_OT_optimize(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_optimize"
    bl_label = "Optimize"
    bl_description = "Decimate using Unsubdivide"
    bl_options = {'REGISTER', 'UNDO'}

    iterations: IntProperty(name="Unsubdivide Iterations",
                            description="Mesh simplification with the Unsubdivide algorithm",
                            default=2, min=1, max=10)

    def invoke(self, context, event):
        self.iterations = context.scene.mrbool_props.decimate_iterations
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        if modifier_exists(obj, 'DECIMATE'):
            self.report({'WARNING'}, "Optimize has already been applied")
            return {'CANCELLED'}
        dec = obj.modifiers.new(name="Decimate", type='DECIMATE')
        dec.decimate_type = 'UNSUBDIV'
        dec.iterations = self.iterations
        dec.show_expanded = False
        dec.show_in_editmode = True
        context.scene.mrbool_props.decimate_iterations = self.iterations
        self.report({'INFO'}, f"Optimize applied with {self.iterations} iterations")
        return {'FINISHED'}


class MRBOOL_OT_uv_unwrap(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_uv_unwrap"
    bl_label = "UV Unwrap"
    bl_description = "Apply the modifiers, then Smart UV Project the whole mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        with PROG.job("BOOLEAN", "Unwrapping", "applying the modifiers"):
            PROG.step("applying the modifiers", 0.2)
            bpy.ops.object.convert(target='MESH')
            if not obj.data.uv_layers:
                obj.data.uv_layers.new(name="UVMap")
            else:
                obj.data.uv_layers.active_index = 0
            PROG.step("projecting the UVs", 0.5)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.smart_project()
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "UV unwrap completed")
        return {'FINISHED'}


class MRBOOL_OT_clean_loops(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_clean_loops"
    bl_label = "Clean Edge Loops"
    bl_description = "Remove redundant edge loops below an angle threshold"
    bl_options = {'REGISTER', 'UNDO'}

    angle: FloatProperty(name="Angle Threshold",
                         description="Edge loops flatter than this are removed",
                         default=5.0, min=0.01, max=180.0)
    preserve_boundary_loops: BoolProperty(name="Preserve Boundary Loops",
                                          description="Keep loops near sharp boundaries",
                                          default=True)
    min_loop_length: IntProperty(name="Min Loop Length", default=3, min=1, max=20)
    triangulate: BoolProperty(name="Triangulate & Requad",
                              description="Triangulate and convert back to quads",
                              default=True)

    def invoke(self, context, event):
        last = context.scene.mrbool_props.clean_edge_loops_last_angle
        if last > 0:
            self.angle = last
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        lay = self.layout
        lay.prop(self, "angle")
        lay.prop(self, "preserve_boundary_loops")
        lay.prop(self, "min_loop_length")
        lay.prop(self, "triangulate")

    def execute(self, context):
        with PROG.job("BOOLEAN", "Cleaning loops", "finding flat loops"):
            return self._run(context)

    def _run(self, context):
        obj = context.active_object
        props = context.scene.mrbool_props
        t0 = time.time()
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')

        threshold = math.radians(self.angle)
        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        pending = {e for e in bm.edges if len(e.link_faces) == 2}
        found = []
        while pending:
            e = next(iter(pending))
            es = get_loop(bm, e)
            pending.difference_update(es)
            if not es or len(es) < self.min_loop_length:
                continue
            if has_complex_topology(es):
                continue
            if self.preserve_boundary_loops:
                keep = False
                for le in es:
                    for v in le.verts:
                        for edge in v.link_edges:
                            if edge != le and len(edge.link_faces) == 2:
                                try:
                                    if edge.calc_face_angle() > 0.7:
                                        keep = True
                                        break
                                except ValueError:
                                    continue
                        if keep:
                            break
                    if keep:
                        break
                if keep:
                    continue
            if not check_angles(es, threshold):
                continue
            found.append(es)

        if not found:
            self.report({'INFO'}, "No redundant edge loops found to clean")
            bpy.ops.object.mode_set(mode='OBJECT')
            return {'FINISHED'}

        PROG.step("dissolving %d loops" % len(found), 0.5)
        for es in found:
            for e in es:
                e.select = True
        bmesh.update_edit_mesh(obj.data)
        bpy.ops.mesh.dissolve_edges()
        if self.triangulate:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
            bpy.ops.mesh.tris_convert_to_quads()
        bpy.ops.object.mode_set(mode='OBJECT')

        dec = get_modifier(obj, 'DECIMATE')
        if dec:
            try:
                bpy.ops.object.modifier_apply(modifier=dec.name)
            except Exception as e:
                self.report({'WARNING'}, f"Couldn't apply Decimate: {e}")
        wn = obj.modifiers.new(name="WeightedNormal", type='WEIGHTED_NORMAL')
        wn.keep_sharp = True
        wn.show_expanded = False
        wn.show_in_editmode = True
        props.clean_edge_loops_last_angle = self.angle
        self.report({'INFO'}, f"Cleaned edge loops at {self.angle:g}° in {time.time() - t0:.2f}s")
        return {'FINISHED'}


class MRBOOL_OT_toggle_realtime_uv(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_toggle_realtime_uv"
    bl_label = "Real-Time UV"
    bl_description = "Add or remove the Tri-Planar UV geometry-nodes modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        mod = realtime_uv_mod(obj)
        if mod:
            obj.modifiers.remove(mod)
            self.report({'INFO'}, "Removed Real-Time UV")
            return {'FINISHED'}
        if TRIPLANAR not in bpy.data.node_groups:
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), BLEND_NAME)
            try:
                with bpy.data.libraries.load(path, link=False) as (src, dst):
                    if TRIPLANAR not in src.node_groups:
                        raise RuntimeError("node group missing from " + BLEND_NAME)
                    dst.node_groups = [TRIPLANAR]
            except Exception as e:
                self.report({'ERROR'}, f"Could not load Real-Time UV: {e}")
                return {'CANCELLED'}
        geo = obj.modifiers.new(name=TRIPLANAR, type='NODES')
        geo.node_group = bpy.data.node_groups[TRIPLANAR]
        geo.use_pin_to_last = True
        geo.show_expanded = True
        geo.show_in_editmode = True
        self.report({'INFO'}, "Added Real-Time UV")
        return {'FINISHED'}


# === Mirror =================================================================

class MRBOOL_OT_add_mirror(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_add_mirror"
    bl_label = "Add/Remove Mirror"
    bl_description = "Add or remove a Mirror modifier centred on a new empty"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.mrbool_props
        mirror = get_modifier(obj, 'MIRROR')
        if not mirror:
            coll = bpy.data.collections.get("Monster Mirror")
            if not coll:
                coll = bpy.data.collections.new("Monster Mirror")
                context.scene.collection.children.link(coll)
                coll.color_tag = 'COLOR_04'
            empty = bpy.data.objects.new(f"{obj.name}_mirror", None)
            coll.objects.link(empty)
            empty.empty_display_type = 'ARROWS'
            empty.empty_display_size = 1.0
            empty.location = (0, 0, 0)
            empty.show_name = True
            mirror = obj.modifiers.new(name="Mirror", type='MIRROR')
            mirror.use_axis[0] = props.mirror_use_axis_x
            mirror.use_axis[1] = props.mirror_use_axis_y
            mirror.use_axis[2] = props.mirror_use_axis_z
            mirror.use_clip = props.mirror_use_clip
            mirror.use_mirror_merge = props.mirror_use_merge
            mirror.mirror_object = empty
            mirror.show_expanded = False
            mirror.show_in_editmode = True
            bpy.ops.object.modifier_move_to_index(modifier=mirror.name,
                                                  index=len(obj.modifiers) - 1)
            props.mirror_empty_created = True
            props.mirror_object = empty
            props.use_mirror = True
            self.report({'INFO'}, "Added mirror")
        else:
            empty = mirror.mirror_object
            obj.modifiers.remove(mirror)
            if empty and props.mirror_empty_created:
                bpy.data.objects.remove(empty, do_unlink=True)
            self.report({'INFO'}, "Removed mirror")
        return {'FINISHED'}


class MRBOOL_OT_move_mirror_up(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_move_mirror_up"
    bl_label = "Mirror First"
    bl_description = "Move the mirror to the top of the stack"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        m = get_modifier(obj, 'MIRROR')
        if m:
            m.use_pin_to_last = False
            bpy.ops.object.modifier_move_to_index(modifier=m.name, index=0)
        return {'FINISHED'}


class MRBOOL_OT_move_mirror_down(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_move_mirror_down"
    bl_label = "Mirror Last"
    bl_description = "Move the mirror to the bottom of the stack and pin it there"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        m = get_modifier(obj, 'MIRROR')
        if m:
            m.use_pin_to_last = True
            bpy.ops.object.modifier_move_to_index(modifier=m.name,
                                                  index=len(obj.modifiers) - 1)
        return {'FINISHED'}


# === Boolean manager ========================================================

class _NamedBool(_MeshOp):
    modifier_name: StringProperty()

    def _mod(self, context):
        mod = context.active_object.modifiers.get(self.modifier_name)
        return mod if mod is not None and mod.type == 'BOOLEAN' else None


class MRBOOL_OT_move_boolean_up(_NamedBool, bpy.types.Operator):
    bl_idname = "object.mrbool_move_boolean_up"
    bl_label = "Move Boolean Up"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mod = self._mod(context)
        if mod and list(context.active_object.modifiers).index(mod) > 0:
            bpy.ops.object.modifier_move_up(modifier=mod.name)
        return {'FINISHED'}


class MRBOOL_OT_move_boolean_down(_NamedBool, bpy.types.Operator):
    bl_idname = "object.mrbool_move_boolean_down"
    bl_label = "Move Boolean Down"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        mod = self._mod(context)
        if mod and list(obj.modifiers).index(mod) < len(obj.modifiers) - 1:
            bpy.ops.object.modifier_move_down(modifier=mod.name)
        return {'FINISHED'}


class MRBOOL_OT_select_boolean(_NamedBool, bpy.types.Operator):
    bl_idname = "object.mrbool_select_boolean"
    bl_label = "Select Cutter"
    bl_description = "Select the object this boolean cuts with"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mod = self._mod(context)
        if mod and mod.object:
            bpy.ops.object.select_all(action='DESELECT')
            mod.object.hide_set(False)
            mod.object.select_set(True)
            context.view_layer.objects.active = mod.object
        return {'FINISHED'}


class MRBOOL_OT_delete_boolean(_NamedBool, bpy.types.Operator):
    bl_idname = "object.mrbool_delete_boolean"
    bl_label = "Delete Boolean"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mod = self._mod(context)
        if mod:
            context.active_object.modifiers.remove(mod)
            self.report({'INFO'}, f"Removed boolean '{self.modifier_name}'")
        return {'FINISHED'}


class MRBOOL_OT_rename_boolean(_NamedBool, bpy.types.Operator):
    bl_idname = "object.mrbool_rename_boolean"
    bl_label = "Rename Boolean"
    bl_options = {'REGISTER', 'UNDO'}

    new_name: StringProperty(name="New Name")

    def invoke(self, context, event):
        self.new_name = self.modifier_name
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "new_name")

    def execute(self, context):
        mod = self._mod(context)
        if mod is None:
            return {'CANCELLED'}
        if not self.new_name:
            self.report({'WARNING'}, "Please enter a valid name")
            return {'CANCELLED'}
        mod.name = self.new_name
        return {'FINISHED'}


# === Lattice ================================================================

class MRBOOL_OT_add_lattice(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_add_lattice"
    bl_label = "Add Lattice Cage"
    bl_description = "Add a lattice cage the size of the mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        lm = get_modifier(obj, 'LATTICE')
        if lm:
            if not lm.object or lm.object.type != 'LATTICE':
                obj.modifiers.remove(lm)
            else:
                self.report({'WARNING'}, "Object already has a lattice cage")
                return {'CANCELLED'}
        lattice = lattice_obj = None
        try:
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            coll = bpy.data.collections.get("Monster Lattice")
            if not coll:
                coll = bpy.data.collections.new("Monster Lattice")
                context.scene.collection.children.link(coll)
                coll.color_tag = 'COLOR_05'
            selected = context.selected_objects[:]
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
            dims = obj.dimensions.copy()
            loc = obj.location.copy()
            name = f"{obj.name}_lattice"
            lattice = bpy.data.lattices.new(name)
            lattice_obj = bpy.data.objects.new(name, lattice)
            coll.objects.link(lattice_obj)
            lattice.points_u = lattice.points_v = lattice.points_w = 4
            lattice_obj.scale = [max(d, 1e-4) * 1.1 for d in dims]
            lattice_obj.location = loc
            lm = obj.modifiers.new(name="Lattice", type='LATTICE')
            lm.object = lattice_obj
            lm.use_pin_to_last = True
            lm.show_expanded = False
            lm.show_in_editmode = True
            for o in context.selected_objects:
                o.select_set(False)
            for o in selected:
                o.select_set(True)
            context.view_layer.objects.active = obj
            self.report({'INFO'}, "Added lattice cage")
            return {'FINISHED'}
        except Exception as e:
            if lattice_obj is not None:
                bpy.data.objects.remove(lattice_obj, do_unlink=True)
            if lattice is not None:
                bpy.data.lattices.remove(lattice)
            self.report({'ERROR'}, f"Failed to create lattice: {e}")
            return {'CANCELLED'}


def _lattice_of(context):
    obj = context.active_object
    lm = get_modifier(obj, 'LATTICE') if obj and obj.type == 'MESH' else None
    return lm if lm and lm.object and lm.object.type == 'LATTICE' else None


class MRBOOL_OT_select_lattice(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_select_lattice"
    bl_label = "Select Lattice"
    bl_description = "Select the lattice cage to edit it"

    def execute(self, context):
        lm = _lattice_of(context)
        if lm:
            bpy.ops.object.select_all(action='DESELECT')
            lm.object.select_set(True)
            context.view_layer.objects.active = lm.object
        return {'FINISHED'}


class MRBOOL_OT_delete_lattice(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_delete_lattice"
    bl_label = "Delete Lattice"
    bl_description = "Remove the lattice modifier and delete the cage"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        lm = get_modifier(obj, 'LATTICE')
        if lm:
            cage = lm.object
            obj.modifiers.remove(lm)
            if cage:
                bpy.data.objects.remove(cage, do_unlink=True)
            self.report({'INFO'}, "Removed lattice")
        return {'FINISHED'}


class MRBOOL_OT_lattice_resolution(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_lattice_resolution"
    bl_label = "Lattice Resolution"
    bl_description = "Change the resolution of the lattice cage"
    bl_options = {'REGISTER', 'UNDO'}

    step: IntProperty(default=1)

    def execute(self, context):
        lm = _lattice_of(context)
        if lm:
            d = lm.object.data
            n = max(2, min(8, d.points_u + self.step))
            d.points_u = d.points_v = d.points_w = n
            self.report({'INFO'}, f"Lattice resolution {n}")
        return {'FINISHED'}


# === Displace ===============================================================

class MRBOOL_OT_add_remove_displace(_MeshOp, bpy.types.Operator):
    bl_idname = "object.mrbool_add_remove_displace"
    bl_label = "Add/Remove Displace"
    bl_description = "Add or remove a Displace modifier with a Clouds texture"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        disp = get_modifier(obj, 'DISPLACE')
        if not disp:
            tex = bpy.data.textures.new(f"{obj.name}_DisplaceTex", type='CLOUDS')
            disp = obj.modifiers.new(name="Displace", type='DISPLACE')
            disp.texture = tex
            disp.strength = 0.5
            disp.mid_level = 0.5
            disp.use_pin_to_last = True
            disp.show_expanded = False
            disp.show_in_editmode = True
            if obj.data.uv_layers:
                disp.texture_coords = 'UV'
                disp.uv_layer = obj.data.uv_layers.active.name
            self.report({'INFO'}, "Added Displace with a Clouds texture")
        else:
            tex = disp.texture
            obj.modifiers.remove(disp)
            if tex and tex.users == 0:
                bpy.data.textures.remove(tex)
            self.report({'INFO'}, "Removed Displace")
        return {'FINISHED'}


# === Presets ================================================================

def _presets_path():
    d = bpy.utils.user_resource("CONFIG", path="monster_remesh", create=True)
    return os.path.join(d, "boolean_presets.json")


PRESET_KEYS = ('remesh_depth', 'remesh_scale', 'bevel_amount', 'bevel_segments',
               'bevel_angle', 'bevel_profile', 'subsurf_level', 'smooth_repeat',
               'use_beauty_bevel')

_PRESET_CACHE = {"mtime": None, "data": {}}


def load_presets():
    path = _presets_path()
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return {}
    if _PRESET_CACHE["mtime"] != mtime:
        try:
            with open(path, 'r', encoding='utf-8') as f:
                _PRESET_CACHE["data"] = json.load(f)
        except Exception:
            _PRESET_CACHE["data"] = {}
        _PRESET_CACHE["mtime"] = mtime
    return dict(_PRESET_CACHE["data"])


def save_presets(presets):
    with open(_presets_path(), 'w', encoding='utf-8') as f:
        json.dump(presets, f, indent=2)
    _PRESET_CACHE["mtime"] = None


class MRBOOL_OT_save_preset(bpy.types.Operator):
    bl_idname = "object.mrbool_save_preset"
    bl_label = "Save Preset"
    bl_description = "Save the current Boolean settings under a name"

    preset_name: StringProperty(name="Preset Name")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "preset_name")

    def execute(self, context):
        if not self.preset_name.strip():
            self.report({'WARNING'}, "Give the preset a name")
            return {'CANCELLED'}
        p = context.scene.mrbool_props
        presets = load_presets()
        presets[self.preset_name.strip()] = {k: getattr(p, k) for k in PRESET_KEYS}
        save_presets(presets)
        self.report({'INFO'}, f"Preset '{self.preset_name}' saved")
        return {'FINISHED'}


class MRBOOL_OT_load_preset(bpy.types.Operator):
    bl_idname = "object.mrbool_load_preset"
    bl_label = "Load Preset"
    bl_description = "Load a saved Boolean preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: StringProperty()

    def execute(self, context):
        preset = load_presets().get(self.preset_name)
        if not preset:
            self.report({'WARNING'}, f"Preset '{self.preset_name}' not found")
            return {'CANCELLED'}
        p = context.scene.mrbool_props
        for k in PRESET_KEYS:
            if k in preset:
                setattr(p, k, preset[k])
        self.report({'INFO'}, f"Preset '{self.preset_name}' loaded")
        return {'FINISHED'}


class MRBOOL_OT_delete_preset(bpy.types.Operator):
    bl_idname = "object.mrbool_delete_preset"
    bl_label = "Delete Preset"
    bl_description = "Delete a saved Boolean preset"

    preset_name: StringProperty()

    def execute(self, context):
        presets = load_presets()
        if self.preset_name in presets:
            del presets[self.preset_name]
            save_presets(presets)
            self.report({'INFO'}, f"Preset '{self.preset_name}' deleted")
        return {'FINISHED'}


CLASSES = (
    MRBOOL_Properties,
    MRBOOL_OT_remeshit, MRBOOL_OT_clear_modifiers, MRBOOL_OT_reset_remesh,
    MRBOOL_OT_toggle_autosync, MRBOOL_OT_sync_now, MRBOOL_OT_transfer_modifiers,
    MRBOOL_OT_apply_all, MRBOOL_OT_optimize, MRBOOL_OT_uv_unwrap, MRBOOL_OT_clean_loops,
    MRBOOL_OT_toggle_realtime_uv,
    MRBOOL_OT_add_mirror, MRBOOL_OT_move_mirror_up, MRBOOL_OT_move_mirror_down,
    MRBOOL_OT_move_boolean_up, MRBOOL_OT_move_boolean_down, MRBOOL_OT_select_boolean,
    MRBOOL_OT_delete_boolean, MRBOOL_OT_rename_boolean,
    MRBOOL_OT_add_lattice, MRBOOL_OT_select_lattice, MRBOOL_OT_delete_lattice,
    MRBOOL_OT_lattice_resolution,
    MRBOOL_OT_add_remove_displace,
    MRBOOL_OT_save_preset, MRBOOL_OT_load_preset, MRBOOL_OT_delete_preset,
)


@bpy.app.handlers.persistent
def _autosync(scene, depsgraph):
    try:
        ctx = bpy.context
        scn = ctx.scene
        if not getattr(scn, "mrbool_autosync_enabled", False):
            return
        obj = ctx.active_object
        if obj is None or obj.type != 'MESH':
            return
        props = scn.mrbool_props
        sync_from_modifiers(obj, props)
        has_mirror = get_modifier(obj, 'MIRROR') is not None
        if props.use_mirror != has_mirror and not has_mirror:
            props.use_mirror = False
    except Exception:
        pass


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    S = bpy.types.Scene
    S.mrbool_props = PointerProperty(type=MRBOOL_Properties)
    S.mrbool_autosync_enabled = BoolProperty(default=False, name="Auto-Sync Enabled")
    if _autosync not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_autosync)


def unregister():
    if _autosync in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_autosync)
    S = bpy.types.Scene
    for name in ("mrbool_props", "mrbool_autosync_enabled"):
        if hasattr(S, name):
            try:
                delattr(S, name)
            except Exception:
                pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
