"""Seam and sharp edges, drawn in Object Mode.

Blender only draws its own seam and sharp overlays while the mesh is open in
Edit Mode. Tick "Show UV seams" in Object Mode and the edges really are marked
- the mesh carries them - but nothing appears on screen, which reads as a
broken button. This draws them itself, so the mark is visible where the work
actually happens.
"""

import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader


SEAM = (0.492, 0.760, 0.106, 1.0)      # the add-on's green
SHARP = (0.20, 0.72, 1.0, 1.0)       # Blender's own sharp blue

_handle = None
_cache = {"key": None, "seam": None, "sharp": None, "matrix": None}


def _wants(context):
    """The object to draw on, or None when neither mark is asked for."""
    lines = getattr(context.scene, "monsterremesh_lines", None)
    if lines is None:
        return None, False, False
    show = bool(getattr(lines, "uv_show_seams", False))
    sharp = bool(getattr(lines, "uv_seams_sharp", False))
    if not (show or sharp):
        return None, False, False
    obj = context.active_object
    if obj is None or obj.type != "MESH" or obj.mode == "EDIT":
        return None, False, False   # Edit Mode already draws its own
    return obj, show, sharp


def _segments(me, flag, off):
    """The marked edges as a flat array of world-space-ready points."""
    n = len(me.edges)
    if n == 0:
        return None
    mask = np.zeros(n, dtype=bool)
    me.edges.foreach_get(flag, mask)
    if not mask.any():
        return None
    idx = np.empty(n * 2, dtype=np.int32)
    me.edges.foreach_get("vertices", idx)
    idx = idx.reshape(n, 2)[mask].ravel()

    nv = len(me.vertices)
    co = np.empty(nv * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    co = co.reshape(nv, 3)
    if off:
        nor = np.empty(nv * 3, dtype=np.float32)
        me.vertices.foreach_get("normal", nor)
        co = co + nor.reshape(nv, 3) * off
    return co[idx]


def _build(obj, show, sharp):
    """Batches for the two kinds of mark, rebuilt only when something moved."""
    me = obj.data
    # A hair off the surface, so the line is not swallowed by the face it sits
    # on. Scaled by the model, or it disappears on big ones and floats on small.
    off = max(obj.dimensions) * 0.0015 if max(obj.dimensions) else 0.0
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    out = {}
    for name, flag, on in (("seam", "use_seam", show),
                           ("sharp", "use_edge_sharp", sharp)):
        pts = _segments(me, flag, off) if on else None
        out[name] = (batch_for_shader(shader, "LINES", {"pos": pts})
                     if pts is not None and len(pts) else None)
    return out


def invalidate():
    """The marks changed; drop what was drawn last."""
    _cache["key"] = None


def _draw():
    context = bpy.context
    obj, show, sharp = _wants(context)
    if obj is None:
        return
    me = obj.data
    key = (obj.as_pointer(), len(me.edges), len(me.vertices), show, sharp)
    if _cache["key"] != key:
        built = _build(obj, show, sharp)
        _cache.update(key=key, seam=built["seam"], sharp=built["sharp"])
    if _cache["seam"] is None and _cache["sharp"] is None:
        return

    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    gpu.state.depth_test_set("LESS_EQUAL")
    gpu.state.line_width_set(2.0)
    gpu.matrix.push()
    gpu.matrix.multiply_matrix(obj.matrix_world)
    shader.bind()
    for name, color in (("sharp", SHARP), ("seam", SEAM)):
        batch = _cache[name]
        if batch is None:
            continue
        shader.uniform_float("color", color)
        batch.draw(shader)
    gpu.matrix.pop()
    gpu.state.line_width_set(1.0)
    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")


def register():
    global _handle
    if _handle is None:
        _handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw, (), "WINDOW", "POST_VIEW")


def unregister():
    global _handle
    if _handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_handle, "WINDOW")
        except Exception:
            pass
        _handle = None
    invalidate()
