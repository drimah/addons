"""Instant Meshes as a remeshing backend, driven in batch mode.

This is the "stable" backend: a known-good reference implementation of the same
family of algorithm ours is working towards. Keeping it alongside ours means
there is always a usable result, and - more usefully - an objective yardstick
to measure ours against with TopoLens.

Instant Meshes is by Wenzel Jakob, Daniele Panozzo, Marco Tarini and Olga
Sorkine-Hornung (SIGGRAPH Asia 2015), BSD-licensed. We ship the official
prebuilt binary unmodified; see vendor/LICENSE-instant-meshes.txt.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time

import numpy as np

EXE_NAME = "Instant Meshes.exe" if os.name == "nt" else "Instant Meshes"


_FOUND: dict = {}


def find_exe(explicit: str = "") -> str | None:
    """Locate the binary: explicit path, bundled copy, repo vendor dir, PATH.

    The answer is cached for the session. This is asked far more often than it
    looks: the engine dropdown's item list calls it every time the enum is
    read, and the viewport card reads that enum on every redraw - measured,
    one search walked PATH with 27,000 file checks and cost 7 ms, three times
    a frame, which is most of a frame gone before anything is drawn. Nothing
    moves the binary mid-session, and Reset Everything clears the cache.
    """
    if explicit in _FOUND:
        return _FOUND[explicit]
    candidates = []
    if explicit:
        candidates.append(explicit)
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates.append(os.path.join(here, "bin", EXE_NAME))
    # Development checkout: <repo>/addon/monsterremesh -> <repo>/vendor/...
    repo = os.path.dirname(os.path.dirname(here))
    candidates.append(os.path.join(repo, "vendor", "instant-meshes", EXE_NAME))
    found = shutil.which(EXE_NAME)
    if found:
        candidates.append(found)
    for c in candidates:
        if c and os.path.isfile(c):
            _FOUND[explicit] = c
            return c
    _FOUND[explicit] = None
    return None


def forget_exe() -> None:
    """Look for the binary again, after a path was set by hand."""
    _FOUND.clear()


QUARANTINE = "com.apple.quarantine"


def ensure_executable(path: str) -> None:
    """Put the execute bit back if the unzip dropped it.

    Not every extractor carries a zip's stored mode through, and a binary that
    lands 0644 cannot be run at all. Restoring a bit on a file we shipped is
    not a security decision, so this happens silently - unlike the quarantine
    flag below, which is.
    """
    if os.name == "nt":
        return
    try:
        mode = os.stat(path).st_mode
        if not mode & 0o111:
            os.chmod(path, mode | 0o755)
    except OSError:
        pass


def is_quarantined(path: str) -> bool:
    """Whether macOS will refuse to exec this file.

    The engine is the authors' own build and carries no Apple signature, so
    anything that arrives inside a download gets flagged. Launched from Finder
    that produces the familiar "Open Anyway" prompt; exec'd from a subprocess
    the way this add-on does it, there is no prompt at all - the process is
    killed and the caller sees a bare failure. Hence checking up front.
    """
    if sys.platform != "darwin":
        return False
    try:
        return QUARANTINE in os.listxattr(path)
    except (OSError, AttributeError):
        return False


def clear_quarantine(path: str) -> tuple[bool, str]:
    """Drop the quarantine flag from the add-on's own bin folder.

    Deliberately not called from the remesh path. Undoing a Gatekeeper flag is
    the user's call, so it is behind a button that says what it does. Scope is
    the folder holding the binary and nothing else.
    """
    if sys.platform != "darwin":
        return True, ""
    folder = os.path.dirname(os.path.abspath(path))
    try:
        proc = subprocess.run(["xattr", "-dr", QUARANTINE, folder],
                              capture_output=True, text=True, timeout=60)
    except Exception as exc:
        return False, str(exc)
    if is_quarantined(path):
        return False, (proc.stderr or proc.stdout or "").strip() or             "the flag is still set"
    return True, ""


def write_obj(path: str, V: np.ndarray, face_verts: np.ndarray,
              face_sizes: np.ndarray) -> None:
    starts = np.concatenate([[0], np.cumsum(face_sizes)[:-1]])
    with open(path, "w") as fh:
        fh.write("# written by monsterremesh\n")
        for x, y, z in V:
            fh.write(f"v {x:.8g} {y:.8g} {z:.8g}\n")
        for s, n in zip(starts.tolist(), face_sizes.tolist()):
            idx = face_verts[s:s + n] + 1
            fh.write("f " + " ".join(str(int(i)) for i in idx) + "\n")


def write_ply(path: str, V, face_verts, face_sizes) -> None:
    """The input as binary PLY, which Instant Meshes reads as well as OBJ.

    Writing OBJ is a Python loop over every vertex and face, and the engine
    then has to parse the text back: on a 1.3 million face model that was ten
    seconds before the engine started, with the progress bar sitting at zero.
    Binary PLY is laid out with numpy in one go - 0.2 s for the same model,
    and the engine loads it in 0.14 s. Doubles, so nothing is rounded.

    The engine's PLY reader takes triangles only ("Only triangle faces are
    supported!"), where its OBJ reader fans every polygon from its first
    corner. So the polygons are fanned here the same way, and the engine sees
    exactly the triangles it would have made itself.
    """
    V = np.ascontiguousarray(V, dtype="<f8")
    fs = np.asarray(face_sizes, dtype=np.int64)
    fv = np.asarray(face_verts, dtype=np.int64)
    nf = len(fs)
    lstart = np.zeros(nf, dtype=np.int64)
    if nf > 1:
        lstart[1:] = np.cumsum(fs)[:-1]
    tris = np.maximum(fs - 2, 0)
    tstart = np.zeros(nf, dtype=np.int64)
    if nf > 1:
        tstart[1:] = np.cumsum(tris)[:-1]
    owner = np.repeat(np.arange(nf, dtype=np.int64), tris)
    k = np.arange(len(owner), dtype=np.int64) - tstart[owner] + 1
    first = lstart[owner]
    rec = np.empty(len(owner), dtype=[("n", "u1"), ("i", "<i4", (3,))])
    rec["n"] = 3
    rec["i"][:, 0] = fv[first]
    rec["i"][:, 1] = fv[first + k]
    rec["i"][:, 2] = fv[first + k + 1]
    head = ("ply\nformat binary_little_endian 1.0\n"
            f"element vertex {len(V)}\n"
            "property double x\nproperty double y\nproperty double z\n"
            f"element face {len(rec)}\n"
            "property list uchar int vertex_indices\nend_header\n")
    with open(path, "wb") as fh:
        fh.write(head.encode("ascii"))
        fh.write(V.tobytes())
        fh.write(rec.tobytes())


def _f(tok: str) -> float:
    """Tolerant float parse. The engine can emit '-nan(ind)' on some inputs."""
    try:
        v = float(tok)
    except ValueError:
        return float("nan")
    return v


def read_obj(path: str):
    """Read back a mesh, keeping n-gons intact.

    Instant Meshes occasionally writes non-finite vertices - seen on a real
    hard-surface asset. Those and any face touching them are dropped here
    rather than allowed to propagate into Blender, where they would produce an
    object that looks fine in the outliner and is unusable in the viewport.
    """
    verts: list = []
    faces: list = []
    with open(path, "r", errors="replace") as fh:
        for line in fh:
            if not line:
                continue
            c = line[0]
            if c == "v" and line[1] == " ":
                p = line.split()
                verts.append((_f(p[1]), _f(p[2]), _f(p[3])))
            elif c == "f":
                p = line.split()
                idx = []
                for tok in p[1:]:
                    slash = tok.find("/")
                    s = tok if slash < 0 else tok[:slash]
                    if s:
                        i = int(s)
                        idx.append(i - 1 if i > 0 else len(verts) + i)
                if len(idx) >= 3:
                    faces.append(idx)

    V = np.asarray(verts, dtype=np.float64)
    if not len(V):
        return V, faces, 0
    good = np.isfinite(V).all(axis=1)
    n_bad = int((~good).sum())
    if n_bad:
        faces = [f for f in faces
                 if all(0 <= i < len(V) and good[i] for i in f)]
        remap = np.full(len(V), -1, dtype=np.int64)
        remap[good] = np.arange(int(good.sum()))
        faces = [[int(remap[i]) for i in f] for f in faces]
        V = V[good]
    return V, faces, n_bad


def remesh(V, face_verts, face_sizes, *, target_faces: int | None = None,
           dominant: bool = False, **kw) -> dict:
    """Instant Meshes, landing on the face count that was asked for.

    Asked for pure quads, Instant Meshes builds the mesh at the count it was
    given and then splits every face into four so that nothing is left a
    triangle. The result is four times the number: measured on a 192,450
    face creature, 10,000 asked, 39,239 back - and the same ratio at every
    size. So the count is quartered before it goes in, and if the answer is
    still more than 3 percent away it is corrected once by what came back.
    """
    if not target_faces or kw.get("target_edge"):
        return _remesh_once(V, face_verts, face_sizes,
                            target_faces=target_faces, dominant=dominant, **kw)
    want = int(target_faces)
    # 3.85 rather than 4: the split is exactly four, but the mesh before it
    # lands a little under what it was asked for - 2,500 asked gave 9,454 on
    # the creature, 10,000 gave 39,239. Starting nearer saves the second run.
    ask = want if dominant else max(4, int(round(want / 3.85)))
    report = kw.pop("progress", None)

    def part(lo, hi):
        if report is None:
            return None
        return lambda name, frac: report(name, lo + (hi - lo) * frac)

    out = _remesh_once(V, face_verts, face_sizes, target_faces=ask,
                       dominant=dominant, progress=part(0.0, 0.8), **kw)
    got = out["log"]["output"]["faces"]
    if got and abs(got - want) > want * 0.03:
        ask = max(4, int(round(ask * want / float(got))))
        if report is not None:
            report("matching the face count", 0.8)
        again = _remesh_once(V, face_verts, face_sizes, target_faces=ask,
                             dominant=dominant, progress=part(0.8, 1.0), **kw)
        if (abs(again["log"]["output"]["faces"] - want)
                < abs(got - want)):
            out = again
    if report is not None:
        report("done", 1.0)
    out["log"]["asked_faces"] = want
    return out


# What Instant Meshes prints as it finishes each stage, and how far along the
# job is once that line has appeared. Timed off its own log on a 1.3 million
# face model read as binary PLY: loading 10%, the hierarchy to 25%, the setup
# to 31%, the orientation solve to 41%, the position solve - the long one -
# to 74%, the extraction steps to 96%. A line is printed only when its stage
# is done, so each entry marks the end of one stage and the start of the next.
_STAGES = (
    ("Loading", 0.10, "building the hierarchy"),
    ("Hierarchy construction took", 0.25, "preparing"),
    ("Preprocessing is done", 0.31, "solving the orientation field"),
    ("Optimizing orientation field", 0.41, "solving the position field"),
    ("Orientation field has", 0.41, "solving the position field"),
    ("Optimizing position field", 0.74, "extracting quads"),
    ("Extraction is done", 0.96, "writing the result"),
    ("Writing", 0.97, "reading the result"),
)


class _Report(object):
    """Carries the latest stage to a watcher on another thread."""


def _run_reporting(cmd, timeout, progress):
    """Run the binary, turning its log into progress as the lines arrive.

    `progress` may raise to stop the job - the engine is killed on the way
    out, so a cancelled remesh does not keep a core busy in the background.
    Returns an object shaped like subprocess.run's, for the callers below.
    """
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True,
                            errors="replace", bufsize=1, creationflags=flags)
    out = []
    t0 = time.perf_counter()
    try:
        for line in proc.stdout:
            out.append(line)
            if time.perf_counter() - t0 > timeout:
                raise subprocess.TimeoutExpired(cmd, timeout)
            if not progress:
                continue
            s = line.strip()
            if s.startswith("Step "):
                try:
                    n = int(s[5:s.index(":")])
                except ValueError:
                    n = 0
                progress("extracting quads", 0.74 + 0.22 * min(n, 12) / 12.0)
                continue
            for key, frac, nxt in _STAGES:
                if s.startswith(key):
                    progress(nxt, frac)
                    break
        proc.wait()
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
    rep = _Report()
    rep.stdout = "".join(out)
    rep.stderr = ""
    rep.returncode = proc.returncode
    return rep


def _remesh_once(V, face_verts, face_sizes, *,
           target_faces: int | None = None,
           target_edge: float | None = None,
           feature_angle: float = 30.0,
           smooth_iterations: int = 2,
           dominant: bool = False,
           deterministic: bool = True,
           align_boundaries: bool = True,
           threads: int = 0,
           exe: str = "",
           timeout: int = 1800,
           progress=None) -> dict:
    """Run Instant Meshes in batch mode. Same signature shape as ours."""
    t0 = time.perf_counter()
    binary = find_exe(exe)
    if binary is None:
        raise RuntimeError(
            f"Instant Meshes binary not found - expected <addon>/bin/{EXE_NAME}, "
            "or a path set in Preferences > Add-ons > Monster Remesh. "
            "Monster Remesh (Hardsurface) needs no binary and works everywhere."
        )

    ensure_executable(binary)
    if is_quarantined(binary):
        raise RuntimeError(
            "macOS has quarantined the Organic engine, so it cannot start. "
            "Press “Allow Organic Engine” in the Monster Remesh panel, "
            "or run this in Terminal:\n\n"
            f'    xattr -dr com.apple.quarantine "{os.path.dirname(binary)}"'
        )

    if progress:
        progress("writing input", 0.02)
    work = tempfile.mkdtemp(prefix="monsterremesh_im_")
    src = os.path.join(work, "in.ply")
    dst = os.path.join(work, "out.obj")
    try:
        write_ply(src, V, face_verts, face_sizes)

        cmd = [binary, src, "-o", dst, "-c", str(float(feature_angle)),
               "-S", str(int(smooth_iterations))]
        if target_edge:
            cmd += ["-s", str(float(target_edge))]
        elif target_faces:
            cmd += ["-f", str(int(target_faces))]
        if dominant:
            cmd.append("-D")
        if deterministic:
            cmd.append("-d")
        if align_boundaries:
            cmd.append("-b")
        if threads > 0:
            cmd += ["-t", str(int(threads))]

        if progress:
            progress("loading the model", 0.05)
        try:
            proc = _run_reporting(cmd, timeout, progress)
        except OSError as exc:
            # The macOS engine is the authors' Intel build, so on Apple
            # Silicon it runs through Rosetta. Rosetta is not installed by
            # default; macOS offers to install it when an Intel app is opened
            # from Finder, and says nothing at all when one is exec'd from a
            # subprocess the way this is. Without that translation the exec
            # fails with EBADARCH and no explanation, so name it here.
            if getattr(exc, "errno", None) == 86 or "cpu type" in str(exc).lower():
                raise RuntimeError(
                    "The Organic engine needs Rosetta, which is not installed "
                    "on this Mac. Install it once by running this in "
                    "Terminal:\n\n"
                    "    softwareupdate --install-rosetta\n\n"
                    "Monster Remesh (Hardsurface) does not need it and works "
                    "either way."
                ) from exc
            raise
        if not os.path.isfile(dst):
            tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-15:])
            raise RuntimeError(f"Instant Meshes produced no output:\n{tail}")

        if progress:
            progress("reading the result", 0.98)
        Vo, faces, n_bad = read_obj(dst)
    finally:
        shutil.rmtree(work, ignore_errors=True)

    # Boundary alignment (-b) can blow up on models with many open holes and
    # non-manifold edges: Instant Meshes then writes non-finite vertices, and
    # dropping them takes whole regions with them. Measured on a character
    # whose head was an open shell: 94% of the head vanished with -b, 4%
    # without. So a run that comes back with non-finite vertices is done once
    # more without boundary alignment, and that result is used instead.
    if n_bad and align_boundaries:
        again = _remesh_once(V, face_verts, face_sizes,
                             target_faces=target_faces, target_edge=target_edge,
                             feature_angle=feature_angle,
                             smooth_iterations=smooth_iterations,
                             dominant=dominant, deterministic=deterministic,
                             align_boundaries=False, threads=threads, exe=exe,
                             timeout=timeout, progress=progress)
        again["log"]["retried_without_boundary_alignment"] = int(n_bad)
        return again

    if not faces:
        raise RuntimeError(
            "Instant Meshes returned nothing usable"
            + (f" ({n_bad} non-finite vertices)" if n_bad else ""))

    sizes = np.array([len(f) for f in faces]) if faces else np.zeros(0, int)
    log = {
        "backend": "instant-meshes",
        "binary": binary,
        "command": " ".join(cmd[1:]),
        "input": {"verts": int(len(V)), "faces": int(len(face_sizes))},
        "output": {
            "verts": int(len(Vo)),
            "faces": int(len(faces)),
            "quads": int((sizes == 4).sum()),
            "tris": int((sizes == 3).sum()),
            "ngons": int((sizes > 4).sum()),
            "quad_ratio": float((sizes == 4).mean()) if len(sizes) else 0.0,
        },
        "seconds": time.perf_counter() - t0,
        "dropped_nonfinite_verts": n_bad,
    }
    if progress:
        progress("done", 1.0)
    return {"V": Vo, "faces": faces, "log": log}
