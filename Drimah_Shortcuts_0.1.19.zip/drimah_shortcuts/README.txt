Drimah Shortcuts 0.1.8

- Começa sem menus; a pessoa cria os seus menus.
- Até 5 menus, com até 8 posições de atalho por menu.
- Cada menu e cada atalho podem ser recolhidos/expandidos.
- Ícones Lucide brancos; o círculo central usa a mesma cor de destaque do setor selecionado.
- Exportar/Importar gera e lê um arquivo JSON para transportar a configuração entre computadores.
- Salvar/Carregar mantém uma cópia local nas preferências do Blender.

Instalação: Blender > Edit > Preferences > Add-ons > Install from Disk e selecione este ZIP.

0.1.12: Added a per-shortcut name field and checkbox to show that name as a tooltip while hovering the radial menu.
