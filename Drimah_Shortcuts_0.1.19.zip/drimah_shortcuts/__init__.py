bl_info = {
    "name": "Drimah Shortcuts",
    "author": "Drimah Studio",
    "version": (0, 1, 18),
    "blender": (5, 2, 0),
    "location": "3D View > Sidebar > Drimah Shortcuts",
    "description": "Menus radiais personalizáveis com ícones Lucide e até cinco atalhos por menu",
    "category": "3D View",
}

import bpy, math, os, glob, re, json
import bpy.utils.previews
import gpu, blf
from bpy.props import (StringProperty, BoolProperty, IntProperty, EnumProperty,
                       CollectionProperty, PointerProperty)
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

ADDON_DIR = os.path.dirname(__file__)
ICON_DIR = os.path.join(ADDON_DIR, "icons")
_ICON_ITEMS = None
_IMAGE_CACHE = {}
_PREVIEWS = None
_DRAW_HANDLE = None
_KEYMAP_ITEMS = []

# User-level configuration file: persists independently of any .blend project.
def config_path():
    # Use Blender's user configuration directory, not the current .blend file.
    base = bpy.utils.user_resource('CONFIG', create=True)
    return os.path.join(base, 'drimah_shortcuts.json')

def settings_to_dict(settings):
    return {
        'active_menu': settings.active_menu,
        'radius': settings.radius,
        'icon_size': settings.icon_size,
        'label_size': settings.label_size,
        'menus': [{
            'name': m.name, 'expanded': m.expanded, 'key': m.key, 'shift': m.shift, 'ctrl': m.ctrl, 'alt': m.alt,
            'items': [{'label': it.label, 'show_label': it.show_label, 'icon': it.icon, 'action': it.action,
                       'shortcut': it.shortcut, 'detected_action': it.detected_action}
                      for it in list(m.items)[:8]]
        } for m in settings.menus]
    }

def save_settings_file(settings):
    path = config_path()
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(settings_to_dict(settings), f, ensure_ascii=False, indent=2)
    return path

def apply_settings_dict(settings, data):
    if not isinstance(data, dict) or not isinstance(data.get('menus', []), list):
        raise ValueError('Arquivo de configuração inválido.')
    settings.menus.clear()
    for md in data.get('menus', [])[:5]:
        if not isinstance(md, dict):
            continue
        m = settings.menus.add()
        m.name = md.get('name', 'Meu menu')
        m.expanded = bool(md.get('expanded', False))
        key = md.get('key', 'NONE')
        m.key = key if key in {k[0] for k in KEYS} else 'NONE'
        m.shift = bool(md.get('shift', False)); m.ctrl = bool(md.get('ctrl', False)); m.alt = bool(md.get('alt', False))
        for idata in md.get('items', [])[:8]:
            if not isinstance(idata, dict):
                continue
            it = m.items.add()
            it.label = idata.get('label', 'Atalho')
            it.show_label = bool(idata.get('show_label', False))
            icon_name = idata.get('icon', 'circle')
            if os.path.isfile(os.path.join(ICON_DIR, icon_name + '.png')): it.icon = icon_name
            action = idata.get('action', 'NONE')
            if action in {a[0] for a in ACTIONS}: it.action = action
            it.shortcut = idata.get('shortcut', '')
            it.detected_action = idata.get('detected_action', '')
    settings.active_menu = min(max(int(data.get('active_menu', 0)), 0), max(0, len(settings.menus)-1))
    settings.radius = min(200, max(110, int(data.get('radius', 155))))
    settings.icon_size = min(64, max(36, int(data.get('icon_size', 50))))
    settings.label_size = min(20, max(8, int(data.get('label_size', 12))))
    refresh_keymaps()
    tag_redraw_all()


def load_settings_file(settings):
    path = config_path()
    if not os.path.isfile(path):
        return False
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    apply_settings_dict(settings, data)
    return True

# Operators are deliberately chosen from a safe, useful Blender list.
ACTIONS = [
    ('NONE', 'None', 'No action assigned'),
    ('builtin.select_box', 'Select Box', 'Activate the box selection tool'),
    ('builtin.move', 'Move', 'Activate the move tool'),
    ('builtin.rotate', 'Rotate', 'Activate the rotate tool'),
    ('builtin.scale', 'Scale', 'Activate the scale tool'),
    ('builtin.transform', 'Transform', 'Activate the transform tool'),
    ('builtin.cursor', '3D Cursor', 'Activate the 3D cursor tool'),
    ('builtin.annotate', 'Annotate', 'Activate the annotation tool'),
    ('builtin.measure', 'Measure', 'Activate the measure tool'),
    ('builtin.extrude_region', 'Extrude Region', 'Activate the extrude tool'),
    ('builtin.inset_faces', 'Inset Faces', 'Activate the inset faces tool'),
    ('builtin.bevel', 'Bevel', 'Activate the bevel tool'),
    ('builtin.loop_cut', 'Loop Cut', 'Activate the loop cut tool'),
    ('builtin.poly_build', 'Poly Build', 'Activate the poly build tool'),
    ('builtin.rip_region', 'Rip Region', 'Activate the rip tool'),
    ('builtin.select_lasso', 'Select Lasso', 'Activate the lasso selection tool'),
    ('builtin.select_circle', 'Select Circle', 'Activate the circle selection tool'),
    ('object.duplicate_move', 'Object: Duplicate', 'Duplicate selected objects'),
    ('object.delete', 'Object: Delete', 'Delete selected objects'),
    ('object.join', 'Object: Join', 'Join selected objects'),
    ('object.shade_smooth', 'Object: Shade Smooth', 'Shade selected objects smooth'),
    ('object.shade_flat', 'Object: Shade Flat', 'Shade selected objects flat'),
    ('mesh.extrude_region_move', 'Mesh: Extrude Region', 'Extrude selected mesh geometry'),
    ('mesh.bevel', 'Mesh: Bevel', 'Bevel selected mesh geometry'),
    ('mesh.loopcut_slide', 'Mesh: Loop Cut and Slide', 'Create a loop cut'),
    ('mesh.subdivide', 'Mesh: Subdivide', 'Subdivide selected geometry'),
    ('mesh.merge', 'Mesh: Merge', 'Merge selected vertices'),
    ('mesh.dissolve_verts', 'Mesh: Dissolve Vertices', 'Dissolve selected vertices'),
    ('mesh.fill', 'Mesh: Fill', 'Create a face from selected vertices'),
]

KEYS = ([('NONE','Nenhuma','Sem atalho')]
        + [(k, k, 'Tecla '+k) for k in '0123456789']
        + [(k, k, 'Tecla '+k) for k in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ']
        + [(f'F{i}', f'F{i}', f'Tecla F{i}') for i in range(1, 13)]
        + [('MIDDLEMOUSE', 'Botão do meio do mouse', 'Clique no botão central do mouse'),
           ('LEFTMOUSE', 'Botão esquerdo do mouse', 'Clique no botão esquerdo do mouse'),
           ('RIGHTMOUSE', 'Botão direito do mouse', 'Clique no botão direito do mouse'),
           ('SPACE', 'Space', 'Barra de espaço'), ('TAB', 'Tab', 'Tecla Tab'),
           ('ACCENT_GRAVE', 'Acento grave', 'Tecla de acento grave')])

def icon_items(self, context):
    global _ICON_ITEMS, _PREVIEWS
    if _ICON_ITEMS is None:
        files = sorted(glob.glob(os.path.join(ICON_DIR, '*.png')))
        if _PREVIEWS is None:
            _PREVIEWS = bpy.utils.previews.new()
        items = []
        for index, path in enumerate(files):
            ident = os.path.splitext(os.path.basename(path))[0]
            try:
                preview = _PREVIEWS.load(ident, path, 'IMAGE')
                items.append((ident, ident.replace('-', ' ').title(), 'Lucide icon: ' + ident, preview.icon_id, index + 1))
            except Exception:
                items.append((ident, ident.replace('-', ' ').title(), 'Lucide icon: ' + ident))
        _ICON_ITEMS = items or [('circle', 'Circle', 'Default Lucide icon')]
    return _ICON_ITEMS

def parse_shortcut(value):
    """Parse common keyboard shortcut spellings such as Ctrl+R or Shift+F3."""
    if not value:
        return None
    parts = [p.strip().lower() for p in value.replace('-', '+').split('+') if p.strip()]
    mods = {'ctrl': False, 'shift': False, 'alt': False, 'oskey': False}
    key = None
    aliases = {
        'control': 'ctrl', 'ctl': 'ctrl', 'cmd': 'oskey', 'command': 'oskey',
        'win': 'oskey', 'super': 'oskey', 'return': 'RET', 'enter': 'RET',
        'esc': 'ESC', 'spacebar': 'SPACE', 'grave': 'ACCENT_GRAVE',
        'middle mouse': 'MIDDLEMOUSE', 'middlemouse': 'MIDDLEMOUSE',
        'left mouse': 'LEFTMOUSE', 'leftmouse': 'LEFTMOUSE',
        'right mouse': 'RIGHTMOUSE', 'rightmouse': 'RIGHTMOUSE',
        'backspace': 'BACK_SPACE', 'delete': 'DEL',
        'left': 'LEFT_ARROW', 'right': 'RIGHT_ARROW', 'up': 'UP_ARROW', 'down': 'DOWN_ARROW',
    }
    for part in parts:
        token = aliases.get(part, part)
        if token in mods:
            mods[token] = True
        else:
            key = token.upper()
    if not key:
        return None
    if len(key) == 1 and key.isalpha():
        pass
    elif key.isdigit():
        pass
    elif key.startswith('F') and key[1:].isdigit() and 1 <= int(key[1:]) <= 24:
        pass
    elif key in {
        'SPACE', 'TAB', 'RET', 'ESC', 'BACK_SPACE', 'DEL', 'ACCENT_GRAVE',
        'LEFT_ARROW', 'RIGHT_ARROW', 'UP_ARROW', 'DOWN_ARROW', 'MIDDLEMOUSE',
        'LEFTMOUSE', 'RIGHTMOUSE', 'NUMPAD_ENTER', 'PERIOD', 'COMMA', 'MINUS',
        'EQUAL', 'SLASH', 'BACK_SLASH', 'SEMI_COLON', 'QUOTE', 'LEFT_BRACKET',
        'RIGHT_BRACKET', 'HOME', 'END', 'PAGE_UP', 'PAGE_DOWN', 'INSERT',
    }:
        pass
    else:
        return None
    return key, mods


def _normalise_action_text(value):
    return re.sub(r'[^a-z0-9]+', '', (value or '').lower())


def find_action_for_shortcut(value):
    """Find action by shortcut (Ctrl+R) OR by an action/operator name.

    The text box intentionally accepts both forms, so users can type e.g.
    "Loop Cut", "mesh.loopcut_slide", or "Ctrl+R" and press Detect Action.
    """
    parsed = parse_shortcut(value)
    wm = bpy.context.window_manager
    configs = []
    if wm:
        keyconfigs = getattr(wm, 'keyconfigs', None)
        if keyconfigs:
            for name in ('user', 'active', 'default', 'addon'):
                try:
                    kc = getattr(keyconfigs, name, None)
                    if kc is not None and all(kc != old for old in configs):
                        configs.append(kc)
                except Exception:
                    pass

    # Shortcut mode: match the complete key + modifier combination in Blender keymaps.
    if parsed:
        key, mods = parsed
        matches, seen = [], set()
        for kc in configs:
            try:
                keymaps = kc.keymaps
            except Exception:
                continue
            for km in keymaps:
                for kmi in km.keymap_items:
                    try:
                        if kmi.type != key or kmi.value != 'PRESS':
                            continue
                        if (bool(kmi.ctrl) != mods['ctrl'] or bool(kmi.shift) != mods['shift']
                                or bool(kmi.alt) != mods['alt'] or bool(kmi.oskey) != mods['oskey']):
                            continue
                        ident = kmi.idname
                        sig = (ident, km.name)
                        if ident and sig not in seen:
                            seen.add(sig)
                            matches.append((ident, km.name))
                    except Exception:
                        continue
        # Helpful fallback for the standard Blender mesh loop-cut shortcut when the
        # active keyconfig does not expose keymap entries yet (e.g. during startup).
        if not matches and key == 'R' and mods['ctrl'] and not mods['shift'] and not mods['alt'] and not mods['oskey']:
            return [('mesh.loopcut_slide', 'Mesh')]
        return matches

    # Name mode: first search the built-in action names/ids, then all keymap operator names.
    query = _normalise_action_text(value)
    if not query:
        return []
    candidates = []
    for ident, label, description in ACTIONS:
        if ident == 'NONE':
            continue
        ident_n = _normalise_action_text(ident)
        label_n = _normalise_action_text(label)
        desc_n = _normalise_action_text(description)
        if query == ident_n or query == label_n:
            score = 0
        elif query in ident_n or query in label_n:
            score = 1
        elif query in desc_n:
            score = 2
        else:
            continue
        candidates.append((score, ident, label))
    candidates.sort(key=lambda x: (x[0], x[2].lower()))
    results, seen = [], set()
    for _, ident, label in candidates:
        if ident not in seen:
            seen.add(ident)
            results.append((ident, label))

    # Include operator names from the active Blender keymaps, including actions not
    # listed in the curated menu. Search both operator id and keymap display name.
    keymap_results = []
    for kc in configs:
        try:
            keymaps = kc.keymaps
        except Exception:
            continue
        for km in keymaps:
            for kmi in km.keymap_items:
                try:
                    ident = kmi.idname
                    display = getattr(kmi, 'name', '') or ident
                    ident_n = _normalise_action_text(ident)
                    display_n = _normalise_action_text(display)
                    if not ident:
                        continue
                    if query == ident_n or query == display_n:
                        score = 0
                    elif query in ident_n or query in display_n:
                        score = 1
                    else:
                        continue
                    keymap_results.append((score, ident, km.name))
                except Exception:
                    continue
    keymap_results.sort(key=lambda x: (x[0], x[1].lower(), x[2].lower()))
    for _, ident, km_name in keymap_results:
        sig = (ident, km_name)
        if sig not in seen:
            seen.add(sig)
            results.append((ident, km_name))
    return results

def ensure_image(icon_name):
    path = os.path.join(ICON_DIR, icon_name + '.png')
    if not os.path.isfile(path): return None
    img = _IMAGE_CACHE.get(path)
    if img is None:
        try:
            img = bpy.data.images.load(path, check_existing=False)
            # Lucide PNGs contain transparent backgrounds; keep alpha straight so
            # the center icon is not composited as an opaque white square.
            try:
                img.alpha_mode = 'STRAIGHT'
            except Exception:
                pass
            img.name = 'DrimahShortcuts_0_1_15_' + icon_name
            try:
                img.pack()
            except Exception:
                pass
            _IMAGE_CACHE[path] = img
        except Exception:
            return None
    try:
        return gpu.texture.from_image(img)
    except Exception:
        return None

def active_menu(context):
    settings = context.scene.drimah_shortcuts
    if not settings.menus:
        return None
    idx = min(max(settings.active_menu, 0), len(settings.menus)-1)
    return settings.menus[idx]

def refresh_keymaps():
    global _KEYMAP_ITEMS
    for km, kmi in _KEYMAP_ITEMS:
        try: km.keymap_items.remove(kmi)
        except Exception: pass
    _KEYMAP_ITEMS.clear()
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon if wm else None
    if not kc: return
    km = kc.keymaps.get('3D View') or kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    # A stable per-menu index is stored in the operator; all configured menus can have their own key.
    try:
        menus = bpy.context.scene.drimah_shortcuts.menus
        for i, menu in enumerate(menus):
            if menu.key == 'NONE': continue
            kmi = km.keymap_items.new('drimah.open_shortcut_menu', menu.key, 'PRESS',
                                      shift=menu.shift, ctrl=menu.ctrl, alt=menu.alt)
            kmi.properties.menu_index = i
            _KEYMAP_ITEMS.append((km, kmi))
    except Exception:
        pass

def tag_redraw_all():
    wm = bpy.context.window_manager
    if wm:
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D': area.tag_redraw()

class DRIMAH_ShortcutItem(bpy.types.PropertyGroup):
    expanded: BoolProperty(name='Expandir configurações', default=False)
    label: StringProperty(name='Nome do atalho', default='Atalho')
    show_label: BoolProperty(name='Show name tooltip', default=False, description='Show this shortcut name as a tooltip when hovered in the radial menu')
    icon: EnumProperty(name='Ícone Lucide', items=icon_items)
    action: EnumProperty(name='Blender Action', items=ACTIONS)
    shortcut: StringProperty(name='Shortcut', default='', description='Type a shortcut such as Ctrl+R or an action name such as Loop Cut, then click Detect Action')
    detected_action: StringProperty(name='Detected operator', default='')

class DRIMAH_ShortcutMenu(bpy.types.PropertyGroup):
    expanded: BoolProperty(name='Expandir menu', default=False)
    name: StringProperty(name='Nome do menu', default='Meu menu')
    key: EnumProperty(name='Tecla de abertura', items=KEYS, default='NONE', update=lambda s,c: refresh_keymaps())
    shift: BoolProperty(name='Shift', default=True, update=lambda s,c: refresh_keymaps())
    ctrl: BoolProperty(name='Ctrl', default=False, update=lambda s,c: refresh_keymaps())
    alt: BoolProperty(name='Alt', default=False, update=lambda s,c: refresh_keymaps())
    items: CollectionProperty(type=DRIMAH_ShortcutItem)

class DRIMAH_Settings(bpy.types.PropertyGroup):
    menus: CollectionProperty(type=DRIMAH_ShortcutMenu)
    active_menu: IntProperty(default=0, min=0)
    radius: IntProperty(name='Tamanho', default=155, min=110, max=200)
    icon_size: IntProperty(name='Tamanho dos ícones', default=50, min=36, max=64)
    label_size: IntProperty(name='Tamanho dos nomes', default=12, min=8, max=20)

class DRIMAH_OT_add_menu(bpy.types.Operator):
    bl_idname='drimah.add_shortcut_menu'; bl_label='Criar menu'; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        s=context.scene.drimah_shortcuts
        if len(s.menus)>=5:
            self.report({'WARNING'}, 'Limite de 5 menus atingido.'); return {'CANCELLED'}
        m=s.menus.add(); m.name='Menu '+str(len(s.menus)); m.expanded=True
        for i in range(8):
            it=m.items.add(); it.label='Atalho '+str(i+1); it.action='NONE'
            if i==0: it.icon='command'
        s.active_menu=len(s.menus)-1; refresh_keymaps(); return {'FINISHED'}

class DRIMAH_OT_remove_menu(bpy.types.Operator):
    bl_idname='drimah.remove_shortcut_menu'; bl_label='Excluir menu'; bl_options={'REGISTER','UNDO'}
    menu_index: IntProperty(default=-1)
    def execute(self, context):
        s=context.scene.drimah_shortcuts
        if not s.menus: return {'CANCELLED'}
        idx = self.menu_index if self.menu_index >= 0 else s.active_menu
        idx = min(max(idx, 0), len(s.menus)-1)
        s.menus.remove(idx)
        s.active_menu=max(0,min(s.active_menu,len(s.menus)-1))
        refresh_keymaps(); tag_redraw_all(); return {'FINISHED'}

class DRIMAH_OT_open_menu(bpy.types.Operator):
    bl_idname='drimah.open_shortcut_menu'; bl_label='Abrir Drimah Shortcuts'; bl_options={'REGISTER'}
    menu_index: IntProperty(default=-1)
    def invoke(self, context, event):
        global _DRAW_HANDLE
        if not context.area or context.area.type!='VIEW_3D':
            self.report({'WARNING'}, 'Abra o menu a partir da Viewport 3D.')
            return {'CANCELLED'}
        settings=context.scene.drimah_shortcuts
        if not settings.menus: return {'CANCELLED'}
        if self.menu_index>=0: settings.active_menu=min(self.menu_index,len(settings.menus)-1)
        self._region=next((r for r in context.area.regions if r.type=='WINDOW'),None)
        if self._region is None: return {'CANCELLED'}
        self._cx=self._region.width/2; self._cy=self._region.height/2
        self._hover=-1; self._dragging=False; self._drag_offset=(0.0, 0.0)
        self._context=context.copy(); self._context['area']=context.area
        self._handle=bpy.types.SpaceView3D.draw_handler_add(self.draw,(context,), 'WINDOW','POST_PIXEL')
        context.window_manager.modal_handler_add(self); context.area.tag_redraw(); return {'RUNNING_MODAL'}
    def draw(self, context):
        settings = context.scene.drimah_shortcuts
        menu = active_menu(context)
        if not menu:
            return
        cx, cy = self._cx, self._cy
        radius = float(settings.radius)
        inner = 52.0 * (radius / 155.0)
        icon_radius = 105.0 * (radius / 155.0)
        icon_size = float(settings.icon_size)
        slots = list(menu.items)[:8]
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('ALPHA')

        def poly(points, color):
            sh = gpu.shader.from_builtin('UNIFORM_COLOR')
            batch = batch_for_shader(sh, 'TRI_FAN', {'pos': points})
            sh.bind(); sh.uniform_float('color', color); batch.draw(sh)

        def circle(r, color, filled=True, width=1.5):
            pts = [(cx + math.cos(i * 2 * math.pi / 80) * r,
                    cy + math.sin(i * 2 * math.pi / 80) * r) for i in range(80)]
            if filled:
                poly([(cx, cy)] + pts + [pts[0]], color)
            else:
                sh = gpu.shader.from_builtin('UNIFORM_COLOR')
                gpu.state.line_width_set(width)
                batch = batch_for_shader(sh, 'LINE_STRIP', {'pos': pts + [pts[0]]})
                sh.bind(); sh.uniform_float('color', color); batch.draw(sh)
                gpu.state.line_width_set(1.0)

        def sector(r0, r1, a0, a1, color, steps=24):
            for j in range(steps):
                t0 = a0 + (a1-a0)*j/steps
                t1 = a0 + (a1-a0)*(j+1)/steps
                points = [(cx+math.cos(t0)*r0, cy+math.sin(t0)*r0),
                          (cx+math.cos(t0)*r1, cy+math.sin(t0)*r1),
                          (cx+math.cos(t1)*r1, cy+math.sin(t1)*r1),
                          (cx+math.cos(t1)*r0, cy+math.sin(t1)*r0)]
                poly(points, color)

        # Same graphite/silver radial construction as Drimah Pie Menu 1.3.5.
        circle(radius + 16, (0.04, 0.04, 0.05, 0.40))
        for i, item in enumerate(slots):
            mid = math.pi / 2 - i * (math.pi / 4)
            a0, a1 = mid - math.pi / 8 + 0.020, mid + math.pi / 8 - 0.020
            sector(inner, radius, a0, a1,
                   (0.25, 0.25, 0.27, 0.98) if i == self._hover else (0.10, 0.10, 0.11, 0.97))
            x = cx + math.cos(mid) * icon_radius
            y = cy + math.sin(mid) * icon_radius
            tex = ensure_image(item.icon)
            if tex:
                try:
                    gpu.state.blend_set('ALPHA')
                    shader_img = gpu.shader.from_builtin('IMAGE')
                    shader_img.bind(); shader_img.uniform_sampler('image', tex)
                    # Keep the eight peripheral icons clearly smaller than the center icon.
                    size = icon_size * 0.72
                    coords = [(x-size/2,y-size/2),(x+size/2,y-size/2),
                              (x+size/2,y+size/2),(x-size/2,y+size/2)]
                    batch = batch_for_shader(shader_img,'TRI_FAN',{'pos':coords,'texCoord':[(0,0),(1,0),(1,1),(0,1)]})
                    batch.draw(shader_img)
                    gpu.state.blend_set('ALPHA')
                    if i == self._hover and item.show_label and item.label.strip():
                        # Render the optional name outside the radial menu, along
                        # the sector direction; for the top sector this sits well
                        # above the icon. This never changes sector/icon geometry.
                        blf.size(0, int(settings.label_size))
                        blf.color(0, 1.0, 1.0, 1.0, 1.0)
                        text_width, text_height = blf.dimensions(0, item.label)
                        # Keep the label comfortably outside the circle, away from its rim.
                        label_distance = radius + 46.0
                        label_x = cx + math.cos(mid) * label_distance - text_width / 2
                        label_y = cy + math.sin(mid) * label_distance - text_height / 2
                        label_x = max(6, min(label_x, self._region.width - text_width - 6))
                        label_y = max(6, min(label_y, self._region.height - text_height - 6))
                        blf.position(0, label_x, label_y, 0)
                        blf.draw(0, item.label)
                except Exception:
                    pass
        center_color = (0.25, 0.25, 0.27, 0.98) if 0 <= self._hover < len(slots) else (0.07, 0.07, 0.08, 0.99)
        circle(inner, center_color)
        # The currently hovered action is represented by its icon in the center.
        if 0 <= self._hover < len(slots):
            tex = ensure_image(slots[self._hover].icon)
            if tex:
                try:
                    gpu.state.blend_set('ALPHA')
                    shader_img = gpu.shader.from_builtin('IMAGE')
                    shader_img.bind(); shader_img.uniform_sampler('image', tex)
                    size = max(icon_size * 1.22, 66.0 * (radius / 155.0))
                    coords = [(cx-size/2,cy-size/2),(cx+size/2,cy-size/2),
                              (cx+size/2,cy+size/2),(cx-size/2,cy+size/2)]
                    batch = batch_for_shader(shader_img,'TRI_FAN',{'pos':coords,'texCoord':[(0,0),(1,0),(1,1),(0,1)]})
                    batch.draw(shader_img)
                except Exception:
                    pass
        else:
            circle(4.0, (0.58, 0.58, 0.61, 0.95))
        gpu.state.blend_set('NONE')
        gpu.state.depth_mask_set(True)
        gpu.state.depth_test_set('LESS_EQUAL')
    def modal(self, context, event):
        # Escape explicitly closes the floating menu. Clicking elsewhere does not.
        if event.type == 'ESC' and event.value == 'PRESS':
            self.finish(context)
            return {'CANCELLED'}
        # Right-click is also an explicit close gesture.
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            self.finish(context)
            return {'CANCELLED'}

        mx = event.mouse_x - self._region.x
        my = event.mouse_y - self._region.y
        settings = context.scene.drimah_shortcuts
        radius = float(settings.radius)
        inner = 52.0 * (radius / 155.0)

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            dx, dy = mx - self._cx, my - self._cy
            # Drag by grabbing the center button. The menu remains visible
            # until the user explicitly closes it with Esc or right-click.
            if math.hypot(dx, dy) <= inner:
                self._dragging = True
                self._drag_offset = (dx, dy)
                return {'RUNNING_MODAL'}
            if self._hover >= 0:
                menu = active_menu(context)
                if menu and self._hover < len(menu.items):
                    item = menu.items[self._hover]
                    chosen = item.detected_action or item.action
                    if chosen and chosen != 'NONE':
                        self.run_action(context, chosen)
                # Deliberately keep the radial menu open after selecting an action.
                context.area.tag_redraw()
            # Clicks outside the radial are ignored rather than dismissing it.
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._dragging = False
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if getattr(self, '_dragging', False):
                self._cx = mx - self._drag_offset[0]
                self._cy = my - self._drag_offset[1]
                margin = radius + 18
                self._cx = max(margin, min(self._cx, self._region.width - margin))
                self._cy = max(margin, min(self._cy, self._region.height - margin))
                self._hover = -1
            else:
                dx, dy = mx - self._cx, my - self._cy
                if math.hypot(dx, dy) < inner:
                    self._hover = -1
                else:
                    a = math.atan2(dy, dx)
                    self._hover = int(round(((math.pi / 2 - a) % (2 * math.pi)) / (math.pi / 4))) % 8
            if context.area:
                context.area.tag_redraw()
        return {'RUNNING_MODAL'}
    def run_action(self,context,action):
        try:
            if action.startswith('builtin.'):
                bpy.ops.wm.tool_set_by_id(name=action)
            elif action=='object.duplicate_move': bpy.ops.object.duplicate_move('INVOKE_DEFAULT')
            elif action=='object.delete': bpy.ops.object.delete('INVOKE_DEFAULT')
            elif action=='object.join': bpy.ops.object.join()
            elif action=='object.shade_smooth': bpy.ops.object.shade_smooth()
            elif action=='object.shade_flat': bpy.ops.object.shade_flat()
            elif action.startswith('mesh.'):
                op=action.split('.',1)[1]; getattr(bpy.ops.mesh,op)('INVOKE_DEFAULT')
            else:
                # Execute an operator detected from Blender's keymap, using its idname.
                namespace, op_name = action.split('.', 1)
                operator = getattr(getattr(bpy.ops, namespace), op_name)
                operator('INVOKE_DEFAULT')
        except Exception as e: self.report({'WARNING'},'Operator unavailable in this context: '+str(e)[:100])
    def finish(self,context):
        try: bpy.types.SpaceView3D.draw_handler_remove(self._handle,'WINDOW')
        except Exception: pass
        if context.area: context.area.tag_redraw()
    def cancel(self,context): self.finish(context)

class DRIMAH_OT_detect_action(bpy.types.Operator):
    bl_idname = 'drimah.detect_shortcut_action'
    bl_label = 'Detect Action'
    bl_description = 'Type a shortcut (Ctrl+R) or action name (Loop Cut), then find it'
    item_index: IntProperty(default=0, min=0, max=7)
    menu_index: IntProperty(default=-1)
    def execute(self, context):
        settings = context.scene.drimah_shortcuts
        idx = self.menu_index if self.menu_index >= 0 else settings.active_menu
        if not settings.menus: return {'CANCELLED'}
        menu = settings.menus[min(max(idx, 0), len(settings.menus)-1)]
        if not menu or self.item_index >= len(menu.items): return {'CANCELLED'}
        item = menu.items[self.item_index]
        matches = find_action_for_shortcut(item.shortcut)
        if not matches:
            item.detected_action = ''
            self.report({'WARNING'}, 'No action found. Try Ctrl+R, Loop Cut, Extrude, or an operator id such as mesh.loopcut_slide.')
            return {'CANCELLED'}
        # Prefer an operator already present in the configured action list.
        ident, keymap_name = matches[0]
        item.detected_action = ident
        try:
            if ident in {a[0] for a in ACTIONS}: item.action = ident
        except Exception: pass
        if len(matches) > 1:
            self.report({'INFO'}, 'Found: ' + ident + ' (' + keymap_name + '); ' + str(len(matches)) + ' matches found.')
        else:
            self.report({'INFO'}, 'Found: ' + ident + ' (' + keymap_name + ')')
        return {'FINISHED'}

class DRIMAH_OT_save_config(bpy.types.Operator):
    bl_idname = 'drimah.save_shortcuts_config'
    bl_label = 'Save Drimah Shortcuts'
    bl_description = 'Save menus and shortcuts independently of a .blend file'
    def execute(self, context):
        try:
            path = save_settings_file(context.scene.drimah_shortcuts)
            self.report({'INFO'}, 'Drimah Shortcuts saved to user preferences.')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, 'Could not save configuration: ' + str(e)[:120])
            return {'CANCELLED'}

class DRIMAH_OT_load_config(bpy.types.Operator):
    bl_idname = 'drimah.load_shortcuts_config'
    bl_label = 'Load Drimah Shortcuts'
    bl_description = 'Load saved menus and shortcuts from user configuration'
    def execute(self, context):
        try:
            if not load_settings_file(context.scene.drimah_shortcuts):
                self.report({'WARNING'}, 'No saved Drimah Shortcuts configuration found yet.')
                return {'CANCELLED'}
            self.report({'INFO'}, 'Drimah Shortcuts configuration loaded.')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, 'Could not load configuration: ' + str(e)[:120])
            return {'CANCELLED'}

class DRIMAH_OT_export_config(bpy.types.Operator):
    bl_idname = 'drimah.export_shortcuts_config'
    bl_label = 'Exportar configuração'
    bl_description = 'Exporta menus e atalhos para usar em outro computador'
    filepath: StringProperty(subtype='FILE_PATH', default='Drimah_Shortcuts.json')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            path = bpy.path.ensure_ext(self.filepath, '.json')
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(settings_to_dict(context.scene.drimah_shortcuts), f, ensure_ascii=False, indent=2)
            self.report({'INFO'}, 'Configuração exportada: ' + os.path.basename(path))
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, 'Falha ao exportar: ' + str(e)[:120])
            return {'CANCELLED'}


class DRIMAH_OT_import_config(bpy.types.Operator):
    bl_idname = 'drimah.import_shortcuts_config'
    bl_label = 'Importar configuração'
    bl_description = 'Importa menus e atalhos exportados de outro computador'
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            apply_settings_dict(context.scene.drimah_shortcuts, data)
            self.report({'INFO'}, 'Configuração importada.')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, 'Falha ao importar: ' + str(e)[:120])
            return {'CANCELLED'}


class DRIMAH_PT_panel(bpy.types.Panel):
    bl_label='Drimah Shortcuts'
    bl_idname='DRIMAH_PT_shortcuts'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Drimah Shortcuts'

    def draw(self, context):
        layout = self.layout
        s = context.scene.drimah_shortcuts

        # Keep the original compact two-row layout: icon plus localized label.
        row = layout.row(align=True)
        row.operator('drimah.save_shortcuts_config', text='Salvar', icon='FILE_TICK')
        row.operator('drimah.load_shortcuts_config', text='Carregar', icon='FILE_REFRESH')

        row = layout.row(align=True)
        row.operator('drimah.export_shortcuts_config', text='Exportar', icon='EXPORT')
        row.operator('drimah.import_shortcuts_config', text='Importar', icon='IMPORT')

        row = layout.row(align=True)
        row.operator('drimah.add_shortcut_menu', icon='ADD', text='Novo menu')

        if not s.menus:
            layout.label(text='Crie um menu para começar.', icon='INFO')
            return

        # Display every configured menu independently. Adding a new menu must
        # never hide the previously-created menus from the panel.
        for menu_index, m in enumerate(s.menus):
            menu_box = layout.box()
            header = menu_box.row(align=True)
            icon = 'TRIA_DOWN' if m.expanded else 'TRIA_RIGHT'
            header.prop(m, 'expanded', text='Menu ' + str(menu_index + 1), icon=icon, emboss=False)
            delete = header.operator('drimah.remove_shortcut_menu', text='', icon='X')
            delete.menu_index = menu_index

            if not m.expanded:
                continue

            keybox = menu_box.box()
            keybox.label(text='Atalho para abrir o menu')
            keybox.prop(m, 'key', text='Tecla')
            mods = keybox.row(align=True)
            mods.prop(m, 'shift')
            mods.prop(m, 'ctrl')
            mods.prop(m, 'alt')

            while len(m.items) < 8:
                it = m.items.add()
                it.label = 'Atalho ' + str(len(m.items))
                it.action = 'NONE'

            keybox.label(text='8 posições de ícones')
            for i, it in enumerate(list(m.items)[:8]):
                row = keybox.row(align=True)
                icon = 'TRIA_DOWN' if it.expanded else 'TRIA_RIGHT'
                row.prop(it, 'expanded', text='Atalho ' + str(i + 1), icon=icon, emboss=False)
                if it.expanded:
                    itembox = keybox.box()
                    itembox.template_icon_view(it, 'icon', show_labels=False, scale=2, scale_popup=1.5)
                    itembox.prop(it, 'action', text='Ação')
                    name_row = itembox.row(align=True)
                    name_row.prop(it, 'label', text='')
                    name_row.prop(it, 'show_label', text='', icon='CHECKBOX_HLT' if it.show_label else 'CHECKBOX_DEHLT')
                    row = itembox.row(align=True)
                    row.prop(it, 'shortcut', text='Atalho / ação')
                    op = row.operator('drimah.detect_shortcut_action', text='Detectar', icon='VIEWZOOM')
                    op.item_index = i
                    op.menu_index = menu_index
                    if it.detected_action:
                        itembox.label(text='Ação identificada', icon='CHECKMARK')

            testrow = keybox.row(align=True)
            test = testrow.operator('drimah.open_shortcut_menu', text='Testar menu radial', icon='ORIENTATION_GIMBAL')
            test.menu_index = menu_index

        layout.separator()
        box = layout.box()
        box.label(text='Aparência do menu')
        box.prop(s, 'radius', text='Raio')
        box.prop(s, 'icon_size', text='Tamanho dos ícones')


CLASSES=(DRIMAH_ShortcutItem,DRIMAH_ShortcutMenu,DRIMAH_Settings,DRIMAH_OT_add_menu,DRIMAH_OT_remove_menu,DRIMAH_OT_open_menu,DRIMAH_OT_detect_action,DRIMAH_OT_save_config,DRIMAH_OT_load_config,DRIMAH_OT_export_config,DRIMAH_OT_import_config,DRIMAH_PT_panel)
def register():
    for cls in CLASSES: bpy.utils.register_class(cls)
    bpy.types.Scene.drimah_shortcuts=PointerProperty(type=DRIMAH_Settings)
    # Start with zero menus. The user creates menus explicitly or imports a backup.
    # Do not silently restore old auto-generated defaults from previous versions.
    refresh_keymaps()
def unregister():
    global _DRAW_HANDLE
    for km,kmi in _KEYMAP_ITEMS:
        try: km.keymap_items.remove(kmi)
        except Exception: pass
    _KEYMAP_ITEMS.clear()
    global _PREVIEWS
    if _PREVIEWS is not None:
        bpy.utils.previews.remove(_PREVIEWS); _PREVIEWS = None
    if hasattr(bpy.types.Scene,'drimah_shortcuts'): del bpy.types.Scene.drimah_shortcuts
    for cls in reversed(CLASSES): bpy.utils.unregister_class(cls)
if __name__=='__main__': register()
