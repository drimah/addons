# Drimah Quad Turbo - automatic area segmentation (core, no UI)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Method: Shape Diameter Function (thickness of the shape under each face, ray cast inside a cone)
# -> smoothed, log-normalized -> clustered in thickness levels -> border smoothing that prefers
# cutting along concave creases (ICM on the face graph) -> connected parts -> hierarchical merge
# of similar neighbours until the requested detail / area count is reached.

import heapq
import math
from collections import deque

import numpy as np

import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree

AREA_ATTR = "qt_area"
COLOR_ATTR = "QT_Areas"


# ------------------------------------------------------------------ mesh arrays
class Graph:
    """Face adjacency graph of a mesh, as numpy arrays."""

    def __init__(self, me, scale=(1.0, 1.0, 1.0)):
        nv, nf, nl, ne = len(me.vertices), len(me.polygons), len(me.loops), len(me.edges)
        co = np.empty(nv * 3, np.float64)
        me.vertices.foreach_get("co", co)
        self.co = co.reshape(-1, 3) * np.asarray(scale, np.float64)
        ls = np.empty(nf, np.int64)
        lt = np.empty(nf, np.int64)
        me.polygons.foreach_get("loop_start", ls)
        me.polygons.foreach_get("loop_total", lt)
        lv = np.empty(nl, np.int64)
        le = np.empty(nl, np.int64)
        me.loops.foreach_get("vertex_index", lv)
        me.loops.foreach_get("edge_index", le)
        ev = np.empty(ne * 2, np.int64)
        me.edges.foreach_get("vertices", ev)
        ev = ev.reshape(-1, 2)
        self.nf = nf
        self.loop_start, self.loop_total, self.loop_vert, self.loop_edge = ls, lt, lv, le
        self.edge_verts = ev
        loop_face = np.repeat(np.arange(nf), lt)
        self.loop_face = loop_face

        # face centers / normals / areas (fan triangulation, works for n-gons)
        c = np.zeros((nf, 3))
        np.add.at(c, loop_face, self.co[lv])
        c /= lt[:, None]
        nrm = np.zeros((nf, 3))
        nxt = np.arange(nl) + 1
        last = ls + lt - 1
        nxt[last] = ls
        a = self.co[lv] - c[loop_face]
        b = self.co[lv[nxt]] - c[loop_face]
        np.add.at(nrm, loop_face, np.cross(a, b))
        area = np.linalg.norm(nrm, axis=1) * 0.5
        nrm /= np.maximum(area[:, None] * 2.0, 1e-30)
        self.center, self.normal, self.area = c, nrm, area

        # adjacency pairs through shared edges
        order = np.argsort(le, kind="stable")
        es = le[order]
        fs = loop_face[order]
        same = es[1:] == es[:-1]
        fa = fs[:-1][same]
        fb = fs[1:][same]
        eid = es[:-1][same]
        ok = fa != fb
        self.fa, self.fb, self.eid = fa[ok], fb[ok], eid[ok]
        pa, pb = self.co[ev[self.eid, 0]], self.co[ev[self.eid, 1]]
        self.elen = np.linalg.norm(pa - pb, axis=1)
        # dihedral angle and concavity
        na, nb = nrm[self.fa], nrm[self.fb]
        cosang = np.clip((na * nb).sum(1), -1.0, 1.0)
        self.angle = np.arccos(cosang)
        d = c[self.fb] - c[self.fa]
        self.concave = (na * d).sum(1) > 1e-9 * (np.linalg.norm(d, axis=1) + 1e-30)
        self._csr = None

    def csr(self):
        """CSR neighbour lists (both directions): indptr, nbr, pair index."""
        if self._csr is None:
            src = np.concatenate([self.fa, self.fb])
            dst = np.concatenate([self.fb, self.fa])
            pid = np.concatenate([np.arange(len(self.fa))] * 2)
            o = np.argsort(src, kind="stable")
            indptr = np.zeros(self.nf + 1, np.int64)
            np.add.at(indptr, src + 1, 1)
            self._csr = (np.cumsum(indptr), dst[o], pid[o])
        return self._csr

    def diag(self):
        if len(self.co) == 0:
            return 1.0
        return float(max(np.linalg.norm(self.co.max(0) - self.co.min(0)), 1e-9))


# ------------------------------------------------------------------ SDF
def _cone_dirs(n_rays, half_angle):
    """Unit directions around +Z inside a cone (center ray + golden spiral)."""
    dirs = [(0.0, 0.0, 1.0)]
    ga = math.pi * (3.0 - math.sqrt(5.0))
    for i in range(1, n_rays):
        t = math.sqrt(i / (n_rays - 1)) * half_angle
        ph = i * ga
        dirs.append((math.sin(t) * math.cos(ph), math.sin(t) * math.sin(ph), math.cos(t)))
    return np.asarray(dirs)


def shape_diameter(g, n_rays=12, half_angle=math.radians(60)):
    """Shape Diameter Function per face (NaN where no valid hit)."""
    verts = [tuple(v) for v in g.co]
    polys = [g.loop_vert[s:s + t].tolist() for s, t in zip(g.loop_start, g.loop_total)]
    bvh = BVHTree.FromPolygons(verts, polys, all_triangles=False, epsilon=0.0)
    diag = g.diag()
    eps = diag * 1e-5
    local = _cone_dirs(n_rays, half_angle)
    # frames: z = -normal (inside)
    z = -g.normal
    helper = np.where(np.abs(z[:, 0:1]) < 0.9, [[1.0, 0.0, 0.0]], [[0.0, 1.0, 0.0]])
    x = np.cross(helper, z)
    x /= np.maximum(np.linalg.norm(x, axis=1, keepdims=True), 1e-30)
    y = np.cross(z, x)
    weights = local[:, 2]  # cos to the axis
    out = np.full(g.nf, np.nan)
    ray = bvh.ray_cast
    for f in range(g.nf):
        if g.area[f] <= 0.0:
            continue
        o = Vector(g.center[f] + z[f] * eps)
        xf, yf, zf = x[f], y[f], z[f]
        ds = []
        ws = []
        for k in range(n_rays):
            lx, ly, lz = local[k]
            d = xf * lx + yf * ly + zf * lz
            dv = Vector(d)
            loc, nrm, idx, dist = ray(o, dv, diag)
            if loc is None or idx == f:
                continue
            if nrm.dot(dv) <= 0.0:  # hit a front face: not the opposite side of the shape
                continue
            ds.append(dist)
            ws.append(weights[k])
        if ds:
            ds = np.asarray(ds)
            ws = np.asarray(ws)
            med = np.median(ds)
            sd = ds.std()
            keep = np.abs(ds - med) <= max(sd, 1e-12)
            out[f] = float((ds[keep] * ws[keep]).sum() / ws[keep].sum())
    return out


def _fill_nan(g, val, iters=50):
    indptr, nbr, _ = g.csr()
    v = val.copy()
    for _ in range(iters):
        bad = np.isnan(v)
        if not bad.any():
            break
        src = np.repeat(np.arange(g.nf), np.diff(indptr))
        nv = v[nbr]
        good = ~np.isnan(nv)
        s = np.zeros(g.nf)
        c = np.zeros(g.nf)
        np.add.at(s, src[good], nv[good])
        np.add.at(c, src[good], 1)
        fill = bad & (c > 0)
        v[fill] = s[fill] / c[fill]
    v[np.isnan(v)] = np.nanmedian(v) if np.isfinite(v).any() else 1.0
    return v


def _edge_weight(g):
    """Smoothness weight per adjacency: low on concave creases (good place to cut)."""
    eff = np.where(g.concave, g.angle, g.angle * 0.08)
    lnorm = g.elen / max(float(np.mean(g.elen)), 1e-30)
    return lnorm * np.exp(-eff / 0.30)


def _smooth(g, val, w, iters):
    for _ in range(iters):
        s = val * 1.0
        c = np.ones(g.nf)
        np.add.at(s, g.fa, val[g.fb] * w)
        np.add.at(s, g.fb, val[g.fa] * w)
        np.add.at(c, g.fa, w)
        np.add.at(c, g.fb, w)
        val = s / c
    return val


def normalized_sdf(g, raw):
    v = _fill_nan(g, raw)
    w = _edge_weight(g)
    v = _smooth(g, v, w, 6)
    # thickness relative to the typical thickness of the model (scale invariant, keeps real contrast:
    # an arm 4x thinner than the torso is ~1.4 apart, a cube corner vs its center only ~0.5)
    med = float(np.median(v[v > 0])) if (v > 0).any() else 1.0
    return np.clip(np.log(np.maximum(v, med * 1e-3) / med), -3.0, 3.0)


# ------------------------------------------------------------------ labeling
def _kmeans_1d(x, k, iters=30):
    mu = np.quantile(x, (np.arange(k) + 0.5) / k)
    for _ in range(iters):
        lab = np.argmin(np.abs(x[:, None] - mu[None, :]), axis=1)
        for j in range(k):
            m = lab == j
            if m.any():
                mu[j] = x[m].mean()
    return mu


def icm_levels(g, x, k, smooth):
    mu = _kmeans_1d(x, k)
    lab = np.argmin(np.abs(x[:, None] - mu[None, :]), axis=1)
    sig = np.array([max(x[lab == j].std() if (lab == j).any() else 0.05, 0.02) for j in range(k)])
    pri = np.array([max((lab == j).mean(), 1e-3) for j in range(k)])
    data = (x[:, None] - mu[None, :]) ** 2 / (2 * sig[None, :] ** 2) + np.log(sig)[None, :] - np.log(pri)[None, :]
    w = _edge_weight(g) * smooth
    wsum = np.zeros(g.nf)
    np.add.at(wsum, g.fa, w)
    np.add.at(wsum, g.fb, w)
    for _ in range(12):
        same = np.zeros((g.nf, k))
        np.add.at(same, (g.fa, lab[g.fb]), w)
        np.add.at(same, (g.fb, lab[g.fa]), w)
        cost = data + (wsum[:, None] - same)
        new = np.argmin(cost, axis=1)
        if (new == lab).all():
            break
        lab = new
    return lab


def components(g, lab, barrier):
    """Connected parts with the same level label; never crosses barrier pairs."""
    indptr, nbr, pid = g.csr()
    comp = np.full(g.nf, -1, np.int64)
    blocked = barrier[pid] | (lab[nbr] != np.repeat(lab, np.diff(indptr)))
    allowed_nbr = np.where(blocked, -1, nbr)
    n = 0
    for s in range(g.nf):
        if comp[s] >= 0:
            continue
        comp[s] = n
        dq = deque([s])
        while dq:
            f = dq.popleft()
            for t in allowed_nbr[indptr[f]:indptr[f + 1]]:
                if t >= 0 and comp[t] < 0:
                    comp[t] = n
                    dq.append(t)
        n += 1
    return comp, n


class _Regions:
    def __init__(self, g, comp, n, x, barrier):
        self.g = g
        self.parent = list(range(n))
        self.area = np.bincount(comp, weights=g.area, minlength=n).astype(float)
        self.sx = np.bincount(comp, weights=g.area * x, minlength=n).astype(float)
        self.alive = set(range(n))
        ra, rb = comp[g.fa], comp[g.fb]
        m = ra != rb
        ra, rb = np.minimum(ra[m], rb[m]), np.maximum(ra[m], rb[m])
        q = np.where(g.concave[m], np.clip(g.angle[m] / math.radians(50), 0, 1), 0.0)
        L = g.elen[m]
        sharp = barrier[m]
        self.nb = [dict() for _ in range(n)]  # nb[a][b] = [len, concave_len, sharp_len]
        key = ra * n + rb
        uk, inv = np.unique(key, return_inverse=True)
        sl = np.bincount(inv, weights=L)
        sc = np.bincount(inv, weights=L * q)
        ss = np.bincount(inv, weights=L * sharp)
        for k, a, b, c, s in zip(uk, sl, sc, ss, range(len(uk))):
            i, j = int(k // n), int(k % n)
            self.nb[i][j] = [a, b, c]
            self.nb[j][i] = [a, b, c]
        self.total = float(self.area.sum())

    def mean(self, r):
        return self.sx[r] / max(self.area[r], 1e-30)

    def merge(self, a, b):
        """Merge b into a."""
        self.area[a] += self.area[b]
        self.sx[a] += self.sx[b]
        self.parent[b] = a
        self.alive.discard(b)
        for c, v in self.nb[b].items():
            if c == a:
                continue
            cur = self.nb[a].get(c)
            if cur is None:
                cur = [0.0, 0.0, 0.0]
                self.nb[a][c] = cur
                self.nb[c][a] = cur
            else:
                pass
            cur[0] += v[0]
            cur[1] += v[1]
            cur[2] += v[2]
            self.nb[c][a] = cur
            del self.nb[c][b]
        self.nb[a].pop(b, None)
        self.nb[b] = {}

    def find(self, r):
        while self.parent[r] != r:
            self.parent[r] = self.parent[self.parent[r]]
            r = self.parent[r]
        return r

    def cost(self, a, b, use_sharp):
        L, C, S = self.nb[a][b]
        d = abs(self.mean(a) - self.mean(b))
        conc = C / max(L, 1e-30)
        # thickness changes count fully only where the border is a concave crease (minima rule):
        # smooth convex variations (cube corners, tapering limbs) merge easily
        c = d * (0.12 + 1.8 * min(conc, 1.0)) + 0.25 * conc
        if use_sharp:
            c += 4.0 * (S / max(L, 1e-30))
        # tiny regions are cheap to merge, big ones expensive
        frac = min(self.area[a], self.area[b]) / self.total
        c *= min(1.0, (frac / 0.02) ** 0.35)
        return c

    def absorb_tiny(self, min_frac, use_sharp):
        changed = True
        while changed:
            changed = False
            for r in sorted(self.alive, key=lambda r: self.area[r]):
                if r not in self.alive or self.area[r] >= min_frac * self.total or not self.nb[r]:
                    continue
                # longest border, but avoid crossing sharp borders if possible
                best = max(self.nb[r].items(),
                           key=lambda kv: kv[1][0] - (kv[1][2] * 0.9 if use_sharp else 0.0))[0]
                big, small = (best, r) if self.area[best] >= self.area[r] else (r, best)
                self.merge(big, small)
                changed = True

    def merge_until(self, threshold, target, use_sharp):
        heap = []
        stamp = {}

        def push(a, b):
            if a > b:
                a, b = b, a
            heapq.heappush(heap, (self.cost(a, b, use_sharp), a, b, stamp.get(a, 0), stamp.get(b, 0)))

        for a in self.alive:
            for b in self.nb[a]:
                if a < b:
                    push(a, b)
        while heap and len(self.alive) > 1:
            c, a, b, sa, sb = heapq.heappop(heap)
            if a not in self.alive or b not in self.alive or stamp.get(a, 0) != sa or stamp.get(b, 0) != sb:
                continue
            if b not in self.nb[a]:
                continue
            if target > 0:
                if len(self.alive) <= target:
                    break
            elif c > threshold:
                break
            big, small = (a, b) if self.area[a] >= self.area[b] else (b, a)
            self.merge(big, small)
            stamp[big] = stamp.get(big, 0) + 1
            for o in list(self.nb[big]):
                stamp[o] = stamp.get(o, 0)
                push(big, o)

    def labels(self, comp):
        root = np.array([self.find(r) for r in range(len(self.parent))])
        lab = root[comp]
        u, lab = np.unique(lab, return_inverse=True)
        return lab


def _geodesic_split(g, lab, region):
    """Split one region in two with a 2-seed geodesic Voronoi (graph distances)."""
    indptr, nbr, pid = g.csr()
    faces = np.nonzero(lab == region)[0]
    if len(faces) < 8:
        return lab, False
    inside = lab == region
    dlen = np.linalg.norm(g.center[g.fa] - g.center[g.fb], axis=1)

    def dijkstra(seeds):
        dist = {s: 0.0 for s in seeds}
        h = [(0.0, s) for s in seeds]
        while h:
            d, f = heapq.heappop(h)
            if d > dist.get(f, 1e300):
                continue
            for j in range(indptr[f], indptr[f + 1]):
                t = nbr[j]
                if not inside[t]:
                    continue
                nd = d + dlen[pid[j]]
                if nd < dist.get(t, 1e300):
                    dist[t] = nd
                    heapq.heappush(h, (nd, t))
        return dist

    d0 = dijkstra([int(faces[0])])
    a = max(d0, key=d0.get)
    da = dijkstra([a])
    b = max(da, key=da.get)
    db = dijkstra([b])
    side_b = np.array([db.get(int(f), 1e300) < da.get(int(f), 1e300) for f in faces])
    if side_b.all() or (~side_b).all():
        return lab, False
    new = lab.copy()
    new[faces[side_b]] = lab.max() + 1
    return new, True


def segment(g, detail=5, target=0, split_sharp=False, sharp_angle=math.radians(40),
            smooth=1.0, n_rays=12, progress=None):
    """Return an area label per face (0..R-1, sorted by size, biggest first)."""
    raw = shape_diameter(g, n_rays=n_rays)
    if progress:
        progress(0.6)
    x = normalized_sdf(g, raw)
    barrier = (g.angle >= sharp_angle) if split_sharp else np.zeros(len(g.fa), bool)
    k = int(np.clip(2 + detail // 2, 2, 8))
    lev = icm_levels(g, x, k, smooth * 1.6)
    comp, n = components(g, lev, barrier)
    regs = _Regions(g, comp, n, x, barrier)
    regs.absorb_tiny(0.0015 + 0.004 * (10 - detail) / 9.0, split_sharp)
    thr = 0.32 * (0.09 / 0.32) ** ((detail - 1) / 9.0)  # detail 1 -> 0.32, 10 -> 0.09
    regs.merge_until(thr, target, split_sharp)
    lab = regs.labels(comp)
    if target > 0:
        tries = 0
        while lab.max() + 1 < target and tries < target * 2:
            areas = np.bincount(lab, weights=g.area)
            lab, ok = _geodesic_split(g, lab, int(np.argmax(areas)))
            tries += 1
            if not ok:
                break
    return sort_by_area(lab, g.area)


def sort_by_area(lab, area):
    u, lab = np.unique(lab, return_inverse=True)
    a = np.bincount(lab, weights=area)
    order = np.argsort(-a)
    remap = np.empty_like(order)
    remap[order] = np.arange(len(order))
    return remap[lab]


def majority_filter(g, lab, iters=2):
    """Remove jagged single faces along borders (vote of the neighbours)."""
    indptr, nbr, _ = g.csr()
    deg = np.diff(indptr)
    maxd = int(min(deg.max() if len(deg) else 0, 8))
    if maxd == 0:
        return lab
    pad = np.full((g.nf, maxd), -1, np.int64)
    rows = np.repeat(np.arange(g.nf), deg)
    pos = np.arange(len(nbr)) - np.repeat(indptr[:-1], deg)
    keep = pos < maxd
    for _ in range(iters):
        pad[:] = -1
        pad[rows[keep], pos[keep]] = lab[nbr[keep]]
        best = lab.copy()
        bestc = (pad == lab[:, None]).sum(1)
        for j in range(maxd):
            cj = (pad == pad[:, j:j + 1]).sum(1)
            better = (pad[:, j] >= 0) & (cj > bestc) & (cj * 2 > np.minimum(deg, maxd))
            best[better] = pad[better, j]
            bestc[better] = cj[better]
        if (best == lab).all():
            break
        lab = best
    return lab


def clean_islands(g, lab, passes=4):
    """Each area must be one connected piece: loose fragments join the neighbour area
    they share the longest border with."""
    lab = np.asarray(lab, np.int64).copy()
    nobar = np.zeros(len(g.fa), bool)
    for _ in range(passes):
        comp, n = components(g, lab, nobar)
        if n == lab.max() + 1:
            break
        carea = np.bincount(comp, weights=g.area, minlength=n)
        clab = np.zeros(n, np.int64)
        clab[comp] = lab
        best = {}
        for c in range(n):
            l = clab[c]
            if l not in best or carea[c] > carea[best[l]]:
                best[l] = c
        keep = np.zeros(n, bool)
        keep[list(best.values())] = True
        if keep.all():
            break
        ca, cb = comp[g.fa], comp[g.fb]
        m = ca != cb
        border = {}
        for a, b, L in zip(ca[m], cb[m], g.elen[m]):
            for x, y in ((a, b), (b, a)):
                if not keep[x]:
                    d = border.setdefault(x, {})
                    d[clab[y]] = d.get(clab[y], 0.0) + L
        newl = clab.copy()
        for c, d in border.items():
            d.pop(clab[c], None)
            if d:
                newl[c] = max(d, key=d.get)
        lab = newl[comp]
    return lab


# ------------------------------------------------------------------ helpers on Blender data
def area_colors(n):
    out = []
    for i in range(n):
        h = (i * 0.618033988749895) % 1.0
        s = 0.55 + 0.35 * ((i * 7) % 3) / 2.0
        v = 0.95 - 0.2 * ((i * 5) % 2)
        out.append(_hsv(h, s, v))
    return np.asarray(out)


def _hsv(h, s, v):
    i = int(h * 6.0) % 6
    f = h * 6.0 - int(h * 6.0)
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    return [(v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q)][i]


def read_labels(me):
    a = me.attributes.get(AREA_ATTR)
    if a is None or a.domain != 'FACE' or a.data_type != 'INT':
        return None
    n = len(a.data)
    if n == 0 or n != len(me.polygons):  # Edit Mode: data lives in the edit mesh
        return None
    lab = np.empty(n, np.int32)
    a.data.foreach_get("value", lab)
    return lab


def write_labels(me, lab):
    a = me.attributes.get(AREA_ATTR)
    if a is not None and (a.domain != 'FACE' or a.data_type != 'INT'):
        me.attributes.remove(a)
        a = None
    if a is None:
        a = me.attributes.new(AREA_ATTR, 'INT', 'FACE')
    a.data.foreach_set("value", np.asarray(lab, np.int32))
    me["qt_area_count"] = int(np.max(lab)) + 1 if len(lab) else 0
    write_colors(me, lab)


def write_colors(me, lab):
    ca = me.color_attributes.get(COLOR_ATTR)
    if ca is not None and (ca.domain != 'CORNER' or ca.data_type != 'BYTE_COLOR'):
        me.color_attributes.remove(ca)
        ca = None
    if ca is None:
        ca = me.color_attributes.new(COLOR_ATTR, 'BYTE_COLOR', 'CORNER')
    n = int(lab.max()) + 1 if len(lab) else 1
    cols = area_colors(n)
    lt = np.empty(len(me.polygons), np.int64)
    me.polygons.foreach_get("loop_total", lt)
    lf = np.repeat(np.asarray(lab), lt)
    rgba = np.ones((len(lf), 4), np.float32)
    rgba[:, :3] = cols[lf]
    ca.data.foreach_set("color", rgba.ravel())
    try:
        me.color_attributes.active_color = ca
    except Exception:
        pass
    me.update()


def clear_labels(me):
    for coll, name in ((me.attributes, AREA_ATTR), (me.color_attributes, COLOR_ATTR)):
        a = coll.get(name)
        if a is not None:
            coll.remove(a)
    if "qt_area_count" in me:
        del me["qt_area_count"]
    me.update()


def write_face_sets(me, lab):
    a = me.attributes.get(".sculpt_face_set")
    if a is None:
        a = me.attributes.new(".sculpt_face_set", 'INT', 'FACE')
    a.data.foreach_set("value", (np.asarray(lab) + 1).astype(np.int32))


def border_edges(g, lab):
    """Edge indices between faces of different areas."""
    m = lab[g.fa] != lab[g.fb]
    return np.unique(g.eid[m])


def set_seams(me, edge_idx, clear=True):
    ne = len(me.edges)
    s = np.zeros(ne, bool)
    if not clear:
        me.edges.foreach_get("use_seam", s)
    s[edge_idx] = True
    me.edges.foreach_set("use_seam", s)
    me.update()


# ------------------------------------------------------------------ disk cuts for UV
def disk_cuts(me, lab):
    """Extra seam edges so that every area becomes a topological disk (tubes and closed shells
    are cut along a shortest path), which gives clean UV islands."""
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    flab = np.asarray(lab)
    extra = set()
    _guard_long = {}
    for r in range(int(flab.max()) + 1 if len(flab) else 0):
        faces = [bm.faces[i] for i in np.nonzero(flab == r)[0]]
        if not faces:
            continue
        fset = set(faces)
        for _guard in range(4):
            edges = {e for f in faces for e in f.edges}
            verts = {v for e in edges for v in e.verts}

            def is_bound(e):
                if e.index in extra:
                    return True
                lf = [f for f in e.link_faces if f in fset]
                return len(lf) < 2 or len(lf) != len(e.link_faces)
            bnd = {e for e in edges if is_bound(e)}
            # boundary loops (vertex connectivity of boundary edges)
            loops = []
            left = set(bnd)
            while left:
                e0 = left.pop()
                comp = {e0}
                st = [e0]
                while st:
                    e = st.pop()
                    for v in e.verts:
                        for e2 in v.link_edges:
                            if e2 in left:
                                left.discard(e2)
                                comp.add(e2)
                                st.append(e2)
                loops.append(comp)
            # euler characteristic of the region with cuts counted as boundary (approximation)
            chi = len(verts) - len(edges) + len(faces)
            if len(loops) == 1 and chi >= 1:
                if not _guard_long.get(r):
                    _guard_long[r] = True
                    cut = _elongation_cut(loops[0], verts, {e for e in edges if e not in bnd})
                    if cut:
                        extra.update(e.index for e in cut)
                break
            if len(loops) == 1 and chi < 1:
                break  # genus > 0: leave it, the unwrapper still works (with distortion)
            interior = {e for e in edges if e not in bnd}
            if len(loops) >= 2:
                srcv = {v for e in loops[0] for v in e.verts}
                dstv = {v for lp in loops[1:] for e in lp for v in e.verts}
            else:  # closed shell: cut from one vertex to the farthest one
                v0 = next(iter(verts))
                far = max(verts, key=lambda v: (v.co - v0.co).length)
                srcv = {v0}
                dstv = {far}
            path = _vert_path(srcv, dstv, interior)
            if not path:
                break
            extra.update(e.index for e in path)
    bm.free()
    return sorted(extra)


def _elongation_cut(loop, verts, interior):
    """Long areas (limbs, head, tubes with a cap) unwrap much better opened along their length:
    cut from the border to the farthest point when the area is much longer than wide."""
    perim = sum(e.calc_length() for e in loop)
    if perim <= 0.0:
        return []
    srcv = {v for e in loop for v in e.verts}
    dist = {v: 0.0 for v in srcv}
    h = [(0.0, id(v), v) for v in srcv]
    heapq.heapify(h)
    while h:
        d, _i, v = heapq.heappop(h)
        if d > dist.get(v, 1e300):
            continue
        for e in v.link_edges:
            if e not in interior:
                continue
            o = e.other_vert(v)
            nd = d + e.calc_length()
            if nd < dist.get(o, 1e300):
                dist[o] = nd
                heapq.heappush(h, (nd, id(o), o))
    far = max(dist, key=dist.get)
    if dist[far] / (perim / (2.0 * math.pi)) < 1.8:
        return []
    return _vert_path(srcv, {far}, interior)


def _vert_path(srcv, dstv, allowed):
    dist = {v: 0.0 for v in srcv}
    prev = {}
    h = [(0.0, id(v), v) for v in srcv]
    heapq.heapify(h)
    goal = None
    while h:
        d, _i, v = heapq.heappop(h)
        if d > dist.get(v, 1e300):
            continue
        if v in dstv and v not in srcv:
            goal = v
            break
        for e in v.link_edges:
            if e not in allowed:
                continue
            o = e.other_vert(v)
            nd = d + e.calc_length()
            if nd < dist.get(o, 1e300):
                dist[o] = nd
                prev[o] = (v, e)
                heapq.heappush(h, (nd, id(o), o))
    if goal is None:
        return []
    out = []
    v = goal
    while v in prev:
        v, e = prev[v]
        out.append(e)
    return out
