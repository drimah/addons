# Drimah Quad Turbo - Areas module
# Automatic split of the mesh into areas (head, arms, legs, flat panels...) like Nitro-style patches,
# but without drawing anything. Areas drive the quad result: seams, UV islands and face sets.
# SPDX-License-Identifier: GPL-3.0-or-later

import math
import time

import numpy as np

import bpy
import bmesh
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from mathutils.bvhtree import BVHTree

from . import areas_core as core
from . import util

QUALITY = {'FAST': 10000, 'NORMAL': 25000, 'HIGH': 60000}


class DQT_AreasSettings(bpy.types.PropertyGroup):
    detail: IntProperty(name="Detail", default=5, min=1, max=10,
                        description="Automatic mode: low = few big areas, high = more and smaller areas")
    area_count: IntProperty(name="Area Count", default=0, min=0, max=200,
                            description="0 = Automatic (uses Detail). Any other value forces that number of areas")
    split_sharp: BoolProperty(name="Split at Sharp Edges", default=False,
                              description="Hard surface: also cut the areas along sharp edges")
    sharp_angle: FloatProperty(name="Sharp Angle", default=math.radians(40), min=math.radians(5),
                               max=math.radians(120), subtype='ANGLE',
                               description="Edges bent more than this are sharp")
    smoothness: FloatProperty(name="Border Smoothness", default=1.0, min=0.0, max=3.0,
                              description="Higher = cleaner, rounder borders between areas")
    quality: EnumProperty(
        name="Analysis Quality",
        items=(('FAST', "Fast", "Analyse a 10k face copy"),
               ('NORMAL', "Normal", "Analyse a 25k face copy"),
               ('HIGH', "High", "Analyse a 60k face copy (slower)")),
        default='NORMAL')
    gen_seams: BoolProperty(name="Seams on Borders", default=True,
                            description="Mark UV seams on the borders between areas of the quad result")
    gen_uv: BoolProperty(name="Unwrap UVs", default=True,
                         description="Unwrap the result: one UV island per area")
    gen_face_sets: BoolProperty(name="Face Sets", default=True,
                                description="One Face Set per area on the result")
    fill_holes: BoolProperty(name="Fill Holes", default=False,
                             description="Separate Areas: close the open borders of each part")


# ------------------------------------------------------------------ helpers
def _mesh_obj(context):
    o = context.active_object
    return o if o is not None and o.type == 'MESH' else None


def _scale(o):
    s = o.matrix_world.to_scale()
    return (abs(s.x) or 1.0, abs(s.y) or 1.0, abs(s.z) or 1.0)


def _to_object_mode(o):
    was_edit = o.mode == 'EDIT'
    if o.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    return was_edit


def _proxy_mesh(context, o, target):
    """Light copy of the base mesh for the analysis (Decimate), or None when not needed."""
    nf = len(o.data.polygons)
    if nf <= target * 1.2:
        return None
    tmp = bpy.data.objects.new("_dqt_areas_tmp", o.data)
    context.scene.collection.objects.link(tmp)
    try:
        m = tmp.modifiers.new("dec", 'DECIMATE')
        m.ratio = max(target / nf, 0.0005)
        dg = context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg), depsgraph=dg)
    finally:
        bpy.data.objects.remove(tmp)
    return me


def _bvh_from_graph(g):
    verts = [tuple(v) for v in g.co]
    polys = [g.loop_vert[s:s + t].tolist() for s, t in zip(g.loop_start, g.loop_total)]
    return BVHTree.FromPolygons(verts, polys, all_triangles=False)


def _transfer(bvh, src_lab, centers):
    out = np.zeros(len(centers), np.int64)
    fn = bvh.find_nearest
    for i, c in enumerate(centers):
        hit = fn(c)
        if hit[2] is not None:
            out[i] = src_lab[hit[2]]
    return out


def analyze_object(context, o, p):
    me = o.data
    sc = _scale(o)
    g_full = core.Graph(me, sc)
    proxy = _proxy_mesh(context, o, QUALITY[p.quality])
    try:
        g = core.Graph(proxy, sc) if proxy is not None else g_full
        lab = core.segment(g, detail=p.detail, target=p.area_count, split_sharp=p.split_sharp,
                           sharp_angle=p.sharp_angle, smooth=p.smoothness)
        if proxy is not None:
            lab = _transfer(_bvh_from_graph(g), lab, g_full.center)
            lab = core.majority_filter(g_full, lab, 3)
        lab = core.clean_islands(g_full, lab)
        lab = core.sort_by_area(lab, g_full.area)
    finally:
        if proxy is not None:
            bpy.data.meshes.remove(proxy)
    core.write_labels(me, lab)
    return int(lab.max()) + 1


def show_colors(context, on=True):
    for win in context.window_manager.windows:
        for area in win.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for sp in area.spaces:
                if sp.type == 'VIEW_3D':
                    if on:
                        if sp.shading.type not in ('SOLID',):
                            sp.shading.type = 'SOLID'
                        sp.shading.color_type = 'VERTEX'
                    else:
                        sp.shading.color_type = 'MATERIAL'
            area.tag_redraw()


def colors_shown(context):
    sp = context.space_data
    return sp is not None and sp.type == 'VIEW_3D' and sp.shading.type == 'SOLID' \
        and sp.shading.color_type == 'VERTEX'


# ------------------------------------------------------------------ operators
class DQT_OT_areas_analyze(bpy.types.Operator):
    bl_idname = "drimah_qt.areas_analyze"
    bl_label = "ANALYZE AREAS"
    bl_description = ("Split the mesh into areas automatically (by thickness and creases)\n"
                      "and show each area with its own color")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _mesh_obj(context) is not None

    def execute(self, context):
        o = _mesh_obj(context)
        was_edit = _to_object_mode(o)
        if len(o.data.polygons) < 4:
            self.report({'ERROR'}, "The object has no faces.")
            return {'CANCELLED'}
        p = context.scene.drimah_qt.areas
        t0 = time.time()
        util.set_busy(context, True)
        try:
            n = analyze_object(context, o, p)
        except Exception as ex:
            util.set_busy(context, False)
            self.report({'ERROR'}, "Area analysis failed: %s" % ex)
            return {'CANCELLED'}
        util.set_busy(context, False)
        show_colors(context, True)
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "%d areas found (%.1fs)" % (n, time.time() - t0))
        return {'FINISHED'}


class _EditAreas:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = _mesh_obj(context)
        return o is not None and o.mode == 'EDIT' and core.AREA_ATTR in o.data.attributes

    def _selected(self, o):
        sel = np.zeros(len(o.data.polygons), bool)
        o.data.polygons.foreach_get("select", sel)
        return sel


class DQT_OT_areas_merge(_EditAreas, bpy.types.Operator):
    bl_idname = "drimah_qt.areas_merge"
    bl_label = "Merge"
    bl_description = "Edit Mode: join all areas touched by the selected faces into one area"

    def execute(self, context):
        o = _mesh_obj(context)
        _to_object_mode(o)
        me = o.data
        lab = core.read_labels(me).astype(np.int64)
        sel = self._selected(o)
        ids = np.unique(lab[sel])
        if len(ids) < 2:
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'ERROR'}, "Select faces on at least two different areas.")
            return {'CANCELLED'}
        lab[np.isin(lab, ids)] = ids[0]
        g = core.Graph(me)
        lab = core.sort_by_area(lab, g.area)
        core.write_labels(me, lab)
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "%d areas merged — %d areas now" % (len(ids), lab.max() + 1))
        return {'FINISHED'}


class DQT_OT_areas_split(_EditAreas, bpy.types.Operator):
    bl_idname = "drimah_qt.areas_split"
    bl_label = "Split"
    bl_description = "Edit Mode: the selected faces become a new area"

    def execute(self, context):
        o = _mesh_obj(context)
        _to_object_mode(o)
        me = o.data
        lab = core.read_labels(me).astype(np.int64)
        sel = self._selected(o)
        if not sel.any() or sel.all():
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'ERROR'}, "Select some faces (not all) to make a new area.")
            return {'CANCELLED'}
        lab[sel] = lab.max() + 1
        g = core.Graph(me)
        lab = core.sort_by_area(lab, g.area)
        core.write_labels(me, lab)
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "New area created — %d areas now" % (lab.max() + 1))
        return {'FINISHED'}


class DQT_OT_areas_select(_EditAreas, bpy.types.Operator):
    bl_idname = "drimah_qt.areas_select"
    bl_label = "Select Area"
    bl_description = "Edit Mode: grow the selection to the whole areas of the selected faces"

    def execute(self, context):
        o = _mesh_obj(context)
        _to_object_mode(o)
        me = o.data
        lab = core.read_labels(me)
        sel = self._selected(o)
        full = np.isin(lab, np.unique(lab[sel]))
        me.polygons.foreach_set("select", full)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        return {'FINISHED'}


class DQT_OT_areas_show(bpy.types.Operator):
    bl_idname = "drimah_qt.areas_show"
    bl_label = "Show Colors"
    bl_description = "Toggle the area colors in the viewport (Solid mode, Attribute color)"

    def execute(self, context):
        show_colors(context, not colors_shown(context))
        return {'FINISHED'}


class DQT_OT_areas_clear(bpy.types.Operator):
    bl_idname = "drimah_qt.areas_clear"
    bl_label = "Clear"
    bl_description = "Remove the areas and their colors from the mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = _mesh_obj(context)
        return o is not None and core.AREA_ATTR in o.data.attributes

    def execute(self, context):
        o = _mesh_obj(context)
        was_edit = _to_object_mode(o)
        core.clear_labels(o.data)
        show_colors(context, False)
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


class DQT_OT_areas_to_facesets(bpy.types.Operator):
    bl_idname = "drimah_qt.areas_to_facesets"
    bl_label = "Areas to Face Sets"
    bl_description = "Write one Face Set per area on this mesh (for Sculpt Mode or 'Use Materials')"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = _mesh_obj(context)
        return o is not None and core.AREA_ATTR in o.data.attributes

    def execute(self, context):
        o = _mesh_obj(context)
        was_edit = _to_object_mode(o)
        lab = core.read_labels(o.data)
        core.write_face_sets(o.data, lab)
        o.data.update()
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "%d Face Sets written" % (lab.max() + 1))
        return {'FINISHED'}


class DQT_OT_areas_separate(bpy.types.Operator):
    bl_idname = "drimah_qt.areas_separate"
    bl_label = "Separate Areas"
    bl_description = ("Create one object per area (in a new collection). The input is hidden, not changed.\n"
                      "Useful for AI models that come with every part stuck together")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = _mesh_obj(context)
        return o is not None and core.AREA_ATTR in o.data.attributes

    def execute(self, context):
        o = _mesh_obj(context)
        _to_object_mode(o)
        p = context.scene.drimah_qt.areas
        lab = core.read_labels(o.data)
        n = int(lab.max()) + 1
        util.set_busy(context, True)
        coll = bpy.data.collections.new(o.name + "_Areas")
        parent_coll = o.users_collection[0] if o.users_collection else context.scene.collection
        parent_coll.children.link(coll)
        base = bmesh.new()
        base.from_mesh(o.data)
        layer = base.faces.layers.int.get(core.AREA_ATTR)
        made = []
        try:
            for r in range(n):
                bm = base.copy()
                layer = bm.faces.layers.int.get(core.AREA_ATTR)
                drop = [f for f in bm.faces if f[layer] != r]
                bmesh.ops.delete(bm, geom=drop, context='FACES')
                if not bm.faces:
                    bm.free()
                    continue
                if p.fill_holes:
                    bnd = [e for e in bm.edges if e.is_boundary]
                    res = bmesh.ops.holes_fill(bm, edges=bnd, sides=0)
                    big = [f for f in res.get("faces", []) if len(f.verts) > 4]
                    if big:
                        bmesh.ops.triangulate(bm, faces=big, quad_method='BEAUTY', ngon_method='BEAUTY')
                me = bpy.data.meshes.new("%s_Area_%02d" % (o.name, r + 1))
                bm.to_mesh(me)
                bm.free()
                for slot in o.material_slots:
                    me.materials.append(slot.material)
                ob = bpy.data.objects.new(me.name, me)
                coll.objects.link(ob)
                ob.matrix_world = o.matrix_world.copy()
                ob["drimah_qt_area_of"] = o.name
                made.append(ob)
        finally:
            base.free()
            util.set_busy(context, False)
        o.hide_set(True)
        if made:
            util.select_only(context, made, made[0])
        self.report({'INFO'}, "%d objects created in collection '%s'" % (len(made), coll.name))
        return {'FINISHED'}


# ---------------------------------------------------------------- generate
def finish_result(context, src, res, p):
    """Bring the areas from the source to the quad result: labels, seams, UVs, face sets."""
    src_lab = core.read_labels(src.data)
    if src_lab is None:
        return 0
    g_src = core.Graph(src.data)
    bvh = _bvh_from_graph(g_src)
    me = res.data
    g = core.Graph(me)
    lab = _transfer(bvh, src_lab, g.center)
    lab = core.majority_filter(g, lab, 3)
    lab = core.clean_islands(g, lab)
    lab = core.sort_by_area(lab, g.area)
    core.write_labels(me, lab)
    if p.gen_face_sets:
        core.write_face_sets(me, lab)
    if p.gen_seams or p.gen_uv:
        cuts = core.border_edges(g, lab)
        extra = core.disk_cuts(me, lab) if p.gen_uv else []
        core.set_seams(me, np.unique(np.concatenate([cuts, np.asarray(extra, np.int64)])).astype(np.int64))
    if p.gen_uv:
        util.select_only(context, [res], res)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.01)
        bpy.ops.object.mode_set(mode='OBJECT')
    me.update()
    res["drimah_qt_areas"] = int(lab.max()) + 1
    return int(lab.max()) + 1


class DQT_OT_areas_generate(bpy.types.Operator):
    bl_idname = "drimah_qt.areas_generate"
    bl_label = "GENERATE QUADS"
    bl_description = ("Quad remesh with the Quad Remesh settings (engine, count, symmetry), then use the\n"
                      "areas for seams, one UV island per area and face sets. Runs the analysis first if needed")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _mesh_obj(context) is not None

    def execute(self, context):
        src = _mesh_obj(context)
        _to_object_mode(src)
        p = context.scene.drimah_qt.areas
        t0 = time.time()
        if core.read_labels(src.data) is None:
            util.set_busy(context, True)
            try:
                analyze_object(context, src, p)
            except Exception as ex:
                util.set_busy(context, False)
                self.report({'ERROR'}, "Area analysis failed: %s" % ex)
                return {'CANCELLED'}
        before = set(bpy.data.objects.keys())
        util.select_only(context, [src], src)
        r = bpy.ops.drimah_qt.remesh('EXEC_DEFAULT')
        if 'FINISHED' in r:
            res = context.view_layer.objects.active
            if res is None or res == src:
                self.report({'ERROR'}, "Remesh produced no result.")
                return {'CANCELLED'}
            n = finish_result(context, src, res, p)
            show_colors(context, True)
            self.report({'INFO'}, "%s — %d quads, %d areas (%.1fs)"
                        % (res.name, len(res.data.polygons), n, time.time() - t0))
            return {'FINISHED'}
        if 'RUNNING_MODAL' in r:  # Instant Meshes runs in the background: finish when it is done
            _wait_for_result(src.name, before, time.time())
            self.report({'INFO'}, "Remeshing... the areas are applied when it finishes.")
            return {'FINISHED'}
        return {'CANCELLED'}


def _wait_for_result(src_name, before, t0):
    def tick():
        if time.time() - t0 > 1800:
            return None
        for ob in bpy.data.objects:
            if ob.name not in before and ob.get("drimah_qt_source") == src_name and ob.type == 'MESH':
                src = bpy.data.objects.get(src_name)
                if src is not None:
                    ctx = bpy.context
                    try:
                        finish_result(ctx, src, ob, ctx.scene.drimah_qt.areas)
                        show_colors(ctx, True)
                    except Exception as ex:
                        print("Drimah Quad Turbo - areas:", ex)
                return None
        return 0.5
    bpy.app.timers.register(tick, first_interval=0.5)


classes = (DQT_AreasSettings, DQT_OT_areas_analyze, DQT_OT_areas_merge, DQT_OT_areas_split,
           DQT_OT_areas_select, DQT_OT_areas_show, DQT_OT_areas_clear, DQT_OT_areas_to_facesets,
           DQT_OT_areas_separate, DQT_OT_areas_generate)
