# Drimah Quad Turbo - minimal OBJ read/write (no dependency on other add-ons)
# SPDX-License-Identifier: GPL-3.0-or-later

import numpy as np


def write_obj_triangles(path, mesh):
    """Write the mesh (local coordinates) as a triangulated OBJ."""
    mesh.calc_loop_triangles()
    nv = len(mesh.vertices)
    nt = len(mesh.loop_triangles)
    co = np.empty(nv * 3, dtype=np.float64)
    mesh.vertices.foreach_get("co", co)
    tri = np.empty(nt * 3, dtype=np.int64)
    mesh.loop_triangles.foreach_get("vertices", tri)
    co = co.reshape(-1, 3)
    tri = tri.reshape(-1, 3) + 1
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("# Drimah Quad Turbo\n")
        np.savetxt(f, co, fmt="v %.9g %.9g %.9g")
        np.savetxt(f, tri, fmt="f %d %d %d")


def read_obj(path):
    """Return (verts, faces). Accepts v/vt/vn face syntax."""
    verts = []
    faces = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("v "):
                p = line.split()
                verts.append((float(p[1]), float(p[2]), float(p[3])))
            elif line.startswith("f "):
                idx = []
                for tok in line.split()[1:]:
                    i = int(tok.split("/")[0])
                    idx.append(i - 1 if i > 0 else len(verts) + i)
                if len(idx) >= 3:
                    faces.append(tuple(idx))
    return verts, faces
