# Drimah Quad Turbo - FBX export module
# SPDX-License-Identifier: GPL-3.0-or-later

import os

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from mathutils import Vector

from . import util

PRESETS = {
    'UNITY': dict(apply_scale_options='FBX_SCALE_ALL', axis_forward='-Z', axis_up='Y',
                  bake_space_transform=True),
    'UNREAL': dict(apply_scale_options='FBX_SCALE_NONE', axis_forward='X', axis_up='Z',
                   bake_space_transform=False),
    'GENERIC': dict(apply_scale_options='FBX_SCALE_NONE', axis_forward='-Z', axis_up='Y',
                    bake_space_transform=False),
}


class DQT_ExportSettings(bpy.types.PropertyGroup):
    preset: EnumProperty(
        name="Target",
        items=(('UNITY', "Unity", "Scale and axes ready for Unity (LODs become a LOD Group)"),
               ('UNREAL', "Unreal Engine", "Axes ready for Unreal Engine"),
               ('GENERIC', "Generic FBX", "Blender's default FBX settings")),
        default='UNITY')
    include_lods: BoolProperty(name="Include LODs", default=True,
                               description="Also export the generated LODs, named _LOD0, _LOD1...")
    separate_files: BoolProperty(name="One File per LOD", default=False,
                                 description="Write each LOD to its own .fbx file")
    center: BoolProperty(name="Center at Origin", default=True,
                         description="Export as if the object were at the world origin")
    triangulate: BoolProperty(name="Triangulate", default=False,
                              description="Convert faces to triangles in the exported file")
    apply_modifiers: BoolProperty(name="Apply Modifiers", default=True)
    embed_textures: BoolProperty(name="Embed Textures", default=False,
                                 description="Copy the textures inside the FBX file")
    output_dir: StringProperty(name="Folder", subtype='DIR_PATH', default="//export/",
                               description="Where the FBX files are saved. With an unsaved .blend, a temp folder is used")


class DQT_OT_export(bpy.types.Operator):
    bl_idname = "drimah_qt.export_fbx"
    bl_label = "Export FBX"
    bl_description = "Export the selected object (and its LODs) as game-ready FBX"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        if not hasattr(bpy.ops.export_scene, "fbx"):
            self.report({'ERROR'}, "The FBX exporter is not available. Enable the FBX format add-on.")
            return {'CANCELLED'}
        p = context.scene.drimah_qt.export
        obj = context.active_object
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        lods = util.lods_of(obj) if p.include_lods else []
        objs = [obj] + lods
        base = bpy.path.clean_name(obj.name)
        folder = util.resolve_dir(p.output_dir, "export")

        reveal = util.Reveal(objs)
        old_names = [(o, o.name) for o in objs]
        old_mats = [(o, o.matrix_world.copy()) for o in objs]
        files = []
        try:
            if lods:
                tmp = [(o, "__dqt_tmp_%d" % i) for i, o in enumerate(objs)]
                for o, n in tmp:
                    o.name = n
                for i, o in enumerate(objs):
                    o.name = "%s_LOD%d" % (old_names[0][1], i)
            for o in lods:  # LODs are copies of LOD0: always export them on top of it
                o.matrix_world = obj.matrix_world.copy()
            if p.center:
                offset = obj.matrix_world.translation.copy()
                for o in objs:
                    m = o.matrix_world.copy()
                    m.translation = m.translation - offset
                    o.matrix_world = m
            context.view_layer.update()
            kw = dict(PRESETS[p.preset])
            kw.update(use_selection=True, object_types={'MESH'}, use_mesh_modifiers=p.apply_modifiers,
                      mesh_smooth_type='FACE', use_triangles=p.triangulate, add_leaf_bones=False,
                      bake_anim=False, path_mode='COPY' if p.embed_textures else 'AUTO',
                      embed_textures=p.embed_textures)
            groups = [[o] for o in objs] if (p.separate_files and lods) else [objs]
            for g in groups:
                name = (base + ".fbx") if len(groups) == 1 else (bpy.path.clean_name(g[0].name) + ".fbx")
                path = os.path.join(folder, name)
                util.select_only(context, g, g[0])
                bpy.ops.export_scene.fbx(filepath=path, **kw)
                files.append(path)
        finally:
            for o, m in old_mats:
                o.matrix_world = m
            if lods:
                for i, (o, _n) in enumerate(old_names):
                    o.name = "__dqt_back_%d" % i
                for o, n in old_names:
                    o.name = n
            reveal.restore()
            util.select_only(context, [obj], obj)
        self.report({'INFO'}, "Exported %d object(s): %s" % (len(objs), ", ".join(files)))
        return {'FINISHED'}


classes = (DQT_ExportSettings, DQT_OT_export)
