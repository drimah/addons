# Drimah Quad Turbo - shared helpers
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import tempfile

import bpy

BUSY_TEXT = "Please wait... Processing..."


def set_busy(context, on):
    try:
        if context.workspace:
            context.workspace.status_text_set(BUSY_TEXT if on else None)
        if context.area:
            context.area.header_text_set(BUSY_TEXT if on else None)
        if on and not bpy.app.background:
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    except Exception:
        pass


def resolve_dir(path, sub):
    """Absolute output folder. A '//' path with an unsaved .blend falls back to the temp folder."""
    path = path or "//" + sub + "/"
    if path.startswith("//") and not bpy.data.filepath:
        out = os.path.join(tempfile.gettempdir(), "DrimahQuadTurbo", sub)
    else:
        out = bpy.path.abspath(path)
    os.makedirs(out, exist_ok=True)
    return os.path.normpath(out)


def lods_of(obj):
    """LOD objects generated for obj, sorted by level."""
    out = [o for o in bpy.data.objects if o.get("drimah_qt_lod_of") == obj.name]
    return sorted(out, key=lambda o: o.get("drimah_qt_lod_level", 0))


def select_only(context, objs, active):
    for o in context.view_layer.objects:
        if o.select_get():
            o.select_set(False)
    for o in objs:
        o.select_set(True)
    context.view_layer.objects.active = active


class Reveal:
    """Temporarily make objects visible/selectable and restore afterwards."""

    def __init__(self, objs):
        self.state = []
        for o in objs:
            self.state.append((o, o.hide_get(), o.hide_viewport, o.hide_select))
            o.hide_viewport = False
            o.hide_set(False)
            o.hide_select = False

    def restore(self):
        for o, h, hv, hs in self.state:
            try:
                o.hide_set(h)
                o.hide_viewport = hv
                o.hide_select = hs
            except ReferenceError:
                pass
