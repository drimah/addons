# Drimah Quad Turbo - LOD module
# SPDX-License-Identifier: GPL-3.0-or-later

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty

from . import util


class DQT_LODSettings(bpy.types.PropertyGroup):
    levels: IntProperty(name="LOD Levels", default=3, min=1, max=4,
                        description="How many LODs to generate (LOD0 is the selected object)")
    ratio_1: FloatProperty(name="LOD1", default=0.5, min=0.01, max=1.0, subtype='FACTOR',
                           description="Fraction of the LOD0 triangles kept in LOD1")
    ratio_2: FloatProperty(name="LOD2", default=0.25, min=0.01, max=1.0, subtype='FACTOR',
                           description="Fraction of the LOD0 triangles kept in LOD2")
    ratio_3: FloatProperty(name="LOD3", default=0.12, min=0.01, max=1.0, subtype='FACTOR',
                           description="Fraction of the LOD0 triangles kept in LOD3")
    ratio_4: FloatProperty(name="LOD4", default=0.06, min=0.01, max=1.0, subtype='FACTOR',
                           description="Fraction of the LOD0 triangles kept in LOD4")
    use_symmetry: BoolProperty(name="Symmetry", default=False,
                               description="Keep the decimation symmetrical")
    symmetry_axis: EnumProperty(name="Axis", items=(('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")), default='X')
    keep_quads: BoolProperty(name="Keep Quads Where Possible", default=True,
                             description="Rejoin triangles into quads after decimation")
    hide_lods: BoolProperty(name="Hide LODs", default=True,
                            description="Hide the generated LODs so they do not overlap LOD0 in the viewport")


def _ratio(p, i):
    return getattr(p, "ratio_%d" % i)


def _tri_count(me):
    me.calc_loop_triangles()
    return len(me.loop_triangles)


def _lod_collection(obj):
    name = obj.name + "_LODs"
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        parent = obj.users_collection[0] if obj.users_collection else bpy.context.scene.collection
        parent.children.link(col)
    return col


class DQT_OT_generate_lods(bpy.types.Operator):
    bl_idname = "drimah_qt.generate_lods"
    bl_label = "Generate LODs"
    bl_description = ("Create decimated copies (LOD1, LOD2...) of the selected object.\n"
                      "Running it again replaces the previous LODs of that object")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH' and "drimah_qt_lod_of" not in o

    def execute(self, context):
        p = context.scene.drimah_qt.lod
        obj = context.active_object
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        util.set_busy(context, True)
        try:
            for old in util.lods_of(obj):
                me = old.data
                bpy.data.objects.remove(old)
                if me.users == 0:
                    bpy.data.meshes.remove(me)

            dg = context.evaluated_depsgraph_get()
            base_me = bpy.data.meshes.new_from_object(obj.evaluated_get(dg), depsgraph=dg)
            base_tris = _tri_count(base_me)
            col = _lod_collection(obj)
            report = ["LOD0 %d tris" % base_tris]
            for i in range(1, p.levels + 1):
                tmp = bpy.data.objects.new("_dqt_lod_tmp", base_me.copy())
                context.scene.collection.objects.link(tmp)
                mod = tmp.modifiers.new("Decimate", 'DECIMATE')
                mod.decimate_type = 'COLLAPSE'
                mod.ratio = _ratio(p, i)
                mod.use_symmetry = p.use_symmetry
                mod.symmetry_axis = p.symmetry_axis
                mod.use_collapse_triangulate = False
                dg = context.evaluated_depsgraph_get()
                me = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg), depsgraph=dg)
                tmp_me = tmp.data
                bpy.data.objects.remove(tmp)
                bpy.data.meshes.remove(tmp_me)
                if p.keep_quads:
                    import bmesh
                    import math
                    bm = bmesh.new()
                    bm.from_mesh(me)
                    tris = [f for f in bm.faces if len(f.verts) == 3]
                    bmesh.ops.join_triangles(bm, faces=tris, angle_face_threshold=math.radians(40),
                                             angle_shape_threshold=math.radians(40))
                    bm.to_mesh(me)
                    bm.free()
                me.name = "%s_LOD%d" % (obj.name, i)
                lod = bpy.data.objects.new("%s_LOD%d" % (obj.name, i), me)
                col.objects.link(lod)
                lod.parent = obj.parent
                lod.matrix_parent_inverse = obj.matrix_parent_inverse.copy()
                lod.matrix_world = obj.matrix_world.copy()
                lod["drimah_qt_lod_of"] = obj.name
                lod["drimah_qt_lod_level"] = i
                if p.hide_lods:
                    lod.hide_set(True)
                report.append("LOD%d %d tris" % (i, _tri_count(me)))
            bpy.data.meshes.remove(base_me)
        finally:
            util.set_busy(context, False)
        util.select_only(context, [obj], obj)
        self.report({'INFO'}, "LODs created: " + ", ".join(report))
        return {'FINISHED'}


class DQT_OT_delete_lods(bpy.types.Operator):
    bl_idname = "drimah_qt.delete_lods"
    bl_label = "Delete LODs"
    bl_description = "Delete the LODs generated for the selected object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and bool(util.lods_of(o))

    def execute(self, context):
        obj = context.active_object
        n = 0
        for old in util.lods_of(obj):
            me = old.data
            bpy.data.objects.remove(old)
            if me.users == 0:
                bpy.data.meshes.remove(me)
            n += 1
        col = bpy.data.collections.get(obj.name + "_LODs")
        if col is not None and not col.all_objects:
            bpy.data.collections.remove(col)
        self.report({'INFO'}, "%d LODs deleted" % n)
        return {'FINISHED'}


class DQT_OT_toggle_lods(bpy.types.Operator):
    bl_idname = "drimah_qt.toggle_lods"
    bl_label = "Show/Hide LODs"
    bl_description = "Toggle the viewport visibility of the LODs of the selected object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and bool(util.lods_of(o))

    def execute(self, context):
        lods = util.lods_of(context.active_object)
        hide = not all(o.hide_get() for o in lods)
        for o in lods:
            o.hide_set(hide)
        return {'FINISHED'}


classes = (DQT_LODSettings, DQT_OT_generate_lods, DQT_OT_delete_lods, DQT_OT_toggle_lods)
