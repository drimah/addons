# Drimah Quad Turbo - preparation, symmetry and post-processing
# SPDX-License-Identifier: GPL-3.0-or-later

import math

import bpy
import bmesh
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree

AXES = (0, 1, 2)


# ------------------------------------------------------------ preparation
def evaluated_mesh_copy(src, depsgraph):
    """Copy of the evaluated mesh (with modifiers) in local coordinates."""
    ev = src.evaluated_get(depsgraph)
    me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=False, depsgraph=depsgraph)
    me.name = src.name + "_drq_work"
    return me


def scale_matrix(src):
    s = src.matrix_world.to_scale()
    return Matrix.Diagonal((s.x, s.y, s.z, 1.0))


def mesh_diag(me):
    if not me.vertices:
        return 1.0
    mn = Vector((1e30, 1e30, 1e30))
    mx = Vector((-1e30, -1e30, -1e30))
    for v in me.vertices:
        for i in AXES:
            mn[i] = min(mn[i], v.co[i])
            mx[i] = max(mx[i], v.co[i])
    return max((mx - mn).length, 1e-9)


def clean_mesh(me):
    """Clean the geometry and tell whether the mesh looks manifold for QuadriFlow."""
    diag = mesh_diag(me)
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=diag * 1e-6)
    bmesh.ops.dissolve_degenerate(bm, dist=diag * 1e-7, edges=bm.edges[:])
    wire = [e for e in bm.edges if not e.link_faces]
    if wire:
        bmesh.ops.delete(bm, geom=wire, context='EDGES')
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    manifold = all(len(e.link_faces) <= 2 for e in bm.edges)
    if manifold:
        manifold = all(v.is_manifold or v.is_boundary for v in bm.verts)
    has_boundary = any(e.is_boundary for e in bm.edges)
    area = sum(f.calc_area() for f in bm.faces)
    bm.to_mesh(me)
    bm.free()
    me.update()
    return manifold, has_boundary, area


def voxel_size_for(me, area, target):
    edge = math.sqrt(max(area, 1e-12) / max(target, 1))
    vs = edge / 3.0
    # avoid memory blow-up on very large meshes
    dims = [0.0, 0.0, 0.0]
    if me.vertices:
        for i in AXES:
            vals = [v.co[i] for v in me.vertices]
            dims[i] = max(vals) - min(vals)
    vol = max(dims[0], 1e-6) * max(dims[1], 1e-6) * max(dims[2], 1e-6)
    vs = max(vs, (vol / 3.0e7) ** (1.0 / 3.0))
    return max(vs, 1e-5)


AXIS_INDEX = {'X': 0, 'Y': 1, 'Z': 2}


def avg_edge_length(me):
    n = len(me.edges)
    if not n:
        return 1e-3
    tot = 0.0
    for e in me.edges:
        a, b = e.vertices
        tot += (me.vertices[a].co - me.vertices[b].co).length
    return max(tot / n, 1e-6)


def check_symmetry_plane(me, i, axis_name):
    """The symmetry plane (object origin) must cut the mesh. The mesh does not have to be
    symmetrical: the base side is kept and the other side is replaced by its mirror."""
    vals = [v.co[i] for v in me.vertices]
    mn, mx = min(vals), max(vals)
    extent = mx - mn
    if extent <= 0:
        raise RuntimeError("Mesh has no size on the symmetry axis")
    tol = 0.02 * extent
    if not (mn < -tol and mx > tol):
        raise RuntimeError("Symmetry %s: the plane through the object origin does not cut the mesh. "
                           "Put the origin in the middle of the model (Object > Set Origin) and try again"
                           % axis_name)


def symmetric_reference(me, i, sign):
    """Reference surface = base side + its mirror, so projection, smoothing and materials are
    identical on both sides even when the input is asymmetrical."""
    out = me.copy()
    bm = bmesh.new()
    bm.from_mesh(out)
    # cut exactly on the plane (works on coarse meshes too), keep the base side
    n = Vector((0.0, 0.0, 0.0))
    n[i] = sign
    geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
    bmesh.ops.bisect_plane(bm, geom=geom, dist=1e-7, plane_co=(0, 0, 0), plane_no=n, clear_inner=True)
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    for v in bm.verts:
        if abs(v.co[i]) < 1e-6:
            v.co[i] = 0.0
    geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
    dup = bmesh.ops.duplicate(bm, geom=geom)
    for g in dup["geom"]:
        if isinstance(g, bmesh.types.BMVert):
            g.co[i] = -g.co[i]
    bmesh.ops.reverse_faces(bm, faces=[g for g in dup["geom"] if isinstance(g, bmesh.types.BMFace)])
    seam = [v for v in bm.verts if v.co[i] == 0.0]
    bmesh.ops.remove_doubles(bm, verts=seam, dist=1e-6)
    bm.to_mesh(out)
    bm.free()
    out.update()
    return out


def _transport_parity(bm, face, i, tol, max_steps=400):
    """Walk straight across quads (entry edge -> opposite edge) from an odd face to a border
    (preferably the seam on the plane) or to another odd face. Inserts a vertex on every crossed
    edge and splits each quad on the path into two quads, so the odd face becomes even and no
    T-junction is created."""
    best = None
    for e0 in face.edges:
        path = [e0]
        cur = face
        e = e0
        quads = []
        seen = {face}
        cand = None
        for _ in range(max_steps):
            if e.is_boundary:
                on_plane = all(abs(v.co[i]) <= tol for v in e.verts)
                cand = (0 if on_plane else 1, len(path), path, quads)
                break
            nxt = [g for g in e.link_faces if g is not cur]
            if len(nxt) != 1:
                break
            g = nxt[0]
            if g in seen:
                break
            if len(g.verts) % 2 == 1:
                cand = (0, len(path), path, quads)
                break
            if len(g.verts) != 4:
                break
            lp = next(l for l in g.loops if l.edge is e)
            opp = lp.link_loop_next.link_loop_next.edge
            quads.append((g, e, opp))
            path.append(opp)
            seen.add(g)
            cur = g
            e = opp
        if cand and (best is None or cand[:2] < best[:2]):
            best = cand
    if best is None:
        return False
    _, _, path, quads = best
    mids = {}
    for e in path:
        a, b = e.verts
        mids[e] = (a.co + b.co) * 0.5
    res = bmesh.ops.bisect_edges(bm, edges=path, cuts=1)
    newv = [x for x in res["geom_split"] if isinstance(x, bmesh.types.BMVert)]

    def find(co):
        return min(newv, key=lambda v: (v.co - co).length_squared)

    for g, ein, eout in quads:
        va = find(mids[ein])
        vb = find(mids[eout])
        if g.is_valid and va in g.verts and vb in g.verts:
            bmesh.ops.connect_verts(bm, verts=[va, vb])
    return True


def _quadify_seam(bm, i, avg):
    """Cutting for symmetry can leave triangles/pentagons touching the plane. On the half
    (open border at the seam) an odd face touching the plane gets a vertex in the middle of its
    seam edge (a border, so no neighbour gets a T-junction) and even faces are split into quads.
    The mirror then comes out as pure quads without subdividing the model."""
    tol = max(1e-7, avg * 1e-4)

    def on_plane(e):
        return e.is_boundary and all(abs(v.co[i]) <= tol for v in e.verts)

    for attempt in range(4):
        bad = [f for f in bm.faces if len(f.verts) != 4]
        if not bad:
            return
        # 1) join neighbouring triangle pairs (angle limit grows every pass)
        region = set(bad)
        for f in bad:
            for e in f.edges:
                region.update(e.link_faces)
        bmesh.ops.triangulate(bm, faces=[f for f in region if f.is_valid and len(f.verts) > 4],
                              quad_method='BEAUTY', ngon_method='BEAUTY')
        tris = [f for f in bm.faces if len(f.verts) == 3]
        if tris:
            bmesh.ops.join_triangles(bm, faces=tris, angle_face_threshold=math.radians(80 if attempt < 2 else 179),
                                     angle_shape_threshold=math.pi, cmp_seam=False, cmp_sharp=False,
                                     cmp_materials=True, cmp_uvs=False)
        # 2) odd faces touching the seam: split the seam edge (face becomes even)
        split = []
        for f in bm.faces:
            if len(f.verts) % 2 == 1:
                e = next((e for e in f.edges if on_plane(e)), None)
                if e is not None and e not in split:
                    split.append(e)
        if split:
            bmesh.ops.subdivide_edges(bm, edges=split, cuts=1, use_grid_fill=False)
        # 2b) odd faces far from the plane: carry the parity straight to the seam/border/another odd face
        for f in [f for f in bm.faces if len(f.verts) % 2 == 1]:
            if f.is_valid and len(f.verts) % 2 == 1:
                _transport_parity(bm, f, i, tol)
        # 3) even faces with more than 4 sides: cut into quads
        for f in [f for f in bm.faces if len(f.verts) > 4 and len(f.verts) % 2 == 0]:
            while f.is_valid and len(f.verts) > 4:
                vs = list(f.verts)
                r = bmesh.ops.connect_verts(bm, verts=[vs[0], vs[3]])
                if not r.get("edges"):
                    break
                nxt = [g for g in r["edges"][0].link_faces if len(g.verts) > 4]
                if not nxt:
                    break
                f = nxt[0]


def mirror_result(me, i, sign=1.0):
    """Symmetry applied to the RESULT: delete the faces on the discarded side, pin the new border
    onto the plane, fix the seam to pure quads and mirror the base side, welding the seam."""
    avg = avg_edge_length(me)
    bm = bmesh.new()
    bm.from_mesh(me)
    drop = [f for f in bm.faces if sign * f.calc_center_median()[i] < 0.0]
    touched = {v for f in drop for v in f.verts}
    if drop:
        bmesh.ops.delete(bm, geom=drop, context='FACES_ONLY')
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    if not bm.faces:
        bm.free()
        raise RuntimeError("Symmetry: no geometry left on the %s side of the axis"
                           % ("positive" if sign > 0 else "negative"))
    seam = {v for v in touched if v.is_valid and v.is_boundary}
    for v in bm.verts:
        if v in seam or sign * v.co[i] < 0.0:
            v.co[i] = 0.0  # seam exactly on the plane
    # clean degenerate edges ONLY in the seam band (never collapse short edges elsewhere)
    band = avg * 1.5
    near = [e for e in bm.edges if all(abs(v.co[i]) <= band for v in e.verts)]
    if near:
        bmesh.ops.dissolve_degenerate(bm, edges=near, dist=avg * 0.02)
    for v in bm.verts:  # second pass: border vertices left right next to the plane
        if v.is_valid and v.is_boundary and sign * v.co[i] < avg * 0.25:
            v.co[i] = 0.0
    # faces lying flat ON the plane would be duplicated by the mirror (3 faces per edge)
    ptol = max(1e-6, avg * 1e-3)
    flat = [f for f in bm.faces if all(abs(v.co[i]) <= ptol for v in f.verts)]
    if flat:
        bmesh.ops.delete(bm, geom=flat, context='FACES_ONLY')
        loose = [v for v in bm.verts if not v.link_faces]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context='VERTS')
    _quadify_seam(bm, i, avg)
    # mirror + weld (same as a Mirror modifier with Merge and Clipping)
    geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
    dup = bmesh.ops.duplicate(bm, geom=geom)
    for g in dup["geom"]:
        if isinstance(g, bmesh.types.BMVert):
            g.co[i] = -g.co[i]
    bmesh.ops.reverse_faces(bm, faces=[g for g in dup["geom"] if isinstance(g, bmesh.types.BMFace)])
    thr = max(1e-5, avg * 0.01)
    on = [v for v in bm.verts if abs(v.co[i]) <= thr]
    bmesh.ops.remove_doubles(bm, verts=on, dist=thr)
    wire = [e for e in bm.edges if not e.link_faces]  # welding can leave loose edges on the seam
    if wire:
        bmesh.ops.delete(bm, geom=wire, context='EDGES')
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(me)
    bm.free()
    me.update()


# ------------------------------------------------------- post-processing
class Reference:
    """BVH of the reference mesh (cleaned, before voxel) for projection and materials."""

    def __init__(self, me):
        self.bm = bmesh.new()
        self.bm.from_mesh(me)
        self.bm.faces.ensure_lookup_table()
        self.bvh = BVHTree.FromBMesh(self.bm)

    def free(self):
        self.bm.free()


def project_and_relax(me, ref, iterations, sym_axes):
    bm = bmesh.new()
    bm.from_mesh(me)
    bvh = ref.bvh
    diag = mesh_diag(me)
    tol = diag * 1e-5
    on_plane = {a: {v.index for v in bm.verts if abs(v.co[a]) < tol} for a in sym_axes}

    def project():
        for v in bm.verts:
            hit = bvh.find_nearest(v.co)
            if hit[0] is not None:
                v.co = hit[0]
        for a, ids in on_plane.items():
            for i in ids:
                bm.verts[i].co[a] = 0.0

    bm.verts.ensure_lookup_table()
    project()
    for _ in range(iterations):
        new = {}
        for v in bm.verts:
            if v.is_boundary or not v.link_edges:
                continue
            acc = Vector((0, 0, 0))
            for e in v.link_edges:
                acc += e.other_vert(v).co
            avg = acc / len(v.link_edges)
            new[v.index] = v.co.lerp(avg, 0.5)
        for i, co in new.items():
            bm.verts[i].co = co
        project()
    bm.to_mesh(me)
    bm.free()
    me.update()


def _boundary_loops(bm):
    edges = {e for e in bm.edges if e.is_boundary}
    loops = []
    while edges:
        e0 = edges.pop()
        loop = {e0}
        stack = [e0]
        while stack:
            e = stack.pop()
            for v in e.verts:
                for e2 in v.link_edges:
                    if e2 in edges:
                        edges.discard(e2)
                        loop.add(e2)
                        stack.append(e2)
        loops.append(list(loop))
    return loops


def fill_spurious_holes(me, ref, edge_len):
    """Fill holes that do not exist in the input (QuadriFlow with sharp features sometimes leaves holes)."""
    from mathutils.kdtree import KDTree
    rb = [e for e in ref.bm.edges if e.is_boundary]
    pts = []
    step = max(edge_len * 0.5, 1e-9)
    for e in rb:
        a, b = e.verts[0].co, e.verts[1].co
        n = max(1, int((b - a).length / step))
        for i in range(n + 1):
            pts.append(a.lerp(b, i / n))
    kd = None
    if pts:
        kd = KDTree(len(pts))
        for i, c in enumerate(pts):
            kd.insert(c, i)
        kd.balance()

    bm = bmesh.new()
    bm.from_mesh(me)
    filled = 0
    for loop in _boundary_loops(bm):
        verts = {v for e in loop for v in e.verts}
        if kd is not None:
            near = sum(1 for v in verts if kd.find(v.co)[2] < edge_len * 1.5)
            if near >= len(verts) * 0.5:
                continue  # real border of the input
        res = bmesh.ops.holes_fill(bm, edges=loop, sides=0)
        new = res.get("faces", [])
        big = [f for f in new if len(f.verts) > 4]
        if big:
            tri = bmesh.ops.triangulate(bm, faces=big, quad_method='BEAUTY', ngon_method='BEAUTY')
            bmesh.ops.join_triangles(bm, faces=tri["faces"], angle_face_threshold=math.radians(60),
                                     angle_shape_threshold=math.radians(60))
        filled += 1
    if filled:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(me)
        me.update()
    bm.free()
    return filled


def transfer_materials(me, ref):
    bvh = ref.bvh
    idx = []
    for p in me.polygons:
        hit = bvh.find_nearest(p.center)
        if hit[2] is not None:
            idx.append(ref.bm.faces[hit[2]].material_index)
        else:
            idx.append(0)
    me.polygons.foreach_set("material_index", idx)
    me.update()


def face_stats(me):
    q = t = n = 0
    for p in me.polygons:
        k = p.loop_total
        if k == 4:
            q += 1
        elif k == 3:
            t += 1
        else:
            n += 1
    return q, t, n


def source_is_flat(src):
    me = src.data
    if not me.polygons:
        return False
    attr = me.attributes.get("sharp_face")
    if attr is None:
        return False
    return bool(attr.data[0].value)


def build_result(src, me, flat, hide_input, suffix="_DrimahQuad"):
    if flat:
        me.shade_flat()
    else:
        me.shade_smooth()
    for slot in src.material_slots:
        me.materials.append(slot.material)
    me.name = src.name + suffix
    obj = bpy.data.objects.new(src.name + suffix, me)
    cols = src.users_collection or (bpy.context.scene.collection,)
    for c in cols:
        c.objects.link(obj)
    obj.parent = src.parent
    obj.matrix_parent_inverse = src.matrix_parent_inverse.copy()
    obj.matrix_world = src.matrix_world.copy()
    for a in ("x", "y", "z"):
        try:
            setattr(obj, "use_mesh_mirror_" + a, getattr(src, "use_mesh_mirror_" + a))
        except Exception:
            pass
    obj["drimah_qt_source"] = src.name
    if hide_input:
        src.hide_set(True)
    for o in bpy.context.view_layer.objects:
        if o.select_get():
            o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    return obj
