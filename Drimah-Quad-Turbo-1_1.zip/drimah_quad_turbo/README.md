# Drimah Quad Turbo 1.1

All-in-one quad retopology toolkit for Blender (4.2 or newer; tested on 5.2.2).
Single package: the same ZIP works on Windows and Linux.

Workflow: **Cleanup → Areas → Quad Remesh → LODs → Bake → Export**

## Install
Edit > Preferences > Add-ons > (▾ menu) Install from Disk > `Drimah-Quad-Turbo-1_1.zip` > enable it.
Panel: 3D Viewport > N key > **Quad Turbo** tab. Each module is a sub-panel; hide the ones you
don't use in the add-on Preferences.

## Modules
| Module | What it does |
|---|---|
| Cleanup | Merges duplicated vertices, removes loose geometry and degenerate faces, fixes normals, optionally fills holes |
| Areas | Splits the mesh into areas automatically (head, neck, arms, legs, panels…) by thickness (Shape Diameter Function) and concave creases. Detail or exact Area Count, optional split at sharp edges. Merge / Split / Select areas in Edit Mode. **Generate Quads** remeshes and gives the result seams on the area borders, one UV island per area and Face Sets. **Separate Areas** makes one object per area |
| Quad Remesh | Quad retopology with QuadriFlow (built in) or Instant Meshes (optional). Quad count, exact count, hard edges, borders, materials, symmetry (axis + base side), pre-voxel, projection + relax |
| LODs | Generates LOD1–LOD4 with your ratios, symmetry option, re-joined quads. Re-running replaces the old LODs |
| Bake | Normal map (tangent) and AO from the high poly to the low poly with Cycles. Auto UVs, auto ray distance, PNG saved, normal map plugged into the material |
| Export | Game-ready FBX for Unity, Unreal or generic. LODs named `_LOD0, _LOD1…`, single file or one per LOD, centered at origin |

The remesh result remembers its source, so **Bake** finds the high poly automatically.
The input object is never modified by Remesh, LODs, Bake or Export.

## Areas
1. Select the mesh, open **Areas**, press **Analyze Areas**. Each area gets a color (Solid view, Attribute color).
2. Not happy? Change **Detail** (or set an exact **Area Count**) and analyze again. For hard surface turn on
   **Split at Sharp Edges**. In Edit Mode select faces and use **Merge** (join the areas they touch) or **Split**
   (selected faces become a new area).
3. **Generate Quads** uses the Quad Remesh settings (engine, quad count, symmetry). The result gets seams on
   the area borders (+ extra cuts so long parts open flat), unwrapped UVs and one Face Set per area.
The areas are stored on the mesh (face attribute `qt_area` and color attribute `QT_Areas`); **Clear** removes them.

## Symmetry
Pick one axis (X, Y or Z) and the **base side** (Side + or Side -). The whole model is remeshed,
then the base side is kept, the seam is pinned to the plane and fixed to pure quads, and the base
side is mirrored with a welded seam. The input does not need to be symmetrical: the base side wins.
The plane goes through the object origin, so the origin must be inside the model
(Object > Set Origin) — otherwise an error explains it.

## Instant Meshes (optional)
Put the executable in the add-on's `bin/` folder (see `bin/README.txt`) or set its path in the
Preferences. Nothing is downloaded automatically.

## License
GPL-3.0-or-later (see LICENSE.txt).
