# Drimah Quad Turbo - Bake module (high poly -> low poly, Cycles)
# SPDX-License-Identifier: GPL-3.0-or-later

import math
import os

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from . import util

RES_ITEMS = tuple((str(r), str(r), "%d x %d pixels" % (r, r)) for r in (512, 1024, 2048, 4096))


def _poll_mesh(self, obj):
    return obj.type == 'MESH'


class DQT_BakeSettings(bpy.types.PropertyGroup):
    high_object: PointerProperty(name="High Poly", type=bpy.types.Object, poll=_poll_mesh,
                                 description=("Detailed source object. Leave empty to use the object the\n"
                                              "selected result was remeshed from"))
    resolution: EnumProperty(name="Resolution", items=RES_ITEMS, default='2048')
    bake_normal: BoolProperty(name="Normal Map", default=True, description="Bake a tangent-space normal map")
    bake_ao: BoolProperty(name="Ambient Occlusion", default=False, description="Also bake an AO map")
    ao_samples: IntProperty(name="AO Samples", default=32, min=1, max=1024)
    ao_distance: FloatProperty(name="AO Distance", default=0.0, min=0.0, soft_max=10.0, subtype='DISTANCE',
                               description="How far occlusion is searched (0 = 10% of the object size)")
    margin: IntProperty(name="Margin", default=16, min=0, max=64, subtype='PIXEL',
                        description="Pixels extended past UV island borders")
    auto_distance: BoolProperty(name="Auto Ray Distance", default=True,
                                description="Pick the cage extrusion from the object size")
    extrusion: FloatProperty(name="Extrusion", default=0.02, min=0.0, soft_max=1.0, subtype='DISTANCE',
                             description="How far rays start outside the low poly surface")
    max_ray: FloatProperty(name="Max Ray Distance", default=0.0, min=0.0, soft_max=1.0, subtype='DISTANCE',
                           description="Maximum ray distance (0 = no limit)")
    auto_uv: BoolProperty(name="Auto UV If Missing", default=True,
                          description="Run Smart UV Project when the low poly has no UV map")
    connect: BoolProperty(name="Connect to Material", default=True,
                          description="Plug the normal map into the Principled BSDF of the low poly")
    output_dir: StringProperty(name="Folder", subtype='DIR_PATH', default="//textures/",
                               description=("Where the PNG files are saved.\n"
                                            "With an unsaved .blend, a temp folder is used"))


def _find_high(low, p):
    if p.high_object is not None and p.high_object != low:
        return p.high_object
    name = low.get("drimah_qt_source")
    if name:
        src = bpy.data.objects.get(name)
        if src is not None and src.type == 'MESH':
            return src
    return None


def _unique_low_materials(low, high):
    """Give the low poly its own materials so baking never reads the image it writes."""
    high_mats = {s.material for s in high.material_slots if s.material}
    if not low.material_slots:
        mat = bpy.data.materials.new(low.name + "_Mat")
        mat.use_nodes = True
        low.data.materials.append(mat)
    mats = []
    for slot in low.material_slots:
        m = slot.material
        if m is None:
            m = bpy.data.materials.new(low.name + "_Mat")
            slot.material = m
        elif m in high_mats or m.users > 1:
            m = m.copy()
            m.name = slot.material.name + "_" + low.name
            slot.material = m
        m.use_nodes = True
        mats.append(m)
    return list(dict.fromkeys(mats))


def _set_target(mats, image, label):
    nodes = []
    for m in mats:
        nt = m.node_tree
        node = nt.nodes.get(label)
        if node is None:
            node = nt.nodes.new("ShaderNodeTexImage")
            node.name = node.label = label
            node.location = (-700, -300 if "Normal" in label else -600)
        node.image = image
        for n in nt.nodes:
            n.select = False
        node.select = True
        nt.nodes.active = node
        nodes.append(node)
    return nodes


def _connect_normal(mats, label):
    for m in mats:
        nt = m.node_tree
        tex = nt.nodes.get(label)
        bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if tex is None or bsdf is None:
            continue
        nm = nt.nodes.get("DQT Normal Map")
        if nm is None:
            nm = nt.nodes.new("ShaderNodeNormalMap")
            nm.name = nm.label = "DQT Normal Map"
            nm.location = (-350, -300)
        nt.links.new(tex.outputs["Color"], nm.inputs["Color"])
        nt.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])


def _new_image(name, size, non_color):
    img = bpy.data.images.get(name)
    if img is not None and tuple(img.size) != (size, size):
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(name, size, size, alpha=False)
    img.colorspace_settings.name = 'Non-Color' if non_color else 'sRGB'
    return img


RAY_FLAGS = ("visible_camera", "visible_diffuse", "visible_glossy", "visible_transmission",
             "visible_volume_scatter", "visible_shadow")


def _isolate(scene, high):
    """Hide every object except the high poly from rays (low poly, LODs and others would occlude)."""
    saved = []
    for o in scene.objects:
        if o == high:
            continue
        saved.append((o, [getattr(o, f) for f in RAY_FLAGS]))
        for f in RAY_FLAGS:
            setattr(o, f, False)
    return saved


def _unisolate(saved):
    for o, vals in saved:
        try:
            for f, v in zip(RAY_FLAGS, vals):
                setattr(o, f, v)
        except ReferenceError:
            pass


def _save(img, folder):
    path = os.path.join(folder, bpy.path.clean_name(img.name) + ".png")
    img.filepath_raw = path
    img.file_format = 'PNG'
    img.save()
    return path


class DQT_OT_bake(bpy.types.Operator):
    bl_idname = "drimah_qt.bake"
    bl_label = "Bake Maps"
    bl_description = ("Bake detail from the high poly onto the selected low poly (Cycles).\n"
                      "The low poly needs UVs (they can be created automatically)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        p = context.scene.drimah_qt.bake
        low = context.active_object
        high = _find_high(low, p)
        if high is None:
            self.report({'ERROR'}, "No high poly found. Pick one in 'High Poly' or select a remeshed result.")
            return {'CANCELLED'}
        if not (p.bake_normal or p.bake_ao):
            self.report({'ERROR'}, "Enable at least one map to bake.")
            return {'CANCELLED'}
        if low.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        scene = context.scene
        old_engine = scene.render.engine
        old_samples = scene.cycles.samples if hasattr(scene, "cycles") else None
        temp_world = None
        if scene.world is None:
            temp_world = scene.world = bpy.data.worlds.new("DQT_TempWorld")
        old_ao_dist = scene.world.light_settings.distance
        reveal = util.Reveal([high, low])
        util.set_busy(context, True)
        saved = []
        isolated = []
        try:
            # UVs
            if not low.data.uv_layers:
                if not p.auto_uv:
                    self.report({'ERROR'}, "The low poly has no UV map.")
                    return {'CANCELLED'}
                util.select_only(context, [low], low)
                with context.temp_override(active_object=low, object=low, selected_objects=[low],
                                           selected_editable_objects=[low]):
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.01)
                    bpy.ops.object.mode_set(mode='OBJECT')

            size = int(p.resolution)
            mats = _unique_low_materials(low, high)
            if p.auto_distance:
                diag = max(low.dimensions.length, 1e-6)
                ext, ray = diag * 0.01, diag * 0.05
            else:
                ext, ray = p.extrusion, p.max_ray
            folder = util.resolve_dir(p.output_dir, "textures")

            scene.render.engine = 'CYCLES'
            isolated = _isolate(scene, high)
            util.select_only(context, [high, low], low)
            jobs = []
            if p.bake_normal:
                jobs.append(('NORMAL', "DQT Normal", low.name + "_normal", True, 1))
            if p.bake_ao:
                jobs.append(('AO', "DQT AO", low.name + "_ao", False, p.ao_samples))
            scene.world.light_settings.distance = p.ao_distance or max(low.dimensions.length, 1e-6) * 0.1
            for kind, label, img_name, non_color, samples in jobs:
                img = _new_image(img_name, size, non_color)
                _set_target(mats, img, label)
                scene.cycles.samples = samples
                with context.temp_override(active_object=low, object=low, selected_objects=[high, low],
                                           selected_editable_objects=[high, low]):
                    bpy.ops.object.bake(type=kind, normal_space='TANGENT', use_selected_to_active=True,
                                        cage_extrusion=ext, max_ray_distance=ray, margin=p.margin,
                                        use_clear=True, target='IMAGE_TEXTURES')
                saved.append(_save(img, folder))
            if p.bake_normal and p.connect:
                _connect_normal(mats, "DQT Normal")
        except RuntimeError as ex:
            self.report({'ERROR'}, "Bake failed: " + str(ex).strip().splitlines()[-1])
            return {'CANCELLED'}
        finally:
            _unisolate(isolated)
            scene.render.engine = old_engine
            if temp_world is not None:
                scene.world = None
                bpy.data.worlds.remove(temp_world)
            elif scene.world is not None:
                scene.world.light_settings.distance = old_ao_dist
            if old_samples is not None:
                scene.cycles.samples = old_samples
            reveal.restore()
            util.select_only(context, [low], low)
            util.set_busy(context, False)
        self.report({'INFO'}, "Baked %d map(s) from %s: %s" % (len(saved), high.name, ", ".join(saved)))
        return {'FINISHED'}


classes = (DQT_BakeSettings, DQT_OT_bake)
