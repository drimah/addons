# Drimah Quad Turbo - open source engines
#   QuadriFlow     : built into Blender (GPL) - nothing to install
#   Instant Meshes : optional BSD executable set by the user in the preferences
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import platform
import stat
import subprocess
import tempfile

import bpy

IS_WIN = platform.system() == "Windows"
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
IM_NAMES = ("Instant Meshes.exe", "InstantMeshes.exe", "Instant Meshes", "InstantMeshes", "instant-meshes")


# ------------------------------------------------------------ QuadriFlow
def run_quadriflow(context, work_obj, target, preserve_sharp, preserve_boundary, sym_axes, seed):
    me = work_obj.data
    me.use_mirror_x = 0 in sym_axes
    me.use_mirror_y = 1 in sym_axes
    me.use_mirror_z = 2 in sym_axes
    vl = context.view_layer
    for o in vl.objects:
        if o.select_get():
            o.select_set(False)
    work_obj.select_set(True)
    vl.objects.active = work_obj
    before = len(me.polygons)
    try:
        with context.temp_override(active_object=work_obj, object=work_obj,
                                   selected_objects=[work_obj], selected_editable_objects=[work_obj]):
            res = bpy.ops.object.quadriflow_remesh(
                mode='FACES',
                target_faces=max(int(target), 4),
                use_mesh_symmetry=bool(sym_axes),
                use_preserve_sharp=preserve_sharp,
                use_preserve_boundary=preserve_boundary,
                preserve_attributes=False,
                smooth_normals=False,
                seed=seed,
            )
    except RuntimeError as ex:
        return False, str(ex).strip().splitlines()[-1]
    me = work_obj.data
    if 'FINISHED' not in res or len(me.polygons) == 0:
        return False, "QuadriFlow produced no result"
    # QuadriFlow may return the mesh untouched on a silent failure
    if len(me.polygons) == before and any(p.loop_total == 3 for p in me.polygons):
        return False, "QuadriFlow could not remesh this mesh"
    return True, ""


def run_voxel(context, work_obj, voxel_size):
    work_obj.data.remesh_voxel_size = voxel_size
    work_obj.data.use_remesh_fix_poles = True
    with context.temp_override(active_object=work_obj, object=work_obj,
                               selected_objects=[work_obj], selected_editable_objects=[work_obj]):
        bpy.ops.object.voxel_remesh()


# -------------------------------------------------------- Instant Meshes
def find_instant_meshes(pref_path):
    cands = []
    if pref_path:
        cands.append(bpy.path.abspath(pref_path))
    bindir = os.path.join(ADDON_DIR, "bin")
    for n in IM_NAMES:
        if n.lower().endswith(".exe") == IS_WIN:
            cands.append(os.path.join(bindir, n))
    for c in cands:
        if c and os.path.isfile(c):
            if not IS_WIN and not os.access(c, os.X_OK):
                try:
                    os.chmod(c, os.stat(c).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
                except OSError:
                    pass
            return c
    return None


def temp_dir():
    d = os.path.join(tempfile.gettempdir(), "DrimahQuadTurbo")
    os.makedirs(d, exist_ok=True)
    return d


def start_instant_meshes(exe, in_obj, out_obj, target, crease_angle, use_crease, boundaries, smooth_iters):
    # in pure-quad mode Instant Meshes subdivides every face into 4 at the end
    cmd = [exe, in_obj, "-o", out_obj, "-f", str(max(int(round(target / 4.0)), 4)),
           "-r", "4", "-p", "4", "-d", "-S", str(int(smooth_iters))]
    if use_crease:
        cmd += ["-c", "%g" % crease_angle]
    if boundaries:
        cmd += ["-b"]
    kw = {}
    if IS_WIN:
        kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    log = open(os.path.join(temp_dir(), "instant_meshes_log.txt"), "w")
    proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, cwd=temp_dir(), **kw)
    proc._drq_log = log
    return proc
