# Drimah Quad Turbo - Cleanup module
# SPDX-License-Identifier: GPL-3.0-or-later

import bmesh
import bpy
from bpy.props import BoolProperty, FloatProperty


class DQT_CleanupSettings(bpy.types.PropertyGroup):
    merge_distance: FloatProperty(name="Merge Distance", default=0.0001, min=0.0, soft_max=0.01,
                                  precision=5, subtype='DISTANCE',
                                  description="Merge vertices closer than this distance")
    delete_loose: BoolProperty(name="Delete Loose", default=True,
                               description="Delete vertices and edges that do not belong to any face")
    dissolve_degenerate: BoolProperty(name="Dissolve Degenerate", default=True,
                                      description="Remove zero-area faces and zero-length edges")
    recalc_normals: BoolProperty(name="Recalculate Normals", default=True,
                                 description="Make face normals point consistently outside")
    fill_holes: BoolProperty(name="Fill Holes", default=False,
                             description="Close open borders (only use on meshes that should be closed)")
    work_on_copy: BoolProperty(name="Work on Copy", default=False,
                               description="Clean a duplicate and keep the input untouched")


class DQT_OT_cleanup(bpy.types.Operator):
    bl_idname = "drimah_qt.cleanup"
    bl_label = "Clean Up Mesh"
    bl_description = "Fix common mesh problems before remeshing (Ctrl+Z to undo)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        p = context.scene.drimah_qt.cleanup
        obj = context.active_object
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if p.work_on_copy:
            new = obj.copy()
            new.data = obj.data.copy()
            new.name = obj.name + "_Clean"
            for c in obj.users_collection:
                c.objects.link(new)
            obj.select_set(False)
            new.select_set(True)
            context.view_layer.objects.active = new
            obj = new

        me = obj.data
        v0, f0 = len(me.vertices), len(me.polygons)
        bm = bmesh.new()
        bm.from_mesh(me)
        merged = 0
        if p.merge_distance > 0:
            n = len(bm.verts)
            bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=p.merge_distance)
            merged = n - len(bm.verts)
        if p.dissolve_degenerate:
            bmesh.ops.dissolve_degenerate(bm, dist=max(p.merge_distance * 0.1, 1e-7), edges=bm.edges[:])
        loose = 0
        if p.delete_loose:
            wire = [e for e in bm.edges if not e.link_faces]
            loose += len(wire)
            if wire:
                bmesh.ops.delete(bm, geom=wire, context='EDGES')
            lv = [v for v in bm.verts if not v.link_faces]
            loose += len(lv)
            if lv:
                bmesh.ops.delete(bm, geom=lv, context='VERTS')
        holes = 0
        if p.fill_holes:
            bnd = [e for e in bm.edges if e.is_boundary]
            if bnd:
                holes = len(bmesh.ops.holes_fill(bm, edges=bnd, sides=0).get("faces", []))
        if p.recalc_normals:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(me)
        bm.free()
        me.update()
        self.report({'INFO'}, "Cleaned %s: %d merged, %d loose removed, %d holes filled (%d→%d verts, %d→%d faces)"
                    % (obj.name, merged, loose, holes, v0, len(me.vertices), f0, len(me.polygons)))
        return {'FINISHED'}


classes = (DQT_CleanupSettings, DQT_OT_cleanup)
