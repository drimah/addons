# Drimah Quad Turbo - operators
# SPDX-License-Identifier: GPL-3.0-or-later

import math
import os
import random
import time

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty

from . import engines, meshio, pipeline

BUSY_TEXT = "Please wait... Processing..."




def _set_busy(context, on):
    try:
        if context.workspace:
            context.workspace.status_text_set(BUSY_TEXT if on else None)
        if context.area:
            context.area.header_text_set(BUSY_TEXT if on else None)
        if on and not bpy.app.background:
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    except Exception:
        pass


def _addon_prefs(context):
    try:
        return context.preferences.addons[__package__].preferences
    except Exception:
        return None


class DQT_RemeshSettings(bpy.types.PropertyGroup):
    engine: EnumProperty(
        name="Engine",
        items=(
            ('QUADRIFLOW', "QuadriFlow", "Built into Blender. Nothing to install"),
            ('INSTANT_MESHES', "Instant Meshes", "External executable (BSD). Set its path in the add-on Preferences"),
        ),
        default='QUADRIFLOW',
    )
    target_count: IntProperty(name="Quad Count", description="Set the desired number of quads",
                              default=5000, min=4, soft_min=100, soft_max=50000)
    adapt_quad_count: BoolProperty(
        name="Adapt Quad Count", default=True,
        description=("On: accept the quad count produced by the engine.\n"
                     "Off: re-run up to 3 times to get within ±5% of the target (QuadriFlow only)"))
    hard_edges: BoolProperty(name="Detect Hard Edges", default=True,
                             description="Try to keep edge loops aligned with the sharp edges of the shape")
    crease_angle: FloatProperty(name="Hard Edge Angle", default=30.0, min=1.0, max=90.0,
                                description="Dihedral angle above which an edge is considered hard (Instant Meshes)")
    preserve_boundary: BoolProperty(name="Preserve Borders", default=True,
                                    description="Keep the open borders of the mesh")
    use_materials: BoolProperty(name="Use Materials", default=False,
                                description="Transfer the material index of each face from the input to the result")
    symmetry: EnumProperty(
        name="Symmetry",
        items=(('NONE', "None", "No symmetry"),
               ('X', "X", "Mirror the result on X"),
               ('Y', "Y", "Mirror the result on Y"),
               ('Z', "Z", "Mirror the result on Z")),
        default='NONE',
        description="Mirror the result on the plane through the object origin on this axis")
    symmetry_side: EnumProperty(
        name="Base Side",
        items=(('POS', "Side +", "The positive side of the axis is kept and mirrored to the negative side"),
               ('NEG', "Side -", "The negative side of the axis is kept and mirrored to the positive side")),
        default='POS',
        description="Side of the model used as the base; the other side is discarded and replaced by the mirror")
    pre_voxel: EnumProperty(
        name="Pre-Voxel",
        items=(
            ('AUTO', "Automatic", "Use voxel remesh only when the mesh is non-manifold or the engine fails"),
            ('ALWAYS', "Always", "Always close/unify the mesh with voxel remesh before remeshing"),
            ('NEVER', "Never", "Never use voxel remesh"),
        ),
        default='AUTO',
    )
    project: BoolProperty(name="Project on Input", default=True,
                          description="Snap the result vertices onto the input surface")
    relax_iterations: IntProperty(name="Relax", default=2, min=0, max=20,
                                  description="Smoothing passes with reprojection onto the input")
    seed: IntProperty(name="Seed", default=0, min=0,
                      description="Changes the QuadriFlow solution (try another one if you dislike the flow)")
    im_smooth: IntProperty(name="IM Smoothing", default=2, min=0, max=10,
                           description="Internal Instant Meshes smoothing iterations")
    hide_input: BoolProperty(name="Hide Input Object", default=True,
                             description="Hide the input object after remeshing")



class DQT_OT_remesh(bpy.types.Operator):
    bl_idname = "drimah_qt.remesh"
    bl_label = "REMESH"
    bl_description = ("Remesh the selected mesh into quads.\n"
                      "The input is not modified; the result is created as a separate object")
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _proc = None

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    # ------------------------------------------------------------ start
    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        p = context.scene.drimah_qt.remesh
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        src = context.active_object if context.active_object in sel else (sel[0] if len(sel) == 1 else None)
        if src is None or len(sel) != 1:
            self.report({'ERROR'}, "You must select one and only one MESH object.")
            return {'CANCELLED'}
        if src.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        self.src = src
        self.t0 = time.time()
        self.sym_axis = None if p.symmetry == 'NONE' else pipeline.AXIS_INDEX[p.symmetry]
        self.sym_sign = 1.0 if p.symmetry_side == 'POS' else -1.0
        self.S = pipeline.scale_matrix(src)
        self.tmp_meshes = []

        _set_busy(context, True)
        dg = context.evaluated_depsgraph_get()
        me_ref = pipeline.evaluated_mesh_copy(src, dg)
        self.tmp_meshes.append(me_ref)
        me_ref.transform(self.S)
        if len(me_ref.polygons) == 0:
            return self._fail(context, "The object has no faces.")
        self.manifold, self.boundary, self.area = pipeline.clean_mesh(me_ref)
        self.me_ref = me_ref
        if self.sym_axis is not None:
            try:
                pipeline.check_symmetry_plane(me_ref, self.sym_axis, p.symmetry)
            except RuntimeError as ex:
                return self._fail(context, str(ex))
            sym_ref = pipeline.symmetric_reference(me_ref, self.sym_axis, self.sym_sign)
            self.tmp_meshes.append(sym_ref)
            self.ref = pipeline.Reference(sym_ref)
        else:
            self.ref = pipeline.Reference(me_ref)

        if p.engine == 'INSTANT_MESHES':
            return self._start_im(context, p)
        return self._run_qf(context, p)

    # --------------------------------------------------------- QuadriFlow
    def _qf_attempt(self, context, target, use_voxel, p):
        me = self.me_ref.copy()
        obj = bpy.data.objects.new("_drq_tmp", me)
        context.scene.collection.objects.link(obj)
        try:
            if use_voxel:
                engines.run_voxel(context, obj, pipeline.voxel_size_for(me, self.area, target))
            ok, msg = engines.run_quadriflow(context, obj, target, p.hard_edges,
                                             p.preserve_boundary, (), p.seed)
            out = obj.data
        finally:
            bpy.data.objects.remove(obj)
        if me is not out:
            bpy.data.meshes.remove(me)
        if not ok:
            bpy.data.meshes.remove(out)
            return None, msg
        return out, ""

    def _run_qf(self, context, p):
        target = p.target_count
        use_voxel = p.pre_voxel == 'ALWAYS' or (p.pre_voxel == 'AUTO' and not self.manifold)
        out, msg = self._qf_attempt(context, target, use_voxel, p)
        if out is None and p.pre_voxel == 'AUTO' and not use_voxel:
            use_voxel = True
            out, msg = self._qf_attempt(context, target, True, p)
        if out is None:
            return self._fail(context, "QuadriFlow failed: " + msg)
        self.used_voxel = use_voxel

        if not p.adapt_quad_count:
            goal = p.target_count
            for _ in range(3):
                got = len(out.polygons)
                if abs(got - goal) <= goal * 0.05:
                    break
                target = max(4, int(round(target * goal / max(got, 1))))
                nxt, _m = self._qf_attempt(context, target, use_voxel, p)
                if nxt is None:
                    break
                if abs(len(nxt.polygons) - goal) < abs(got - goal):
                    bpy.data.meshes.remove(out)
                    out = nxt
                else:
                    bpy.data.meshes.remove(nxt)
        return self._finish(context, out, p)

    # ----------------------------------------------------- Instant Meshes
    def _start_im(self, context, p):
        prefs = _addon_prefs(context)
        exe = engines.find_instant_meshes(prefs.instant_meshes_path if prefs else "")
        if not exe:
            return self._fail(context, "Instant Meshes not found. Set the executable in the "
                                       "add-on Preferences or use the QuadriFlow engine.")
        me_in = self.me_ref.copy()
        self.tmp_meshes.append(me_in)
        self.used_voxel = p.pre_voxel == 'ALWAYS'
        if self.used_voxel:
            obj = bpy.data.objects.new("_drq_tmp", me_in)
            context.scene.collection.objects.link(obj)
            try:
                engines.run_voxel(context, obj, pipeline.voxel_size_for(me_in, self.area, p.target_count))
            finally:
                bpy.data.objects.remove(obj)
        d = engines.temp_dir()
        self.im_in = os.path.join(d, "input.obj")
        self.im_out = os.path.join(d, "output.obj")
        for f in (self.im_in, self.im_out):
            if os.path.exists(f):
                os.remove(f)
        meshio.write_obj_triangles(self.im_in, me_in)
        target = p.target_count
        try:
            self._proc = engines.start_instant_meshes(exe, self.im_in, self.im_out, target, p.crease_angle,
                                                      p.hard_edges, p.preserve_boundary,
                                                      p.im_smooth)
        except Exception as ex:
            return self._fail(context, "Cannot execute Instant Meshes: %s" % ex)
        if bpy.app.background:  # tests / command line
            self._proc.wait()
            return self._im_done(context, p)
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.25, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self._stop_proc()
            return self._fail(context, "Remeshing cancelled.", level='INFO')
        if event.type == 'TIMER' and self._proc is not None and self._proc.poll() is not None:
            return self._im_done(context, context.scene.drimah_qt.remesh)
        return {'RUNNING_MODAL'}

    def _stop_proc(self):
        if self._proc is not None and self._proc.poll() is None:
            self._proc.terminate()
        self._close_log()

    def _close_log(self):
        try:
            self._proc._drq_log.close()
        except Exception:
            pass

    def _im_done(self, context, p):
        self._close_log()
        code = self._proc.returncode
        self._proc = None
        if code != 0 or not os.path.exists(self.im_out):
            return self._fail(context, "Instant Meshes failed (code %s). See instant_meshes_log.txt in %s"
                              % (code, engines.temp_dir()))
        verts, faces = meshio.read_obj(self.im_out)
        if not faces:
            return self._fail(context, "Instant Meshes returned an empty mesh.")
        out = bpy.data.meshes.new("_drq_im")
        out.from_pydata(verts, [], faces)
        out.validate()
        out.update()
        return self._finish(context, out, p)

    # ------------------------------------------------------------- end
    def _finish(self, context, out, p):
        edge_len = math.sqrt(self.area / max(p.target_count, 1))
        pipeline.fill_spurious_holes(out, self.ref, edge_len)
        sym_axes = ()
        if self.sym_axis is not None:
            # same as Drimah Retopo: the engine remeshes the whole model, then the base side is
            # kept, the seam is fixed to pure quads and the base side is mirrored
            try:
                pipeline.mirror_result(out, self.sym_axis, self.sym_sign)
            except RuntimeError as ex:
                bpy.data.meshes.remove(out)
                return self._fail(context, str(ex))
            sym_axes = (self.sym_axis,)
        if p.project:
            pipeline.project_and_relax(out, self.ref, p.relax_iterations, sym_axes)
            if self.sym_axis is not None:  # smoothing touches the seam: mirror the base side again
                pipeline.mirror_result(out, self.sym_axis, self.sym_sign)
        if p.use_materials and len(self.src.material_slots) > 1:
            pipeline.transfer_materials(out, self.ref)
        out.transform(self.S.inverted())
        out.update()
        flat = pipeline.source_is_flat(self.src)
        obj = pipeline.build_result(self.src, out, flat, p.hide_input)
        if self.sym_axis is not None:
            obj["drimah_qt_symmetry"] = p.symmetry + ("+" if self.sym_sign > 0 else "-")
        q, t, n = pipeline.face_stats(out)
        self._cleanup(context)
        extra = (", %d triangles" % t if t else "") + (", %d n-gons" % n if n else "")
        sym = "" if self.sym_axis is None else ", symmetry %s" % obj["drimah_qt_symmetry"]
        self.report({'INFO'}, "Remeshing succeeded: %s — %d quads%s%s (%.1fs)"
                    % (obj.name, q, extra, sym, time.time() - self.t0))
        return {'FINISHED'}

    def _fail(self, context, msg, level='ERROR'):
        self._cleanup(context)
        self.report({level}, msg)
        return {'CANCELLED'}

    def _cleanup(self, context):
        _set_busy(context, False)
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        ref = getattr(self, "ref", None)
        if ref is not None:
            ref.free()
            self.ref = None
        for m in getattr(self, "tmp_meshes", []):
            try:
                if m.users == 0:
                    bpy.data.meshes.remove(m)
            except ReferenceError:
                pass
        self.tmp_meshes = []

    def cancel(self, context):
        self._stop_proc()
        self._cleanup(context)


class DQT_OT_reset(bpy.types.Operator):
    bl_idname = "drimah_qt.remesh_reset"
    bl_label = "Reset Settings"
    bl_description = "Reset all settings to their default values"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        p = context.scene.drimah_qt.remesh
        for name in p.bl_rna.properties.keys():
            if name not in ("rna_type", "name"):
                p.property_unset(name)
        return {'FINISHED'}


class DQT_OT_facesets_to_materials(bpy.types.Operator):
    bl_idname = "drimah_qt.facesets_to_materials"
    bl_label = "Face Sets to Materials"
    bl_description = ("Assign a new material (random color) to each Face Set,\n"
                      "so Face Sets can be used with 'Use Materials'")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        o = context.active_object
        if o.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        me = o.data
        attr = me.attributes.get(".sculpt_face_set")
        if attr is None or attr.domain != 'FACE':
            self.report({'ERROR'}, "No Face Sets found in the mesh.")
            return {'CANCELLED'}
        vals = [d.value for d in attr.data]
        ids = sorted(set(vals))
        if len(ids) < 2:
            self.report({'ERROR'}, "The mesh has only one Face Set.")
            return {'CANCELLED'}
        base = len(me.materials)
        rng = random.Random(1)
        mapping = {}
        for k, fs in enumerate(ids):
            mat = bpy.data.materials.new("FaceSet_%d" % fs)
            mat.diffuse_color = (rng.random(), rng.random(), rng.random(), 1.0)
            me.materials.append(mat)
            mapping[fs] = base + k
        me.polygons.foreach_set("material_index", [mapping[v] for v in vals])
        me.update()
        self.report({'INFO'}, "%d materials created" % len(ids))
        return {'FINISHED'}


classes = (DQT_RemeshSettings, DQT_OT_remesh, DQT_OT_reset, DQT_OT_facesets_to_materials)
