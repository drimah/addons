# Drimah Quad Turbo 1.0

All-in-one quad retopology toolkit for Blender (4.2 or newer; tested on 5.2.2).
Single package: the same ZIP works on Windows and Linux.

Workflow: **Cleanup → Quad Remesh → LODs → Bake → Export**

## Install
Edit > Preferences > Add-ons > (▾ menu) Install from Disk > `Drimah-Quad-Turbo-1_0.zip` > enable it.
Panel: 3D Viewport > N key > **Quad Turbo** tab. Each module is a sub-panel; hide the ones you
don't use in the add-on Preferences.

## Modules
| Module | What it does |
|---|---|
| Cleanup | Merges duplicated vertices, removes loose geometry and degenerate faces, fixes normals, optionally fills holes |
| Quad Remesh | Quad retopology with QuadriFlow (built in) or Instant Meshes (optional). Quad count, exact count, hard edges, borders, materials, symmetry (axis + base side), pre-voxel, projection + relax |
| LODs | Generates LOD1–LOD4 with your ratios, symmetry option, re-joined quads. Re-running replaces the old LODs |
| Bake | Normal map (tangent) and AO from the high poly to the low poly with Cycles. Auto UVs, auto ray distance, PNG saved, normal map plugged into the material |
| Export | Game-ready FBX for Unity, Unreal or generic. LODs named `_LOD0, _LOD1…`, single file or one per LOD, centered at origin |

The remesh result remembers its source, so **Bake** finds the high poly automatically.
The input object is never modified by Remesh, LODs, Bake or Export.

## Symmetry
Pick one axis (X, Y or Z) and the **base side** (Side + or Side -). The whole model is remeshed,
then the base side is kept, the seam is pinned to the plane and fixed to pure quads, and the base
side is mirrored with a welded seam. The input does not need to be symmetrical: the base side wins.
The plane goes through the object origin, so the origin must be inside the model
(Object > Set Origin) — otherwise an error explains it.

## Instant Meshes (optional)
Put the executable in the add-on's `bin/` folder (see `bin/README.txt`) or set its path in the
Preferences. Nothing is downloaded automatically.

## License
GPL-3.0-or-later (see LICENSE.txt).
