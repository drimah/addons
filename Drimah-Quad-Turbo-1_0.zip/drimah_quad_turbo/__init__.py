# Drimah Quad Turbo
# All-in-one quad retopology toolkit for Blender (Windows and Linux in the same package):
#   Cleanup -> Remesh -> LODs -> Bake -> Export
# Remesh engines: QuadriFlow (built into Blender) and Instant Meshes (optional, user-supplied).
#
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This program is free software: you can redistribute it and/or modify it under the terms
# of the GNU General Public License, version 3 or later. See LICENSE.txt.

bl_info = {
    "name": "Drimah Quad Turbo",
    "author": "Drimah",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Quad Turbo",
    "description": "Quad remesh, cleanup, LODs, normal/AO bake and game-ready FBX export",
    "category": "Mesh",
}

VERSION_TEXT = "1.0"

import bpy
from bpy.props import BoolProperty, PointerProperty, StringProperty

from . import mod_bake, mod_cleanup, mod_export, mod_lod, mod_remesh, util

MODULES = (
    ("cleanup", "Cleanup", 'BRUSH_DATA'),
    ("remesh", "Quad Remesh", 'MOD_REMESH'),
    ("lod", "LODs", 'MOD_DECIM'),
    ("bake", "Bake", 'TEXTURE'),
    ("export", "Export", 'EXPORT'),
)


class DQT_Settings(bpy.types.PropertyGroup):
    cleanup: PointerProperty(type=mod_cleanup.DQT_CleanupSettings)
    remesh: PointerProperty(type=mod_remesh.DQT_RemeshSettings)
    lod: PointerProperty(type=mod_lod.DQT_LODSettings)
    bake: PointerProperty(type=mod_bake.DQT_BakeSettings)
    export: PointerProperty(type=mod_export.DQT_ExportSettings)


class DQT_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    show_cleanup: BoolProperty(name="Cleanup", default=True)
    show_remesh: BoolProperty(name="Quad Remesh", default=True)
    show_lod: BoolProperty(name="LODs", default=True)
    show_bake: BoolProperty(name="Bake", default=True)
    show_export: BoolProperty(name="Export", default=True)
    instant_meshes_path: StringProperty(
        name="Instant Meshes Executable", subtype='FILE_PATH', default="",
        description=("Optional. Windows: 'Instant Meshes.exe'. Linux: 'Instant Meshes' binary.\n"
                     "Also detected automatically when placed in the add-on's 'bin' folder"))

    def draw(self, context):
        lay = self.layout
        box = lay.box()
        box.label(text="Modules shown in the panel")
        row = box.row(align=True)
        for key, label, icon in MODULES:
            row.prop(self, "show_" + key, text=label, toggle=True, icon=icon)
        box = lay.box()
        box.label(text="Remesh engine")
        box.prop(self, "instant_meshes_path")
        from . import engines
        found = engines.find_instant_meshes(self.instant_meshes_path)
        box.label(text=("Found: " + found) if found else "Instant Meshes not found (optional)",
                  icon='CHECKMARK' if found else 'INFO')
        box.label(text="QuadriFlow is built into Blender and works with nothing extra.")


def _prefs(context):
    try:
        return context.preferences.addons[__package__].preferences
    except Exception:
        return None


def _shown(context, key):
    pr = _prefs(context)
    return True if pr is None else getattr(pr, "show_" + key)


# ------------------------------------------------------------------ panels
class DQT_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Quad Turbo"
    bl_label = "Drimah Quad Turbo " + VERSION_TEXT

    def draw(self, context):
        lay = self.layout
        o = context.active_object
        if o is None or o.type != 'MESH':
            lay.label(text="Select a mesh object", icon='INFO')
            return
        me = o.data
        lay.label(text="%s  —  %d verts, %d faces" % (o.name, len(me.vertices), len(me.polygons)),
                  icon='OBJECT_DATA')
        if o.get("drimah_qt_source"):
            lay.label(text="Remeshed from: " + o["drimah_qt_source"], icon='LINKED')


class _Sub:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Quad Turbo"
    bl_parent_id = "DQT_PT_main"
    key = ""

    @classmethod
    def poll(cls, context):
        return _shown(context, cls.key)


class DQT_PT_cleanup(_Sub, bpy.types.Panel):
    bl_label = "Cleanup"
    bl_options = {'DEFAULT_CLOSED'}
    key = "cleanup"

    def draw_header(self, context):
        self.layout.label(icon='BRUSH_DATA')

    def draw(self, context):
        p = context.scene.drimah_qt.cleanup
        lay = self.layout
        col = lay.column(align=True)
        col.prop(p, "merge_distance")
        col.prop(p, "delete_loose")
        col.prop(p, "dissolve_degenerate")
        col.prop(p, "recalc_normals")
        col.prop(p, "fill_holes")
        col.prop(p, "work_on_copy")
        lay.operator("drimah_qt.cleanup", icon='BRUSH_DATA')


class DQT_PT_remesh(_Sub, bpy.types.Panel):
    bl_label = "Quad Remesh"
    key = "remesh"

    def draw_header(self, context):
        self.layout.label(icon='MOD_REMESH')

    def draw(self, context):
        p = context.scene.drimah_qt.remesh
        lay = self.layout
        row = lay.row()
        row.scale_y = 1.6
        row.operator("drimah_qt.remesh", icon='MOD_REMESH')

        col = lay.column(align=True)
        col.prop(p, "engine", text="")
        col.prop(p, "target_count")

        box = lay.box()
        box.label(text="Quad Size Settings")
        box.prop(p, "adapt_quad_count")
        if p.engine == 'QUADRIFLOW':
            box.prop(p, "seed")
        else:
            box.prop(p, "im_smooth")

        box = lay.box()
        box.label(text="Edge Loops Control")
        box.prop(p, "hard_edges")
        if p.engine == 'INSTANT_MESHES' and p.hard_edges:
            box.prop(p, "crease_angle")
        box.prop(p, "preserve_boundary")
        box.prop(p, "use_materials")
        box.operator("drimah_qt.facesets_to_materials", icon='MATERIAL')

        box = lay.box()
        box.label(text="Symmetry", icon='MOD_MIRROR')
        box.row(align=True).prop(p, "symmetry", expand=True)
        if p.symmetry != 'NONE':
            box.row(align=True).prop(p, "symmetry_side", expand=True)

        box = lay.box()
        box.label(text="Misc")
        box.prop(p, "pre_voxel")
        box.prop(p, "project")
        sub = box.row()
        sub.enabled = p.project
        sub.prop(p, "relax_iterations")
        box.prop(p, "hide_input")
        box.operator("drimah_qt.remesh_reset", icon='LOOP_BACK')


class DQT_PT_lod(_Sub, bpy.types.Panel):
    bl_label = "LODs"
    bl_options = {'DEFAULT_CLOSED'}
    key = "lod"

    def draw_header(self, context):
        self.layout.label(icon='MOD_DECIM')

    def draw(self, context):
        p = context.scene.drimah_qt.lod
        lay = self.layout
        lay.prop(p, "levels")
        col = lay.column(align=True)
        for i in range(1, p.levels + 1):
            col.prop(p, "ratio_%d" % i)
        row = lay.row(align=True)
        row.prop(p, "use_symmetry")
        sub = row.row(align=True)
        sub.enabled = p.use_symmetry
        sub.prop(p, "symmetry_axis", expand=True)
        lay.prop(p, "keep_quads")
        lay.prop(p, "hide_lods")
        lay.operator("drimah_qt.generate_lods", icon='MOD_DECIM')
        o = context.active_object
        lods = util.lods_of(o) if o else []
        if lods:
            row = lay.row(align=True)
            row.operator("drimah_qt.toggle_lods", icon='HIDE_OFF')
            row.operator("drimah_qt.delete_lods", icon='TRASH')
            lay.label(text="%d LOD(s) for this object" % len(lods))


class DQT_PT_bake(_Sub, bpy.types.Panel):
    bl_label = "Bake"
    bl_options = {'DEFAULT_CLOSED'}
    key = "bake"

    def draw_header(self, context):
        self.layout.label(icon='TEXTURE')

    def draw(self, context):
        p = context.scene.drimah_qt.bake
        lay = self.layout
        lay.prop(p, "high_object")
        o = context.active_object
        if p.high_object is None and o is not None:
            src = o.get("drimah_qt_source")
            lay.label(text=("Auto: " + src) if src else "Pick a high poly object",
                      icon='CHECKMARK' if src else 'ERROR')
        lay.prop(p, "resolution")
        row = lay.row(align=True)
        row.prop(p, "bake_normal", toggle=True)
        row.prop(p, "bake_ao", toggle=True)
        if p.bake_ao:
            col = lay.column(align=True)
            col.prop(p, "ao_samples")
            col.prop(p, "ao_distance")
        lay.prop(p, "margin")
        lay.prop(p, "auto_distance")
        if not p.auto_distance:
            col = lay.column(align=True)
            col.prop(p, "extrusion")
            col.prop(p, "max_ray")
        lay.prop(p, "auto_uv")
        lay.prop(p, "connect")
        lay.prop(p, "output_dir")
        row = lay.row()
        row.scale_y = 1.3
        row.operator("drimah_qt.bake", icon='RENDER_STILL')


class DQT_PT_export(_Sub, bpy.types.Panel):
    bl_label = "Export"
    bl_options = {'DEFAULT_CLOSED'}
    key = "export"

    def draw_header(self, context):
        self.layout.label(icon='EXPORT')

    def draw(self, context):
        p = context.scene.drimah_qt.export
        lay = self.layout
        lay.prop(p, "preset")
        lay.prop(p, "include_lods")
        sub = lay.row()
        sub.enabled = p.include_lods
        sub.prop(p, "separate_files")
        lay.prop(p, "center")
        lay.prop(p, "triangulate")
        lay.prop(p, "apply_modifiers")
        lay.prop(p, "embed_textures")
        lay.prop(p, "output_dir")
        row = lay.row()
        row.scale_y = 1.3
        row.operator("drimah_qt.export_fbx", icon='EXPORT')


classes = (
    mod_cleanup.classes + mod_remesh.classes + mod_lod.classes + mod_bake.classes + mod_export.classes
    + (DQT_Settings, DQT_Preferences, DQT_PT_main, DQT_PT_cleanup, DQT_PT_remesh,
       DQT_PT_lod, DQT_PT_bake, DQT_PT_export)
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.drimah_qt = PointerProperty(type=DQT_Settings)


def unregister():
    del bpy.types.Scene.drimah_qt
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
